/* ==================================================================== */
/* === rotation-gate === */
/* ==================================================================== */
  /* Auto-landscape gate: on a small portrait screen, rotate #gameRoot (and the
     #boot splash, in lockstep) via CSS instead of showing a "please rotate"
     prompt. Runs as early as possible (before DOMContentLoaded) so layout is
     correct on first paint, and on every resize/orientationchange thereafter,
     since some mobile browsers fire resize before innerWidth/innerHeight settle
     to their final post-rotation values. */
  function __updateRotateLock(){
    var el = document.getElementById('gameRoot'); if(!el) return;
    var boot = document.getElementById('boot'); // may be null pre-DOMContentLoaded
    var w = window.innerWidth, h = window.innerHeight;
    var isPortrait = h > w;
    var shouldRotate = isPortrait && Math.min(w,h) <= 900;
    var changed = el.classList.contains('forceLandscape') !== shouldRotate;
    el.classList.toggle('forceLandscape', shouldRotate);
    if(boot) boot.classList.toggle('forceLandscape', shouldRotate);
    /* The canvas resize()/fit() listener is registered later in the page and
       can't be called directly from here; nudge it via a follow-up resize
       event once the rotated box's dimensions have actually changed, so the
       canvas re-measures against the post-rotation layout rather than a
       stale pre-rotation box. */
    if(changed) requestAnimationFrame(function(){ dispatchEvent(new Event('resize')); });
  }
  addEventListener('resize', __updateRotateLock);
  addEventListener('orientationchange', function(){ setTimeout(__updateRotateLock, 300); });
  document.addEventListener('DOMContentLoaded', __updateRotateLock);
  __updateRotateLock();


/* ==================================================================== */
/* === main-game === */
/* ==================================================================== */
"use strict";
/* --- mobile safety net: surface any uncaught error on-screen instead of a blank map --- */
(function(){
  function _banner(msg){ try{ var b=document.getElementById('_err');
    if(!b){ b=document.createElement('div'); b.id='_err';
      b.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:99999;background:#7a1c12;color:#ffeede;font:12px/1.45 ui-monospace,Menlo,monospace;padding:9px 32px 9px 9px;white-space:pre-wrap;max-height:45%;overflow:auto;box-shadow:0 -2px 10px rgba(0,0,0,.6)';
      var x=document.createElement('div'); x.textContent='\u2715'; x.style.cssText='position:absolute;top:5px;right:10px;cursor:pointer;font-weight:700;padding:4px'; x.onclick=function(){b.remove();}; b.appendChild(x);
      var p=document.createElement('div'); p.id='_errmsg'; b.appendChild(p);
      (document.body||document.documentElement).appendChild(b); }
    document.getElementById('_errmsg').textContent=msg; }catch(e){} }
  window.addEventListener('error',function(e){ _banner('\u26a0 '+((e.error&&e.error.message)||e.message||'error')+(e.lineno?(' @'+e.lineno+':'+(e.colno||'?')):'')); });
  window.addEventListener('unhandledrejection',function(e){ _banner('\u26a0 '+((e.reason&&e.reason.message)||e.reason||'promise rejection')); });
  window.__err=_banner;
})();
/* ===================================================================================
   SORUSHITI — ISOMETRIC DYNASTY.  Full port of the top-down city-sim to a 2:1 iso engine.
   Simulation logic (economy, demand, development, coverage, land value, blight, fire,
   apparitions, web3) is rendering-agnostic; every visual is drawn isometrically.
   =================================================================================== */
const TW=64, TH=32, W=68, H=68;   // world expanded ~30% (60->68) to host the frozen tundra rim
// terrain
const WATER=0,SAND=1,GRASS=2,GRASS2=3,FOREST=4,BARE=5,ROCK=6,SNOW=7;
/* ART OVERHAUL — FLOATING ISLAND IN THE VOID + SELECTIVE COLOUR (sumi-e mono terrain, vivid life).
   Single locked toggle. VOID drives: no water (sea/rivers -> black void), terrain/trees/rocks/roads
   desaturated to ink-wash, buildings/people/blossoms/fire/blood/yokai stay full colour, refined ink. */
const VOID=true;
// zone ids (cell.zone)
const ZR=1,ZC=2,ZI=3;
// civic ids (cell.civ)
const TOWN=1,FARM=2,MARKET=3,SCHOOL=4,HOSP=5,LIB=6,PARK=7,PLANT=8,VALID=9,TEMPLE=10,FIRE=11,POLICE=12;
const CLIENT=1; // ownership: 0 none, 1 you, 2+ others
const NEIGH=[[1,0],[-1,0],[0,1],[0,-1]];
// ---- farm crop cycle: stage indices + per-group crop type ----
const CROP=['rice','millet','daikon','soy','tea','eggplant'];
const FARM_STAGE_T=[12,20,40,50]; // seconds in tilled/seeded/sprout/mature before advancing (sum~2min); 'ready'(4) holds until harvest
let _farmGroups=null, _farmGroupsVer=-1; // [{id,tiles:[[x,y]..],crop}], cached by gridVersion

const cv=document.getElementById('cv'), ctx=cv.getContext('2d');
let DPR=Math.min(2,window.devicePixelRatio||1);
let VW=document.documentElement.clientWidth||window.innerWidth||360;
let VH=document.documentElement.clientHeight||window.innerHeight||640;
const cam={x:0,y:0,zoom:0.9}; const ZMIN=0.4,ZMAX=2.6;
function resize(){
  // cv.clientWidth/clientHeight reflect the canvas's own LOCAL layout box (pre-transform),
  // which is what the backing-store resolution must match. getBoundingClientRect() instead
  // reports the POST-transform on-screen box — on the rotated mobile portrait layout
  // (#gameRoot.forceLandscape) that box has width/height swapped vs. the local box, so using
  // it here sized the canvas backing store with width/height swapped, and the browser then
  // had to non-uniformly stretch that buffer to fit the actual (un-swapped) CSS box, squishing
  // everything drawn on it. clientWidth/clientHeight are unaffected by CSS transforms.
  let w=Math.round(cv.clientWidth)||document.documentElement.clientWidth||window.innerWidth||360;
  let h=Math.round(cv.clientHeight)||document.documentElement.clientHeight||window.innerHeight||640;
  VW=w; VH=h;
  DPR=Math.min(w<760?1.5:2, window.devicePixelRatio||1);
  cv.width=Math.max(1,Math.floor(w*DPR)); cv.height=Math.max(1,Math.floor(h*DPR)); }
addEventListener('resize',()=>{resize();render();});
if(window.visualViewport){ window.visualViewport.addEventListener('resize',()=>{resize();render();}); }
addEventListener('load',()=>{resize();fit();});
/* ---------- boot splash: black screen, tap to enter ---------- */
(function(){
  var bootEl=document.getElementById('boot');
  if(!bootEl) return;
  var dismissed=false;
  function dismissBoot(){
    if(dismissed) return; dismissed=true;
    bootEl.classList.add('hide');
    setTimeout(()=>{ if(bootEl&&bootEl.parentNode) bootEl.parentNode.removeChild(bootEl); resize(); fit(); },650);
  }
  bootEl.addEventListener('pointerdown',dismissBoot,{once:true});
  bootEl.addEventListener('click',dismissBoot,{once:true});
})();
addEventListener('orientationchange',()=>{ setTimeout(()=>{resize();fit();},300); });
function s2(tx,ty){ return [cam.x+(tx-ty)*(TW/2)*cam.zoom, cam.y+(tx+ty)*(TH/2)*cam.zoom]; }
function pick(mx,my){ const a=(mx-cam.x)/cam.zoom,b=(my-cam.y)/cam.zoom; return [Math.floor(a/TW+b/TH), Math.floor(b/TH-a/TW)]; }
function shade(hex,d){ if(!isFinite(d))d=0; let n=parseInt(hex.slice(1),16); if(!isFinite(n))return '#888888';
  let r=(n>>16)+d,g=((n>>8)&255)+d,b=(n&255)+d;
  r=Math.max(0,Math.min(255,r|0));g=Math.max(0,Math.min(255,g|0));b=Math.max(0,Math.min(255,b|0));
  return '#'+((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1); }
function mix(h1,h2,w){ const a=parseInt(h1.slice(1),16),b=parseInt(h2.slice(1),16); const iw=1-w;
  const r=Math.round((a>>16)*iw+(b>>16)*w), g=Math.round(((a>>8)&255)*iw+((b>>8)&255)*w), bl=Math.round((a&255)*iw+(b&255)*w);
  return '#'+((1<<24)+(r<<16)+(g<<8)+bl).toString(16).slice(1); }
function inoise(x,y){ const n=Math.sin(x*12.9898+y*78.233)*43758.5453; return n-Math.floor(n); }

/* ============================ ERAS / COSTS ============================ */
/* 9 Ages of Japan (TOKENOMICS.md) — Bad North palette evolution: serene → storm → neon.
   grade = soft full-screen colour wash per age (diorama grade). */
const ERAS=[
  {jp:'縄文',nm:'JOMON',   roof:'#6a584a',wall:'#cfc1a4',post:'#5a3d24', grade:'rgba(108,120,140,0.13)'},
  {jp:'弥生',nm:'YAYOI',   roof:'#7a6a4a',wall:'#d8caa6',post:'#6a4a2a', grade:'rgba(116,124,140,0.11)'},
  {jp:'古墳',nm:'KOFUN',   roof:'#8a6a4a',wall:'#d0bf9a',post:'#6a4630', grade:'rgba(250,238,210,0.05)'},
  {jp:'飛鳥',nm:'ASUKA',   roof:'#b5532f',wall:'#efe2c4',post:'#a83228', grade:'rgba(255,232,210,0.05)'},
  {jp:'奈良',nm:'NARA',    roof:'#3d6e8c',wall:'#efe2c4',post:'#a83228', grade:'rgba(226,236,240,0.05)'},
  {jp:'平安',nm:'HEIAN',   roof:'#4a6e7a',wall:'#f0e6cc',post:'#a83228', grade:'rgba(220,234,235,0.06)'},
  {jp:'鎌倉',nm:'KAMAKURA',roof:'#5a5066',wall:'#e2d8bf',post:'#6a3a2a', grade:'rgba(190,200,212,0.09)'},
  {jp:'室町',nm:'SENGOKU', roof:'#4a4450',wall:'#cabfa8',post:'#7a2d24', grade:'rgba(120,124,140,0.16)'},
  {jp:'量子江戸',nm:'QUANTUM EDO',roof:'#1a3a3a',wall:'#16302e',post:'#14f195', grade:'rgba(40,20,70,0.20)'},
];
// global Kami thresholds (cumulative, to REACH each age index) + per-age Kami multiplier
const KAMI_REQ =[0, 3e6, 11e6, 31e6, 81e6, 201e6, 501e6, 1201e6, 3001e6];
const KAMI_MULT=[1, 3, 2.67, 2.5, 2.5, 2.4, 2.5, 2.33, 2.57];
const STEAM_ERA=8; // electricity / power arrives only with Quantum Edo
function researchedElectric(){ return S.era>=STEAM_ERA; }

const CATALOG=[
  {id:'zr', zone:ZR, nm:'HOUSING',  cost:500,  era:0, ic:'zone'},   // Basic
  {id:'zc', zone:ZC, nm:'COMMERCE', cost:2500, era:0, ic:'zone'},   // Standard
  {id:'zi', zone:ZI, nm:'INDUSTRY', cost:3000, era:1, ic:'zone'},   // Standard
  {id:'road', road:1, nm:'ROAD',    cost:100, era:0, ic:'road'},    // infrastructure
  {id:'wire', wire:1, nm:'POWER LN', cost:100, era:8, ic:'wire'},   // infrastructure
  {id:'farm', civ:FARM,   nm:'FARM',    cost:600,   era:0, ic:'civ'},  // Basic
  {id:'market',civ:MARKET,nm:'MARKET',  cost:2000,  era:0, ic:'civ'},  // Standard
  {id:'fire',  civ:FIRE,  nm:'FIRE STN', cost:2500, era:1, ic:'civ'},  // Standard
  {id:'police',civ:POLICE,nm:'POLICE',  cost:2800,  era:1, ic:'civ'},  // Standard
  {id:'school',civ:SCHOOL,nm:'SCHOOL',  cost:10000, era:1, ic:'civ'},  // Advanced
  {id:'hosp', civ:HOSP,   nm:'HOSPITAL',cost:14000, era:2, ic:'civ'},  // Advanced
  {id:'lib',  civ:LIB,    nm:'LIBRARY', cost:10000, era:2, ic:'civ'},  // Advanced
  {id:'park', civ:PARK,   nm:'PARK',    cost:700,   era:0, ic:'civ'},  // Basic
  {id:'temple',civ:TEMPLE,nm:'TEMPLE',  cost:16000, era:3, ic:'civ'},  // Advanced prestige
  {id:'plant',civ:PLANT,  nm:'POWER',   cost:40000, era:8, ic:'civ'},  // High-tier
  {id:'valid',civ:VALID,  nm:'VALIDATOR',cost:80000,era:8, ic:'civ'},  // Wonder
];
const CIVIC_NAME={[TOWN]:'TOWN',[FARM]:'FARM',[MARKET]:'MARKET',[SCHOOL]:'SCHOOL',[HOSP]:'HOSPITAL',[LIB]:'LIBRARY',[PARK]:'PARK',[PLANT]:'POWER',[VALID]:'VALIDATOR',[TEMPLE]:'TEMPLE',[FIRE]:'FIRE STN',[POLICE]:'POLICE'};
const SVC_R=6, PARK_R=3, FIRE_R=5, POLICE_R=6, SHRINE_R=7;

/* ===== ECONOMY TUNING (single place to balance) =====
   SOL creator rewards are paid from a shared global pool and split by CURRENT
   ownership share: your cut = POOL * (yourProperty / allProperty). Own 100% of
   the island's standing property -> you receive ~100% of the pool.            */
const SOL_POOL_BASE   = 0.03;    // baseline SOL/turn split across ALL owners by share
const SOL_POOL_GROWTH = 0.0012;  // pool grows with total standing property (creator-fee proxy)
const VAL_WEIGHT      = 5;       // a Validator counts as 5 standing plots of property
/* Kami = EXACTLY the total $SORU ever burned (1:1, no simulation). Ages turn
   only when the island's collective burn reaches the KAMI_REQ thresholds.     */
const DEV_SIMULATE_KAMI = false; // dev/test only: fakes other players' burn so ages advance solo. SHIP AS false.
const DEV_ERA_SWITCH    = true;  // dev/test only: manual era-jump panel for curating look/style. SHIP AS false.

/* ============================ STATE ============================ */
const S={ era:0, pop:0, cap:0, jobs:0, comJobs:0, indJobs:0,
  netTurn:0, solShare:0, demand:{R:0.5,C:0.3,I:0.2}, healthPct:0, eduPct:0, safetyPct:1, electricity:false,
  powerCap:0, powerUse:0, turn:0, kami:0, burned:0, recentBurn:0,
  wallet:{sol:5.0, soru:60000}, dex:{sol:80, soru:600000}, // $SORU is THE spend currency; SOL = premium/creator-reward rail
  tool:null, overlay:false, hand:false, douse:false, demo:false, pillage:false, arson:false };

/* ============================ ENVIRONMENT: DAY-NIGHT + WEATHER ============================ */
const CYCLE=200; // seconds per full day
const ENV={ t:0.32, night:0, weather:'clear', target:'clear', wT:0, wTimer:24, rain:[], snow:[], lightning:0, auto:true };
// sky keyframes [t, topColor, botColor, nightFactor]
const SKYK=[
  [0.00,'#0a1230','#10202c',1.0],[0.16,'#2a3a64','#7a5648',0.55],[0.24,'#6f93c4','#d8b074',0.12],
  [0.40,'#a9b8bd','#c6bca6',0.0],[0.62,'#a6b4ba','#c2b8a2',0.0],[0.76,'#c0875a','#7a4a3a',0.18],
  [0.86,'#5a4a72','#3a2c4a',0.6],[1.00,'#0a1230','#10202c',1.0]];
function lerpC(a,b,f){ const pa=parseInt(a.slice(1),16),pb=parseInt(b.slice(1),16);
  const r=Math.round(((pa>>16)&255)+(((pb>>16)&255)-((pa>>16)&255))*f), g=Math.round(((pa>>8)&255)+(((pb>>8)&255)-((pa>>8)&255))*f), bl=Math.round((pa&255)+((pb&255)-(pa&255))*f);
  return 'rgb('+r+','+g+','+bl+')'; }
function skyNow(){ const t=ENV.t; let i=0; for(;i<SKYK.length-1;i++)if(t>=SKYK[i][0]&&t<SKYK[i+1][0])break;
  const a=SKYK[i],b=SKYK[i+1],f=(t-a[0])/(b[0]-a[0]||1);
  return {top:lerpC(a[1],b[1],f),bot:lerpC(a[2],b[2],f),night:a[3]+(b[3]-a[3])*f}; }
function updateEnv(dt){ const pt=ENV.t; if(ENV.auto)ENV.t=(ENV.t+dt/CYCLE)%1; if(ENV.t<pt){S.day=(S.day||0)+1; if(typeof updateMystic==='function')updateMystic();} ENV.night=skyNow().night;
  // weather scheduling
  ENV.wTimer-=dt; if(ENV.wTimer<=0){ const opts= S.era<=4?['clear','clear','rain','fog']:['clear','clear','rain','snow','fog'];
    ENV.target=opts[(Math.random()*opts.length)|0]; ENV.wTimer=26+Math.random()*40; }
  const tgt=ENV.target==='clear'?0:1; ENV.wT+= (tgt-ENV.wT)*Math.min(1,dt*0.4); if(ENV.weather!=='clear'&&ENV.target==='clear'&&ENV.wT<0.04)ENV.weather='clear'; if(ENV.target!=='clear')ENV.weather=ENV.target;
  // particles in screen space
  const heavy=ENV.weather==='rain'?Math.round(ENV.wT*140):ENV.weather==='snow'?Math.round(ENV.wT*90):0;
  if(ENV.weather==='rain'){ while(ENV.rain.length<heavy)ENV.rain.push({x:Math.random()*VW,y:Math.random()*VH,v:520+Math.random()*260});
    if(ENV.rain.length>heavy)ENV.rain.length=heavy;
    for(const d of ENV.rain){ d.y+=d.v*dt; d.x+=d.v*0.28*dt; if(d.y>VH){d.y=-10;d.x=Math.random()*VW*1.3-VW*0.15;} }
    if(Math.random()<0.004)ENV.lightning=1; } else ENV.rain.length=0;
  if(ENV.weather==='snow'){ while(ENV.snow.length<heavy)ENV.snow.push({x:Math.random()*VW,y:Math.random()*VH,v:30+Math.random()*40,ph:Math.random()*6,r:1.2+Math.random()*1.8});
    if(ENV.snow.length>heavy)ENV.snow.length=heavy;
    for(const d of ENV.snow){ d.ph+=dt*2; d.y+=d.v*dt; d.x+=Math.sin(d.ph)*14*dt; if(d.y>VH){d.y=-6;d.x=Math.random()*VW;} } } else ENV.snow.length=0;
  if(ENV.lightning>0)ENV.lightning=Math.max(0,ENV.lightning-dt*3); }
function weatherGfxDisabled(){ return optGet('opt_noWeather',false); }
function drawWeatherFX(){ if(weatherGfxDisabled())return; const z=cam.zoom;
  // night tint
  if(ENV.night>0.04){ ctx.fillStyle='rgba(18,26,54,'+(ENV.night*0.42)+')'; ctx.fillRect(0,0,VW,VH); }
  // fog
  if(ENV.weather==='fog'){ ctx.fillStyle='rgba(200,205,210,'+(ENV.wT*0.42)+')'; ctx.fillRect(0,0,VW,VH); }
  // rain
  if(ENV.rain.length){ ctx.strokeStyle='rgba(170,190,225,0.45)'; ctx.lineWidth=1.1;
    ctx.beginPath(); for(const d of ENV.rain){ ctx.moveTo(d.x,d.y); ctx.lineTo(d.x-4,d.y+11); } ctx.stroke();
    if(ENV.lightning>0.5){ ctx.fillStyle='rgba(255,255,255,'+(ENV.lightning*0.35)+')'; ctx.fillRect(0,0,VW,VH); } }
  // snow
  if(ENV.snow.length){ ctx.fillStyle='rgba(255,255,255,0.85)'; for(const d of ENV.snow){ ctx.beginPath(); ctx.arc(d.x,d.y,d.r,0,7); ctx.fill(); } }
}
function drawCelestial(){ const z=cam.zoom; // sun by day, moon by night across the sky arc
  const ang=(ENV.t-0.25)*Math.PI*2; const sx=VW*0.5+Math.cos(ang)*VW*0.42, sy=VH*0.46+Math.sin(ang)*VH*0.5;
  if(sy>VH*0.95)return;
  if(ENV.night>0.5){ ctx.fillStyle='rgba(238,240,225,0.95)'; ctx.beginPath();ctx.arc(sx,sy,15,0,7);ctx.fill();
    ctx.fillStyle=skyNow().top; ctx.beginPath();ctx.arc(sx+6,sy-4,13,0,7);ctx.fill(); // crescent
    ctx.fillStyle='rgba(255,255,255,0.8)'; for(let i=0;i<26;i++){const rx=(i*89%VW),ry=(i*53%(VH*0.4));ctx.fillRect(rx,ry,1.4,1.4);} }
  else { const gr=ctx.createRadialGradient(sx,sy,4,sx,sy,42); gr.addColorStop(0,'rgba(255,244,200,0.95)');gr.addColorStop(1,'rgba(255,230,140,0)');
    ctx.fillStyle=gr; ctx.beginPath();ctx.arc(sx,sy,42,0,7);ctx.fill(); ctx.fillStyle='#fff2c4'; ctx.beginPath();ctx.arc(sx,sy,15,0,7);ctx.fill(); } }

/* ============================ MAP ============================ */
const grid=[];
function carveRiver(elevG){ let sx=W>>1, sy=H>>1, best=-1;
  for(let y=(H*0.32)|0;y<H*0.68;y++)for(let x=(W*0.32)|0;x<W*0.68;x++){ if(elevG[y][x]>best&&grid[y][x].ter!==WATER&&grid[y][x].ter!==SNOW){best=elevG[y][x];sx=x;sy=y;} }
  let x=sx,y=sy,steps=0;
  while(steps++<W){ const c=grid[y][x]; if(c.ter===WATER)break; c.ter=WATER; c.h=0; c.coast=true;
    if(Math.random()<0.4){const[dx,dy]=NEIGH[(Math.random()*4)|0]; const ax=x+dx,ay=y+dy; if(inB(ax,ay)&&grid[ay][ax].ter!==WATER&&grid[ay][ax].ter!==SNOW){grid[ay][ax].ter=WATER;grid[ay][ax].h=0;grid[ay][ax].coast=true;}}
    let bx=x,by=y,bl=elevG[y][x];
    for(const[dx,dy]of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1],[1,-1],[-1,1]]){const ax=x+dx,ay=y+dy; if(inB(ax,ay)&&elevG[ay][ax]<bl){bl=elevG[ay][ax];bx=ax;by=ay;}}
    if(bx===x&&by===y)break; x=bx;y=by; }
}
/* VOID perimeter cleanup: keep the main landmass whole + a few chunky satellites for that
   ancient-floating feel; dissolve the rest of the speckled debris back into the void so the
   silhouette reads clean and intentional rather than cluttered. */
function cleanPerimeter(){
  const lab=Array.from({length:H},()=>new Int16Array(W).fill(-1)), comps=[];
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
    if(grid[y][x].ter===WATER||lab[y][x]!==-1)continue;
    const id=comps.length, tiles=[], stk=[[x,y]]; lab[y][x]=id;
    while(stk.length){ const[cx,cy]=stk.pop(); tiles.push([cx,cy]);
      for(const[dx,dy]of NEIGH){ const ax=cx+dx,ay=cy+dy;
        if(inB(ax,ay)&&grid[ay][ax].ter!==WATER&&lab[ay][ax]===-1){ lab[ay][ax]=id; stk.push([ax,ay]); } } }
    comps.push({size:tiles.length,tiles});
  }
  if(comps.length<=1)return;
  comps.sort((a,b)=>b.size-a.size);                       // [0] = the main island (kept whole)
  // main landmass centroid + reach, used to reject debris that sits right against its shore
  // (that's what reads as messy stray islets) while still allowing a couple of genuinely
  // distant satellites further out in the void for the floating-diorama feel.
  let mcx=0,mcy=0; for(const[x,y]of comps[0].tiles){mcx+=x;mcy+=y;} mcx/=comps[0].size; mcy/=comps[0].size;
  let mainR=0; for(const[x,y]of comps[0].tiles){ const d=Math.hypot(x-mcx,y-mcy); if(d>mainR)mainR=d; }
  const KEEP=0, MINK=1e9, MAXK=1e9; let kept=0;
  for(let i=1;i<comps.length;i++){ const c=comps[i]; let keep=false;
    let ccx=0,ccy=0; for(const[x,y]of c.tiles){ccx+=x;ccy+=y;} ccx/=c.size; ccy/=c.size;
    const distOut=Math.hypot(ccx-mcx,ccy-mcy)-mainR;        // how far beyond the main shore this chunk sits
    // ALL detached land masses dissolved — only the single main island survives in the void
    if(keep)continue;
    for(const[x,y]of c.tiles){ const cc=grid[y][x]; cc.ter=WATER; cc.h=0; cc.spirit=0; cc.frozen=0; cc.tundra=0;
      cc.coast=false; cc.shore=false; cc.road=0; cc.wire=0; cc.zone=0; cc.civ=0; }   // dissolve to void
  }
}
/* subtle, zen spirit-water: a small still pond fed by a thin meandering river. Marked spirit=1
   so the renderer paints it as dreamy cool mist-water rather than black void or turquoise sea. */
function carveSpiritWater(elevG){
  const usable=(x,y)=>inB(x,y)&&grid[y][x].ter!==WATER&&grid[y][x].ter!==ROCK&&grid[y][x].ter!==SNOW;
  const wet=(x,y)=>{ const c=grid[y][x]; c.ter=WATER; c.spirit=1; c.frozen=0; c.h=0; };
  const cxw=W>>1, cyw=H>>1;
  // --- LAKE: a larger, peaceful body near the centre / starting area (seeded just south of centre
  //     so the town settles on its dry northern shore) ---
  let lx=cxw, ly=cyw+2, lo=1e9;
  for(let y=cyw-2;y<=cyw+6;y++)for(let x=cxw-5;x<=cxw+5;x++){ if(usable(x,y)&&elevG[y][x]<lo){lo=elevG[y][x];lx=x;ly=y;} }
  if(!usable(lx,ly)){ for(let y=4;y<H-4;y++)for(let x=4;x<W-4;x++){ if(usable(x,y)&&elevG[y][x]<lo){lo=elevG[y][x];lx=x;ly=y;} } }
  const LAKE=26, lake=[], seen=new Set(), pq=[[lx,ly]]; seen.add(lx+','+ly);
  while(pq.length&&lake.length<LAKE){                              // grow a rounded lake, biased low + compact
    pq.sort((a,b)=>(elevG[a[1]][a[0]]+(Math.abs(a[0]-lx)+Math.abs(a[1]-ly))*0.03)
                  -(elevG[b[1]][b[0]]+(Math.abs(b[0]-lx)+Math.abs(b[1]-ly))*0.03));
    const[cx,cy]=pq.shift(); if(!usable(cx,cy))continue; lake.push([cx,cy]);
    for(const[dx,dy]of NEIGH){ const ax=cx+dx,ay=cy+dy,k=ax+','+ay;
      if(usable(ax,ay)&&!seen.has(k)&&Math.abs(ax-lx)+Math.abs(ay-ly)<=4){ seen.add(k); pq.push([ax,ay]); } } }
  if(!lake.length)return; for(const[x,y]of lake) wet(x,y);
  // --- RIVER: leave the lake's bottom-right rim and wind toward the FRONT (bottom) edge of the
  //     island, then freeze where it meets the void — a surreal glacial waterfall into the abyss. ---
  let rx=lx,ry=ly,bestRim=-1e9; for(const[x,y]of lake){ if(x+y>bestRim){bestRim=x+y;rx=x;ry=y;} }
  const tgt=[Math.min(W-1, lx+(W>>1)), Math.min(H-1, ly+(H>>1))];   // head toward the +x,+y (front) border
  const D8=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1],[1,-1],[-1,1]];
  const atVoid=(x,y)=>{ for(const[dx,dy]of [[1,0],[0,1]]){ const ax=x+dx,ay=y+dy;     // a front face opens to the void?
    if(!inB(ax,ay)||(grid[ay][ax].ter===WATER&&!grid[ay][ax].spirit&&!grid[ay][ax].frozen)) return true; } return false; };
  let x=rx,y=ry,steps=0; const path=[], maxS=W+H;
  while(steps++<maxS){
    if(usable(x,y)){ wet(x,y); path.push([x,y]);
      if(inoise(x*3.7,y*2.3)>0.84){ const[wx,wy]=D8[(inoise(x,y)*8)|0]; if(usable(x+wx,y+wy))wet(x+wx,y+wy); } }  // rare widening
    if(atVoid(x,y)) break;                                          // reached the abyss -> stop
    const hx=tgt[0]-x, hy=tgt[1]-y, mag=Math.hypot(hx,hy)||1, wob=(inoise(x*0.6+9,y*0.6+3)*2-1);
    let bx=x,by=y,best=-1e9;                                        // step toward target + a noise meander
    for(const[dx,dy]of D8){ const ax=x+dx,ay=y+dy; if(!usable(ax,ay))continue;
      const align=(dx*hx+dy*hy)/mag, perp=(dx*(-hy)+dy*hx)/mag;
      const score=align*1.0 + perp*wob*0.85 - elevG[ay][ax]*0.18;
      if(score>best){best=score;bx=ax;by=ay;} }
    if(bx===x&&by===y) break; x=bx;y=by;
  }
  // FREEZE the river's final stretch into glacial ice (the dramatic frozen terminus)
  if(path.length && atVoid(path[path.length-1][0],path[path.length-1][1])){
    for(let i=Math.max(0,path.length-3);i<path.length;i++){ const[fx,fy]=path[i]; const c=grid[fy][fx]; c.frozen=1; c.spirit=0; }
  }
  // heal: any tiny land sliver the winding river pinched off blends back into the flowing stream
  { const lab=Array.from({length:H},()=>new Int16Array(W).fill(-1)), comps=[];
    for(let yy=0;yy<H;yy++)for(let xx=0;xx<W;xx++){ if(grid[yy][xx].ter===WATER||lab[yy][xx]!==-1)continue;
      const id=comps.length,tiles=[],stk=[[xx,yy]]; lab[yy][xx]=id;
      while(stk.length){ const[ax,ay]=stk.pop(); tiles.push([ax,ay]);
        for(const[dx,dy]of NEIGH){ const bx=ax+dx,by=ay+dy;
          if(inB(bx,by)&&grid[by][bx].ter!==WATER&&lab[by][bx]===-1){ lab[by][bx]=id; stk.push([bx,by]); } } }
      comps.push(tiles); }
    if(comps.length>1){ comps.sort((a,b)=>b.length-a.length);
      for(let i=1;i<comps.length;i++){ if(comps[i].length<3) for(const[ax,ay]of comps[i]) wet(ax,ay); } }   // <3 = river-orphaned, not a kept satellite
  }
}
function genMap(){ grid.length=0;
  const cxw=W/2, cyw=H/2, maxR=30;   // core radius PINNED (was min(W,H)/2): the living heart stays its
                                     // original size; the extra grid becomes the frozen tundra rim.
  const elevG=[];
  for(let y=0;y<H;y++){ const er=[]; for(let x=0;x<W;x++){
    const nx=(x-cxw)/maxR, ny=(y-cyw)/maxR, dist=Math.sqrt(nx*nx+ny*ny);
    const fbm = 0.5*(inoise(x*0.09,y*0.09)*2-1)+0.28*(inoise(x*0.20+5,y*0.20+9)*2-1)+0.16*(inoise(x*0.42+3,y*0.42+1)*2-1);
    let elev = 0.92 - dist*1.05 + fbm*0.45;
    const border=Math.min(x,y,W-1-x,H-1-y); if(border<3)elev-=(3-border)*0.7;
    er.push(elev);
  } elevG.push(er); }
  for(let y=0;y<H;y++){ const row=[]; for(let x=0;x<W;x++){
    const e=elevG[y][x]; let ter, h=0, tnd=0;
    if(e<0.03){
      // beyond the warm coast: grow a ragged FROZEN TUNDRA ring into the void band before the abyss
      const nx=(x-cxw)/maxR, ny=(y-cyw)/maxR;
      // FINAL OUTER-RIM OVERHAUL — domain-warped fracture (not additive octaves stacked on a
      // circle). The sample point itself is bent sideways by independent low-freq noise BEFORE
      // any ring distance or coverage is evaluated, so the broken edge can no longer be traced
      // back to a clean circle/diamond grid at all — bays and peninsulas warp clean across what
      // would have been ring-symmetric noise, killing the "wobbly circle" read completely.
      const warpAmt=0.34;
      const wx=nx + warpAmt*(inoise(x*0.05+101,y*0.05+57)*2-1);
      const wy=ny + warpAmt*(inoise(x*0.05+13, y*0.05+89)*2-1);
      const dn=Math.hypot(wx,wy);
      // multi-octave fracture noise, now sampled in WARPED space — broad ragged bays + frozen
      // peninsulas with no residual ring symmetry, reading as a shattered, torn coastline at
      // any zoom, including fully zoomed out.
      const tn=0.46*(inoise(wx*7+31,wy*7+17)*2-1)+0.30*(inoise(wx*16+5,wy*16+23)*2-1)+0.20*(inoise(wx*34+11,wy*34+3)*2-1)+0.30*(inoise(wx*78+61,wy*78+47)*2-1)+0.18*(inoise(wx*160+9,wy*160+29)*2-1);
      const cov=0.50*inoise(wx*9+41,wy*9+29)+0.28*inoise(wx*21+7,wy*21+19)+0.14*inoise(wx*55+83,wy*55+71)+0.18*inoise(wx*140+19,wy*140+5);   // four-octave coverage incl. a sharp tap -> coherent ragged bays AND dense scattered void-holes right at the broken edge
      const reach=dn - tn*0.70;   // amplitude raised again 0.52->0.70: rim front swings violently tile-to-tile, no two neighbouring bays read the same depth
      // hard per-tile dissolve noise: even inside the "land" band, a fraction of tiles are torn
      // straight out to void — the rim doesn't end on a clean front, it disintegrates into it.
      const tear=inoise(x*0.9+205,y*0.9+77);
      const farTear = Math.max(0,(dn-0.78))*1.8;   // tear probability grows the further out you are
      if(dn>0.74 && reach<1.10 && cov>0.36 && tear>farTear*0.55){ tnd=1;
        // LOW-FREQUENCY patch noise (period ~6 tiles) plus a coarser drift-band tap so rock/snow/
        // bare ground forms large coherent broken plates, not a speckle — reads as fractured
        // permafrost slabs from a distance instead of static.
        const rr=0.5*inoise(x*0.16+7,y*0.16+13)+0.32*inoise(x*0.07+71,y*0.07+53)+0.18*inoise(x*0.035+19,y*0.035+61);
        ter=(rr<0.13?ROCK:(rr<0.24?SNOW:BARE)); h=0.04+rr*0.20; }  // barren: bare ice-ground, rock/snow in large coherent drifts
      else ter=WATER;
    }
    else { h=Math.max(0,Math.min(1,(e-0.03)/1.25));
      let coastal=false; for(const[dx,dy]of NEIGH){const ax=x+dx,ay=y+dy; if(ax<0||ay<0||ax>=W||ay>=H||elevG[ay][ax]<0.03){coastal=true;break;}}
      if(coastal&&h<0.17) ter=SAND;
      else { const r=inoise(x*0.5+9,y*0.5+2); ter=(r<0.105?FOREST:(r<0.45?GRASS2:GRASS)); }   // forest threshold lowered ~25% (0.14->0.105) per tree-count reduction pass
    }
    row.push({ter,h,tundra:tnd,coast:false,shore:false,spirit:0,frozen:0,road:0,wire:0,br:0,zone:0,civ:0,dev:0,own:0,blight:0,ruin:0,burn:0,seed:inoise(x*2.1,y*1.7)});
  } grid.push(row); }
  if(VOID){ // FLOATING-ISLAND SOLIDITY: flood the OUTER sea inward from the map borders; any water it
            // can't reach is an enclosed pond -> convert to land so the island has no void holes punched in it.
    const sea=Array.from({length:H},()=>new Uint8Array(W)), st=[];
    for(let x=0;x<W;x++){ if(grid[0][x].ter===WATER){sea[0][x]=1;st.push([x,0]);} if(grid[H-1][x].ter===WATER){sea[H-1][x]=1;st.push([x,H-1]);} }
    for(let y=0;y<H;y++){ if(grid[y][0].ter===WATER){sea[y][0]=1;st.push([0,y]);} if(grid[y][W-1].ter===WATER){sea[y][W-1]=1;st.push([W-1,y]);} }
    while(st.length){ const[x,y]=st.pop(); for(const[dx,dy]of NEIGH){ const ax=x+dx,ay=y+dy;
      if(inB(ax,ay)&&!sea[ay][ax]&&grid[ay][ax].ter===WATER){ sea[ay][ax]=1; st.push([ax,ay]); } } }
    for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const c=grid[y][x]; if(c.ter!==WATER||sea[y][x])continue;
      c.h=Math.max(c.h,0.06);
      const nx2=(x-cxw)/maxR, ny2=(y-cyw)/maxR;
      const wx2=nx2+0.34*(inoise(x*0.05+101,y*0.05+57)*2-1), wy2=ny2+0.34*(inoise(x*0.05+13,y*0.05+89)*2-1);
      const dn=Math.hypot(wx2,wy2);   // warped, matching the outer-rim fracture so pockets read as part of the same shattered field, not a separate clean ring
      if(dn>0.82){ const rr=0.5*inoise(x*0.16+7,y*0.16+13)+0.32*inoise(x*0.07+71,y*0.07+53)+0.18*inoise(x*0.035+19,y*0.035+61); c.ter=(rr<0.14?ROCK:BARE); c.tundra=1; }   // pockets in the rim stay frozen, coherent drift patches
      else { const r=inoise(x*0.5+9,y*0.5+2); c.ter=(r<0.105?FOREST:(r<0.45?GRASS2:GRASS)); } } }   // matches lowered forest threshold above
  if(VOID){ cleanPerimeter(); carveSpiritWater(elevG); }   // cull stray floating debris, then add subtle river + pond
  if(VOID){ // NO COLD RIM: dissolve the old frozen-tundra ring into ordinary land so the island
            // reads as ONE clean uniform landmass — the painted shoreline mass alone carries the edge.
    for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const c=grid[y][x]; if(!c.tundra)continue; c.tundra=0; c.frozen=0;
      if(c.ter===ROCK||c.ter===BARE||c.ter===SNOW){ const r=inoise(x*0.5+9,y*0.5+2); c.ter=(r<0.105?FOREST:(r<0.45?GRASS2:GRASS)); } } }
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ if(grid[y][x].ter!==WATER)continue;
    for(const[dx,dy]of NEIGH){const ax=x+dx,ay=y+dy; if(inB(ax,ay)&&grid[ay][ax].ter!==WATER){grid[y][x].coast=true;break;}} }
  // land tiles that touch the sea — flagged for the painterly coastline pass
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const cc=grid[y][x]; if(cc.ter===WATER)continue;
    for(const[dx,dy]of NEIGH){const ax=x+dx,ay=y+dy; if(!inB(ax,ay)||grid[ay][ax].ter===WATER){cc.shore=true;break;}} }
  if(!VOID) carveRiver(elevG);   // VOID: no internal water channels — the island stays a solid floating mass
  // town centre on low grass near centre
  let bx=W>>1,by=H>>1; for(let i=0;i<600;i++){const x=(W>>1)+((Math.random()*12)|0)-6,y=(H>>1)+((Math.random()*12)|0)-6;
    if(grid[y]&&grid[y][x]&&grid[y][x].ter>=GRASS&&grid[y][x].ter<=FOREST&&grid[y][x].h<0.5){bx=x;by=y;break;}}
  grid[by][bx].civ=TOWN; grid[by][bx].ter=BARE;
  for(let i=-3;i<=3;i++){ const c=grid[by]&&grid[by][bx+i]; if(c&&c.ter!==WATER&&c.ter!==ROCK&&c.ter!==SNOW){c.road=1; if(c.ter===FOREST)c.ter=GRASS;} }
  // pre-smooth the base colour field across ALL tiles (water included) so the shoreline
  // blends — coastal water pulls toward sand and beaches pull toward water, killing the checkerboard.
  // WIDE KERNEL: a 1-ring blur still leaves visible facets at type boundaries (reads as blocky
  // patchwork); a 5x5 weighted kernel (center + ring1 + ring2, falloff by distance) produces a
  // genuinely continuous painterly colour field with no hard steps between terrain classes.
  const cbR=new Float32Array(W*H),cbG=new Float32Array(W*H),cbB=new Float32Array(W*H);
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const own=parseInt(terBaseColor(grid[y][x].ter).slice(1),16);
    cbR[y*W+x]=own>>16; cbG[y*W+x]=(own>>8)&255; cbB[y*W+x]=own&255; }
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ let rs=0,gs=0,bs=0,ws=0;
    for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){ const ax=x+dx,ay=y+dy; if(!inB(ax,ay))continue;
      const wgt=1/(1+dx*dx+dy*dy); const i=ay*W+ax;
      rs+=cbR[i]*wgt; gs+=cbG[i]*wgt; bs+=cbB[i]*wgt; ws+=wgt; }
    const r=Math.round(rs/ws),g2=Math.round(gs/ws),b=Math.round(bs/ws);
    grid[y][x].cbase='#'+((1<<24)+(r<<16)+(g2<<8)+b).toString(16).slice(1);
  }
}
function mountain(c){ return c.ter===ROCK||c.ter===SNOW; }
function isPeak(x,y){ const h=grid[y][x].h; if(h<0.66)return false; for(const[dx,dy]of NEIGH){const ax=x+dx,ay=y+dy; if(inB(ax,ay)&&grid[ay][ax].h>h)return false;} return true; }
function inB(x,y){ return x>=0&&x<W&&y>=0&&y<H; }
function isLand(x,y){ return inB(x,y)&&grid[y][x].ter!==WATER; }
function occupied(c){ return c.zone||c.civ||c.road||c.wire; }
function roadAdj(x,y){ for(const[dx,dy]of NEIGH){const nx=x+dx,ny=y+dy; if(inB(nx,ny)&&grid[ny][nx].road)return true;} return false; }
function nearRoad(x,y,r){ for(let j=-r;j<=r;j++)for(let i=-r;i<=r;i++){const nx=x+i,ny=y+j; if(inB(nx,ny)&&grid[ny][nx].road&&Math.abs(i)+Math.abs(j)<=r)return true;} return false; }

/* ============================ COVERAGE / LAND VALUE ============================ */
let healthGrid=null, eduGrid=null, parkGrid=null, valueGrid=null, fireGrid=null, policeGrid=null, crimeGrid=null, shrineGrid=null;
function stampCircle(g,x,y,r){ for(let j=-r;j<=r;j++)for(let i=-r;i<=r;i++){const nx=x+i,ny=y+j;
  if(inB(nx,ny)&&i*i+j*j<=r*r)g[ny][nx]=1; } }
function stampFalloff(g,x,y,r,peak){ for(let j=-r;j<=r;j++)for(let i=-r;i<=r;i++){const nx=x+i,ny=y+j,d2=i*i+j*j;
  if(inB(nx,ny)&&d2<=r*r){ const v=peak*(1-Math.sqrt(d2)/(r+0.6)); if(v>g[ny][nx])g[ny][nx]=v; } } }
function rebuildCoverage(){
  healthGrid=Array.from({length:H},()=>new Uint8Array(W));
  eduGrid=Array.from({length:H},()=>new Uint8Array(W));
  parkGrid=Array.from({length:H},()=>new Uint8Array(W));
  fireGrid=Array.from({length:H},()=>new Float32Array(W));     // graded: strong at the station, weaker at the edge
  policeGrid=Array.from({length:H},()=>new Uint8Array(W));
  shrineGrid=Array.from({length:H},()=>new Uint8Array(W));     // hard boundary: hallowed ground wards or it doesn't, no falloff
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const c=grid[y][x]; if(!c.civ||c.burn)continue;
    if(c.civ===HOSP)stampCircle(healthGrid,x,y,SVC_R);
    if(c.civ===SCHOOL)stampCircle(eduGrid,x,y,SVC_R);
    if(c.civ===LIB)stampCircle(eduGrid,x,y,SVC_R+1);
    if(c.civ===FIRE)stampFalloff(fireGrid,x,y,FIRE_R,0.85);
    if(c.civ===POLICE)stampCircle(policeGrid,x,y,POLICE_R);
    if(c.civ===PARK||c.civ===TEMPLE)stampCircle(parkGrid,x,y,PARK_R);
    if(c.civ===TEMPLE)stampCircle(shrineGrid,x,y,SHRINE_R); }
  // crime field — rises with residential density, falls with police, education, parks
  crimeGrid=Array.from({length:H},()=>new Float32Array(W));
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const c=grid[y][x]; if(!(c.dev>0))continue;
    let dens=0; for(let j=-1;j<=1;j++)for(let i=-1;i<=1;i++){const n=grid[y+j]&&grid[y+j][x+i]; if(n&&n.dev>0)dens+=n.dev;}
    let cr=0.10+0.035*dens; if(policeGrid[y][x])cr-=0.45; if(eduGrid[y][x])cr-=0.12; if(parkGrid[y][x])cr-=0.05;
    crimeGrid[y][x]=Math.max(0,Math.min(0.9,cr)); }
}
function qualityAt(x,y){ let q=0.4; if(healthGrid&&healthGrid[y][x])q+=0.3; if(eduGrid&&eduGrid[y][x])q+=0.2; if(parkGrid&&parkGrid[y][x])q+=0.15;
  if(crimeGrid&&crimeGrid[y][x])q-=0.25*crimeGrid[y][x];      // crime drags land value (SimCity-style)
  if(scarGrid&&scarGrid[y][x])q-=scarGrid[y][x];              // fresh street violence temporarily craters value/demand
  // industry/blight nearby drags value
  for(const[dx,dy]of NEIGH){const nx=x+dx,ny=y+dy; if(inB(nx,ny)){ const n=grid[ny][nx]; if(n.zone===ZI)q-=0.05; if(n.blight)q-=0.04*n.blight; if(n.ruin)q-=0.08; }}
  return Math.max(0,Math.min(1,q)); }
function rebuildValue(){ valueGrid=Array.from({length:H},()=>new Float32Array(W));
  for(let y=0;y<H;y++)for(let x=0;x<W;x++) valueGrid[y][x]=qualityAt(x,y); }

/* ============================ ART ============================ */
function diamondPath(g,cx,cy,z){ const hw=TW/2*z,hh=TH/2*z; g.beginPath();
  g.moveTo(cx,cy-hh);g.lineTo(cx+hw,cy);g.lineTo(cx,cy+hh);g.lineTo(cx-hw,cy);g.closePath(); }
/* Soft pooling watercolor shadow: a feathered radial that fades to nothing at the
   rim (so it reads as pigment settling on paper, never a hard dropshadow disc — and
   because the edge alpha falls to 0, the ink pass finds no hard silhouette to trace). */
function shadowEllipse(g,cx,cy,rw,z){ const R=Math.max(0.5,rw*z*0.9), oy=cy+2*z;
  g.save(); g.translate(cx,oy); g.scale(1,0.42);
  const rg=g.createRadialGradient(0,0,0,0,0,R);
  // softened: lower peak + earlier fade-out, reads as a watercolor pool settling into the
  // paper rather than a dark blob sitting on top of it
  rg.addColorStop(0,'rgba(30,24,15,0.055)'); rg.addColorStop(0.4,'rgba(30,24,15,0.026)'); rg.addColorStop(1,'rgba(30,24,15,0)');
  g.fillStyle=rg; g.beginPath(); g.arc(0,0,R,0,7); g.fill(); g.restore(); }
/* ---- LOCKED 3-LAYER PAINT PRIMITIVE (Master Spec §1) ----
   The whole painterly technique on one polygon: seeded edge-wobble silhouette + watercolor
   wash (luminous top -> pooled-pigment base) + granulation flecks + sumi-e ink contour, with
   an optional soft pooling shadow. pts = [[x,y],...].
   o = { fill, lt, dk, z, seed, wobble, wash, grain, shadow, ink, inkC, inkA, inkW, alpha } */
function paintFill(g,pts,o){
  o=o||{}; const z=o.z||1, seed=o.seed||0, wob=(o.wobble!=null?o.wobble:0.9)*z, n=pts.length;
  // seeded edge wobble — each vertex nudged so the silhouette reads hand-drawn, not vector-perfect
  const P=new Array(n); let minX=1e9,minY=1e9,maxX=-1e9,maxY=-1e9;
  for(let i=0;i<n;i++){ const x=pts[i][0]+(vhash(seed,i*2+1)*2-1)*wob, y=pts[i][1]+(vhash(seed,i*2+2)*2-1)*wob;
    P[i]=[x,y]; if(x<minX)minX=x; if(x>maxX)maxX=x; if(y<minY)minY=y; if(y>maxY)maxY=y; }
  const path=()=>{ g.beginPath(); g.moveTo(P[0][0],P[0][1]); for(let i=1;i<n;i++)g.lineTo(P[i][0],P[i][1]); g.closePath(); };
  // soft pooling shadow hugging the base (gives forms weight on the paper) — feathered to nothing
  if(o.shadow){ const scx=(minX+maxX)*0.5, scy=maxY-1*z, sr=Math.max(1,(maxX-minX)*0.5);
    g.save(); g.translate(scx,scy); g.scale(1,(maxY-minY)*0.20/sr);
    const sg=g.createRadialGradient(0,0,0,0,0,sr);
    sg.addColorStop(0,'rgba(22,18,11,'+(o.shadow*0.85)+')'); sg.addColorStop(0.5,'rgba(22,18,11,'+(o.shadow*0.42)+')'); sg.addColorStop(1,'rgba(22,18,11,0)');
    g.fillStyle=sg; g.beginPath(); g.arc(0,0,sr,0,7); g.fill(); g.restore(); }
  // 1) base silhouette
  g.save(); if(o.alpha!=null)g.globalAlpha=o.alpha; path(); g.fillStyle=o.fill; g.fill(); g.globalAlpha=1;
  // 2) watercolor wash — luminous crown, pigment pools at the base
  if(o.wash!==false && o.lt && o.dk){ const gw=g.createLinearGradient(0,minY,0,maxY);
    gw.addColorStop(0,o.lt); gw.addColorStop(0.55,o.fill); gw.addColorStop(1,o.dk);
    g.globalAlpha=0.5; path(); g.fillStyle=gw; g.fill(); g.globalAlpha=1; }
  // 2b) edge-darkening bloom — pigment pools at the wash perimeter (the watercolor "tell").
  // A fat dark stroke clipped to the shape darkens only the inner rim, so washes stop reading flat.
  if(o.wash!==false && (o.dk||o.fill)){ path(); g.clip();
    g.globalAlpha=0.24; g.strokeStyle=o.dk||shade(o.fill,-26); g.lineJoin='round'; g.lineWidth=2.9*z; path(); g.stroke(); g.globalAlpha=1; }
  g.restore();
  // 3) granulation — seeded pigment-settling flecks, weighted toward the base (gravity pools pigment)
  if(o.grain!==false){ const m=o.grain||5, w=maxX-minX, h=maxY-minY; g.save(); g.fillStyle=o.dk||shade(o.fill,-22);
    for(let i=0;i<m;i++){ const gx=minX+vhash(seed,i*3+31)*w, gy=minY+h*(0.42+0.58*vhash(seed,i*3+32));
      g.globalAlpha=0.12+0.13*vhash(seed,i*3+33); g.beginPath(); g.arc(gx,gy,(0.55+0.6*vhash(seed,i*3+34))*z,0,7); g.fill(); }
    g.restore(); }
  // 4) sumi-e ink contour — the sacred silhouette line (dark, soft-jointed)
  if(o.ink!==false){ g.save(); g.strokeStyle=o.inkC||'#130e08'; g.lineJoin='round'; g.lineCap='round';
    g.globalAlpha=o.inkA!=null?o.inkA:0.85; g.lineWidth=(o.inkW||1.45)*z; path(); g.stroke(); g.restore(); }
}
/* coarse terrain class for ink-contour boundary detection: 0 void/water, 1 sand, 2 open ground,
   3 forest, 4 stone/snow. Edges between *different* classes get an expressive sumi-e contour;
   like-vs-like stays seamless so flat ground never reads as a wireframe grid. */
function terClass(k){ if(k===WATER)return 0; if(k===SAND)return 1; if(k===ROCK||k===SNOW)return 4; return 2; }
/* ---- painterly grain: shared paper-tooth texture, built once, reused by all layers ---- */
const GRAIN=document.createElement('canvas'); GRAIN.width=GRAIN.height=128;
(function(){ const gg=GRAIN.getContext('2d'); gg.fillStyle='#808080'; gg.fillRect(0,0,128,128);
  for(let i=0;i<3000;i++){ const x=(Math.random()*128)|0,y=(Math.random()*128)|0,d=((Math.random()*2-1)*42)|0,c=128+d;
    gg.fillStyle='rgb('+c+','+c+','+c+')'; gg.fillRect(x,y,1,1); } })();
let GRAINPAT=null;
/* ---- dry-brush texture: a transparent tile scattered with small specks + short streaks.
   Used via destination-out to punch organic gaps into the AGENT ink mask, so small figures
   read as fine sumi-e brushwork (broken, dry-edged) instead of a solid uniform outline. ---- */
const BRUSHTEX=document.createElement('canvas'); BRUSHTEX.width=BRUSHTEX.height=48;
(function(){ const bg=BRUSHTEX.getContext('2d'); bg.clearRect(0,0,48,48); bg.fillStyle='#000';
  for(let i=0;i<64;i++){ const x=Math.random()*48,y=Math.random()*48,r=0.3+Math.random()*1.2;
    bg.globalAlpha=0.35+Math.random()*0.5; bg.beginPath(); bg.arc(x,y,r,0,7); bg.fill(); }
  bg.strokeStyle='#000'; bg.lineWidth=0.7;                                  // short directional dry-brush streaks
  for(let i=0;i<9;i++){ const x=Math.random()*48,y=Math.random()*48,an=Math.random()*6.28,l=2+Math.random()*3;
    bg.globalAlpha=0.4+Math.random()*0.4; bg.beginPath(); bg.moveTo(x,y); bg.lineTo(x+Math.cos(an)*l,y+Math.sin(an)*l); bg.stroke(); }
})();
let BRUSHPAT=null;
/* ---- LOCKED CORE STYLE · Layer 3: global paper-grain (multiply) ----
   A near-WHITE warm-paper texture (multiply needs a light base, unlike the grey soft-light GRAIN
   above). Drawn once over the WHOLE composed frame so terrain + buildings + agents share one
   paper tooth and nothing floats — "ties everything into one painting". Kept gentle so silhouettes
   and function colours (fire, zone tints, raid markers) always stay legible. */
const PAPER=document.createElement('canvas'); PAPER.width=PAPER.height=180;
(function(){ const pg=PAPER.getContext('2d');
  pg.fillStyle='#f3efe6'; pg.fillRect(0,0,180,180);                         // warm paper base (near-white)
  for(let i=0;i<9000;i++){ const x=(Math.random()*180)|0,y=(Math.random()*180)|0; // fine pigment flecks (subtle tooth, not a veil)
    const v=226+((Math.random()*2-1)*42|0); pg.fillStyle='rgb('+v+','+(v-3)+','+(v-9)+')'; pg.fillRect(x,y,1,1); }
  pg.globalAlpha=0.06; pg.strokeStyle='#cfc6b2'; pg.lineWidth=1;            // a few long paper fibres
  for(let i=0;i<26;i++){ const y=Math.random()*180,x=Math.random()*180,w=20+Math.random()*60;
    pg.beginPath(); pg.moveTo(x,y); pg.lineTo(x+w,y+(Math.random()*2-1)); pg.stroke(); }
  pg.globalAlpha=1; })();
let PAPERPAT=null, GRAINPAT2=null;
/* ===================== PER-AGE MASTER PALETTE (Art Progression Phase 1) =====================
   Nine distinct worlds. Each age retints the terrain bases (grass/forest/ground/water/sand/tree),
   sets a painterliness factor `wet` (0..1 -> how hard the watercolor kit runs) and a war-age
   desaturation `dry`. Blend weights stay moderate so SILHOUETTES + function colours
   (fire, zone tints, service coverage) always survive the wash. Arc: serene -> golden Heian ->
   greyed Kamakura -> ash Sengoku (rock bottom) -> teal/neon Quantum rebirth. */
const AGEPAL=[
 /*0 JOMON   */ {grass:'#7d9b4d',forest:'#5a7d3e',ground:'#9a8f5a',water:'#3a5566',sand:'#bfb184',tree:'#3f5c2e', wet:1.00,dry:0.00},   // GREEN ISLAND base — natural Japanese greens (若草 young grass, 杉 cedar), shared by every age
 /*1 YAYOI   */ {grass:'#869058',forest:'#4a5a38',ground:'#9a8a5e',water:'#5a8088',sand:'#cdbc96',tree:'#46583a', wet:1.00,dry:0.00},
 /*2 KOFUN   */ {grass:'#869150',forest:'#48592f',ground:'#9c8458',water:'#4f7283',sand:'#c9b58c',tree:'#445428', wet:0.85,dry:0.00},
 /*3 ASUKA   */ {grass:'#7f9050',forest:'#46592f',ground:'#9c875c',water:'#4e7686',sand:'#cab98e',tree:'#42542a', wet:0.80,dry:0.00},
 /*4 NARA    */ {grass:'#7e9054',forest:'#45592f',ground:'#9a875c',water:'#3d6e8c',sand:'#cab98e',tree:'#41552c', wet:0.75,dry:0.00},
 /*5 HEIAN   */ {grass:'#86995a',forest:'#4a6038',ground:'#a89368',water:'#4f7a86',sand:'#d6c79a',tree:'#4a6034', wet:1.00,dry:0.00,bloom:1},
 /*6 KAMAKURA*/ {grass:'#6e7656',forest:'#42503a',ground:'#8c8068',water:'#566576',sand:'#bdb295',tree:'#3c4632', wet:0.55,dry:0.32},
 /*7 SENGOKU */ {grass:'#6a6c58',forest:'#41463a',ground:'#8a8270',water:'#4f5866',sand:'#b9b09a',tree:'#3a3e34', wet:0.40,dry:0.55},
 /*8 QUANTUM */ {grass:'#2c5346',forest:'#1c3a34',ground:'#244038',water:'#14506a',sand:'#3a5a5e',tree:'#1a3a30', wet:0.85,dry:0.10,neon:1},
];
function agePal(){ return AGEPAL[Math.min(S.era|0,AGEPAL.length-1)]; }
/* ===== SUMI-E INK-WASH: collapse a terrain colour to true neutral greyscale, with a gentle
   contrast push so the island reads as a black-&-white ink painting. Only natural terrain
   (ground/trees/rocks/roads/fields) is routed through here — buildings, people, cherry
   blossoms, fire, blood and yokai never pass through inkize and keep their full vibrant colour.
   Water (its own spirit-water/frozen pipeline) and the icy void-rim (its own gradient pipeline)
   never call inkize either, so they stay coloured. */
function inkize(hex){
  // GREEN ISLAND: the old behaviour collapsed every terrain colour to neutral grey in VOID.
  // The island is now painted in natural Japanese greens, identical across all ages, so this
  // pass-through keeps the palette colour intact. (Kept as a function so every call site that
  // routed terrain/coast/foliage through it continues to work unchanged.)
  return hex;
}
function _inkize_legacy(hex){
  const n=parseInt(hex.slice(1),16); const r=(n>>16)&255,g=(n>>8)&255,b=n&255;
  let y=0.30*r+0.59*g+0.11*b;            // luminance
  // wider contrast curve pivoted slightly below mid-gray (rice-paper tends light, ink pools dark),
  // so mid-tone earth/grass hexes spread across a real tonal range instead of collapsing to mud.
  y=118+(y-118)*1.55;
  const cl=v=>v<0?0:v>255?255:v|0, yy=cl(y);                 // true neutral grey — no warm/cool split
  return '#'+((1<<24)|(yy<<16)|(yy<<8)|yy).toString(16).slice(1);
}
/* the 28 traditional Lunar Mansions (二十八宿) — pure atmospheric lore accent scattered through
   the void as a minimal starfield. No gameplay system, no interactivity, no glyphs or labels:
   each mansion is a small point-star asterism, grouped by age-feel and gently restyled as the
   island's age advances. Positions are normalized (0..1 of VW/VH) and fixed per mansion so the
   field reads as a stable sky rather than noise; only opacity/tint/jitter shift with era.
   `deg` is a loose stand-in for each mansion's real (and famously very unequal) width along the
   ecliptic — from a couple of degrees at its narrowest (觜 Zī) to the low 30s at its widest
   (井 Jǐng) — used only to vary how tight vs. loose each star cluster looks, not as exact data.
   `n` (3-6) keeps every mansion an intentionally minimal handful of points, never a busy cluster.
   `ch` is kept as a code-only label for readability; it is never drawn. */
const MANSIONS=[
  // Early Ages — Jomon..Nara: ancient, nature-oriented, widest scatter, lowest light
  {ch:'角',x:0.06,y:0.10,grp:0,n:4,deg:12},{ch:'亢',x:0.14,y:0.06,grp:0,n:3,deg:9},
  {ch:'氐',x:0.22,y:0.12,grp:0,n:5,deg:16},{ch:'房',x:0.30,y:0.07,grp:0,n:4,deg:5},
  {ch:'心',x:0.10,y:0.20,grp:0,n:3,deg:6},{ch:'尾',x:0.04,y:0.30,grp:0,n:6,deg:18},
  {ch:'箕',x:0.18,y:0.25,grp:0,n:4,deg:11},{ch:'斗',x:0.08,y:0.40,grp:0,n:6,deg:24},
  {ch:'牛',x:0.92,y:0.10,grp:0,n:4,deg:8},{ch:'女',x:0.86,y:0.06,grp:0,n:4,deg:12},
  {ch:'虚',x:0.95,y:0.22,grp:0,n:3,deg:10},{ch:'危',x:0.88,y:0.18,grp:0,n:4,deg:17},
  // Middle Ages — Asuka..Heian: refined, balanced, drift toward upper sky, warmest light
  {ch:'室',x:0.40,y:0.05,grp:1,n:4,deg:16},{ch:'壁',x:0.48,y:0.08,grp:1,n:3,deg:9},
  {ch:'奎',x:0.56,y:0.05,grp:1,n:5,deg:16},{ch:'婁',x:0.64,y:0.08,grp:1,n:4,deg:12},
  {ch:'胃',x:0.72,y:0.05,grp:1,n:4,deg:15},{ch:'昴',x:0.36,y:0.14,grp:1,n:6,deg:11},
  {ch:'畢',x:0.60,y:0.13,grp:1,n:6,deg:16},{ch:'觜',x:0.50,y:0.15,grp:1,n:3,deg:2},
  {ch:'参',x:0.78,y:0.12,grp:1,n:5,deg:9},{ch:'井',x:0.44,y:0.20,grp:1,n:5,deg:33},
  {ch:'鬼',x:0.68,y:0.18,grp:1,n:4,deg:3},{ch:'柳',x:0.82,y:0.28,grp:1,n:6,deg:14},
  // Later Ages — Kamakura..Sengoku: intense, aggressive, low and close, damaged sky
  {ch:'星',x:0.15,y:0.55,grp:2,n:5,deg:7},{ch:'張',x:0.85,y:0.50,grp:2,n:5,deg:17},
  {ch:'翼',x:0.30,y:0.62,grp:2,n:6,deg:18},{ch:'軫',x:0.70,y:0.58,grp:2,n:4,deg:13},
];
function grpDist(g1,g2){ return Math.abs(g1-g2); }
/* a single mansion: a minimal point-star asterism, scaled to that mansion's real ecliptic
   width (wide historical mansions like Jing/Kui read as a looser scatter; narrow ones like
   Zi/Bi read as a tight knot) — joined by hairline ink strokes, no labels, no glyphs. Drawn
   like a faint ink-wash sky-sketch rather than a crisp star-chart icon. */
function paintMansion(g,m,era,t){
  const seed=(m.x*131.7+m.y*71.3)%1;
  const cxp=m.x*VW, cyp=m.y*VH*0.62;                          // confine to upper void band, above the island
  const cy2=cyp+Math.sin(t*0.00006+seed*40)*VH*0.004;
  let op=0.30, tint='200,200,220', dmg=false, neon=false;
  if(era<=4){ op=0.34-grpDist(m.grp,0)*0.10; }
  else if(era<=5){ op=0.40-grpDist(m.grp,1)*0.10; tint='235,222,196'; }   // Heian: warmest, most visible
  else if(era<=7){ op=0.22-grpDist(m.grp,2)*0.06; dmg=(m.grp===2); tint='150,140,150'; }
  else { op=0.30; neon=true; }                                 // Quantum Edo: all 28 present, neon/glitch
  if(op<0.05) op=0.05;                                          // age-inappropriate mansions fade, never fully vanish
  const baseRGB=neon?(seed>0.5?'20,241,149':'153,69,255'):tint;
  // star positions: n points laid out around the mansion's centre, spread scaled by its
  // real ecliptic width (deg) so wide mansions feel looser, narrow ones feel tight —
  // a minimal, schematic stand-in for the asterism rather than a literal star map.
  const n=m.n, spread=6+(m.deg/33)*16;
  const pts=[];
  for(let i=0;i<n;i++){
    const a=seed*6.28+i*(6.28/n)+vhash(seed,i*13)*0.5;
    const r=spread*(0.4+0.6*vhash(seed,i*7+2));
    pts.push([cxp+Math.cos(a)*r, cy2+Math.sin(a)*r*0.6]);
  }
  // hairline connecting strokes — a simple open chain through the points, brush-faint
  g.save(); g.globalAlpha=op*0.65; g.strokeStyle='rgba('+baseRGB+',1)'; g.lineWidth=0.55;
  for(let i=0;i<pts.length-1;i++){
    if(dmg && vhash(seed,i*9)>0.55) continue;                   // later-age mansions: a link missing, "damaged"
    g.beginPath(); g.moveTo(pts[i][0],pts[i][1]); g.lineTo(pts[i+1][0],pts[i+1][1]); g.stroke();
  }
  // the stars themselves — soft round points, the only thing that actually reads as a star
  g.fillStyle='rgba('+baseRGB+',1)';
  for(let i=0;i<pts.length;i++){
    const tw=0.75+0.25*Math.sin(t*0.0007+seed*50+i*1.3);        // gentle per-star twinkle
    const rad=(neon?1.0:0.75)*(i===0?1.3:1)*tw;                  // first point in each mansion reads slightly brighter, a quiet anchor star
    g.globalAlpha=op*tw;
    g.beginPath(); g.arc(pts[i][0],pts[i][1],rad,0,7); g.fill();
    if(neon){ g.save(); g.globalAlpha=op*0.4*tw; g.shadowColor='rgba('+baseRGB+',0.9)'; g.shadowBlur=3;
      g.beginPath(); g.arc(pts[i][0],pts[i][1],rad*1.8,0,7); g.fill(); g.restore(); }
  }
  g.restore();
}
/* draws the full 28-mansion field, low-opacity so it stays a backdrop accent at any zoom —
   especially zoomed out, where it must enhance the void rather than compete with the island. */
function paintConstellations(g){
  const era=(typeof S!=='undefined')?S.era:0, t=(typeof fx!=='undefined')?fx:0;
  for(let i=0;i<MANSIONS.length;i++) paintMansion(g,MANSIONS[i],era,t);
}
/* deep surreal void — near-black with a faint indigo/Solana-purple nebula behind the island,
   so the floating diorama reads as suspended in darkness rather than sitting on flat black. */
function paintVoid(g){
  g.fillStyle='#000004'; g.fillRect(0,0,VW,VH);
  const cx=VW*0.5, cy=VH*0.44, neb=g.createRadialGradient(cx,cy,0,cx,cy,Math.max(VW,VH)*0.72);
  neb.addColorStop(0,'rgba(30,16,56,0.55)'); neb.addColorStop(0.42,'rgba(12,8,30,0.30)'); neb.addColorStop(1,'rgba(0,0,3,0)');
  g.fillStyle=neb; g.fillRect(0,0,VW,VH);
  paintConstellations(g);
}
/* the island's edge where land meets the (now void) sea: a dark cliff lip dropping into darkness
   on the front faces, a delicate moon-cool rim catching the void light on the back faces. */
/* the island's underside where land meets the void: broken ancient cliffs hung with jagged
   stalactites on the front faces (organic, crumbling, mythical), a cool moon-rim on the back. */
function isVoidFace(nx,ny){ return !inB(nx,ny) || (grid[ny][nx].ter===WATER && !grid[ny][nx].spirit && !grid[ny][nx].frozen); }
function paintVoidEdge(g,tx,ty,c,cx,cy,hw,hh,z){ return; /* superseded by paintShorelineMass: one continuous painted cliff ribbon replaces all per-tile faces */
  const T=[cx,cy-hh],R=[cx+hw,cy],B=[cx,cy+hh],L=[cx-hw,cy];
  const seed=c.seed!=null?c.seed:(tx*7+ty*3)%97/97;
  // ORGANIC LIP MASK: a single irregular ink-wash blob centred on the corner where this tile
  // meets the void, oversized so it swallows the hard right-angle step between this tile and
  // its neighbours and reads as one continuous painted edge, not a staircase of diamonds.
  const lipBlob=(px,py,rr,ph)=>{ g.beginPath();
    for(let i=0;i<=10;i++){ const a=ph+(i/10)*Math.PI*2, jr=rr*(0.7+0.4*vhash(seed,a*9.3+5));
      const bx=px+Math.cos(a)*jr, by=py+Math.sin(a)*jr*0.6;
      if(i===0)g.moveTo(bx,by); else g.lineTo(bx,by); }
    g.closePath(); };
  if(isVoidFace(tx,ty+1)||isVoidFace(tx+1,ty)){
    g.fillStyle='rgba(6,5,12,0.5)'; lipBlob(B[0],B[1]+hh*0.15,Math.max(hw,hh)*1.5,seed*6.28); g.fill();
  }
  const front=[[tx,ty+1,B,L,31],[tx+1,ty,R,B,57]];   // SW + SE faces -> hanging cliff
  for(const[nx,ny,A,Bp,salt] of front){
    if(!isVoidFace(nx,ny)) continue;
    const dx=Bp[0]-A[0], dy=Bp[1]-A[1], base=hh*4.1;          // deeper glacial fracture drop
    const segs=7+((vhash(seed,salt)*5)|0);            // 7..11 fractured shards per face — more violently jagged
    const bottom=[]; let maxd=0;
    for(let i=0;i<=segs;i++){ const t=i/segs, jx=(vhash(seed,salt+i*19+2)*2-1)*hw*0.09,
        ex=A[0]+dx*t+jx, ey=A[1]+dy*t;                                        // jittered lip notch, glacier-fracture feel
      const nd=base*(0.07+0.2*vhash(seed,salt+i*7)); bottom.push([ex,ey+nd]); maxd=Math.max(maxd,nd);
      if(i<segs){ const tt=(i+0.5)/segs, mx=A[0]+dx*tt+(vhash(seed,salt+i*31+8)*2-1)*hw*0.07, my=A[1]+dy*tt;  // jagged shattered tip, irregular
        const td=base*(1.05+1.7*vhash(seed,salt+i*13+3)); bottom.push([mx,my+td]); maxd=Math.max(maxd,td);
        // mid-break notch: an extra inward jag halfway down each shard for a fractured, broken-glass silhouette
        const bt=(i+0.78)/segs, bx=A[0]+dx*bt+(vhash(seed,salt+i*41+6)*2-1)*hw*0.1, by=A[1]+dy*bt+td*0.42;
        bottom.push([bx,by]); } }
    g.beginPath(); g.moveTo(A[0],A[1]); g.lineTo(Bp[0],Bp[1]);
    for(let i=bottom.length-1;i>=0;i--) g.lineTo(bottom[i][0],bottom[i][1]);
    g.closePath();
    const gr=g.createLinearGradient(0,A[1],0,A[1]+maxd);
    gr.addColorStop(0,'rgba(7,6,14,0.96)'); gr.addColorStop(0.32,'rgba(5,4,11,0.74)'); gr.addColorStop(0.62,'rgba(3,2,8,0.4)'); gr.addColorStop(0.86,'rgba(2,1,6,0.12)'); gr.addColorStop(1,'rgba(2,1,6,0)');
    g.fillStyle=gr; g.fill();
    // fracture seams: jagged crack lines radiating down through the broken shard body — denser web
    g.strokeStyle='rgba(0,0,0,0.4)'; g.lineWidth=0.5*z;
    for(let i=0;i<5;i++){ const t=0.16+0.18*i, lx=A[0]+dx*0.08+dx*0.86*vhash(seed,salt+i*5);
      const ly=(A[1]+dy*0.08)+base*t;
      g.beginPath(); g.moveTo(lx,ly); g.lineTo(lx+dx*0.1+ (vhash(seed,salt+i*9)*2-1)*hw*0.1, ly+2.6*z);
      g.lineTo(lx+dx*0.18+(vhash(seed,salt+i*15)*2-1)*hw*0.06,ly+4.8*z); g.stroke(); }
    // multiple long shards dissolving into the void for drama — glacier calving off the island
    for(let s=0;s<2;s++){ if(vhash(seed,salt+91+s*17)>0.42){ const ti=1+2*((vhash(seed,salt+71+s*23)*Math.max(1,segs-1))|0);
      const tip=bottom[Math.min(ti,bottom.length-1)]; const ex=tip?tip[0]:cx, ey=tip?tip[1]:A[1]+base;
      const drip=base*(0.55+0.5*vhash(seed,salt+s*29));
      g.beginPath(); g.moveTo(ex-2.1*z,ey-4.2*z); g.lineTo(ex+2.1*z,ey-4.2*z); g.lineTo(ex+0.6*z,ey+drip); g.closePath();
      const dg=g.createLinearGradient(0,ey-4.2*z,0,ey+drip); dg.addColorStop(0,'rgba(5,4,11,0.9)'); dg.addColorStop(0.55,'rgba(3,2,8,0.36)'); dg.addColorStop(1,'rgba(2,1,6,0)');
      g.fillStyle=dg; g.fill(); } }
    // FROZEN-RIM accents: on tundra edges, an icy rime on the lip + a tasteful, sparse Solana glint
    if(c.tundra){
      g.strokeStyle='rgba(206,224,232,0.55)'; g.lineWidth=0.8*z;
      g.beginPath(); g.moveTo(A[0],A[1]); g.lineTo(Bp[0],Bp[1]); g.stroke();
      // jagged ice rime teeth biting down from the lip — frost shattering with the rock
      g.fillStyle='rgba(214,230,238,0.5)';
      for(let i=0;i<segs;i+=2){ const tt=i/segs, tx2=A[0]+dx*tt, ty2=A[1]+dy*tt, tn=base*0.16*(0.5+vhash(seed,salt+i*17+4));
        g.beginPath(); g.moveTo(tx2-hw*0.05,ty2); g.lineTo(tx2+hw*0.05,ty2); g.lineTo(tx2,ty2+tn); g.closePath(); g.fill(); }
      if(vhash(seed,salt+123)>0.7){ const acc=vhash(seed,salt+131)>0.5?'#9945ff':'#14f195';
        const ti=bottom[Math.min(2,bottom.length-1)], gx=ti?ti[0]:cx, gy=ti?ti[1]:A[1]+base*0.6;
        const gl=g.createRadialGradient(gx,gy,0,gx,gy,5*z); gl.addColorStop(0,acc); gl.addColorStop(1,'rgba(0,0,0,0)');
        g.globalAlpha=0.2; g.fillStyle=gl; g.beginPath(); g.arc(gx,gy,5*z,0,7); g.fill(); g.globalAlpha=1; }
    }
  }
  const back=[[tx,ty-1,T,R],[tx-1,ty,L,T]];          // NE + NW faces -> cool void-rim
  for(const[nx,ny,A,Bp] of back){
    if(!isVoidFace(nx,ny)) continue;
    g.strokeStyle=c.tundra?'rgba(172,182,212,0.4)':'rgba(150,140,180,0.32)'; g.lineWidth=0.6*z; g.lineCap='round';
    g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(Bp[0],Bp[1]);g.stroke(); g.lineCap='butt';
  }
}
/* pull a colour toward its own luminance (war-age bleaching) */
function desatHex(hex,a){ if(a<=0)return hex; const n=parseInt(hex.slice(1),16); const r=(n>>16)&255,g=(n>>8)&255,b=n&255;
  const y=Math.round(0.30*r+0.59*g+0.11*b); const mr=Math.round(r+(y-r)*a),mg=Math.round(g+(y-g)*a),mb=Math.round(b+(y-b)*a);
  return '#'+((1<<24)|(mr<<16)|(mg<<8)|mb).toString(16).slice(1); }
/* age-target colour for a terrain key (null = keep neutral, e.g. rock/snow) */
function ageTarget(k,P){ switch(k){ case WATER:return P.water; case SAND:return P.sand; case BARE:return P.ground;
  case GRASS2:return P.grass; case FOREST:return mix(P.forest,P.grass,0.55); case ROCK: case SNOW:return null; default:return P.grass; } }

/* Painterly Japanese palette — representative base per terrain, retinted to the active age (used to feather neighbouring edges) */
function terBaseColor(k){ const P=VOID?AGEPAL[0]:agePal();   // LAND IS TIMELESS: terrain colour locked across all ages
  let c; switch(k){ case WATER:c=P.water;break; case SNOW:c='#dfe3e2';break; case ROCK:c='#7e776b';break;
    case SAND:c=P.sand;break; case BARE:c=P.ground;break; case GRASS2:c=P.grass;break;
    // FOREST ground reads as natural grass with only a faint forest lean — the tree canopy sprite
    // itself carries the "forest" identity, so the tile underneath no longer paints as a dark
    // square patch that singles out every tree from its surroundings.
    case FOREST:c=P.grass;break; default:c=P.grass; }
  return inkize(P.dry>0?desatHex(c,P.dry):c); }
/* organic, seeded, slightly over-drawn tile corners — breaks the hard voxel grid into hand-painted edges */
function tileCorners(cx,cy,hw,hh,seed,tx,ty){ const J=(typeof TJIT!=='undefined'?TJIT:1); const ax=hw*0.028*J, ay=hh*0.05*J, ov=1.1*J;
  // vertex-seeded (not tile-seeded) wobble: every tile shares the exact same offset at a
  // given grid corner as its neighbours, so the diamond edges always meet flush — no torn seams.
  // Amplitude halved: the old jitter was strong enough to make flat ground read as bumps.
  const hx=typeof tx==='number'?tx:0, hy=typeof ty==='number'?ty:0;
  const vj=(vx,vy)=>{ const s=vhash(vx*53.17+vy*13.7,vx*7+vy*31+1); return s*2-1; };
  const jT=vj(hx,hy),  jR=vj(hx+1,hy), jB=vj(hx,hy+1), jL=vj(hx-1,hy);
  return [ [cx+jT*ax, cy-hh-ov+jT*ay*0.6], [cx+hw+ov+jR*ax*0.6, cy+jR*ay],
           [cx+jB*ax, cy+hh+ov+jB*ay*0.6], [cx-hw-ov+jL*ax*0.6, cy+jL*ay] ]; }
/* grid dissolve: tint a thin wedge along one back edge toward a differing neighbour */
function featherEdge(g,cx,cy,hw,hh,k,nx,ny,side){ if(!inB(nx,ny))return; const nk=grid[ny][nx].ter; if(nk===k)return;
  const tpx=cx,tpy=cy-hh, cpx=side==='L'?cx-hw:cx+hw, cpy=cy;
  const mx=(tpx+cpx)/2,my=(tpy+cpy)/2;
  // soft radial wash instead of a flat-fill wedge: fades smoothly to transparent so the
  // neighbour colour bleeds in like wet pigment rather than reading as a hard triangular facet.
  const rad=Math.max(hw,hh)*0.62;
  const rg=g.createRadialGradient(mx,my,0,mx,my,rad);
  const nc=terBaseColor(nk);
  rg.addColorStop(0, hexA(nc,0.34)); rg.addColorStop(0.6, hexA(nc,0.14)); rg.addColorStop(1, hexA(nc,0));
  g.fillStyle=rg;
  g.beginPath();g.arc(mx,my,rad,0,7);g.fill(); }
function hexA(hex,a){ if(!hex||hex[0]!=='#')return 'rgba(0,0,0,'+a+')'; const n=parseInt(hex.slice(1),16);
  return 'rgba('+((n>>16)&255)+','+((n>>8)&255)+','+(n&255)+','+a+')'; }
function waterNeighbors(tx,ty){
  const wN=inB(tx,ty-1)&&grid[ty-1][tx].ter===WATER, wS=inB(tx,ty+1)&&grid[ty+1][tx].ter===WATER,
        wE=inB(tx+1,ty)&&grid[ty][tx+1].ter===WATER, wWst=inB(tx-1,ty)&&grid[ty][tx-1].ter===WATER;
  return {wN,wS,wE,wWst,deg:(wN?1:0)+(wS?1:0)+(wE?1:0)+(wWst?1:0)};
}
/* SPIRIT-WATER BODY — replaces the old per-tile renderer. The old approach drew every
   water tile as its own diamond (fill + gradient + stroke), and even with seam-matched
   gradients the SHAPE itself was still N separate diamonds — at any zoom level the lake
   read as a staircase of facets and the river as a chain of disconnected beads (exactly
   what the screenshots showed). Fix: render the ENTIRE connected spirit-water region
   (lake + flowing river, pre-freeze) as ONE silhouette, built from a supersampled blurred
   mask so the coastline comes out as a smooth organic curve with no per-tile corners at
   all, then fill that single shape with the painterly wash. Frozen terminus tiles keep
   their own crystalline per-tile look (drawFrozenWater) since ice is a different material
   and is SUPPOSED to read faceted. */
let _swMaskC=null,_swMaskX=null,_swBlurC=null,_swBlurX=null,_swLayerC=null,_swLayerX=null;
function ensureSpiritMaskBuffers(w,h){
  if(_swMaskC&&_swMaskC.width===w&&_swMaskC.height===h)return;
  _swMaskC=document.createElement('canvas'); _swMaskC.width=w; _swMaskC.height=h; _swMaskX=_swMaskC.getContext('2d');
  _swBlurC=document.createElement('canvas'); _swBlurC.width=w; _swBlurC.height=h; _swBlurX=_swBlurC.getContext('2d');
  _swLayerC=document.createElement('canvas'); _swLayerC.width=w; _swLayerC.height=h; _swLayerX=_swLayerC.getContext('2d');
}
function drawSpiritWaterBody(g,z,t){
  // 1) collect every spirit OR frozen water tile currently on/near screen, in screen space.
  // NOTE: carveSpiritWater explicitly sets spirit=0 when it sets frozen=1 (the terminus
  // stops being "flowing mist" and becomes "glacial ice"), so frozen tiles fail a spirit-only
  // filter and were silently never collected — every icicle/drip/bloom fix for the frozen
  // edge was dead code until this filter accepted frozen tiles too.
  const cells=[]; let minX=1e9,minY=1e9,maxX=-1e9,maxY=-1e9;
  const hw=TW/2*z, hh=TH/2*z;
  for(let ty=0;ty<H;ty++)for(let tx=0;tx<W;tx++){ const c=grid[ty][tx];
    if(c.ter!==WATER||!(c.spirit||c.frozen))continue;
    const[cx,cy]=s2(tx,ty);
    if(cx<-TW*z*3||cx>VW+TW*z*3||cy<-TH*z*14||cy>VH+TH*z*6)continue;
    cells.push([cx,cy,tx,ty,!!c.frozen]);
    if(cx-hw<minX)minX=cx-hw; if(cx+hw>maxX)maxX=cx+hw;
    if(cy-hh<minY)minY=cy-hh; if(cy+hh>maxY)maxY=cy+hh;
  }
  if(!cells.length)return;
  const pad=Math.max(hw,hh)*7;
  minX-=pad; minY-=pad; maxX+=pad; maxY+=pad;
  const bw=Math.max(1,Math.min(2200,Math.ceil(maxX-minX))), bh=Math.max(1,Math.min(2200,Math.ceil(maxY-minY)));
  ensureSpiritMaskBuffers(bw,bh);

  // 2) stamp every tile's (slightly oversized, overlapping) diamond into a mask, then soften
  //    it with a downscale->upscale bilinear blur (the SAME trick compositeSoftGround already
  //    uses elsewhere in this file). NOTE: ctx.filter='blur()' is NOT used here — it is
  //    unsupported on Safari/iOS WKWebView (the primary deployment target for this build),
  //    so this mask softening must stay within plain drawImage scaling, which iOS has always
  //    supported. A soft feathered edge is correct for sumi-e/watercolor work anyway.
  _swMaskX.setTransform(1,0,0,1,0,0); _swMaskX.clearRect(0,0,bw,bh);
  _swMaskX.fillStyle='#fff';
  // oversize factor is large because a 1-tile-wide river takes diagonal steps in world space
  // (carveSpiritWater meanders via 8-directional movement) — consecutive diamonds need to
  // physically overlap a lot to read as one smooth tube rather than a sawtooth of facets.
  // The lake (many adjacent wet tiles) tolerates the same factor fine, it just stays a wide
  // continuous blob either way.
  const OVR=1.85;
  for(const[cx,cy]of cells){
    const ox=cx-minX, oy=cy-minY;
    _swMaskX.beginPath();
    _swMaskX.moveTo(ox,oy-hh*OVR); _swMaskX.lineTo(ox+hw*OVR,oy); _swMaskX.lineTo(ox,oy+hh*OVR); _swMaskX.lineTo(ox-hw*OVR,oy);
    _swMaskX.closePath(); _swMaskX.fill();
  }
  // icicle drip skirt: any frozen cell facing the void gets a long tapered drip stamped into
  // the SAME mask, so the lake/river silhouette pours seamlessly into hanging ice with no gap.
  for(const[cx,cy,tx,ty,fz]of cells){ if(!fz)continue;
    const dirs=[[0,1],[1,0]];
    for(const[dx,dy]of dirs){ const nx=tx+dx,ny=ty+dy;
      if(!isVoidFace(nx,ny))continue;
      const ox=cx-minX, oy=cy-minY, dlen=Math.max(hw,hh)*5.5, dw2=hw*0.9;
      _swMaskX.beginPath();
      _swMaskX.moveTo(ox-dw2,oy); _swMaskX.lineTo(ox+dw2,oy);
      _swMaskX.lineTo(ox+dw2*0.35,oy+dlen); _swMaskX.lineTo(ox-dw2*0.35,oy+dlen);
      _swMaskX.closePath(); _swMaskX.fill();
    }
  }
  // blur radius must be comparable to the zigzag amplitude itself (~hw) to actually erase it,
  // not a small fraction of it — express directly as "blur this many source px" rather than
  // an inverse shrink-factor formula, which is far more predictable to tune.
  const blurPx=Math.max(6, hw*0.85);
  const shrink=Math.max(0.03,Math.min(0.5, 1/blurPx));
  const sbw=Math.max(1,Math.round(bw*shrink)), sbh=Math.max(1,Math.round(bh*shrink));
  if(_swBlurC.width!==sbw||_swBlurC.height!==sbh){ _swBlurC.width=sbw; _swBlurC.height=sbh; }
  _swBlurX.setTransform(1,0,0,1,0,0); _swBlurX.imageSmoothingEnabled=true; _swBlurX.imageSmoothingQuality='high';
  _swBlurX.clearRect(0,0,sbw,sbh);
  _swBlurX.drawImage(_swMaskC,0,0,bw,bh,0,0,sbw,sbh);   // downscale — averages neighbouring tile edges together
  _swMaskX.clearRect(0,0,bw,bh); _swMaskX.imageSmoothingEnabled=true; _swMaskX.imageSmoothingQuality='high';
  _swMaskX.drawImage(_swBlurC,0,0,sbw,sbh,0,0,bw,bh);   // upscale back — bilinear interpolation reads as a soft blur
  // restamp once more at full alpha to lift the now-soft interior back toward solid white,
  // leaving only the genuinely soft band right at the coastline
  _swMaskX.drawImage(_swMaskC,0,0);


  // 3) paint every body layer (silhouette, wash, glow, flow strokes) at full strength into
  //    an unclipped scratch layer, then composite that ENTIRE layer through the mask exactly
  //    once. This avoids the old approach's repeated save/clip/destination-in juggling and
  //    guarantees the final result never bleeds past the one smooth edge we just built.
  _swLayerX.setTransform(1,0,0,1,0,0); _swLayerX.clearRect(0,0,bw,bh);
  _swLayerX.globalCompositeOperation='source-over';
  // sumi-e silhouette — deep indigo ink ground
  _swLayerX.globalAlpha=0.94; _swLayerX.fillStyle='#161e2a'; _swLayerX.fillRect(0,0,bw,bh); _swLayerX.globalAlpha=1;
  // watercolor wash — gradient anchored to fixed canvas-space bounds so it matches the rest
  // of the body's lighting regardless of where on screen this bounding box sits
  const deep='#1c2a38', mid=mix('#274656','#2f5a52',0.5), glow='#4f8a86';
  const base=mid, lt=mix(glow,mid,0.45), dk=shade(deep,-10);
  const gr=_swLayerX.createLinearGradient(0,-minY,0,VH-minY); gr.addColorStop(0,lt); gr.addColorStop(0.5,base); gr.addColorStop(1,dk);
  _swLayerX.globalAlpha=0.78; _swLayerX.fillStyle=gr; _swLayerX.fillRect(0,0,bw,bh); _swLayerX.globalAlpha=1;
  // icy pale bloom at every frozen cell — blends the deep-water wash into glacial ice so the
  // colour itself transitions smoothly instead of cutting hard at the terminus
  for(const[cx,cy,tx,ty,fz]of cells){ if(!fz)continue;
    const ox=cx-minX, oy=cy-minY, ir=Math.max(hw,hh)*4.2;
    const ig=_swLayerX.createRadialGradient(ox,oy,0,ox,oy,ir);
    ig.addColorStop(0,'rgba(223,236,239,0.98)'); ig.addColorStop(0.35,'rgba(200,218,224,0.85)'); ig.addColorStop(0.7,'rgba(183,202,210,0.45)'); ig.addColorStop(1,'rgba(183,202,210,0)');
    _swLayerX.fillStyle=ig; _swLayerX.beginPath(); _swLayerX.arc(ox,oy,ir,0,7); _swLayerX.fill();
  }
  // deep glow undertone — soft teal-violet bloom drifting through the body
  const gcx=(maxX-minX)/2, gcy=(maxY-minY)/2, gph=t*0.00006;
  const glowAmt=0.5+0.5*Math.sin(gph+(minX*0.002));
  _swLayerX.globalAlpha=0.10*glowAmt; const rg=_swLayerX.createRadialGradient(gcx,gcy,0,gcx,gcy,Math.max(bw,bh)*0.55);
  rg.addColorStop(0,'#5fa8a0'); rg.addColorStop(1,hexA('#5fa8a0',0));
  _swLayerX.fillStyle=rg; _swLayerX.beginPath();_swLayerX.arc(gcx,gcy,Math.max(bw,bh)*0.55,0,7);_swLayerX.fill(); _swLayerX.globalAlpha=1;
  // 4) flow ribbons — one continuous stroke per river "spine" run, walked along the REAL
  //    path (8-directional, same as carveSpiritWater's diagonal meander) instead of a single
  //    locked horizontal/vertical axis. The old single-axis walker broke at every diagonal
  //    step in the actual river path, restarting as tiny runs at mismatched angles, which is
  //    what produced the zigzag/sawtooth look. Pond tiles get a few long lazy drift strokes.
  const D8R=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1],[1,-1],[-1,1]];
  const visited=new Set(); const runs=[]; const pondPts=[];
  for(const[cx,cy,tx,ty,fz]of cells){ if(fz)continue;
    const N=waterNeighbors(tx,ty);
    if(N.deg>=3){ pondPts.push([cx,cy]); continue; }
    const key=tx+','+ty; if(visited.has(key))continue;
    visited.add(key); let run=[[cx-minX,cy-minY]];
    // extend forward and backward along whichever real wet neighbour continues the channel
    for(let dir=0;dir<2;dir++){ let cxw2=tx,cyw2=ty;
      for(let guard=0;guard<400;guard++){
        let found=null;
        for(const[dx,dy]of D8R){ const nx=cxw2+dx,ny=cyw2+dy; const nkey=nx+','+ny;
          if(visited.has(nkey))continue; if(!inB(nx,ny))continue;
          const nc=grid[ny][nx]; if(nc.ter!==WATER||!nc.spirit||nc.frozen)continue;
          if(waterNeighbors(nx,ny).deg>=3)continue;   // stop at the open pond's rim, don't wander into it
          found=[nx,ny]; break; }
        if(!found)break; const[nx,ny]=found; visited.add(nx+','+ny);
        const[scx,scy]=s2(nx,ny);
        if(dir===0) run.unshift([scx-minX,scy-minY]); else run.push([scx-minX,scy-minY]);
        cxw2=nx; cyw2=ny;
      }
    }
    if(run.length>=2) runs.push(run);
  }
  // smooth each run's point chain (simple 3-point moving average, a couple passes) so the
  // ribbon reads as one continuous curve even though the underlying tiles step diagonally
  function smoothRun(run){ if(run.length<3)return run;
    let pts=run;
    for(let pass=0;pass<2;pass++){ const out=[pts[0]];
      for(let i=1;i<pts.length-1;i++){ const a=pts[i-1],b=pts[i],c=pts[i+1];
        out.push([(a[0]+b[0]*2+c[0])/4,(a[1]+b[1]*2+c[1])/4]); }
      out.push(pts[pts.length-1]); pts=out; }
    return pts;
  }
  for(const run of runs){
    const sm=smoothRun(run);
    _swLayerX.globalAlpha=0.22; _swLayerX.strokeStyle=glow; _swLayerX.lineWidth=Math.max(1,hh*0.5); _swLayerX.lineCap='round'; _swLayerX.lineJoin='round';
    _swLayerX.beginPath(); _swLayerX.moveTo(sm[0][0],sm[0][1]);
    for(let i=1;i<sm.length;i++) _swLayerX.lineTo(sm[i][0],sm[i][1]);
    _swLayerX.stroke(); _swLayerX.globalAlpha=1;
    _swLayerX.globalAlpha=0.22; _swLayerX.strokeStyle='rgba(206,232,224,0.6)'; _swLayerX.lineWidth=Math.max(0.6,hh*0.16);
    _swLayerX.beginPath(); _swLayerX.moveTo(sm[0][0],sm[0][1]-hh*0.18);
    for(let i=1;i<sm.length;i++) _swLayerX.lineTo(sm[i][0],sm[i][1]-hh*0.18);
    _swLayerX.stroke(); _swLayerX.globalAlpha=1;
  }

  if(pondPts.length){
    let pminX=1e9,pminY=1e9,pmaxX=-1e9,pmaxY=-1e9;
    for(const[cx,cy]of pondPts){ if(cx<pminX)pminX=cx; if(cx>pmaxX)pmaxX=cx; if(cy<pminY)pminY=cy; if(cy>pmaxY)pmaxY=cy; }
    const pw=pmaxX-pminX, ph2=pmaxY-pminY, pcx=(pminX+pmaxX)/2-minX, pcy=(pminY+pmaxY)/2-minY;
    for(let i=0;i<3;i++){ const fy=pcy+(i-1)*ph2*0.22, amp=pw*0.34, drift=Math.sin(t*0.00007+i*2.1)*hh*0.4;
      _swLayerX.globalAlpha=0.12; _swLayerX.strokeStyle=glow; _swLayerX.lineWidth=Math.max(1,hh*0.34); _swLayerX.lineCap='round';
      _swLayerX.beginPath(); _swLayerX.moveTo(pcx-amp,fy+drift);
      _swLayerX.quadraticCurveTo(pcx,fy-hh*0.3+drift,pcx+amp,fy+drift); _swLayerX.stroke(); _swLayerX.globalAlpha=1;
    }
  }
  // 5) mask the whole painted layer in ONE pass, so every layer above shares the exact
  //    same smooth edge with zero risk of mismatched clips
  _swLayerX.globalCompositeOperation='destination-in';
  _swLayerX.drawImage(_swMaskC,0,0);
  _swLayerX.globalCompositeOperation='source-over';
  // 6) bank ink line — a thin glow rim just outside the body, derived from the same mask,
  //    so the shoreline reads as one continuous sumi-e contour with no facet corners.
  //    Built with the same downscale/upscale softening (not shadowBlur) to stay consistent
  //    with the rest of this file's iOS-safe blur technique.
  _swLayerX.save();
  _swLayerX.globalCompositeOperation='destination-over';
  _swLayerX.globalAlpha=0.4; _swLayerX.drawImage(_swBlurC,0,0,sbw,sbh,0,0,bw,bh);   // already-soft pre-restamp mask = a ready-made wider, fainter halo
  _swLayerX.globalAlpha=1;
  _swLayerX.restore();
  // 7) blit the finished, fully-masked body onto the real ground buffer in one draw
  g.save(); g.setTransform(1,0,0,1,0,0);
  g.drawImage(_swLayerC,0,0,bw,bh,minX,minY,bw,bh);
  g.restore();
  // 8) re-stamp icicles on top of the body — they were drawn per-tile during the terrain
  //    pass (paintFrozenEdge) but the body's bloom/wash just painted over them; redraw here
  //    so the frozen waterfall hangs visibly off the now-seamless edge.
  for(const[cx,cy,tx,ty,fz]of cells){ if(!fz)continue;
    const fc=grid[ty][tx];
    g.globalAlpha=0.5; g.strokeStyle='rgba(247,252,254,0.85)'; g.lineWidth=0.7*z;
    g.beginPath();g.moveTo(cx-hw*0.32,cy-hh*0.08);g.lineTo(cx+hw*0.06,cy-hh*0.42);g.lineTo(cx+hw*0.34,cy+0.02);g.stroke();
    g.strokeStyle='rgba(118,148,164,0.5)';
    g.beginPath();g.moveTo(cx-hw*0.2,cy+hh*0.22);g.lineTo(cx+hw*0.22,cy-hh*0.04);g.stroke(); g.globalAlpha=1;
    paintFrozenEdge(g,tx,ty,fc,cx,cy,hw,hh,z);
  }
}


/* frozen terminus: where the river meets the void it crystallises into pale glacial ice —
   a faceted surface above, an icicle-hung frozen waterfall pouring (and stopping) into the abyss. */
function drawFrozenWater(g,tx,ty,c,cx,cy,hw,hh,z,t){
  const T=tileCorners(cx,cy,hw,hh,c.seed!=null?c.seed:(tx*7+ty*3)%97/97,tx,ty)[0];
  const base='#b7cad2', lt='#dfeaee', dk='#90a8b4';
  const C=tileCorners(cx,cy,hw,hh,c.seed!=null?c.seed:(tx*7+ty*3)%97/97,tx,ty), Tp=C[0],R=C[1],B=C[2],L=C[3];
  const gr=g.createLinearGradient(0,Tp[1],0,B[1]); gr.addColorStop(0,lt); gr.addColorStop(0.55,base); gr.addColorStop(1,dk);
  g.beginPath();g.moveTo(Tp[0],Tp[1]);g.lineTo(R[0],R[1]);g.lineTo(B[0],B[1]);g.lineTo(L[0],L[1]);g.closePath();g.fillStyle=gr;g.fill();
}
function paintFrozenEdge(g,tx,ty,c,cx,cy,hw,hh,z){
  const B=[cx,cy+hh],L=[cx-hw,cy],R=[cx+hw,cy];
  const seed=c.seed!=null?c.seed:(tx*7+ty*3)%97/97;
  const front=[[tx,ty+1,B,L,41],[tx+1,ty,R,B,67]];
  for(const[nx,ny,A,Bp,salt] of front){
    if(!isVoidFace(nx,ny)) continue;                                  // only where ice meets the abyss
    const dx=Bp[0]-A[0], dy=Bp[1]-A[1], drop=hh*5.6;                  // far longer, mystic frozen fall
    const segs=8+((vhash(seed,salt)*5)|0); const bottom=[]; let maxd=0;
    for(let i=0;i<=segs;i++){ const tt=i/segs, jx=(vhash(seed,salt+i*23+9)*2-1)*hw*0.07,
        ex=A[0]+dx*tt+jx, ey=A[1]+dy*tt;
      const nd=drop*(0.1+0.12*vhash(seed,salt+i*7)); bottom.push([ex,ey+nd]); maxd=Math.max(maxd,nd);
      if(i<segs){ const mt=(i+0.5)/segs, mx=A[0]+dx*mt+(vhash(seed,salt+i*33+11)*2-1)*hw*0.06, my=A[1]+dy*mt;     // long needle-thin icicle tip
        const td=drop*(1.0+1.5*vhash(seed,salt+i*13+5)); bottom.push([mx,my+td]); maxd=Math.max(maxd,td);
        // secondary thinner icicle hanging beside the main one — clustered stalactite drip
        const st=(i+0.65)/segs, sx=A[0]+dx*st+(vhash(seed,salt+i*47+14)*2-1)*hw*0.08, sy=A[1]+dy*st;
        const sd=drop*(0.5+0.7*vhash(seed,salt+i*19+7)); bottom.push([sx,sy+sd]); } }
    g.beginPath(); g.moveTo(A[0],A[1]); g.lineTo(Bp[0],Bp[1]);
    for(let i=bottom.length-1;i>=0;i--) g.lineTo(bottom[i][0],bottom[i][1]);
    g.closePath();
    const gr=g.createLinearGradient(0,A[1],0,A[1]+maxd);
    gr.addColorStop(0,'rgba(218,236,242,0.97)'); gr.addColorStop(0.3,'rgba(190,214,226,0.78)'); gr.addColorStop(0.6,'rgba(162,192,208,0.42)'); gr.addColorStop(0.85,'rgba(150,180,198,0.14)'); gr.addColorStop(1,'rgba(150,180,198,0)');
    g.fillStyle=gr; g.fill();
    g.strokeStyle='rgba(247,253,255,0.65)'; g.lineWidth=0.6*z; g.lineCap='round';    // crystalline striations
    for(let i=0;i<segs;i++){ const mt=(i+0.5)/segs, mx=A[0]+dx*mt, my=A[1]+dy*mt;
      g.beginPath(); g.moveTo(mx,my); g.lineTo(mx,my+drop*(0.55+0.85*vhash(seed,salt+i*13+5))); g.stroke(); }
    g.lineCap='butt';
    // several long mystic icicles dripping deep into the void, like frozen stalactites hanging off the island
    for(let s=0;s<3;s++){ if(vhash(seed,salt+97+s*31)>0.4){ const ti=1+2*((vhash(seed,salt+79+s*37)*Math.max(1,segs-1))|0);
      const tip=bottom[Math.min(ti,bottom.length-1)]; const ex=tip?tip[0]:cx, ey=tip?tip[1]:A[1]+drop;
      const dripLen=drop*(0.5+0.55*vhash(seed,salt+s*41));
      g.beginPath(); g.moveTo(ex-1.5*z,ey-3.2*z); g.lineTo(ex+1.5*z,ey-3.2*z); g.lineTo(ex+0.3*z,ey+dripLen); g.closePath();
      const ig=g.createLinearGradient(0,ey-3.2*z,0,ey+dripLen); ig.addColorStop(0,'rgba(224,240,245,0.92)'); ig.addColorStop(0.55,'rgba(180,206,218,0.42)'); ig.addColorStop(1,'rgba(160,190,205,0)');
      g.fillStyle=ig; g.fill(); } }
    g.strokeStyle='rgba(120,170,196,0.6)'; g.lineWidth=0.9*z;                       // cold inner glow along the lip
    g.beginPath(); g.moveTo(A[0],A[1]); g.lineTo(Bp[0],Bp[1]); g.stroke();
  }
}
/* FROZEN TUNDRA: barren icy ground forming the cold rim — pale desaturated grey-blue, quiet and
   treeless, with rare tasteful Solana crystal specks. Keeps the sumi-e mono feel but reads cold. */
function drawTundra(g,tx,ty,c,cx,cy,z,t){ const hw=TW/2*z,hh=TH/2*z;
  // RIM DISSOLVE: the outer tundra ring fades into the painted shoreline cliff beneath it
  // (drawn first in rebuildWorld). Near-invisible at the silhouette, ramping to full a few tiles
  // inland — so the eye reads one continuous painted edge melting into the void, not a field of
  // noisy grey diamonds. Below the floor the tile is skipped entirely; the clean mass shows through.
  ensureEdgeDist();
  const ed=_edgeDist?_edgeDist[ty][tx]:9;
  let AL=(ed-0.3)/3.4; AL=AL<=0?0:(AL>=1?1:AL*AL*(3-2*AL));
  if(AL<0.05) return;
  // RECOLOURED (was pale grey/cream/white -> read as a soft cotton/cloud mass smothering the
  // dark void-edge ink ribbon underneath). Now a dark, ink-washed broken stone/glacier-rock
  // palette consistent with the rest of the void rim — cool moonlit highlights stay thin
  // accents only, never the dominant fill, so the rim reads as shattered rock at night
  // instead of a puffy cloud bank.
  let base='#3c4044', lt='#5a6268', dk='#23262a';
  if(c.ter===ROCK){ base='#34373b'; lt='#4e5358'; dk='#1c1e21'; }
  else if(c.ter===SNOW){ base='#444b52'; lt='#6b7680'; dk='#262a2e'; }
  const hL=inB(tx-1,ty)?grid[ty][tx-1].h:c.h, hR=inB(tx+1,ty)?grid[ty][tx+1].h:c.h,
        hU=inB(tx,ty-1)?grid[ty-1][tx].h:c.h, hD=inB(tx,ty+1)?grid[ty+1][tx].h:c.h;
  const dh=c.h-(hL+hR+hU+hD)*0.25, m=Math.round(Math.max(-1,Math.min(1,dh*3.0))*14);
  base=shade(base,m); lt=shade(lt,m); dk=shade(dk,m);
  const seed=c.seed!=null?c.seed:(tx*7+ty*3)%97/97;
  // darken further the closer this tile sits to the true void edge, so the painted shoreline
  // ribbon (drawn first, underneath) stays the visibly darkest line and never gets buried —
  // tundra reads as rocky ground receding INLAND from that edge, not a wall built over it.
  if(c.shore){ base=shade(base,-10); lt=shade(lt,-8); dk=shade(dk,-12); }
  // IRREGULAR INK-WASH BLOB (not a 4-point diamond): radius wobbles around the tile centre at
  // many angles so adjacent rim tiles fuse into one organic painted mass instead of tracing the
  // isometric grid. SHRUNK from the old 1.92x (which over-overlapped into one solid puffy bank)
  // to 1.18x — enough to dissolve the diamond grid seams without erasing individual fractured
  // rock/ice forms into a single blob.
  const R=Math.max(hw,hh)*1.18, N=7;
  const blob=(px,py,rr,ph)=>{ g.beginPath();
    for(let i=0;i<=N;i++){ const a=ph+(i/N)*Math.PI*2, jr=rr*(0.56+0.56*vhash(seed,a*7.7+11)); 
      const bx=px+Math.cos(a)*jr, by=py+Math.sin(a)*jr*0.62;
      if(i===0)g.moveTo(bx,by); else g.lineTo(bx,by); }
    g.closePath(); };
  blob(cx,cy,R,seed*6.28);
  g.globalAlpha=AL; g.fillStyle=base; g.fill(); g.globalAlpha=1;
  const gw=g.createRadialGradient(cx,cy-hh*0.3,0,cx,cy,R*1.1); gw.addColorStop(0,lt); gw.addColorStop(0.6,base); gw.addColorStop(1,dk);
  g.globalAlpha=0.5*AL; blob(cx,cy,R,seed*6.28); g.fillStyle=gw; g.fill(); g.globalAlpha=1;
  // FRACTURE CRACKS: 2-3 hard ink lines radiating across the tile, jagged (not straight),
  // so the surface itself reads as shattered ice sheet rather than a smooth painted patch.
  g.globalAlpha=0.22*AL; g.strokeStyle='rgba(8,8,10,0.85)'; g.lineWidth=0.6*z; g.lineJoin='miter'; g.lineCap='round';
  const nCracks=AL>0.45?(1+((vhash(seed,303)*2)|0)):0;   // cracks only read well-inland; the rim stays a clean painted edge
  for(let ci=0;ci<nCracks;ci++){
    const a0=vhash(seed,ci*41+9)*6.28, len=R*(0.85+0.5*vhash(seed,ci*41+15));
    const midA=a0+(vhash(seed,ci*41+21)*2-1)*0.5, midR=len*(0.45+0.2*vhash(seed,ci*41+27));
    const mx=cx+Math.cos(midA)*midR, my=cy+Math.sin(midA)*midR*0.62;
    const ex=cx+Math.cos(a0)*len, ey=cy+Math.sin(a0)*len*0.62;
    g.beginPath(); g.moveTo(cx,cy); g.lineTo(mx,my); g.lineTo(ex,ey); g.stroke();
  }
  g.globalAlpha=0.16*AL; g.strokeStyle='rgba(180,196,210,0.55)'; g.lineWidth=0.55*z;   // thin cool moonrim facet — accent only, not a fill
  g.beginPath(); g.moveTo(cx-hw*0.28,cy-hh*0.05); g.lineTo(cx+hw*0.05,cy-hh*0.34); g.lineTo(cx+hw*0.3,cy); g.stroke(); g.globalAlpha=1;
  const sv=vhash(seed,77);                                                          // sparse Solana ice-crystal (inland only)
  if(sv>0.87&&AL>0.7){ g.globalAlpha=0.5*AL; g.fillStyle=(sv>0.94?'#14f195':'#9945ff');
    const ax=cx+(vhash(seed,12)*2-1)*hw*0.4, ay=cy+(vhash(seed,13)*2-1)*hh*0.4;
    g.beginPath(); g.moveTo(ax,ay-2*z); g.lineTo(ax+1.4*z,ay); g.lineTo(ax,ay+2*z); g.lineTo(ax-1.4*z,ay); g.closePath(); g.fill(); g.globalAlpha=1; }
  // soft mottled wash speckle (replaces the old hard-stroked seam) so the surface itself reads
  // painterly rather than tiled
  g.globalAlpha=0.12*AL; g.fillStyle=dk;
  for(let i=0;i<4;i++){ const a=vhash(seed,200+i)*2-1, b=vhash(seed,210+i)*2-1, mx=cx+a*hw*0.7, my=cy+b*hh*0.7;
    g.beginPath(); g.arc(mx,my,hw*0.22,0,7); g.fill(); }
  g.globalAlpha=1;
  if(c.shore) paintVoidEdge(g,tx,ty,c,cx,cy,hw,hh,z);   // jagged stalactite underside w/ frozen-rim accents
}
function drawTerrain(g,tx,ty,c,cx,cy,z,t){ const hw=TW/2*z,hh=TH/2*z,k=c.ter; let base,lt,dk; const P=VOID?AGEPAL[0]:agePal();
  if(VOID&&k===WATER){ if(c.frozen) drawFrozenWater(g,tx,ty,c,cx,cy,hw,hh,z,t); else if(c.spirit) return; return; }   // sea -> void; flowing mist drawn as ONE body in drawSpiritWaterBody (see rebuildWorld); terminus -> glacial ice
  if(VOID&&c.tundra){ drawTundra(g,tx,ty,c,cx,cy,z,t); return; }   // cold barren rim
  if(k===WATER){const deep=!c.coast; const sh=Math.sin((tx+ty)*0.6+t*0.0016)*4|0;
    base=shade(deep?'#374f63':'#587f88',sh);lt=deep?'#4a657a':'#7099a2';dk=deep?'#2a3e4f':'#46707a';
    // pull coastal water toward the blended shore colour so the beach line dissolves into a soft wash
    if(c.cbase && c.coast){ base=mix(base,c.cbase,0.42); lt=shade(base,12); dk=shade(base,-12); } }
  else if(k===SNOW){base='#dfe3e2';lt='#eef2f1';dk='#c2cac9';}
  else if(k===ROCK){base='#7e776b';lt='#928a7c';dk='#655f55';}
  else if(k===SAND){base='#bfb184';lt='#cdc093';dk='#a89a70';}   // soft beach tan, faintly green
  else if(k===BARE){base='#9a8f5a';lt='#aa9f68';dk='#827853';}   // muted khaki-olive earth/paths
  else if(k===GRASS2){base='#7d9b4d';lt='#8eac5c';dk='#62803a';}  // 若草 young grass green
  else if(k===FOREST){base='#5a7d3e';lt='#6c8f4e';dk='#476730';}  // deep foliage green
  else{base='#6f9144';lt='#80a254';dk='#577334';}
  // smoothed colour field (set in genMap) — softens type-to-type transitions before any shading
  if(k!==WATER && c.cbase){ base=c.cbase; lt=shade(base,22); dk=shade(base,-24); }
  // PER-AGE RETINT (Art Progression): shift this tile toward the active age's master palette so
  // every age-up reads as a new world. Moderate weight keeps form/silhouette legible.
  { const tgt=ageTarget(k,P);
    if(k===WATER){ base=mix(base,P.water,0.50); lt=shade(base,12); dk=shade(base,-14); }
    else if(tgt){ base=mix(base,tgt,0.50); if(P.dry>0)base=desatHex(base,P.dry*0.8); lt=shade(base,22); dk=shade(base,-24); } }
  // sculpted form: SOFT slope shading — 4-neighbour averaged gradient (no hard triangular facets)
  if(k!==WATER){ const hL=inB(tx-1,ty)?grid[ty][tx-1].h:c.h, hR=inB(tx+1,ty)?grid[ty][tx+1].h:c.h,
      hU=inB(tx,ty-1)?grid[ty-1][tx].h:c.h, hD=inB(tx,ty+1)?grid[ty+1][tx].h:c.h;
    // gentle directional read: shade toward the local average so neighbours blend instead of facet.
    // Wider dead-zone + halved gain so ordinary terrain noise never reads as a dimple grid —
    // only genuine, sustained slopes (hills, cliffs) pick up directional shading now.
    const dh=c.h-(hL+hR+hU+hD)*0.25, dhz=Math.abs(dh)<0.07?0:dh, m=Math.max(-2.5,Math.min(2.5,dhz*7)); base=shade(base,m);lt=shade(lt,m);dk=shade(dk,m); }
  // SELECTIVE COLOUR: terrain collapses to monochrome ink-wash (buildings/people/blossoms keep colour)
  if(VOID){ base=inkize(base); lt=inkize(lt); dk=inkize(dk); }
  const C=tileCorners(cx,cy,hw,hh,c.seed!=null?c.seed:(tx*7+ty*3)%97/97,tx,ty), T=C[0],R=C[1],B=C[2],L=C[3];
  // base organic fill
  g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(R[0],R[1]);g.lineTo(B[0],B[1]);g.lineTo(L[0],L[1]);g.closePath();g.fillStyle=base;g.fill();
  // WATERCOLOR WASH: world-space (not tile-diagonal) light gradient. The old per-tile T->B
  // gradient made every tile its own light source, so flat ground read as a grid of sunken
  // dimples. This instead reads a single shared light direction across the whole island —
  // tiles still vary subtly tile-to-tile, but never independently brighten/darken on a diagonal.
  if(P.wet>=0.7 && k!==WATER){ const wsy=cy-cam.y, lp=Math.max(0,Math.min(1,0.5+wsy*0.00055));
    const ltw=mix(lt,base,lp*0.55), dkw=mix(dk,base,(1-lp)*0.55);
    g.globalAlpha=0.16; g.fillStyle=mix(ltw,dkw,lp);
    g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(R[0],R[1]);g.lineTo(B[0],B[1]);g.lineTo(L[0],L[1]);g.closePath();g.fill();g.globalAlpha=1; }
  else { g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(R[0],R[1]);g.lineTo(L[0],L[1]);g.closePath();g.fillStyle=lt;g.globalAlpha=0.09;g.fill();g.globalAlpha=1;
    g.beginPath();g.moveTo(L[0],L[1]);g.lineTo(B[0],B[1]);g.lineTo(R[0],R[1]);g.closePath();g.fillStyle=dk;g.globalAlpha=0.10;g.fill();g.globalAlpha=1; }
  if(k!==WATER){ const sd=c.seed!=null?c.seed:(tx*7+ty*3)%97/97;
    const warm=vhash(Math.floor(tx*0.16)+sd*0.01,Math.floor(ty*0.16)+1)>0.5;
    g.globalAlpha=0.022; g.fillStyle=warm?lt:dk;
    g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(R[0],R[1]);g.lineTo(B[0],B[1]);g.lineTo(L[0],L[1]);g.closePath();g.fill();
    g.globalAlpha=1; }
  if(P.wet>=0.8 && k!==WATER && k!==SNOW){ paintLandEarly(g,cx,cy,hw,hh,z,base,lt,dk,c.seed!=null?c.seed:(tx*7+ty*3)%97/97);
    featherEdge(g,cx,cy,hw,hh,k,tx+1,ty,'R'); featherEdge(g,cx,cy,hw,hh,k,tx,ty+1,'L');
    g.globalAlpha=0.14; g.strokeStyle=base; g.lineWidth=hw*0.22; g.lineJoin='round';
    g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(R[0],R[1]);g.lineTo(B[0],B[1]);g.lineTo(L[0],L[1]);g.closePath();g.stroke(); g.globalAlpha=1; }
  // grid dissolve: feather the two back edges toward differing neighbours
  featherEdge(g,cx,cy,hw,hh,k,tx-1,ty,'L'); featherEdge(g,cx,cy,hw,hh,k,tx,ty-1,'R');
  // SUMI-E TERRAIN CONTOUR (Master Spec §1, layer 1): ink the silhouette of every terrain
  // FEATURE — the island rim into void and boundaries between different ground classes —
  // while leaving like-vs-like seamless so flat ground never reads as a wireframe grid.
  // Lives in the cached wBuf, so this costs nothing per frame.
  if(VOID && k!==WATER){
    const E=[[T,R,tx,ty-1],[R,B,tx+1,ty],[B,L,tx,ty+1],[L,T,tx-1,ty]];
    g.lineCap='round'; g.lineJoin='round';
    for(const[a,b,nx,ny]of E){ const vd=isVoidFace(nx,ny);
      const nIsWater=inB(nx,ny)&&grid[ny][nx].ter===WATER;
      // VOID faces: NO per-tile staircase outline — the smooth painted shoreline mass carries the
      // island's silhouette, so the rim stays clean instead of reading as blocky inked diamonds.
      if(vd) continue;
      if(!nIsWater) continue;
      g.strokeStyle='#140d07'; g.globalAlpha=0.5; g.lineWidth=1.4*z;
      g.beginPath(); g.moveTo(a[0],a[1]); g.lineTo(b[0],b[1]); g.stroke(); }
    g.globalAlpha=1; }
  // painterly shoreline on coastal land (wet sand / eroded cliffs / foam)
  if(k!==WATER && c.shore) paintCoast(g,tx,ty,c,cx,cy,hw,hh,z,t);
  if(VOID && k!==WATER && c.shore) paintVoidEdge(g,tx,ty,c,cx,cy,hw,hh,z);   // cliff into darkness + cool rim
  // floating-diorama shadow + low coastal mist
  if(k===WATER&&c.coast){ diamondPath(g,cx,cy,z*0.9); g.fillStyle=S.era<=1?'rgba(6,22,40,0.08)':'rgba(6,22,40,0.15)'; g.fill();
    // world-seeded sheen patch (not a per-tile ellipse stamp): position drawn from (tx,ty) so it
    // sits in one place on the body and only its brightness breathes, instead of every coastal
    // tile painting an identical oval that reads as a repeating motif when the camera pans.
    const sv=vhash(tx*3+1,ty*5+2);
    if(sv>0.45){ const mph=Math.sin((tx*0.5-ty*0.4)+t*0.0007);
      g.globalAlpha=(0.06+0.05*mph)*sv; g.fillStyle='#cdd6db';
      g.beginPath();g.ellipse(cx+(sv-0.5)*hw*0.6,cy-1.6*z+mph*2*z,hw*0.46,hh*0.32,0,0,7);g.fill(); g.globalAlpha=1; } }
  if(k===WATER){
    if(S.era<=1){ // CONTINUOUS SEA/LAKE: flat shared base so adjacent tiles merge seamlessly (no per-tile vertical seam)
      const sc=1.14, eT=[cx,cy-hh*sc],eR=[cx+hw*sc,cy],eB=[cx,cy+hh*sc],eL=[cx-hw*sc,cy];
      g.fillStyle=base; g.beginPath();g.moveTo(eT[0],eT[1]);g.lineTo(eR[0],eR[1]);g.lineTo(eB[0],eB[1]);g.lineTo(eL[0],eL[1]);g.closePath();g.fill();
      // soft sky sheen: single FIXED canvas-space gradient (not per-tile eT/eB), so every
      // tile in the body samples the identical gradient function and edges match exactly —
      // reads as one continuous overcast sky reflected on the surface, no seam at tile borders.
      g.globalAlpha=0.13; const skyG=g.createLinearGradient(0,0,0,VH);
      skyG.addColorStop(0,shade(lt,18)); skyG.addColorStop(0.45,base); skyG.addColorStop(1,shade(dk,-4));
      g.fillStyle=skyG; g.beginPath();g.moveTo(eT[0],eT[1]);g.lineTo(eR[0],eR[1]);g.lineTo(eB[0],eB[1]);g.lineTo(eL[0],eL[1]);g.closePath();g.fill(); g.globalAlpha=1;
      // granulated pigment mottling — soft, irregular pooling seeded purely from world tile
      // coords (tx,ty), placed off-centre and at varied radius/alpha per tile so the body reads
      // as hand-painted watercolor texture rather than a stamped per-tile ellipse repeating in a grid.
      const mv=vhash(tx*131+ty*17,5);
      if(mv>0.3){ const mx=cx+(vhash(tx,ty+1)*2-1)*hw*0.55, my=cy+(vhash(tx+2,ty)*2-1)*hh*0.4,
          mr=Math.max(hw,hh)*(0.4+0.5*vhash(tx+5,ty+5));
        const mg=g.createRadialGradient(mx,my,0,mx,my,mr);
        mg.addColorStop(0,hexA(shade(dk,-4),0.10+0.08*mv)); mg.addColorStop(1,hexA(dk,0));
        g.fillStyle=mg; g.beginPath();g.arc(mx,my,mr,0,7);g.fill(); }
      // WORLD-SPACE RIPPLE FIELD: short broken ink strokes seeded purely from world tile coords
      // (tx,ty), each tile drawing a different stroke angle/phase so the surface reads as one
      // continuous wind-rippled sheet rather than a stamped, repeating per-tile motif.
      const rs=vhash(tx*131+ty*17,5);
      if(rs>0.34){ const ang=(vhash(tx,ty+1)*2-1)*0.5, drift=Math.sin(tx*0.7+ty*0.5+t*0.0009)*1.4*z;
        const len=hw*(0.5+0.4*vhash(tx+3,ty*2)), rx=Math.cos(ang)*len, ry=Math.sin(ang)*len*0.4;
        g.globalAlpha=0.07+0.05*rs; g.strokeStyle=shade(lt,20); g.lineWidth=0.6*z; g.lineCap='round';
        g.beginPath();g.moveTo(cx-rx*0.5+drift,cy-ry*0.5);g.lineTo(cx+rx*0.5+drift,cy+ry*0.5);g.stroke(); g.globalAlpha=1; }
      // sparse sun glints — world-seeded so they don't reroll/shimmer as a grid when panning
      if(vhash(tx,ty)>0.86){ g.globalAlpha=0.35+0.25*Math.sin(t*0.004+tx*1.3+ty*0.7); g.fillStyle='rgba(255,250,228,0.85)';
        g.fillRect(cx-hw*0.3, cy-hh*0.18, 2.2*z, 1*z); g.globalAlpha=1; } }
    if(c.coast) paintCoast(g,tx,ty,c,cx,cy,hw,hh,z,t);   // turquoise shallow shelf hugging the land
    if(!(VOID&&c.coast)){
    // gentle current line — phase keyed to world coords only (no screen-space term) so it doesn't swim while panning
    g.strokeStyle='rgba(150,180,200,0.22)';g.lineWidth=0.7*z; const ph=Math.sin(tx*1.7+ty*1.3+t*0.003)*3;
    g.beginPath();g.moveTo(cx-9*z,cy+2*z+ph*z);g.lineTo(cx-1*z,cy-1*z+ph*z);g.stroke();
    if(c.coast){ const fo=Math.sin(tx*2.1-ty*1.7+t*0.004)*2, jt=(vhash(tx*5+ty,3)*2-1)*2;   // lapping foam, varied per tile
      g.strokeStyle='rgba(232,240,242,0.6)';g.lineWidth=1.05*z;
      g.beginPath();g.moveTo(cx-hw*0.62,cy-hh*0.18+fo*z);g.quadraticCurveTo(cx+jt*z,cy-hh*0.42,cx+hw*0.62,cy-hh*0.18-fo*z);g.stroke();
      g.strokeStyle='rgba(232,240,242,0.28)';g.lineWidth=0.63*z;
      g.beginPath();g.moveTo(cx-hw*0.5,cy-hh*0.05+fo*z);g.quadraticCurveTo(cx-jt*z,cy-hh*0.26,cx+hw*0.5,cy-hh*0.05-fo*z);g.stroke(); } }
    }
}
/* atmospheric depth: distance haze + drifting fog banks + melancholic wash (heaviest in early ages) */
function drawFog(){ const e=S.era||0, haze=e<=1?0.20:e<=3?0.13:0.07;
  const gr=ctx.createLinearGradient(0,0,0,VH*0.6); gr.addColorStop(0,'rgba(156,166,178,'+haze+')'); gr.addColorStop(1,'rgba(156,166,178,0)');
  ctx.fillStyle=gr; ctx.fillRect(0,0,VW,VH);
  const tt=fx*0.00016;
  for(let i=0;i<3;i++){ const fxp=(((i*0.37+tt)%1)*1.3-0.15)*VW, fyp=VH*(0.28+i*0.17), rad=ctx.createRadialGradient(fxp,fyp,0,fxp,fyp,VW*0.30);
    rad.addColorStop(0,'rgba(202,208,216,'+(0.075*(e<=1?1.5:1))+')'); rad.addColorStop(1,'rgba(202,208,216,0)');
    ctx.fillStyle=rad; ctx.fillRect(0,0,VW,VH); }
  if(e<=2){ ctx.fillStyle='rgba(58,70,94,0.05)'; ctx.fillRect(0,0,VW,VH); }
  // soft mist creeping in from the screen edges — the island dissolves into haze at the perimeter
  const ev = e<=1?0.22 : e<=4?0.13 : 0.05;
  const vg=ctx.createRadialGradient(VW*0.5,VH*0.46,Math.min(VW,VH)*0.32, VW*0.5,VH*0.5,Math.max(VW,VH)*0.72);
  vg.addColorStop(0,'rgba(208,214,222,0)'); vg.addColorStop(1,'rgba(208,214,222,'+ev+')');
  ctx.fillStyle=vg; ctx.fillRect(0,0,VW,VH);
}
/* ---- painterly coastline: turquoise shallow shelf, damp-sand beaches, eroded
   cliffs on high ground, soft animated foam. Per iso-edge so it hugs the real
   shoreline, not the tile box. Gated to the watercolor ages by callers. ---- */
function paintCoast(g,tx,ty,c,cx,cy,hw,hh,z,t){
  const land=c.ter!==WATER;
  const T=[cx,cy-hh],R=[cx+hw,cy],B=[cx,cy+hh],L=[cx-hw,cy];   // clean diamond corners
  const edges=[[tx,ty-1,T,R,1],[tx+1,ty,R,B,2],[tx,ty+1,B,L,3],[tx-1,ty,L,T,4]]; // edge -> facing neighbour
  for(const[nx,ny,A,Bp,id] of edges){
    const nWater = !inB(nx,ny) || (grid[ny][nx].ter===WATER && !grid[ny][nx].spirit && !grid[ny][nx].frozen);  // spirit/frozen banks get no sea foam
    if(VOID && (!inB(nx,ny) || isVoidFace(nx,ny))) continue;   // the void boundary is sealed by the painted ink-mass coastline only — no per-tile shelf lobes there
    const mx=(A[0]+Bp[0])/2, my=(A[1]+Bp[1])/2;                // edge midpoint (the water line)
    if(land){
      if(!nWater) continue;
      const ix=cx+(mx-cx)*0.42, iy=cy+(my-cy)*0.42;            // inward point toward tile centre
      if(c.h>0.36 && c.ter!==SAND){                            // high coastal ground -> eroded rock cliff
        g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(Bp[0],Bp[1]);g.lineTo(ix,iy);g.closePath();
        const gr=g.createLinearGradient(mx,my,ix,iy); gr.addColorStop(0,inkize('#4c473d')); gr.addColorStop(1,'rgba(76,71,61,0)');
        g.fillStyle=gr; g.globalAlpha=0.85; g.fill(); g.globalAlpha=1;
        g.fillStyle='rgba(38,34,28,0.5)';
        for(let i=0;i<2;i++){ const f=0.3+0.3*i; g.beginPath(); g.ellipse(mx+(ix-mx)*f,my+(iy-my)*f,1.6*z,1*z,0.6,0,7); g.fill(); }
      } else {                                                 // damp sand: wet at the water line -> dry inland
        g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(Bp[0],Bp[1]);g.lineTo(ix,iy);g.closePath();
        const gr=g.createLinearGradient(mx,my,ix,iy); gr.addColorStop(0,inkize('#ae986a')); gr.addColorStop(0.5,inkize('#ccb686')); gr.addColorStop(1,'rgba(204,182,134,0)');
        g.fillStyle=gr; g.globalAlpha=0.7; g.fill(); g.globalAlpha=1;
      }
      const ph=Math.sin((tx*1.9-ty*1.5)+t*0.004)*1.6, jt=(vhash(tx*5+ty,id)*2-1)*1.5;  // soft animated foam line
      g.lineCap='round';
      g.strokeStyle='rgba(238,244,246,0.55)'; g.lineWidth=0.98*z;
      g.beginPath(); g.moveTo(A[0],A[1]); g.quadraticCurveTo(mx+jt*z,my+ph*z,Bp[0],Bp[1]); g.stroke();
      g.strokeStyle='rgba(238,244,246,0.20)'; g.lineWidth=0.56*z;
      g.beginPath(); g.moveTo(A[0],A[1]); g.quadraticCurveTo(mx-jt*z,my-2*z+ph*z,Bp[0],Bp[1]); g.stroke();
      g.lineCap='butt';
    } else {
      if(!(inB(nx,ny)&&grid[ny][nx].ter!==WATER)) continue;    // water tile: shelf only on land-facing edges
      const ix=cx+(mx-cx)*0.58, iy=cy+(my-cy)*0.58;            // turquoise shallow fading to deep
      g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(Bp[0],Bp[1]);g.lineTo(ix,iy);g.closePath();
      const gr=g.createLinearGradient(mx,my,ix,iy); gr.addColorStop(0,'rgba(122,198,196,0.5)'); gr.addColorStop(1,'rgba(122,198,196,0)');
      g.fillStyle=gr; g.fill();
    }
  }
}
function drawRoad(g,tx,ty,cx,cy,z,br){ const hw=TW/2*z,hh=TH/2*z;
  if(br){ diamondPath(g,cx,cy,z); g.fillStyle=inkize('#37627e'); g.fill(); }
  // road surface diamond (slightly inset)
  diamondPath(g,cx,cy,z*0.96); g.fillStyle=inkize(br?'#7a5a34':'#9a8a6a'); g.fill();
  diamondPath(g,cx,cy,z*0.62); g.fillStyle=inkize(br?'#8a6a3a':'#b6a684'); g.fill();
  // connection arms toward road neighbours (lighter path)
  g.fillStyle=inkize(br?'#a07a44':'#c8bb98');
  const dirs=[[1,0],[0,1],[-1,0],[0,-1]];
  for(const[dx,dy]of dirs){ const nx=tx+dx,ny=ty+dy; if(inB(nx,ny)&&(grid[ny][nx].road||grid[ny][nx].civ===TOWN)){
    const ex=(dx-dy)*hw*0.5, ey=(dx+dy)*hh*0.5;
    g.beginPath(); g.moveTo(cx+ex*0.2,cy+ey*0.2); g.lineTo(cx+ex,cy+ey);
    g.lineTo(cx+ex+ (dy?hw*0.18:0), cy+ey+(dx?hh*0.18:0)); g.closePath(); g.fill();
  }}
  // centre dashes
  g.fillStyle=inkize(br?'#d8b46a':'#e6dcc0'); g.fillRect(cx-1*z,cy-1*z,2*z,2*z);
}
function drawWire(g,tx,ty,cx,cy,z){ g.strokeStyle='#3a2a1c'; g.lineWidth=0.98*z;
  const poleTop=cy-12*z; g.beginPath(); g.moveTo(cx,cy); g.lineTo(cx,poleTop); g.stroke();
  g.strokeStyle='#5a4a3a'; g.beginPath(); g.moveTo(cx-5*z,poleTop+2*z); g.lineTo(cx+5*z,poleTop+2*z); g.stroke();
  g.strokeStyle='rgba(20,20,20,0.5)'; for(const[dx,dy]of [[1,0],[0,1]]){ const nx=tx+dx,ny=ty+dy;
    if(inB(nx,ny)&&grid[ny][nx].wire){ const [ncx,ncy]=[cx+(dx-dy)*TW/2*z,cy+(dx+dy)*TH/2*z];
      g.beginPath(); g.moveTo(cx,poleTop+2*z); g.quadraticCurveTo((cx+ncx)/2,(poleTop+ncy-10*z)/2+4*z,ncx,ncy-12*z); g.stroke(); } }
}
/* tiled east-asian building. st = {h,roof,wall,post,rh,ov,modern} */
function vhash(seed,salt){ const n=Math.sin((seed*97.13+1.7)*127.1+salt*311.7)*43758.5453; return n-Math.floor(n); }
function envNight(){ return (typeof ENV!=='undefined')?ENV.night:0; }
function litWin(g,x,y,w,h,night,base){ if(night>0.34){ const a=Math.min(1,(night-0.34)/0.45); g.fillStyle='rgba(255,212,118,'+(0.5+0.45*a)+')'; }
  else g.fillStyle=base; g.fillRect(x,y,w,h); }
function drawProps(g,cx,cy,z,st,wallH,hw,night){ if(!st.props)return; const top=cy-wallH;
  for(const p of st.props){
    if(p==='chimney'){ g.fillStyle='#5a4030'; g.fillRect(cx+hw*0.32,top-7*z,3*z,9*z); g.fillStyle='rgba(170,170,170,0.35)'; g.beginPath();g.arc(cx+hw*0.32+1.5*z,top-9*z,3*z,0,7);g.fill(); }
    else if(p==='lantern'){ g.fillStyle='#3a2a1c'; g.fillRect(cx-hw-3*z,top+wallH*0.3,0.8*z,3*z); g.fillStyle=night>0.34?'#ffcf6a':'#c0392b'; g.beginPath();g.arc(cx-hw-2.6*z,top+wallH*0.3+4*z,2.4*z,0,7);g.fill(); }
    else if(p==='banner'){ g.fillStyle=st.neon||'#c0392b'; g.fillRect(cx-hw*0.5,top+2*z,2.6*z,wallH*0.66); g.fillStyle=shade(st.neon||'#c0392b',30); g.fillRect(cx-hw*0.5,top+2*z,2.6*z,2*z); }
    else if(p==='garden'){ g.fillStyle='#3f8a4a'; g.beginPath();g.ellipse(cx,top-1*z,6*z,3*z,0,0,7);g.fill(); g.fillStyle='#e85a8a';g.fillRect(cx-3*z,top-2.5*z,1.5*z,1.5*z); g.fillStyle='#e8c24a';g.fillRect(cx+2*z,top-2*z,1.5*z,1.5*z); }
    else if(p==='tank'){ g.fillStyle='#8a8a8a'; g.fillRect(cx+2*z,top-8*z,7*z,7*z); g.fillStyle='#6a6a6a';g.fillRect(cx+2*z,top-8*z,7*z,2.2*z); g.fillStyle='#4a4a4a';g.fillRect(cx+3*z,top-1*z,1.4*z,2*z);g.fillRect(cx+7*z,top-1*z,1.4*z,2*z); }
    else if(p==='antenna'){ g.strokeStyle=st.neon||'#9aa3ad'; g.lineWidth=0.98*z; g.beginPath();g.moveTo(cx,top-2*z);g.lineTo(cx,top-15*z);g.stroke();
      g.fillStyle=st.neon||'#e23a18';g.beginPath();g.arc(cx,top-15*z,1.8*z,0,7);g.fill(); if(night>0.3){g.fillStyle='rgba(255,80,80,'+(0.4+0.4*Math.sin(fx*0.006))+')';g.beginPath();g.arc(cx,top-15*z,3*z,0,7);g.fill();} }
    else if(p==='sign'){ g.fillStyle=night>0.34?(st.neon||'#ff5a8a'):shade(st.neon||'#b0407a',-10); g.fillRect(cx-hw*0.34,top+3*z,5.5*z,3.4*z);
      if(night>0.34){g.fillStyle='rgba(255,120,170,0.3)';g.fillRect(cx-hw*0.34-1*z,top+2*z,7.5*z,5.4*z);} }
    else if(p==='awning'){ // striped shop awning projecting over the storefront (front-right face)
      const ay=cy-wallH+9*z; const col=st.roof;
      g.fillStyle=shade(col,-10); g.beginPath();g.moveTo(cx+1*z,ay);g.lineTo(cx+hw+3*z,ay+hw*0.5*0.5);g.lineTo(cx+hw+3*z,ay+hw*0.5*0.5+4*z);g.lineTo(cx+1*z,ay+5*z);g.closePath();g.fill();
      g.fillStyle=shade(col,25); for(let i=0;i<4;i++){const f=i/4; g.beginPath();g.moveTo(cx+1*z+(hw+2*z)*f,ay+ (hw*0.25)*f);g.lineTo(cx+1*z+(hw+2*z)*(f+0.12),ay+(hw*0.25)*(f+0.12));g.lineTo(cx+1*z+(hw+2*z)*(f+0.12),ay+(hw*0.25)*(f+0.12)+4.6*z);g.lineTo(cx+1*z+(hw+2*z)*f,ay+(hw*0.25)*f+4.8*z);g.closePath();g.fill();} }
    else if(p==='kanban'){ // vertical shop signboard above the roofline
      const sx=cx+hw*0.42, sy=top-2*z; g.fillStyle='#3a2a1c'; g.fillRect(sx-0.7*z,sy-9*z,1.4*z,11*z);
      const sc=st.neon||['#c0392b','#2c5aa0','#1f7a3a','#8a5a1a'][(st.vR*4)|0];
      g.fillStyle=sc; g.fillRect(sx-3.2*z,sy-17*z,6.4*z,10*z); g.fillStyle=shade(sc,-26);g.fillRect(sx-3.2*z,sy-17*z,6.4*z,10*z); g.strokeStyle='#efe2c4';g.lineWidth=0.49*z;g.strokeRect(sx-3.2*z,sy-17*z,6.4*z,10*z);
      g.fillStyle='#efe2c4'; g.fillRect(sx-1.6*z,sy-15.4*z,3.2*z,1.4*z); g.fillRect(sx-1.6*z,sy-13*z,3.2*z,1.2*z); g.fillRect(sx-1.6*z,sy-11*z,3.2*z,1.6*z);
      if(night>0.34&&st.neon){g.fillStyle='rgba(20,241,149,0.3)';g.fillRect(sx-4.6*z,sy-18.4*z,9.2*z,12.8*z);} }
    else if(p==='lantern2'){ for(const sgn of [-1,1]){ const lx=cx+sgn*(hw*0.62)+ (sgn<0?-1*z:1*z), ly=cy-wallH+11*z;
      g.strokeStyle='#2a1c12';g.lineWidth=0.49*z;g.beginPath();g.moveTo(lx,ly-4*z);g.lineTo(lx,ly-1*z);g.stroke();
      g.fillStyle=night>0.34?'#ffcf6a':'#c0392b'; g.beginPath();g.ellipse(lx,ly+1.5*z,2.2*z,2.8*z,0,0,7);g.fill();
      g.strokeStyle='#7a1f16';g.lineWidth=0.35*z;g.beginPath();g.moveTo(lx-2*z,ly+1.5*z);g.lineTo(lx+2*z,ly+1.5*z);g.stroke();
      if(night>0.34){g.fillStyle='rgba(255,200,110,0.4)';g.beginPath();g.arc(lx,ly+1.5*z,4.5*z,0,7);g.fill();} } }
    else if(p==='smokestack'){ const sx=cx+hw*0.36, by=top+2*z; g.fillStyle='#6a4a38'; g.fillRect(sx-2.2*z,by-16*z,4.4*z,18*z);
      g.fillStyle='#8a5a44';g.fillRect(sx-2.2*z,by-16*z,1.4*z,18*z); g.fillStyle='#4a3328';g.fillRect(sx-2.2*z,by-16*z,4.4*z,2*z); g.fillStyle='#c0503a';g.fillRect(sx-2.2*z,by-13*z,4.4*z,1.6*z);
      const pf=(fx*0.004); for(let i=0;i<3;i++){const yy=by-17*z-i*5*z-(pf%5)*z, r=(2.2+i*1.1)*z; g.fillStyle='rgba(150,150,150,'+(0.4-i*0.1)+')'; g.beginPath();g.arc(sx+Math.sin(pf+i)*2*z,yy,r,0,7);g.fill();} }
    else if(p==='brickstack'){ const sx=cx+hw*0.34, by=top+2*z, ht=26*z;     // tall industrial brick chimney
      g.fillStyle='#7c3a28'; g.fillRect(sx-2.4*z,by-ht,4.8*z,ht+2*z); g.fillStyle='#94493a';g.fillRect(sx-2.4*z,by-ht,1.6*z,ht+2*z);
      g.strokeStyle='rgba(40,20,14,0.5)';g.lineWidth=0.35*z; for(let r=0;r<9;r++){const yy=by+1*z-r*3*z; g.beginPath();g.moveTo(sx-2.4*z,yy);g.lineTo(sx+2.4*z,yy);g.stroke();}
      g.fillStyle='#5a2a1e';g.fillRect(sx-3*z,by-ht-1.5*z,6*z,2.4*z);       // cap
      const pf=(fx*0.0035); for(let i=0;i<4;i++){const yy=by-ht-3*z-i*6*z-(pf%6)*z, r=(2.4+i*1.3)*z; g.fillStyle='rgba(160,160,160,'+(0.45-i*0.09)+')'; g.beginPath();g.arc(sx+Math.sin(pf+i)*2.4*z,yy,r,0,7);g.fill();} }
    else if(p==='kiln'){ const sx=cx+hw*0.3, by=top+2*z;                     // potter's/charcoal kiln dome
      g.fillStyle='#6a5038'; g.beginPath();g.ellipse(sx,by-1*z,5.5*z,4.5*z,0,Math.PI,0,true);g.fill(); g.fillStyle='#7a5e44';g.beginPath();g.ellipse(sx-1.5*z,by-2*z,3*z,2.6*z,0,Math.PI,0,true);g.fill();
      g.fillStyle='#2a1a12';g.beginPath();g.ellipse(sx,by-0.5*z,1.6*z,1.2*z,0,0,7);g.fill(); g.fillStyle=night>0.3?'rgba(255,140,40,0.8)':'rgba(220,90,20,0.6)';g.beginPath();g.arc(sx,by-0.5*z,1*z,0,7);g.fill();
      const pf=(fx*0.004); for(let i=0;i<2;i++){const yy=by-7*z-i*4*z-(pf%4)*z; g.fillStyle='rgba(120,110,100,'+(0.4-i*0.12)+')'; g.beginPath();g.arc(sx+2*z+Math.sin(pf+i)*1.5*z,yy,(1.8+i)*z,0,7);g.fill();} }
    else if(p==='watertower'){ const sx=cx+hw*0.28, by=top-1*z;             // rooftop water tower on a frame
      g.strokeStyle='#4a4a50';g.lineWidth=0.63*z; g.beginPath();g.moveTo(sx-4*z,by);g.lineTo(sx-2.6*z,by-7*z);g.moveTo(sx+4*z,by);g.lineTo(sx+2.6*z,by-7*z);g.moveTo(sx-4*z,by);g.lineTo(sx+2.6*z,by-7*z);g.moveTo(sx+4*z,by);g.lineTo(sx-2.6*z,by-7*z);g.stroke();
      g.fillStyle='#7d8690'; g.beginPath();g.ellipse(sx,by-8*z,4*z,2*z,0,0,7);g.fillRect(sx-4*z,by-8*z,8*z,5*z);g.fill(); g.fillStyle='#5f676f';g.fillRect(sx-4*z,by-4*z,8*z,1.4*z);
      g.fillStyle='#9aa3ad';g.beginPath();g.ellipse(sx,by-8.5*z,4*z,2*z,0,0,7);g.fill(); g.fillStyle='#5a3a2a';g.beginPath();g.moveTo(sx-3*z,by-3*z);g.lineTo(sx+3*z,by-3*z);g.lineTo(sx,by+0.5*z);g.closePath();g.fill(); }
    else if(p==='goods'){ // scattered market crates/baskets/jars along the open front, world-seeded so they hold still
      const _u=(cx-cam.x)/z,_v=(cy-cam.y)/z, gWX=Math.round(_u/TW+_v/TH),gWY=Math.round(_v/TH-_u/TW), gseed=Math.abs((gWX*5+gWY*9)|0);
      const gy=cy+TH*0.42*z;
      for(let i=0;i<5;i++){ const f=(i-2)/2.2, gx=cx+f*hw*0.75, jb=vhash(gseed,i*3)*1.2*z, kind=(vhash(gseed,i*5+1)*4)|0;
        if(kind===0){ g.fillStyle='#8a6a3a'; g.fillRect(gx-2.6*z,gy-4*z-jb,5.2*z,4*z); g.fillStyle='#6a4a28';g.fillRect(gx-2.6*z,gy-4*z-jb,5.2*z,1*z); } // crate
        else if(kind===1){ g.fillStyle='#a0773a'; g.beginPath();g.ellipse(gx,gy-2.2*z-jb,2.8*z,2.3*z,0,0,7);g.fill(); g.strokeStyle='#5a3e1e';g.lineWidth=0.42*z;g.beginPath();g.moveTo(gx-2.6*z,gy-3.2*z-jb);g.lineTo(gx+2.6*z,gy-3.2*z-jb);g.stroke(); } // basket
        else if(kind===2){ g.fillStyle='#7a8a6a'; g.beginPath();g.ellipse(gx,gy-2.6*z-jb,1.9*z,3*z,0,0,7);g.fill(); g.fillStyle='#5a6a4a';g.fillRect(gx-1.3*z,gy-5.2*z-jb,2.6*z,1*z); } // jar
        else { g.fillStyle='#caa23a'; g.beginPath();g.ellipse(gx,gy-1.6*z-jb,2.6*z,1.7*z,0,0,7);g.fill(); } } } // produce pile
    else if(p==='torii_small'){ const sx=cx, by=cy+hw*0.42*(TH/TW); // small freestanding gate in front of the structure (hh derived from hw via tile aspect)
      g.strokeStyle='#a03020';g.lineWidth=1.4*z; g.beginPath();g.moveTo(sx-5*z,by);g.lineTo(sx-5*z,by-9*z);g.moveTo(sx+5*z,by);g.lineTo(sx+5*z,by-9*z);g.stroke();
      g.strokeStyle='#a03020';g.lineWidth=2*z; g.beginPath();g.moveTo(sx-6.5*z,by-9*z);g.lineTo(sx+6.5*z,by-9*z);g.stroke();
      g.strokeStyle='#7a2418';g.lineWidth=1.1*z; g.beginPath();g.moveTo(sx-5.6*z,by-6.8*z);g.lineTo(sx+5.6*z,by-6.8*z);g.stroke(); }
    else if(p==='scrollstack'){ const sx=cx+hw*0.32, by=top+1*z; // stacked archive document boxes near entrance
      for(let i=0;i<3;i++){ const bw=6.5*z-i*0.6*z, bh=2.6*z, by2=by-i*bh;
        g.fillStyle=shade('#caa23a',-6-i*6); g.fillRect(sx-bw/2,by2-bh,bw,bh);
        g.strokeStyle='#7a5a1e';g.lineWidth=0.35*z; g.strokeRect(sx-bw/2,by2-bh,bw,bh);
        g.fillStyle='#efe2c4'; g.fillRect(sx-bw*0.18,by2-bh+0.5*z,bw*0.36,1.1*z); } }
  }
}
/* ── era-specific building helpers ── */
function glassFace(g,O,U,V,nu,nv,night){ const P=(u,v)=>[O[0]+u*(U[0]-O[0])+v*(V[0]-O[0]),O[1]+u*(U[1]-O[1])+v*(V[1]-O[1])];
  for(let i=0;i<nu;i++)for(let j=0;j<nv;j++){ const a=P(i/nu+0.06,j/nv+0.05),b=P((i+1)/nu-0.06,j/nv+0.05),c=P((i+1)/nu-0.06,(j+1)/nv-0.05),d=P(i/nu+0.06,(j+1)/nv-0.05);
    const lit=night>0.3&&vhash(i*3.1+j*5.7,i+j*2)>0.55; g.fillStyle= lit?'#ffe7a0':(night>0.3?'#23415e':'#86bcdc');
    g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineTo(c[0],c[1]);g.lineTo(d[0],d[1]);g.closePath();g.fill(); } }
/* a stallkeeper standing/seated behind their counter — fixed to the stall (not a residents[] agent),
   so it costs nothing in simulation; just gives commerce buildings an occupant instead of reading
   as an abandoned stand. Reuses the same proportions/values as the walking-pedestrian figure. */
function drawVendorFigure(g,cx,cy,z,skin,cloth){
  g.fillStyle=shade(cloth,-22); g.beginPath(); g.ellipse(cx,cy-2.6*z,2.3*z,3.1*z,0,0,7); g.fill();          // torso/shoulders, in shadow under the awning
  g.fillStyle=cloth; g.beginPath(); g.ellipse(cx-0.4*z,cy-2.8*z,2*z,2.7*z,0,0,7); g.fill();                  // lit half
  g.fillStyle=skin; g.beginPath(); g.arc(cx,cy-6*z,1.5*z,0,7); g.fill();                                     // head
  g.fillStyle=shade(cloth,10); g.beginPath(); g.ellipse(cx+1.6*z,cy-3.6*z,0.7*z,1.6*z,0.5,0,7); g.fill();   // raised arm, gesturing toward wares
  g.fillStyle=skin; g.beginPath(); g.arc(cx+2.3*z,cy-4.6*z,0.6*z,0,7); g.fill();                             // hand
}
function drawTradeMark(g,x,y,z,t){ g.fillStyle='#efe2c4';
  if(t===0){ g.beginPath();g.arc(x,y,1.5*z,0,7);g.fill(); g.fillStyle='#b5532f';g.beginPath();g.arc(x,y,0.7*z,0,7);g.fill(); }      // sake cup
  else if(t===1){ g.beginPath();g.ellipse(x,y,1*z,1.9*z,0.6,0,7);g.fill(); }                                                       // tea leaf
  else if(t===2){ g.beginPath();g.ellipse(x-0.4*z,y,1.8*z,1*z,0,0,7);g.fill(); g.beginPath();g.moveTo(x+1.4*z,y);g.lineTo(x+2.8*z,y-1.1*z);g.lineTo(x+2.8*z,y+1.1*z);g.closePath();g.fill(); } // fish
  else if(t===3){ g.fillRect(x-1.7*z,y-1.2*z,3.4*z,2.4*z); g.fillStyle='#b5532f';g.fillRect(x-1.7*z,y-0.3*z,3.4*z,0.6*z); }         // cloth roll
  else if(t===4){ for(let i=-1;i<=1;i++)g.fillRect(x+i*1.2*z-0.3*z,y-1.7*z,0.6*z,3.4*z); }                                          // rice grain
  else { g.fillRect(x-0.5*z,y-1.7*z,1*z,3.4*z); g.fillRect(x-1.7*z,y-0.5*z,3.4*z,1*z); } }                                          // medicine cross
function drawStall(g,cx,cy,z,st){ const hh=TH/2*z; shadowEllipse(g,cx,cy+hh*0.3,TW*0.32,z); const tc=st.noren||'#b5532f', ph=11*z;
  const _u=(cx-cam.x)/z,_v=(cy-cam.y)/z, WX=Math.round(_u/TW+_v/TH),WY=Math.round(_v/TH-_u/TW), vseed=Math.abs((WX*7+WY*11)|0);  // world-stable seed for the vendor's stable look
  g.fillStyle='#6a4a2a'; for(const[px,py]of [[-7,-2],[7,-2],[-7,3.5],[7,3.5]]) g.fillRect(cx+px*z-0.7*z,cy+py*z-ph,1.4*z,ph);
  drawVendorFigure(g,cx-3*z,cy+0.2*z,z,SKIN[vseed%SKIN.length],KIM[(vseed+5)%KIM.length]);                                          // stallkeeper, drawn before the counter so it reads as standing behind it
  g.fillStyle='#8a6a3a'; g.fillRect(cx-8*z,cy+1*z,16*z,3*z); g.fillStyle='#6a4a28';g.fillRect(cx-8*z,cy+4*z,16*z,1.4*z);            // counter
  g.fillStyle='#a06a30';g.beginPath();g.arc(cx-4*z,cy+0.6*z,1.6*z,0,7);g.fill(); g.fillStyle=shade(tc,12);g.beginPath();g.arc(cx,cy+0.4*z,1.5*z,0,7);g.fill(); g.fillStyle='#caa23a';g.beginPath();g.arc(cx+4*z,cy+0.6*z,1.5*z,0,7);g.fill();
  const ay=cy-ph; g.fillStyle=tc; g.beginPath();g.moveTo(cx-9*z,ay+2*z);g.lineTo(cx+9*z,ay+2*z);g.lineTo(cx+7*z,ay-3.5*z);g.lineTo(cx-7*z,ay-3.5*z);g.closePath();g.fill();
  g.fillStyle=shade(tc,30); for(let i=0;i<5;i+=2){const f=i/5; g.beginPath();g.moveTo(cx-9*z+18*z*f,ay+2*z);g.lineTo(cx-9*z+18*z*(f+0.2),ay+2*z);g.lineTo(cx-7*z+14*z*(f+0.2),ay-3.5*z);g.lineTo(cx-7*z+14*z*f,ay-3.5*z);g.closePath();g.fill();}
  g.fillStyle=shade(tc,-16); g.fillRect(cx-9*z,ay+2*z,18*z,1.6*z); drawTradeMark(g,cx,ay-0.6*z,z,st.trade); }
function drawMachiya(g,cx,cy,z,st,wallH){ const tc=st.noren||'#b5532f';
  const hw=TW/2*z,hh=TH/2*z, gY=x=>cy+hh-hh*((x-cx)/hw);                          // ground y on the right face
  const sx1=cx+1*z, sx2=cx+16*z, storeH=Math.min(wallH-6*z,16*z);
  const gb=x=>gY(x)-2*z, tp=x=>gY(x)-2*z-storeH;                                  // sill + lintel, both sloped to ground
  const b1=gb(sx1),b2=gb(sx2),t1=tp(sx1),t2=tp(sx2);
  g.fillStyle='#3a2a1c'; g.beginPath();g.moveTo(sx1,t1);g.lineTo(sx2,t2);g.lineTo(sx2,b2);g.lineTo(sx1,b1);g.closePath();g.fill();   // recessed shop interior, grounded
  g.strokeStyle='#8a6638';g.lineWidth=0.42*z;                                                                                       // koshi lattice down to each column's ground
  for(let i=0;i<8;i++){ const lx=sx1+0.7*z+i*1.95*z; if(lx>sx2)break; g.beginPath();g.moveTo(lx,tp(lx)+1.6*z);g.lineTo(lx,gb(lx));g.stroke(); }
  g.fillStyle='#7a5a36'; g.beginPath();g.moveTo(sx1,b1);g.lineTo(sx2,b2);g.lineTo(sx2,b2+1.8*z);g.lineTo(sx1,b1+1.8*z);g.closePath();g.fill(); // raised wooden threshold (agarikamachi)
  for(const nx of [cx+8*z,cx+11.6*z]){ const ny=tp(nx); g.fillStyle=tc; g.fillRect(nx,ny,3*z,4*z); g.fillStyle=shade(tc,26); g.fillRect(nx,ny,3*z,1*z); } // split noren at the lintel
  const ky=tp(cx+7.5*z)-4.6*z;                                                                                                       // kanban signboard just above the lintel
  g.fillStyle=shade(tc,-12); g.fillRect(cx-1*z,ky,17*z,3.8*z); g.strokeStyle='#efe2c4';g.lineWidth=0.42*z;g.strokeRect(cx-1*z,ky,17*z,3.8*z);
  drawTradeMark(g,cx+7.5*z,ky+1.9*z,z,st.trade);
  const cgy=gb(cx+4.3*z); g.fillStyle='#a07a3a'; g.fillRect(cx+2.5*z,cgy-3*z,3.6*z,3*z); g.fillStyle='#8a6630';g.fillRect(cx+2.5*z,cgy-3*z,3.6*z,1*z); } // goods crate on the ground
/* tiled east-asian building w/ stories, props, tiers, night glow */
function drawBuilding(g,cx,cy,z,st){ const hw=TW/2*z,hh=TH/2*z,wallH=(st.h||20)*z; const night=envNight();
  // STABLE WOBBLE SEED — invert s2() to recover this building's integer tile (WX,WY). All hand-painted
  // wobble/granulation seeds derive from world position, NOT screen cx,cy, so the silhouette is identical
  // every frame and roofs no longer shimmer when the camera pans or zooms. Math.round snaps off float drift
  // (vhash uses sin() of a large number, so it's hypersensitive to sub-pixel jitter in its seed).
  const _u=(cx-cam.x)/z, _v=(cy-cam.y)/z, WX=Math.round(_u/TW+_v/TH), WY=Math.round(_v/TH-_u/TW);
  shadowEllipse(g,cx,cy+hh*0.4,TW*0.42,z);
  let wall=st.wall||'#ece0c4'; if(night>0.3)wall=shade(wall,-Math.round(night*24));
  const wallD=shade(wall,-34),post=st.post||'#7a2d24';
  g.beginPath();g.moveTo(cx-hw,cy);g.lineTo(cx,cy+hh);g.lineTo(cx,cy+hh-wallH);g.lineTo(cx-hw,cy-wallH);g.closePath();g.fillStyle=wallD;g.fill();
  g.beginPath();g.moveTo(cx,cy+hh);g.lineTo(cx+hw,cy);g.lineTo(cx+hw,cy-wallH);g.lineTo(cx,cy+hh-wallH);g.closePath();g.fillStyle=wall;g.fill();
  // watercolor tooth on the plaster: pigment-settling granulation so walls read painted, not flat
  // vector. wobble:0 keeps the structural corners exact (posts/windows/foundation stay aligned).
  if(!LOD && z>0.55){ const sd=WX*0.7+WY*1.3;
    paintFill(g,[[cx-hw,cy],[cx,cy+hh],[cx,cy+hh-wallH],[cx-hw,cy-wallH]],{z,seed:sd,wobble:0,ink:false,grain:5,fill:wallD,lt:shade(wallD,12),dk:shade(wallD,-22)});
    paintFill(g,[[cx,cy+hh],[cx+hw,cy],[cx+hw,cy-wallH],[cx,cy+hh-wallH]],{z,seed:sd+9,wobble:0,ink:false,grain:5,fill:wall,lt:shade(wall,14),dk:shade(wall,-24)}); }
  if(!st.flat||st.modern){ const fb=3.2*z, ston=st.modern?'#8a8a90':'#9a8f78';
    g.fillStyle=shade(ston,-18); g.beginPath();g.moveTo(cx-hw,cy);g.lineTo(cx,cy+hh);g.lineTo(cx,cy+hh-fb);g.lineTo(cx-hw,cy-fb);g.closePath();g.fill();
    g.fillStyle=ston; g.beginPath();g.moveTo(cx,cy+hh);g.lineTo(cx+hw,cy);g.lineTo(cx+hw,cy-fb);g.lineTo(cx,cy+hh-fb);g.closePath();g.fill(); }
  g.fillStyle=post; g.fillRect(cx-1.5*z,cy+hh-wallH,3*z,wallH);
  g.fillStyle=shade(post,-20); g.fillRect(cx-hw,cy-wallH,2.5*z,wallH); g.fillStyle=shade(post,12); g.fillRect(cx+hw-2.5*z,cy-wallH,2.5*z,wallH);
  // wood-grain striations on the corner posts — thin uneven strokes, world-seeded so they hold
  // still under pan/zoom. Same gate as wall granulation: invisible cost at LOD/far zoom.
  if(!LOD && z>0.55){ const gsd=WX*0.41+WY*0.67;
    g.strokeStyle='rgba(0,0,0,0.16)'; g.lineWidth=Math.max(0.4,0.5*z);
    for(let i=0;i<3;i++){ const gf=vhash(gsd,i)*0.7+0.12, gx=cx-1.5*z+gf*3*z, jx=(vhash(gsd+i,2)-0.5)*0.6*z;
      g.beginPath(); g.moveTo(gx,cy+hh-wallH+1*z); g.lineTo(gx+jx,cy+hh-wallH*0.3); g.lineTo(gx,cy-wallH+1*z); g.stroke(); } }
  if(st.corrugated){ g.strokeStyle='rgba(0,0,0,0.12)';g.lineWidth=0.42*z;       // corrugated metal ribs
    for(let i=1;i<7;i++){const f=i/7; g.beginPath();g.moveTo(cx+hw*f,cy+hh*f-1);g.lineTo(cx+hw*f,cy+hh*f-wallH);g.stroke();
      g.beginPath();g.moveTo(cx-hw*f,cy+hh*f-1);g.lineTo(cx-hw*f,cy+hh*f-wallH);g.stroke();} }
  if(st.glassTower){ // glass curtain-wall tower
    const flr=Math.max(4,Math.min(9,st.stories||5));
    g.fillStyle=shade(wall,-30); g.beginPath();g.moveTo(cx-hw,cy);g.lineTo(cx,cy+hh);g.lineTo(cx,cy+hh-wallH);g.lineTo(cx-hw,cy-wallH);g.closePath();g.fill();
    g.beginPath();g.moveTo(cx,cy+hh);g.lineTo(cx+hw,cy);g.lineTo(cx+hw,cy-wallH);g.lineTo(cx,cy+hh-wallH);g.closePath();g.fill();
    glassFace(g,[cx,cy+hh],[cx+hw,cy],[cx,cy+hh-wallH],4,flr,night);     // right face glass
    glassFace(g,[cx,cy+hh],[cx-hw,cy],[cx,cy+hh-wallH],4,flr,night);     // left face glass
    if(st.neon){ g.strokeStyle=st.neon;g.lineWidth=0.98*z; g.beginPath();g.moveTo(cx,cy+hh-wallH);g.lineTo(cx+hw,cy-wallH);g.moveTo(cx,cy+hh-wallH);g.lineTo(cx-hw,cy-wallH);g.stroke(); }
  } else {
  // ENTRANCE — sheared to sit ON the isometric ground line. gY(x) gives the ground y for any
  // x on the right (lit) wall face; the door is a parallelogram from that ground line up, so it
  // reads as a real doorway people walk into (was a flat-bottomed rect floating mid-wall = window).
  const gY=x=>cy+hh-hh*((x-cx)/hw);
  if(st.machiya){ drawMachiya(g,cx,cy,z,st,wallH); }
  else {
    const dx1=cx+6.5*z, dx2=cx+15.5*z, dvar=vhash(WX*2.3+WY*1.7,31);
    const bL=gY(dx1)-2.2*z, bR=gY(dx2)-2.2*z;             // sit on the stone sill, just above ground
    const dh=Math.min(wallH-3.5*z, st.modern?15*z:14*z);  // door height
    const tLy=bL-dh, tRy=bR-dh;                            // lintel (sloped, parallel to ground)
    g.fillStyle=st.modern?'#1c2630':'#241a12';             // recessed dark opening
    g.beginPath();g.moveTo(dx1,tLy);g.lineTo(dx2,tRy);g.lineTo(dx2,bR);g.lineTo(dx1,bL);g.closePath();g.fill();
    if(st.modern){                                          // glass/metal entrance: sheen + handle bar
      g.fillStyle='rgba(150,200,225,0.20)'; g.beginPath();g.moveTo(dx1,tLy);g.lineTo(dx2,tRy);g.lineTo(dx2,bR);g.lineTo(dx1,bL);g.closePath();g.fill();
      const mx=(dx1+dx2)/2; g.strokeStyle='rgba(190,225,245,0.5)';g.lineWidth=0.7*z; g.beginPath();g.moveTo(mx,(tLy+tRy)/2+dh*0.28);g.lineTo(mx,bL-2*z);g.stroke();
    } else if(dvar<0.5){                                    // split sliding shoji — paper panels + mullion
      g.fillStyle=night>0.3?'rgba(245,228,170,0.46)':'rgba(232,220,192,0.30)';
      g.beginPath();g.moveTo(dx1,tLy);g.lineTo(dx2,tRy);g.lineTo(dx2,bR);g.lineTo(dx1,bL);g.closePath();g.fill();
      const mx=(dx1+dx2)/2; g.strokeStyle='rgba(58,42,26,0.7)';g.lineWidth=0.6*z;
      g.beginPath();g.moveTo(mx,(tLy+tRy)/2);g.lineTo(mx,(bL+bR)/2);g.stroke();
    } else {                                                // vertical plank door
      g.strokeStyle='rgba(20,12,6,0.5)';g.lineWidth=0.5*z;
      for(let i=1;i<4;i++){ const f=i/4, px=dx1+(dx2-dx1)*f; g.beginPath();g.moveTo(px,tLy+(tRy-tLy)*f);g.lineTo(px,bL+(bR-bL)*f);g.stroke(); }
    }
    // timber frame: jambs + sloped lintel beam + stone sill, for a defined, grounded entrance
    g.fillStyle=shade(post,-8); g.fillRect(dx1-1.2*z,tLy,1.3*z,dh); g.fillRect(dx2-0.1*z,tRy,1.3*z,dh);
    g.fillStyle=shade(post,8); g.beginPath();g.moveTo(dx1-1.2*z,tLy-1.5*z);g.lineTo(dx2+1.3*z,tRy-1.5*z);g.lineTo(dx2+1.3*z,tRy);g.lineTo(dx1-1.2*z,tLy);g.closePath();g.fill();
    g.fillStyle='#9a8f78'; g.beginPath();g.moveTo(dx1-1*z,bL);g.lineTo(dx2+1*z,bR);g.lineTo(dx2+1*z,bR+1.8*z);g.lineTo(dx1-1*z,bL+1.8*z);g.closePath();g.fill();
    if(!st.modern){                                         // noren split curtain hung at the lintel
      const nc=st.noren||'#2c4a8a', nh=3.6*z;
      g.fillStyle=nc; g.beginPath();g.moveTo(dx1,tLy);g.lineTo(dx2,tRy);g.lineTo(dx2,tRy+nh);g.lineTo(dx1,tLy+nh);g.closePath();g.fill();
      g.fillStyle=shade(nc,24); g.beginPath();g.moveTo(dx1,tLy);g.lineTo(dx2,tRy);g.lineTo(dx2,tRy+0.9*z);g.lineTo(dx1,tLy+0.9*z);g.closePath();g.fill();
      const mx=(dx1+dx2)/2, my=(tLy+tRy)/2; g.fillStyle=shade(nc,-22); g.fillRect(mx-0.3*z,my,0.6*z,nh);
      if(st.form==='shop')drawTradeMark(g,mx+0.4*z,my+1.9*z,z,st.trade); else { g.fillStyle='#efe2c4'; g.fillRect(mx-2.6*z,my+1.1*z,1.4*z,1.4*z); }
    }
  }
  const stories=Math.max(1,st.stories||1), winBase=st.modern?'#9fd0f0':'#caa24a';
  const span=Math.max(7*z,(wallH-9*z)); const step=stories>1?span/stories:0;
  const wvar=vhash(WX*1.9+WY*2.6,53), frameC=st.modern?'rgba(70,92,108,0.6)':shade(post,-4);
  const drawWin=(wx,wy,ww,wh)=>{                                  // framed window w/ seeded muntin density (variety per building)
    litWin(g,wx,wy,ww,wh,night,winBase);
    g.fillStyle=frameC; g.fillRect(wx-0.8*z,wy-0.8*z,ww+1.6*z,0.8*z); g.fillRect(wx-0.8*z,wy+wh,ww+1.6*z,0.9*z);
    g.fillRect(wx-0.8*z,wy-0.8*z,0.8*z,wh+1.6*z); g.fillRect(wx+ww,wy-0.8*z,0.8*z,wh+1.6*z);
    g.strokeStyle=st.modern?'rgba(40,70,90,0.5)':'rgba(90,60,30,0.55)';g.lineWidth=0.35*z; g.beginPath();
    g.moveTo(wx+ww*0.5,wy);g.lineTo(wx+ww*0.5,wy+wh); g.moveTo(wx,wy+wh*0.5);g.lineTo(wx+ww,wy+wh*0.5);
    if(wvar>0.55){ g.moveTo(wx+ww*0.25,wy);g.lineTo(wx+ww*0.25,wy+wh); g.moveTo(wx+ww*0.75,wy);g.lineTo(wx+ww*0.75,wy+wh); } // denser shoji grid
    g.stroke();
  };
  for(let s=(st.machiya?1:0);s<stories;s++){ const wy=cy-wallH+5*z+s*step; if(wy>cy+hh-6*z)break;
    drawWin(cx-15*z,wy,7*z,4.5*z);
    if((st.modern||stories>1)&&!(st.machiya&&s===0)) drawWin(cx+4*z,wy+1*z,5*z,3.6*z);
  }
  // ── ERA-SPECIFIC FACADE TRIM (mid-lower wall, below the eave) ──────────────────────────────
  if(z>0.55){ const _era=st.era!=null?st.era:(typeof S!=='undefined'?S.era:0), wear=st.wear||0;
    const gYr=x=>cy+hh-hh*((x-cx)/hw), gYl=x=>cy+hh-hh*((cx-x)/hw), tseed=WX*1.7+WY*2.3;
    if(_era===5){                                                    // HEIAN — hanging sudare bamboo blind (golden-era refinement)
      const bx1=cx+18*z,bx2=cx+27*z, tb=x=>gYr(x)-wallH+8*z, bh=Math.min(12*z,wallH*0.42);
      g.fillStyle='rgba(170,142,88,0.5)'; g.beginPath();g.moveTo(bx1,tb(bx1));g.lineTo(bx2,tb(bx2));g.lineTo(bx2,tb(bx2)+bh);g.lineTo(bx1,tb(bx1)+bh);g.closePath();g.fill();
      g.fillStyle='#8a2f26'; g.beginPath();g.moveTo(bx1,tb(bx1));g.lineTo(bx2,tb(bx2));g.lineTo(bx2,tb(bx2)+1.4*z);g.lineTo(bx1,tb(bx1)+1.4*z);g.closePath();g.fill();   // valance
      g.strokeStyle='rgba(70,52,30,0.45)';g.lineWidth=0.3*z; for(let i=1;i<6;i++){ const f=i/6; g.beginPath();g.moveTo(bx1,tb(bx1)+bh*f);g.lineTo(bx2,tb(bx2)+bh*f);g.stroke(); }
    }
    if(_era>=6&&_era<=7){ const w=Math.min(1, wear+(_era===7?0.22:0));  // KAMAKURA/SENGOKU — weathering; collapse era reads worn even at baseline
      if(w>0.05){ g.strokeStyle='rgba(28,22,16,'+(0.08+0.20*w)+')';g.lineWidth=0.7*z;g.lineCap='round';   // grime streaks dripping from the eave
        for(let i=0;i<5;i++){ const f=(i+0.5)/5; let x=cx+hw*f,yt=gYr(x)-wallH+7*z,yl=(0.28+vhash(tseed+i,1)*0.46)*wallH; g.beginPath();g.moveTo(x,yt);g.lineTo(x+0.6*z,yt+yl);g.stroke();
          x=cx-hw*f; yt=gYl(x)-wallH+7*z; yl=(0.28+vhash(tseed+i,2)*0.46)*wallH; g.beginPath();g.moveTo(x,yt);g.lineTo(x-0.6*z,yt+yl);g.stroke(); } g.lineCap='butt'; }
      if(wear>0.34){ const px=cx-15*z, py=gYl(cx-12*z)-wallH*0.5, pw=8*z, ph=5*z;                          // boarded-up window (abandonment / siege)
        g.strokeStyle='#5a4128';g.lineWidth=1.7*z;g.lineCap='round'; g.beginPath();g.moveTo(px-1*z,py-ph*0.55);g.lineTo(px+pw,py+ph*0.55);g.moveTo(px-1*z,py+ph*0.55);g.lineTo(px+pw,py-ph*0.55);g.stroke();g.lineCap='butt';
        g.fillStyle='#241810'; for(const[dx,dy]of [[-1,-0.55],[pw,0.55],[-1,0.55],[pw,-0.55]]){ g.beginPath();g.arc(px+dx*z,py+dy*ph,0.7*z,0,7);g.fill(); } }
    }
    if(_era===8){ const nc=st.neon||'#14f195';                       // QUANTUM EDO — vertical neon sign strip + glow
      const sx=cx+20*z, sy=gYr(sx)-wallH+8*z, sh=Math.min(14*z,wallH*0.46);
      g.fillStyle=nc; g.globalAlpha=0.12; g.beginPath();g.ellipse(sx,sy+sh*0.5,4.5*z,sh*0.62,0,0,7);g.fill(); g.globalAlpha=1;
      g.fillStyle='rgba(8,10,12,0.55)'; g.fillRect(sx-1.7*z,sy-1*z,3.8*z,sh+2*z);
      g.fillStyle=nc; g.globalAlpha=0.92; for(let i=0;i<4;i++) g.fillRect(sx-0.9*z, sy+sh*(i/4)+0.7*z, 2.1*z, 1.3*z); g.globalAlpha=1;
    }
  }
  }
  const roof=st.roof||'#3d6e8c',roofD=shade(roof,-26);
  const ry=cy-wallH,ov=(st.ov||9)*z,ridge=(st.rh||16)*z;
  if(st.thatch){ // thick golden thatched roof (steep, bound ridge)
    const rc='#bfa252',rL=shade(rc,20),rD=shade(rc,-30), sc=1.16, hh2=hh*sc,hw2=hw*sc,ov2=ov*1.35,rg=ridge*1.35;
    const eT=[cx,ry-hh2-ov2*0.5],eR=[cx+hw2+ov2,ry],eB=[cx,ry+hh2+ov2*0.5],eL=[cx-hw2-ov2,ry],rT=[cx,ry-hh2-rg],rB=[cx,ry+hh2-rg];
    g.beginPath();g.moveTo(eR[0],eR[1]);g.lineTo(eB[0],eB[1]);g.lineTo(rB[0],rB[1]);g.lineTo(rT[0],rT[1]);g.lineTo(eT[0],eT[1]);g.closePath();g.fillStyle=rc;g.fill();
    g.strokeStyle=rD;g.lineWidth=0.49*z; for(let i=1;i<7;i++){const f=i/7; g.beginPath();g.moveTo(eT[0]+(eR[0]-eT[0])*f,eT[1]+(eR[1]-eT[1])*f);g.lineTo(rT[0]+(rB[0]-rT[0])*f,rT[1]+(rB[1]-rT[1])*f);g.stroke();}
    g.beginPath();g.moveTo(eL[0],eL[1]);g.lineTo(eB[0],eB[1]);g.lineTo(rB[0],rB[1]);g.lineTo(rT[0],rT[1]);g.lineTo(eT[0],eT[1]);g.closePath();g.fillStyle=rD;g.fill();
    g.strokeStyle=shade(rD,-12);g.lineWidth=0.49*z; for(let i=1;i<7;i++){const f=i/7; g.beginPath();g.moveTo(eL[0]+(eB[0]-eL[0])*f,eL[1]+(eB[1]-eL[1])*f);g.lineTo(rT[0]+(rB[0]-rT[0])*f,rT[1]+(rB[1]-rT[1])*f);g.stroke();}
    g.fillStyle=shade(rc,-14); g.beginPath();g.moveTo(eL[0],eL[1]);g.lineTo(eB[0],eB[1]);g.lineTo(eB[0],eB[1]+2.5*z);g.lineTo(eL[0],eL[1]+2.5*z);g.closePath();g.fill();
    g.beginPath();g.moveTo(eB[0],eB[1]);g.lineTo(eR[0],eR[1]);g.lineTo(eR[0],eR[1]+2.5*z);g.lineTo(eB[0],eB[1]+2.5*z);g.closePath();g.fill();
    g.strokeStyle='#6a4a2a';g.lineWidth=2.24*z;g.beginPath();g.moveTo(rT[0],rT[1]);g.lineTo(rB[0],rB[1]);g.stroke();
    g.strokeStyle='#5a3e24';g.lineWidth=0.7*z; for(let i=1;i<4;i++){const f=i/4; g.beginPath();g.moveTo(rT[0]-2.5*z,rT[1]+(rB[1]-rT[1])*f);g.lineTo(rT[0]+2.5*z,rT[1]+(rB[1]-rT[1])*f);g.stroke();}
    drawProps(g,cx,cy,z,st,wallH,hw,night); return; }
  if(st.factoryRoof){ // flat industrial roof + parapet + sawtooth north-light skylights
    g.beginPath();g.moveTo(cx,ry-hh);g.lineTo(cx+hw,ry);g.lineTo(cx,ry+hh);g.lineTo(cx-hw,ry);g.closePath();
    g.fillStyle=night>0.3?shade(roof,-Math.round(night*18)):roof;g.fill();
    g.strokeStyle=shade(roof,-32);g.lineWidth=1.12*z;g.stroke();
    for(let i=0;i<3;i++){ const f=0.3+i*0.2, my=ry-hh+(hh*2)*f, w=hw*0.46;
      g.fillStyle=shade(roof,-14); g.beginPath();g.moveTo(cx-w,my);g.lineTo(cx+w,my);g.lineTo(cx,my-4.5*z);g.closePath();g.fill();
      g.fillStyle=night>0.34?'#3a4a5a':'#a9d6f0'; g.beginPath();g.moveTo(cx-w,my);g.lineTo(cx,my-4.5*z);g.lineTo(cx,my+0.5*z);g.closePath();g.fill(); }
    drawProps(g,cx,cy,z,st,wallH,hw,night); return; }
  if(st.flat){ g.beginPath();g.moveTo(cx,ry-hh);g.lineTo(cx+hw,ry);g.lineTo(cx,ry+hh);g.lineTo(cx-hw,ry);g.closePath();g.fillStyle=night>0.3?shade(roof,-Math.round(night*20)):roof;g.fill();
    g.strokeStyle=roofD;g.lineWidth=0.98*z;g.stroke(); if(st.neon){g.fillStyle=st.neon;g.fillRect(cx-1.5*z,ry-hh,3*z,4*z);}
    drawProps(g,cx,cy,z,st,wallH,hw,night); return; }
  function hip(cx,ryy,scale,roofC){ const rL=shade(roofC,30),rD=shade(roofC,-26),hh2=hh*scale,hw2=hw*scale,ov2=ov*scale,rg=ridge*scale;
    const jw=s=>(vhash(WX*0.13+WY*0.21,s)*2-1)*0.9*z;   // world-seeded +-0.9px eave wobble (stable under pan/zoom; ridge stays exact)
    const eT=[cx+jw(1),ryy-hh2-ov2*0.5+jw(2)],eR=[cx+hw2+ov2+jw(3),ryy+jw(4)],eB=[cx+jw(5),ryy+hh2+ov2*0.5+jw(6)],eL=[cx-hw2-ov2+jw(7),ryy+jw(8)],rT=[cx,ryy-hh2-rg],rB=[cx,ryy+hh2-rg];
    g.beginPath();g.moveTo(eR[0],eR[1]);g.lineTo(eB[0],eB[1]);g.lineTo(rB[0],rB[1]);g.lineTo(rT[0],rT[1]);g.lineTo(eT[0],eT[1]);g.closePath();g.fillStyle=roofC;g.fill();
    g.strokeStyle=rD;g.lineWidth=0.7*z; for(let i=1;i<=3;i++){const f=i/4; g.beginPath();g.moveTo(eT[0]+(eR[0]-eT[0])*f,eT[1]+(eR[1]-eT[1])*f);g.lineTo(rT[0]+(rB[0]-rT[0])*f,rT[1]+(rB[1]-rT[1])*f);g.stroke();}
    g.beginPath();g.moveTo(eL[0],eL[1]);g.lineTo(eB[0],eB[1]);g.lineTo(rB[0],rB[1]);g.lineTo(rT[0],rT[1]);g.lineTo(eT[0],eT[1]);g.closePath();g.fillStyle=rD;g.fill();
    g.strokeStyle=rL;g.lineWidth=1.68*z;g.beginPath();g.moveTo(rT[0],rT[1]);g.lineTo(rB[0],rB[1]);g.stroke();
    g.fillStyle=rL; g.fillRect(eL[0]-1*z,eL[1]-3*z,3.5*z,3*z);g.fillRect(eR[0]-2.5*z,eR[1]-3*z,3.5*z,3*z);g.fillRect(eT[0]-1.6*z,eT[1]-1*z,3.2*z,2*z);g.fillRect(eB[0]-1.6*z,eB[1]-1*z,3.2*z,2*z);
    g.strokeStyle=rD;g.lineWidth=1.4*z;g.beginPath();g.moveTo(eL[0],eL[1]);g.lineTo(eB[0],eB[1]);g.lineTo(eR[0],eR[1]);g.stroke();
    // tile-course striations on the shadow face: short cross-strokes between the eave and ridge
    // edges, suggesting overlapping ceramic tile rows. Mirrors the rafter-line loop above but
    // on the eL-eB face, gated by zoom since this only runs in the full-detail (non-LOD) branch.
    if(z>0.55){ g.strokeStyle=rD; g.lineWidth=Math.max(0.35,0.32*z); g.globalAlpha=0.55;
      for(let i=1;i<=3;i++){ const f=i/4;
        g.beginPath(); g.moveTo(eL[0]+(eB[0]-eL[0])*f,eL[1]+(eB[1]-eL[1])*f); g.lineTo(rT[0]+(rB[0]-rT[0])*f,rT[1]+(rB[1]-rT[1])*f); g.stroke(); }
      g.globalAlpha=1; }
    // round eave tiles (tomoe) along the two front eaves
    g.fillStyle=rL; for(let i=1;i<6;i++){ const f=i/6;
      let x=eL[0]+(eB[0]-eL[0])*f, y=eL[1]+(eB[1]-eL[1])*f; g.beginPath();g.arc(x,y,0.9*z,0,7);g.fill();
      x=eB[0]+(eR[0]-eB[0])*f; y=eB[1]+(eR[1]-eB[1])*f; g.beginPath();g.arc(x,y,0.9*z,0,7);g.fill(); }
    if(scale>=1){ for(const e of [rT,rB]){ g.fillStyle=shade(roofC,-36); g.fillRect(e[0]-1.5*z,e[1]-3.2*z,3*z,3.4*z); g.fillStyle=shade(roofC,20); g.fillRect(e[0]-1.5*z,e[1]-3.2*z,3*z,0.9*z);
      g.fillStyle='#caa24a'; g.fillRect(e[0]-0.5*z,e[1]-4*z,1*z,1.3*z); } } }
  const rc=night>0.3?shade(roof,-Math.round(night*18)):roof; hip(cx,ry,1,rc);
  if(st.tiers){ hip(cx,ry-ridge-3*z,0.52,shade(rc,8)); }
  drawProps(g,cx,cy,z,st,wallH,hw,night);
}
/* zone building style: deep per-building variation from seed */
function zoneStyle(zone,era,dev,seed){ const E=ERAS[era];
  const vH=vhash(seed,1),vR=vhash(seed,2),vP=vhash(seed,3),vW=vhash(seed,4),vS=vhash(seed,5),vH2=vhash(seed,6),vO=vhash(seed,7),vJ=vhash(seed,8);
  const modern=era>=8; let roof, wall, post=shade(E.post,Math.round((vP-0.5)*24)), form, h, rh=8+dev*4+Math.round(vH2*8), ov=6+dev*2+Math.round(vW*6);
  let thatch=false, stall=false, machiya=false, glassTower=false, workshop=false, brickChimney=false, kiln=false;
  if(zone===ZR){ form='house';
    const pal= era<=1?['#7a5a3a','#6a4a2e','#86663e','#8c6a44','#6e5236']:era<=3?['#8a5a3a','#9c6a3a','#7c4a30','#a0743e','#6e4a2e','#b07a44']
      :era<=5?['#6a5a4a','#74604a','#5e4c3a','#82705a','#534436','#6e5e4e']:era<=7?['#5a5260','#4e4654','#665a52','#46404e','#6e6258','#544a5a']:['#2a4a44','#22403a','#346056','#1e4640','#2e5650','#3a6a5e'];
    roof=shade(pal[(vR*pal.length)|0],Math.round((vH-0.5)*20)); wall=shade(E.wall,10+Math.round((vW-0.5)*34)); h=8+dev*5+Math.round(vH*10);
    thatch = era<=1; }                                            // Jomon/Yayoi: thatched hut
  else if(zone===ZC){ form='shop';
    const pal= era<=2?['#9c7a3a','#a8843a','#b5532f','#b08a44','#8a6a32','#c06a3a']:era<=4?['#b5532f','#2f7fb0','#caa23a','#3f8a4a','#8a3aa0','#c05a34','#356a9a','#aa8a2a']
      :era<=5?['#b5532f','#c05a34','#a8472a','#9a5a3a','#c26a44','#8a3a2a']:era<=7?['#6a5a4a','#7a6a52','#5e5042','#82705a','#54483a','#6e5e4a']:['#14f195','#9945ff','#14d0c0','#1ad0a0','#7a3ad0','#10b0c8'];
    roof=shade(pal[(vR*pal.length)|0],Math.round((vH-0.5)*16)); wall=shade('#efe6d2',-4+Math.round((vW-0.5)*30)); h=14+dev*8+Math.round(vH*12);
    stall = era<=2;                                               // ancient: market stall
    machiya = (era>=3&&era<=7);                                   // middle ages: machiya storefront
    glassTower = era>=8; }                                        // Quantum Edo: glass tower
  else { form='factory';
    const pal= era<=4?['#6a6a5a','#5e6450','#72685a','#5a604e','#76705e','#646a56']:era<=6?['#6a4838','#5c3e2e','#74503c','#8a5a44','#503628','#7c5236']:era===7?['#54585e','#4a4e54','#5e6268','#44484e']:['#1e3a32','#16302a','#244038','#1a342c'];
    roof=shade(pal[(vR*pal.length)|0],Math.round((vH-0.5)*16)); wall=shade(era<=5?'#b6a583':'#9a9384',-6+Math.round((vW-0.5)*26)); h=12+dev*6+Math.round(vH*9);
    workshop = era<=5;                                            // pre-modern: thatched workshop + kiln
    kiln = era<=7; brickChimney = era>=8; }                       // Quantum Edo: chimney stack
  const flat=((form==='shop')&&modern)||glassTower;
  const factoryRoof=(form==='factory'&&!workshop);
  const corrugated=(form==='factory'&&era>=8);
  const neon= era===8?(zone===ZC?'#14f195':zone===ZI?'#14d0c0':'#9945ff'):null;
  const stories= glassTower?(4+dev+((vS*3)|0)) : form==='shop'?(modern?2+((vS*3)|0)+dev:(dev>=1?2:1)) : form==='factory'?(1+(dev>=2?1:0)) : (dev>=2?2:1);
  const trade=(vP*6)|0;                                           // shop trade: sake/tea/fish/cloth/rice/medicine
  const props=[];
  if(form==='house'){ if(!thatch&&vP>0.2)props.push('garden'); if(era<=7&&vW<0.55)props.push('lantern'); if(era>=8&&vP>0.55)props.push('chimney'); if(thatch&&vS>0.6)props.push('lantern'); }
  else if(form==='shop'){ if(!stall&&!machiya&&!glassTower)props.push('awning'); if(!glassTower&&!stall)props.push('kanban'); if(!stall&&vP>0.18)props.push('lantern2'); if(!glassTower&&vH>0.7)props.push('banner'); }
  else { props.push(brickChimney?'brickstack':(kiln?'kiln':'smokestack')); if(vP>0.35)props.push('tank'); }
  if(modern&&vS>0.4&&!glassTower)props.push('watertower');
  if(era>=8&&vP>0.7&&!glassTower)props.push('antenna');
  const tiers=(form==='house'&&dev>=2&&vJ>0.5&&!thatch);
  const TRADEC=['#b5532f','#3f8a4a','#2f7fb0','#7a3ba0','#caa23a','#d8d2c4'];
  const NORENS=['#2c4a8a','#7a2d24','#2c6a3a','#5a2d6a','#1a1a2a','#8a5a1a'];
  const noren= form==='shop'?(neon||TRADEC[trade]) : NORENS[(vR*NORENS.length)|0];
  return {roof,wall,post,h,rh,ov,modern,flat,factoryRoof,corrugated,neon,stories,props,tiers,noren,form,vR,
    thatch,stall,machiya,glassTower,workshop,brickChimney,kiln,trade,era}; }
function drawLot(g,cx,cy,z,zone){ const hw=TW/2*z,hh=TH/2*z;
  diamondPath(g,cx,cy,z); g.fillStyle='#b89a66'; g.fill();           // cleared dirt plot
  const col= zone===ZR?'#3f8a4a' : zone===ZC?'#3a6ea5' : '#caa23a';
  // corner survey stakes with string
  g.strokeStyle='#6a4a2a'; g.lineWidth=0.98*z;
  const cs=[[0,-hh],[hw,0],[0,hh],[-hw,0]];
  for(const[sx,sy]of cs){ g.beginPath(); g.moveTo(cx+sx,cy+sy); g.lineTo(cx+sx,cy+sy-7*z); g.stroke(); g.fillStyle=col; g.fillRect(cx+sx-1*z,cy+sy-8*z,2*z,2*z); }
  g.strokeStyle='rgba(230,210,150,0.8)'; g.lineWidth=0.7*z; g.beginPath();
  g.moveTo(cx,cy-hh-6*z);g.lineTo(cx+hw,cy-6*z);g.lineTo(cx,cy+hh-6*z);g.lineTo(cx-hw,cy-6*z);g.closePath(); g.stroke();
  // small foundation stones + a stack of timber
  g.fillStyle='#8a8276'; g.fillRect(cx-5*z,cy-1*z,4*z,2*z); g.fillRect(cx+2*z,cy+2*z,4*z,2*z);
  g.fillStyle='#7a5630'; for(let i=0;i<3;i++)g.fillRect(cx-3*z+i*1.2*z,cy-3*z-i*1.2*z,7*z,1.2*z);
  g.fillStyle=col; g.fillRect(cx-1*z,cy-12*z,2*z,4*z); g.fillStyle=shade(col,30); g.fillRect(cx-1*z,cy-12*z,2*z,1.4*z); // marker flag
}
/* ============================================================
   PAINTERLY AGE 1-2 (Jomon / Yayoi) — watercolor render kit
   Soft edges, washed gradients, layered contact shadow, hand
   wobble. Cheap on mobile: gradients + a few strokes, no grain
   loops in the hot path. Routed ONLY at S.era<=1 so later ages
   are untouched.
   ============================================================ */
function ptNow(){ return (typeof performance!=='undefined'&&performance.now)?performance.now():0; }
// layered low-alpha contact shadow (blurred feel without ctx.filter — iOS-safe)
function ptShadow(g,cx,cy,rw,z){ for(let i=3;i>=1;i--){ g.fillStyle='rgba(26,26,30,'+(0.015*i)+')';
  g.beginPath(); g.ellipse(cx,cy+2*z, rw*z*(0.62+i*0.2), rw*0.5*z*(0.62+i*0.2),0,0,7); g.fill(); } }
// fill a polygon with a vertical watercolor wash (top light -> bottom deep)
function ptWash(g,p,cTop,cBot){ let mn=1e9,mx=-1e9; for(const q of p){ if(q[1]<mn)mn=q[1]; if(q[1]>mx)mx=q[1]; }
  const gr=g.createLinearGradient(0,mn,0,mx); gr.addColorStop(0,cTop); gr.addColorStop(1,cBot);
  g.fillStyle=gr; g.beginPath(); g.moveTo(p[0][0],p[0][1]); for(let i=1;i<p.length;i++)g.lineTo(p[i][0],p[i][1]); g.closePath(); g.fill(); }
// soft rounded form (pots, bales, fruit) with light-from-top wash
function ptBlob(g,x,y,rx,ry,cTop,cBot){ const gr=g.createLinearGradient(0,y-ry,0,y+ry); gr.addColorStop(0,cTop); gr.addColorStop(1,cBot);
  g.fillStyle=gr; g.beginPath(); g.ellipse(x,y,rx,ry,0,0,7); g.fill(); }
// deterministic hand-wobble offset
function ptJit(seed,i,amt,z){ return (vhash(seed,i)*2-1)*amt*z; }
// drifting smoke wisp (signals a living, inhabited hearth)
function ptWisp(g,x,y,z,seed){ const t=ptNow()*0.0011+seed; g.lineWidth=1.19*z; g.lineCap='round';
  for(let k=0;k<3;k++){ const a=0.16-k*0.04, sway=Math.sin(t+k*1.3)*3.2*z; g.strokeStyle='rgba(214,208,196,'+a+')';
    g.beginPath(); g.moveTo(x,y-k*5*z); g.quadraticCurveTo(x+sway,y-(k*5+4)*z, x-sway*0.5,y-(k*5+9)*z); g.stroke(); } g.lineCap='butt'; }
// warm ember/kiln glow
function ptEmber(g,x,y,z){ const gr=g.createRadialGradient(x,y,0,x,y,7*z); gr.addColorStop(0,'rgba(255,150,60,0.55)'); gr.addColorStop(1,'rgba(255,120,40,0)');
  g.fillStyle=gr; g.beginPath(); g.arc(x,y,7*z,0,7); g.fill(); }

/* --- Jomon/Yayoi pit-dwelling (tateana jukyo): low earthen mound under a
   sweeping straw cone. Humble, serene, lived-in. --- */
function drawDwellingP(g,cx,cy,z,st){ const hw=TW/2*z,hh=TH/2*z, _u=(cx-cam.x)/z,_v=(cy-cam.y)/z, WX=Math.round(_u/TW+_v/TH),WY=Math.round(_v/TH-_u/TW), seed=(st.vR||0.4)*53+WX*1.3+WY*2.7;  // world-stable seed (was cx-based -> caused pan shimmer)
  const night=(typeof envNight==='function')?envNight():0;
  ptShadow(g,cx,cy+hh*0.34,TW*0.40,z);
  if(typeof paintCastShadow==="function")paintCastShadow(g,cx,cy,z);
  // earthen mound base (warm ochre wash, slightly dug-in)
  const mb=cy+hh*0.18, mw=hw*0.86;
  ptWash(g,[[cx-mw,mb],[cx,cy+hh*0.5],[cx+mw,mb],[cx,mb-7*z]], '#b59a6e', '#7c6442');
  g.fillStyle='rgba(60,46,28,0.18)'; g.beginPath(); g.ellipse(cx,mb-1*z,mw*0.9,5*z,0,0,7); g.fill();
  // thatch cone — two washed faces meeting at a high apex, eaves near the ground
  const apex=[cx, cy-27*z], eL=[cx-hw*0.96+ptJit(seed,1,2,z), mb-3*z], eR=[cx+hw*0.96+ptJit(seed,2,2,z), mb-3*z];
  const eF=[cx+ptJit(seed,3,2,z), cy+hh*0.42], eB=[cx, cy-hh*0.2];
  let tcT=night>0.3?'#9c8246':'#c8a85a', tcB=night>0.3?'#5e4e2c':'#7a6232';
  ptWash(g,[apex,eL,eF], shade(tcT,-14), shade(tcB,-10));               // left face (shadow)
  ptWash(g,[apex,eF,eR], tcT, tcB);                                      // right face (light)
  g.strokeStyle='rgba(255,240,200,0.45)'; g.lineWidth=0.91*z; g.lineCap='round';   // warm sunlit rim on the light eave
  g.beginPath(); g.moveTo(apex[0],apex[1]); g.lineTo(eR[0],eR[1]); g.stroke(); g.lineCap='butt';
  g.fillStyle='rgba(86,108,58,0.45)'; for(let i=0;i<3;i++){ const f=0.45+0.16*i; g.beginPath();   // moss on old thatch (age/weight)
    g.ellipse(apex[0]+(eF[0]-apex[0])*f+(vhash(seed,40+i)*2-1)*3*z, apex[1]+(eF[1]-apex[1])*f, 2.1*z,1.3*z,0.3,0,7); g.fill(); }
  // straw streaks (a few soft strokes per face — readable, cheap)
  g.lineWidth=0.49*z; g.strokeStyle='rgba(90,70,36,0.4)';
  for(let i=1;i<6;i++){ const f=i/6; g.beginPath(); g.moveTo(apex[0]+(eF[0]-apex[0])*f, apex[1]+(eF[1]-apex[1])*f);
    g.lineTo(apex[0]+(eR[0]-apex[0])*f, apex[1]+(eR[1]-apex[1])*f); g.stroke(); }
  g.strokeStyle='rgba(230,210,150,0.28)'; // a couple of sun-bleached highlights
  for(let i=1;i<4;i++){ const f=i/4; g.beginPath(); g.moveTo(apex[0]+(eF[0]-apex[0])*f, apex[1]+(eF[1]-apex[1])*f-0.6*z);
    g.lineTo(apex[0]+(eR[0]-apex[0])*f, apex[1]+(eR[1]-apex[1])*f-0.6*z); g.stroke(); }
  // soft bound ridge near the apex only (no hard central pole)
  g.strokeStyle='rgba(74,52,30,0.75)'; g.lineWidth=1.47*z; g.lineCap='round'; g.beginPath(); g.moveTo(apex[0],apex[1]); g.lineTo(apex[0]+(eF[0]-apex[0])*0.34, apex[1]+(eF[1]-apex[1])*0.34); g.stroke(); g.lineCap='butt';
  paintThatchFringe(g,eF,eL,eR,z,'rgba(110,88,42,0.75)');   // ragged hand-thatched eaves
  // low dark doorway with hanging reed mat
  const dx=cx+3*z, dyT=cy+1*z;
  g.fillStyle='#221a12'; g.beginPath(); g.moveTo(dx-4*z,cy+hh*0.34); g.lineTo(dx+4*z,cy+hh*0.34); g.lineTo(dx+3*z,dyT); g.lineTo(dx-3*z,dyT); g.closePath(); g.fill();
  g.strokeStyle='rgba(150,128,86,0.7)'; g.lineWidth=0.49*z; for(let i=-2;i<=2;i++){ g.beginPath(); g.moveTo(dx+i*1.6*z,dyT+0.5*z); g.lineTo(dx+i*1.5*z,cy+hh*0.3); g.stroke(); }
  // hearth smoke from the apex — the house is alive
  ptWisp(g,apex[0],apex[1]+1*z,z,seed);
  if(night>0.34){ g.fillStyle='rgba(255,170,90,0.5)'; g.beginPath(); g.ellipse(dx,cy+hh*0.22,2.4*z,3*z,0,0,7); g.fill(); }
  const fwx=cx-hw*0.5, fwy=cy+hh*0.1;                                    // stacked firewood — lived-in
  for(let i=0;i<4;i++){ ptBlob(g,fwx+(i%2)*1.6*z, fwy-i*1.1*z, 2*z,0.9*z, '#8a6238','#5a3f24'); }
  paintCraftBase(g,cx,cy,z,seed);
}

/* --- Open-air market stall (commerce): timber frame, washed cloth awning,
   soft heaps of early goods (clay pots, fish, rice straw, baskets). --- */
function drawStallP(g,cx,cy,z,st){ const hh=TH/2*z, _u=(cx-cam.x)/z,_v=(cy-cam.y)/z, WX=Math.round(_u/TW+_v/TH),WY=Math.round(_v/TH-_u/TW), seed=(st.vR||0.4)*71+WX*1.3+WY*2.7;  // world-stable seed (was cx-based -> caused pan shimmer)
  ptShadow(g,cx,cy+hh*0.3,TW*0.34,z);
  if(typeof paintCastShadow==="function")paintCastShadow(g,cx,cy,z);
  const post='#6a4c2c', ph=12*z;
  // four posts (wood wash + grain)
  for(const[px,py] of [[-8,-2],[8,-2],[-8,3.5],[8,3.5]]){ const x=cx+px*z; ptWash(g,[[x-0.8*z,cy+py*z],[x+0.8*z,cy+py*z],[x+0.8*z,cy+py*z-ph],[x-0.8*z,cy+py*z-ph]], shade(post,22), shade(post,-18)); paintGrain(g,x,cy+py*z-ph,cy+py*z,z); }
  // counter plank
  ptWash(g,[[cx-9*z,cy+0.6*z],[cx+9*z,cy+0.6*z],[cx+9*z,cy+4.4*z],[cx-9*z,cy+4.4*z]], '#9a7440', '#6a4c28');
  const vseed=Math.abs((seed*131)|0);
  drawVendorFigure(g,cx-2.5*z,cy+0.6*z,z,SKIN[vseed%SKIN.length],KIM[(vseed+3)%KIM.length]);                          // stallkeeper standing behind the counter, fixed to the stall
  // goods: clay pots + rice bales + fish + woven basket
  ptBlob(g,cx-5.4*z,cy+0.6*z,1.9*z,2.2*z,'#b07a4a','#7c4f2c');          // clay pot
  ptBlob(g,cx-1.4*z,cy+0.7*z,2.1*z,1.8*z,'#cdb784','#9a8456');          // rice straw bale
  ptBlob(g,cx+2.6*z,cy+0.8*z,1.7*z,2.0*z,'#a98f5c','#76603a');          // basket
  g.fillStyle='#9fb0bc'; for(let i=0;i<3;i++){ g.beginPath(); g.ellipse(cx+5.2*z+i*0.7*z,cy+1.2*z-i*0.6*z,2.0*z,0.7*z,-0.5,0,7); g.fill(); } // silver fish
  // washed cloth awning (noren) — desaturated for early age
  let tc=st.noren||'#9c7a3a'; tc=shade(tc,-6);
  const ay=cy-ph, p=[[cx-9.5*z+ptJit(seed,1,1.5,z),ay+2.4*z],[cx+9.5*z+ptJit(seed,2,1.5,z),ay+2.4*z],[cx+7.4*z,ay-3.6*z],[cx-7.4*z,ay-3.6*z]];
  ptWash(g,p, shade(tc,18), shade(tc,-12));
  g.strokeStyle='rgba(255,240,200,0.4)'; g.lineWidth=0.77*z; g.lineCap='round';   // warm rim on awning crest
  g.beginPath(); g.moveTo(p[3][0],p[3][1]); g.lineTo(p[2][0],p[2][1]); g.stroke(); g.lineCap='butt';
  // cloth hang wobble + seams
  g.strokeStyle='rgba(40,30,18,0.3)'; g.lineWidth=0.42*z;
  for(let i=1;i<5;i++){ const f=i/5; g.beginPath(); g.moveTo(cx-7.4*z+14.8*z*f, ay-3.6*z); g.lineTo(cx-9.5*z+19*z*f, ay+2.4*z+ptJit(seed,i+3,1.2,z)); g.stroke(); }
  g.fillStyle=shade(tc,-20); g.beginPath(); g.moveTo(p[0][0],p[0][1]); g.lineTo(p[1][0],p[1][1]); g.lineTo(p[1][0],p[1][1]+1.6*z); g.lineTo(p[0][0],p[0][1]+1.6*z); g.closePath(); g.fill();
  if(typeof drawTradeMark==='function') drawTradeMark(g,cx,ay-0.4*z,z,st.trade);
  // dried-fish / persimmon string for life
  g.strokeStyle='#7a5a30'; g.lineWidth=0.49*z; g.beginPath(); g.moveTo(cx-8*z,ay+2*z); g.lineTo(cx+8*z,ay+2*z); g.stroke();
  g.fillStyle='#c8682f'; for(let i=0;i<5;i++){ g.beginPath(); g.arc(cx-6*z+i*3*z,ay+3.2*z,0.9*z,0,7); g.fill(); }
  paintCraftBase(g,cx,cy,z,seed);
}

/* --- Yayoi raised-floor granary / workshop (takayuka): stilts + rat-guards,
   chigi & katsuogi finials, a ladder, and a small firing kiln (industry). --- */
function drawGranaryP(g,cx,cy,z,st){ const hw=TW/2*z,hh=TH/2*z, _u=(cx-cam.x)/z,_v=(cy-cam.y)/z, WX=Math.round(_u/TW+_v/TH),WY=Math.round(_v/TH-_u/TW), seed=(st.vR||0.4)*89+WX*1.3+WY*2.7;  // world-stable seed (was cx-based -> caused pan shimmer)
  const night=(typeof envNight==='function')?envNight():0;
  ptShadow(g,cx,cy+hh*0.34,TW*0.40,z);
  if(typeof paintCastShadow==="function")paintCastShadow(g,cx,cy,z);
  const fl=cy-9*z;                                                       // raised floor height
  // stilts with rat-guard discs
  const posts=[[-7,1],[7,1],[-7,-3.5],[7,-3.5]];
  for(const[px,py]of posts){ const x=cx+px*z, yb=cy+py*z;
    ptWash(g,[[x-1*z,yb],[x+1*z,yb],[x+1*z,fl+2*z],[x-1*z,fl+2*z]], '#7a5a36','#4e3a22');
    g.fillStyle='#caa86a'; g.beginPath(); g.ellipse(x,fl+2*z,2.4*z,1.1*z,0,0,7); g.fill();   // nezumi-gaeshi disc
    g.fillStyle='rgba(60,42,24,0.4)'; g.beginPath(); g.ellipse(x,fl+2.5*z,2.4*z,1.0*z,0,0,7); g.fill(); }
  // raised floor platform (iso quad)
  ptWash(g,[[cx-hw*0.7,fl+2*z],[cx,fl+2*z+hh*0.7],[cx+hw*0.7,fl+2*z],[cx,fl+2*z-hh*0.7]], '#8a6a3e','#6a4e2c');
  const wallH=12*z, top=fl-wallH;
  // body walls (two faces)
  ptWash(g,[[cx-hw*0.62,fl],[cx,fl+hh*0.6],[cx,fl+hh*0.6-wallH],[cx-hw*0.62,fl-wallH]], '#9a7a4a','#6e5232'); // left/shadow
  ptWash(g,[[cx,fl+hh*0.6],[cx+hw*0.62,fl],[cx+hw*0.62,fl-wallH],[cx,fl+hh*0.6-wallH]], '#b08e54','#86653a'); // right/light
  // plank seams
  g.strokeStyle='rgba(60,42,24,0.35)'; g.lineWidth=0.35*z; for(let i=1;i<5;i++){ const f=i/5;
    g.beginPath(); g.moveTo(cx,fl+hh*0.6-wallH*f); g.lineTo(cx+hw*0.62,fl-wallH*f); g.stroke(); }
  // thatch hip roof
  let tcT=night>0.3?'#9c8246':'#c8a85a', tcB=night>0.3?'#5e4e2c':'#7a6232';
  const apex=[cx,top-13*z], reL=[cx-hw*0.92,top+1*z], reR=[cx+hw*0.92,top+1*z], reF=[cx,top+hh*0.55];
  ptWash(g,[apex,reL,reF], shade(tcT,-14),shade(tcB,-10));
  ptWash(g,[apex,reF,reR], tcT,tcB);
  g.strokeStyle='rgba(255,240,200,0.42)'; g.lineWidth=0.91*z; g.lineCap='round';   // warm sunlit rim
  g.beginPath(); g.moveTo(apex[0],apex[1]); g.lineTo(reR[0],reR[1]); g.stroke(); g.lineCap='butt';
  g.fillStyle='rgba(86,108,58,0.4)'; for(let i=0;i<2;i++){ g.beginPath();   // moss
    g.ellipse(apex[0]+(reF[0]-apex[0])*(0.5+0.2*i), apex[1]+(reF[1]-apex[1])*(0.5+0.2*i), 2*z,1.2*z,0.3,0,7); g.fill(); }
  g.strokeStyle='#5a3e22'; g.lineWidth=1.68*z; g.beginPath(); g.moveTo(apex[0],apex[1]); g.lineTo(reF[0],reF[1]-1*z); g.stroke();
  paintThatchFringe(g,reF,reL,reR,z,'rgba(110,88,42,0.75)');   // ragged hand-thatched eaves
  // chigi (crossed gable finials) + katsuogi (ridge billets) — the iconic Yayoi mark
  g.strokeStyle='#4a341e'; g.lineWidth=1.12*z;
  g.beginPath(); g.moveTo(apex[0]-4*z,apex[1]-6*z); g.lineTo(apex[0]+1*z,apex[1]+1*z);
  g.moveTo(apex[0]+4*z,apex[1]-6*z); g.lineTo(apex[0]-1*z,apex[1]+1*z); g.stroke();
  g.fillStyle='#5a3e22'; for(let i=0;i<3;i++){ g.fillRect(apex[0]-1.4*z, apex[1]+1*z+i*2.4*z, 2.8*z,1.4*z); }
  // ladder up to the floor
  g.strokeStyle='#6a4c2c'; g.lineWidth=0.63*z;
  g.beginPath(); g.moveTo(cx-1.5*z,cy+hh*0.34); g.lineTo(cx-1.5*z,fl+2*z); g.moveTo(cx+1.5*z,cy+hh*0.34); g.lineTo(cx+1.5*z,fl+2*z); g.stroke();
  for(let i=0;i<4;i++){ const yy=cy+hh*0.3-i*((cy+hh*0.3-(fl+2*z))/4); g.beginPath(); g.moveTo(cx-1.5*z,yy); g.lineTo(cx+1.5*z,yy); g.stroke(); }
  // small firing kiln beside it — the "industry" read
  const kx=cx-hw*0.78, ky=cy+hh*0.2;
  ptBlob(g,kx,ky,3.2*z,2.4*z,'#7a5238','#4a3120');
  g.fillStyle='#2a1c12'; g.beginPath(); g.arc(kx,ky+0.4*z,1.1*z,0,7); g.fill();
  ptEmber(g,kx,ky+0.4*z,z);
  ptWisp(g,kx,ky-2.2*z,z,seed+2);
  if(night>0.34){ g.fillStyle='rgba(255,180,100,0.4)'; g.beginPath(); g.ellipse(cx,fl-wallH*0.5,3*z,4*z,0,0,7); g.fill(); }
  paintCraftBase(g,cx,cy,z,seed);
}

/* ============================================================
   PAINTERLY PASS 2 — atmosphere, softer hand-painted ground,
   craft imperfection. All gated to S.era<=1 by callers.
   ============================================================ */
let TJIT=0.55; // tile-corner jitter multiplier — lowered for a clean, organic edge without torn/blocky seams

// extra watercolor land treatment: hand-flicked grass blades only — the warm/cool wash and
// mossy dabs that used to live here are now folded into drawTerrain's single unified paper-tooth
// pass, so this isn't stacking a second independent layer of noise on top.
function paintLandEarly(g,cx,cy,hw,hh,z,base,lt,dk,seed){
  g.lineCap='round';
  for(let i=0;i<5;i++){ const a=vhash(seed,70+i)*2-1,b=vhash(seed,80+i)*2-1, gx=cx+a*hw*0.55, gy=cy+b*hh*0.45; // grass blades
    g.strokeStyle= i%2?(VOID?'rgba(158,158,148,0.5)':'rgba(150,168,96,0.5)'):(VOID?'rgba(96,98,88,0.5)':'rgba(92,110,58,0.5)'); g.lineWidth=0.56*z;
    g.beginPath();g.moveTo(gx,gy);g.quadraticCurveTo(gx+0.6*z,gy-2.3*z,gx+a*1.2*z,gy-3.6*z);g.stroke(); }
  g.lineCap='butt';
}

// full-screen dawn light + atmospheric depth (cheap: 3 fills)
function paintAtmosphereEarly(g){
  const dep=g.createLinearGradient(0,0,0,VH); dep.addColorStop(0,'rgba(196,206,214,0.32)'); dep.addColorStop(0.5,'rgba(214,206,186,0.10)'); dep.addColorStop(1,'rgba(150,130,96,0.07)');
  g.fillStyle=dep; g.fillRect(0,0,VW,VH);                                        // cool-high / warm-low depth haze
  const lx=VW*0.26, ly=VH*0.15, rad=g.createRadialGradient(lx,ly,0,lx,ly,Math.max(VW,VH)*0.82);
  rad.addColorStop(0,'rgba(255,236,196,0.24)'); rad.addColorStop(0.5,'rgba(255,224,176,0.07)'); rad.addColorStop(1,'rgba(255,224,176,0)');
  g.save(); g.globalCompositeOperation='lighter'; g.fillStyle=rad; g.fillRect(0,0,VW,VH); g.restore(); // dawn directional glow
  g.save(); g.globalCompositeOperation='soft-light'; g.fillStyle='rgba(216,182,122,0.20)'; g.fillRect(0,0,VW,VH); g.restore(); // unifying warm wash
  g.save(); g.globalCompositeOperation='lighter';                                  // soft sun shaft from the NW
  const sg=g.createLinearGradient(VW*0.05,0,VW*0.5,VH*0.75); sg.addColorStop(0,'rgba(255,242,206,0.10)'); sg.addColorStop(1,'rgba(255,242,206,0)');
  g.fillStyle=sg; g.beginPath(); g.moveTo(0,0); g.lineTo(VW*0.42,0); g.lineTo(VW*0.18,VH); g.lineTo(0,VH); g.closePath(); g.fill(); g.restore();
  const mt=ptNow()*0.00006, my=VH*0.62+Math.sin(mt)*10;                            // low drifting morning mist over the water
  const mg=g.createLinearGradient(0,my-VH*0.13,0,my+VH*0.13); mg.addColorStop(0,'rgba(216,224,226,0)'); mg.addColorStop(0.5,'rgba(216,224,226,0.15)'); mg.addColorStop(1,'rgba(216,224,226,0)');
  g.fillStyle=mg; g.fillRect(0,my-VH*0.13,VW,VH*0.26);
}

// hand-crafted base: grass skirt + soft ambient-occlusion contact + a moss fleck or two
function paintCraftBase(g,cx,cy,z,seed){
  const hh=TH/2*z;
  g.fillStyle='rgba(24,18,10,0.10)'; g.beginPath(); g.ellipse(cx,cy+hh*0.30,TW*0.40*z,TW*0.16*z,0,0,7); g.fill(); // soft AO into ground
  g.lineCap='round';
  for(let i=0;i<8;i++){ const a=(i/8-0.5), gx=cx+a*TW*0.46*z, gy=cy+hh*0.30+(vhash(seed,i)*2-1)*1.4*z;
    g.strokeStyle= i%2?(VOID?'rgba(132,134,122,0.75)':'rgba(122,142,80,0.75)'):(VOID?'rgba(92,94,82,0.75)':'rgba(86,104,54,0.75)'); g.lineWidth=0.63*z;
    g.beginPath();g.moveTo(gx,gy);g.quadraticCurveTo(gx+0.8*z,gy-2.6*z,gx+a*4*z,gy-3.8*z);g.stroke(); }
  g.lineCap='butt';
}
// irregular thatch fringe along an eave line (apex->eaveL, apex->eaveR)
function paintThatchFringe(g,apex,eL,eR,z,col){ g.strokeStyle=col; g.lineCap='round';
  for(let i=2;i<7;i++){ const f=i/7; for(const e of [eL,eR]){ const bx=apex[0]+(e[0]-apex[0])*f, by=apex[1]+(e[1]-apex[1])*f;
    g.lineWidth=(0.7+vhash(bx,f)*0.7)*z; g.beginPath(); g.moveTo(bx,by); g.lineTo(bx+(vhash(bx,2)*2-1)*1.4*z, by+(1.6+vhash(by,3)*1.6)*z); g.stroke(); } }
  g.lineCap='butt'; }
// quick wood grain on a vertical timber
function paintGrain(g,x,yTop,yBot,z){ g.strokeStyle='rgba(40,28,16,0.3)'; g.lineWidth=0.28*z;
  g.beginPath(); g.moveTo(x,yTop); g.bezierCurveTo(x+0.6*z,yTop+(yBot-yTop)*0.4, x-0.6*z,yTop+(yBot-yTop)*0.7, x,yBot); g.stroke(); }

/* ============================================================
   PAINTERLY PASS 3 — dissolve the grid further: dappled cloud
   light over the whole landmass, directional building shadows.
   Gated to S.era<=1 by callers.
   ============================================================ */
// landmass-scale light + drifting cloud shadows (Bad North dappling). Cheap: ~6 fills.
function paintLandmassEarly(g){ const t=ptNow()*0.00004;
  const lg=g.createLinearGradient(VW*0.18,0,VW*0.82,VH);                    // warm sun NW -> cool shadow SE
  lg.addColorStop(0,'rgba(255,240,204,0.13)'); lg.addColorStop(0.55,'rgba(255,240,204,0)'); lg.addColorStop(1,'rgba(58,78,94,0.13)');
  g.fillStyle=lg; g.fillRect(0,0,VW,VH);
  g.save(); g.globalCompositeOperation='multiply';
  for(let i=0;i<5;i++){ const px=(((i*0.27)+t)%1.35-0.18)*VW, py=VH*(0.26+0.13*i)+Math.sin(t*30+i*1.7)*18, r=VW*(0.13+0.05*((i*37)%5)/5);
    const cl=g.createRadialGradient(px,py,0,px,py,r); cl.addColorStop(0,'rgba(66,84,60,0.17)'); cl.addColorStop(1,'rgba(66,84,60,0)');
    g.fillStyle=cl; g.beginPath();g.ellipse(px,py,r,r*0.58,0,0,7);g.fill(); }
  g.restore(); }
// soft directional contact shadow so a structure sits IN the ground (light from NW)
function paintCastShadow(g,cx,cy,z){ const hh=TH/2*z; g.fillStyle='rgba(26,30,36,0.055)';
  g.beginPath(); g.ellipse(cx+TW*0.20*z, cy+hh*0.36, TW*0.44*z, TW*0.18*z, -0.28, 0,7); g.fill(); }

/* Silhouette LOD for any building: two wall faces + roof massing only — no windows,
   noren, glass, props or ribs. Drawn into the same buffer so the sumi-e ink outline is
   preserved; only the sub-pixel interior detail (invisible at overview zoom) is dropped. */
function drawBuildingLOD(g,cx,cy,z,st){ const hw=TW/2*z,hh=TH/2*z,wallH=(st.h||20)*z,night=envNight();
  shadowEllipse(g,cx,cy+hh*0.4,TW*0.42,z);
  let wall=st.wall||'#ece0c4'; if(night>0.3)wall=shade(wall,-Math.round(night*24));
  const wallD=shade(wall,-34);
  g.fillStyle=wallD; g.beginPath();g.moveTo(cx-hw,cy);g.lineTo(cx,cy+hh);g.lineTo(cx,cy+hh-wallH);g.lineTo(cx-hw,cy-wallH);g.closePath();g.fill();
  g.fillStyle=wall;  g.beginPath();g.moveTo(cx,cy+hh);g.lineTo(cx+hw,cy);g.lineTo(cx+hw,cy-wallH);g.lineTo(cx,cy+hh-wallH);g.closePath();g.fill();
  const roof=st.roof||'#3d6e8c', roofD=shade(roof,-26), ry=cy-wallH, ov=(st.ov||9)*z, ridge=(st.rh||16)*z;
  if(st.flat||st.factoryRoof||st.glassTower){ // flat cap
    g.fillStyle=night>0.3?shade(roof,-Math.round(night*20)):roof;
    g.beginPath();g.moveTo(cx,ry-hh);g.lineTo(cx+hw,ry);g.lineTo(cx,ry+hh);g.lineTo(cx-hw,ry);g.closePath();g.fill();
    if(st.neon){g.fillStyle=st.neon;g.fillRect(cx-1.5*z,ry-hh,3*z,3*z);} return; }
  // hipped silhouette: flared eaves diamond rising to a ridge, split lit/shadow
  const thatch=st.thatch, rc=thatch?'#bfa252':roof, rcD=thatch?shade('#bfa252',-30):roofD, sc=thatch?1.16:1;
  const hh2=hh*sc,hw2=hw*sc,ov2=ov*sc,rg=ridge*sc;
  const eT=[cx,ry-hh2-ov2*0.5],eR=[cx+hw2+ov2,ry],eB=[cx,ry+hh2+ov2*0.5],eL=[cx-hw2-ov2,ry],rT=[cx,ry-hh2-rg],rB=[cx,ry+hh2-rg];
  g.fillStyle=rc;  g.beginPath();g.moveTo(eR[0],eR[1]);g.lineTo(eB[0],eB[1]);g.lineTo(rB[0],rB[1]);g.lineTo(rT[0],rT[1]);g.lineTo(eT[0],eT[1]);g.closePath();g.fill();
  g.fillStyle=rcD; g.beginPath();g.moveTo(eL[0],eL[1]);g.lineTo(eB[0],eB[1]);g.lineTo(rB[0],rB[1]);g.lineTo(rT[0],rT[1]);g.lineTo(eT[0],eT[1]);g.closePath();g.fill();
}
function drawZoneBuilding(g,cx,cy,z,c){ if(c.dev<=0){ drawLot(g,cx,cy,z,c.zone); return; }
  const st=zoneStyle(c.zone,S.era,c.dev,c.seed);
  if(S.era<=1){ const mark=()=>{ if(c.own){ g.fillStyle=c.own===CLIENT?'#14f195':'#ff7a3d'; g.fillRect(cx-1.4*z,cy-16*z,2.8*z,2.8*z); } if(c.blight){ g.fillStyle='rgba(60,40,20,'+(0.12*c.blight)+')'; diamondPath(g,cx,cy,z); g.fill(); } };
    if(c.zone===ZR){ drawDwellingP(g,cx,cy,z,st); mark(); return; }
    if(c.zone===ZC){ drawStallP(g,cx,cy,z,st); mark(); return; }
    if(c.zone===ZI){ drawGranaryP(g,cx,cy,z,st); mark(); return; } }
  if(st.stall){ drawStall(g,cx,cy,z,st); if(c.own){ g.fillStyle=c.own===CLIENT?'#14f195':'#ff7a3d'; g.fillRect(cx-1.4*z,cy-16*z,2.8*z,2.8*z); } if(c.blight){g.fillStyle='rgba(60,40,20,'+(0.12*c.blight)+')';diamondPath(g,cx,cy,z);g.fill();} return; }
  if(LOD) drawBuildingLOD(g,cx,cy,z,st); else { st.wear=Math.min(1,(c.blight||0)/3); drawBuilding(g,cx,cy,z,st); }
  if(c.own){ g.fillStyle=c.own===CLIENT?'#14f195':'#ff7a3d'; g.fillRect(cx-1.4*z,cy-(st.h+st.rh+6)*z,2.8*z,2.8*z); }
  if(c.blight){ g.fillStyle='rgba(60,40,20,'+(0.12*c.blight)+')'; diamondPath(g,cx,cy,z); g.fill(); }
}
function drawRuin(g,cx,cy,z,scorch,parkRuin){ const hw=TW/2*z,hh=TH/2*z; shadowEllipse(g,cx,cy+hh*0.3,TW*0.3,z);
  if(parkRuin){                                                                            // park/farm destroyed -> a low rubble heap, not a collapsed-building silhouette
    const seed=cx*0.07+cy*0.11;
    g.save(); g.fillStyle='rgba(40,32,24,0.30)'; g.beginPath(); g.ellipse(cx,cy+hh*0.32,hw*0.62,hh*0.34,0,0,7); g.fill(); g.restore();   // ground shadow, low and wide
    const stones=[[-0.30,0,3.2,0.55],[0.18,-0.08,2.6,0.42],[-0.05,-0.32,2.2,0.36],[0.34,0.14,1.9,0.30],[-0.42,0.18,1.7,0.27]];
    for(let i=0;i<stones.length;i++){ const[sx,sy,sr,sh]=stones[i], px=cx+sx*hw, py=cy+sy*hh*0.6,
        tone=vhash(seed,i*13)>0.5?'#6a5c4a':'#5a4c3c';
      g.fillStyle=tone; g.beginPath(); g.ellipse(px,py,sr*z,sr*sh*z,0,0,7); g.fill();
      g.fillStyle='#7e6e58'; g.beginPath(); g.ellipse(px-sr*0.2*z,py-sr*sh*0.3*z,sr*0.45*z,sr*sh*0.4*z,0,0,7); g.fill(); }     // highlight chip on each stone
    g.strokeStyle='#3a2e22'; g.lineWidth=0.4*z;                                            // a few scattered splinters/stakes — reads as cleared rubble, not architecture
    for(let i=0;i<3;i++){ const a=vhash(seed,40+i)*6.283, rr=(2+vhash(seed,50+i)*2.4)*z;
      g.beginPath(); g.moveTo(cx+Math.cos(a)*rr,cy+Math.sin(a)*rr*0.5); g.lineTo(cx+Math.cos(a)*(rr+3*z),cy+Math.sin(a)*(rr+3*z)*0.5-2.5*z); g.stroke(); }
    return; }
  if(scorch){                                                                              // arson aftermath reads distinctly from plain ruin — burnt, not just broken
    g.save(); g.fillStyle='rgba(20,16,14,0.5)'; g.beginPath();g.ellipse(cx,cy+hh*0.25,hw*0.95,hh*0.5,0,0,7);g.fill(); g.restore();   // ash halo on the ground, wider than the frame
    g.fillStyle='#241c18'; g.beginPath();g.moveTo(cx-hw*0.5,cy);g.lineTo(cx,cy+hh*0.5);g.lineTo(cx,cy-9*z);g.lineTo(cx-hw*0.5,cy-13*z);g.closePath();g.fill();
    g.fillStyle='#1a1411'; g.beginPath();g.moveTo(cx,cy+hh*0.5);g.lineTo(cx+hw*0.4,cy+hh*0.2);g.lineTo(cx+hw*0.4,cy-7*z);g.lineTo(cx,cy-9*z);g.closePath();g.fill();
    g.strokeStyle='#0e0a08'; g.lineWidth=0.35*z;                                           // crackled char lines on the blackened timber, not the clean plank lines of plain ruin
    for(let k=0;k<5;k++){ const xx=cx-hw*0.42+k*4.2*z; g.beginPath();g.moveTo(xx,cy-1*z-k%2*2*z);g.lineTo(xx+1.2*z,cy-11*z+k%3*1.5*z);g.stroke(); }
    g.fillStyle='#100c0a'; g.fillRect(cx-hw*0.3,cy-7*z,4*z,5*z);                            // doorway, gone fully black inside
    g.fillStyle='#3a2e26'; for(let k=0;k<4;k++){g.fillRect(cx-hw*0.4+k*5*z,cy+hh*0.2,2*z,1.6*z);}   // charred debris, not weathered planks
    // faint residual smoke wisp — the embers are out but the site still reads as freshly burnt
    const tt=(typeof fx!=='undefined'?fx:0)*0.001, seed=cx*0.11+cy*0.07;
    g.save(); g.globalAlpha=0.22; g.fillStyle='rgba(60,56,52,0.5)';
    for(let i=0;i<3;i++){ const ph=((tt*0.18+i*0.3+seed)%1), sx=cx+Math.sin(tt*0.6+i+seed)*3*z, sy=cy-9*z-ph*16*z;
      g.beginPath();g.arc(sx,sy,(2+ph*5)*z,0,7);g.fill(); }
    g.restore();
    return; }
  g.fillStyle='#6a5c4a'; g.beginPath();g.moveTo(cx-hw*0.5,cy);g.lineTo(cx,cy+hh*0.5);g.lineTo(cx,cy-9*z);g.lineTo(cx-hw*0.5,cy-13*z);g.closePath();g.fill();
  g.fillStyle='#5a4c3c'; g.beginPath();g.moveTo(cx,cy+hh*0.5);g.lineTo(cx+hw*0.4,cy+hh*0.2);g.lineTo(cx+hw*0.4,cy-7*z);g.lineTo(cx,cy-9*z);g.closePath();g.fill();
  g.fillStyle='#241a14'; g.fillRect(cx-hw*0.3,cy-7*z,4*z,5*z);
  g.fillStyle='#7e6e58'; for(let k=0;k<4;k++){g.fillRect(cx-hw*0.4+k*5*z,cy+hh*0.2,2*z,2*z);}
  g.fillStyle='#5a7a3a'; g.fillRect(cx-hw*0.45,cy-2*z,2*z,3*z); g.fillRect(cx+hw*0.3,cy+hh*0.1,2*z,3*z);
}
function drawCivic(g,cx,cy,z,civ,era){ const E=ERAS[Math.min(era,4)];
  const styles={
    [TOWN]:{h:30,roof:'#8a2f26',wall:'#f0e6cc',post:'#7a2d24',rh:22,ov:13,props:['banner']},
    [FARM]:null,
    [MARKET]:{h:18,roof:'#9c5a2a',wall:'#efe2c4',post:'#7a2d24',rh:12,ov:11,props:['goods']},
    [SCHOOL]:{h:20,roof:'#3a6ea5',wall:'#f0e6cc',post:'#5a3d24',rh:16,ov:10,stories:2},
    [HOSP]:{h:26,roof:'#c43a2c',wall:'#f4eeda',post:'#a02018',rh:16,ov:9,modern:era>=8,props:['lantern2']},
    [LIB]:{h:20,roof:'#caa23a',wall:'#efe2c4',post:'#7a2d24',rh:16,ov:11,tiers:true,props:['scrollstack']},
    [PARK]:null,
    [PLANT]:{h:26,roof:'#5a5a5a',wall:'#8a8076',post:'#3a3a3a',rh:10,ov:5,factoryRoof:true,neon:'#14f195',props:['smokestack']},
    [FIRE]:{h:22,roof:'#3a3f6a',wall:'#efe2c4',post:'#7a2d24',rh:16,ov:10},
    [POLICE]:{h:22,roof:'#2c3038',wall:'#e8ecef',post:'#3a3a3a',rh:14,ov:9,modern:era>=8},
    [VALID]:{h:30,roof:'#1a3a3a',wall:'#14302e',post:'#14f195',rh:20,ov:12,neon:'#14f195'},
    [TEMPLE]:{h:24,roof:'#caa23a',wall:'#f0e6cc',post:'#a03020',rh:20,ov:13,tiers:true,props:['lantern2','torii_small']},
  };
  if(civ===FARM){ drawFarmField(g,cx,cy,z); return; }
  if(civ===PARK){ drawPark(g,cx,cy,z); return; }
  if(LOD){ drawBuildingLOD(g,cx,cy,z,styles[civ]||styles[MARKET]); return; }   // overview: massing only
  drawBuilding(g,cx,cy,z,styles[civ]||styles[MARKET]);
  const hw=TW/2*z, top=cy-(styles[civ].h+styles[civ].rh+4)*z;
  if(civ===MARKET){ // static stallkeeper figures — fixed to the building, no simulation cost, flanking the front corners clear of the doorway/goods
    const hh=TH/2*z, _u=(cx-cam.x)/z,_v=(cy-cam.y)/z, mWX=Math.round(_u/TW+_v/TH),mWY=Math.round(_v/TH-_u/TW), mseed=Math.abs((mWX*5+mWY*9)|0);
    drawVendorFigure(g,cx-hw*0.62,cy-hh*0.05,z*1.3,SKIN[mseed%SKIN.length],KIM[mseed%KIM.length]);
    drawVendorFigure(g,cx+hw*0.66,cy+hh*0.1,z*1.3,SKIN[(mseed+3)%SKIN.length],KIM[(mseed+7)%KIM.length]); }
  // emblems
  g.fillStyle='#fff';
  if(civ===HOSP){ g.fillStyle='#fff'; g.fillRect(cx-1.4*z,top,2.8*z,7*z); g.fillRect(cx-3.5*z,top+2*z,7*z,2.8*z); } // cross
  else if(civ===SCHOOL){ g.fillStyle='#e8c24a'; g.fillRect(cx-3*z,top+1*z,6*z,4*z); g.fillStyle='#fff'; g.fillRect(cx-0.5*z,top+1*z,1*z,4*z);} // book
  else if(civ===LIB){ g.fillStyle='#caa24a'; g.fillRect(cx-2.5*z,top,5*z,5*z);}
  else if(civ===MARKET){ g.fillStyle='#7a2d24'; g.beginPath();g.ellipse(cx,top+3*z,3*z,2.2*z,0,0,7);g.fill(); g.strokeStyle='#efe2c4';g.lineWidth=0.42*z;g.beginPath();g.moveTo(cx-2.4*z,top+1.4*z);g.lineTo(cx+2.4*z,top+1.4*z);g.stroke();} // basket emblem
  else if(civ===TEMPLE){ // temple bell silhouette above the roofline
    g.fillStyle='#caa23a'; g.beginPath();g.moveTo(cx-2.6*z,top+6*z);g.lineTo(cx-1.8*z,top);g.lineTo(cx+1.8*z,top);g.lineTo(cx+2.6*z,top+6*z);g.closePath();g.fill();
    g.fillStyle='#7a5a1a'; g.fillRect(cx-0.7*z,top-2.2*z,1.4*z,2.2*z); g.fillStyle='#5a3e10';g.fillRect(cx-3*z,top+5.6*z,6*z,1*z); }
  else if(civ===FIRE){ // yagura fire-watch post + hanging hanshō bell
    g.fillStyle='#5a3d24'; g.fillRect(cx-1*z,top-7*z,2*z,9*z);
    g.fillStyle='#caa23a'; g.beginPath();g.arc(cx,top-6*z,2.6*z,0,7);g.fill();
    g.fillStyle='#8a6a1a'; g.fillRect(cx-0.6*z,top-3.6*z,1.2*z,1.6*z);
    g.fillStyle='#14f195'; g.fillRect(cx-0.5*z,top-8.4*z,1*z,1.6*z); }
  else if(civ===POLICE){ // red kōban lamp + white band
    g.fillStyle='#c43a2c'; g.beginPath();g.arc(cx,top+1.5*z,2.3*z,0,7);g.fill();
    g.fillStyle='#ffd9cf'; g.beginPath();g.arc(cx-0.7*z,top+0.8*z,0.8*z,0,7);g.fill();
    g.fillStyle='#fff'; g.fillRect(cx-3*z,top+4*z,6*z,1.5*z); }
  else if(civ===VALID){ g.fillStyle='#14f195'; g.fillRect(cx-5*z,top+4*z,10*z,1.6*z); g.fillRect(cx-3.4*z,top,1.8*z,7*z); g.fillRect(cx+1.6*z,top,1.8*z,7*z);} // torii
  else if(civ===PLANT){ g.fillStyle='#6a6a6a'; g.fillRect(cx+hw*0.3,cy-(styles[civ].h+8)*z,4*z,10*z); g.fillStyle='rgba(220,220,220,0.5)'; g.beginPath();g.arc(cx+hw*0.3+2*z,cy-(styles[civ].h+10)*z,4*z,0,7);g.fill();}
}
// crop full-colour accents at full bloom (mature/ready) — kept vivid like fire/blood, the rest of the
// field stays in the inked tilled-soil tone so the crop colour is what reads as "alive" against it.
const CROP_COLOR={ rice:'#e8e0a0', millet:'#d4b860', daikon:'#eef0e6', soy:'#7a9a4a', tea:'#3a6e44', eggplant:'#5a3a7a' };
const CROP_LEAF ={ rice:'#7a9a4a', millet:'#6a8a3a', daikon:'#4a7a3e', soy:'#5a8a3a', tea:'#2a5234', eggplant:'#3a6a3a' };
function drawFarmField(g,cx,cy,z,c){
  const hw=TW/2*z,hh=TH/2*z, stage=(c&&c.stage)||0, crop=(c&&c.cropType)||'rice';
  diamondPath(g,cx,cy,z); g.fillStyle=inkize('#b89150'); g.fill();
  g.strokeStyle=inkize('#9a7338'); g.lineWidth=0.84*z;
  for(let i=1;i<4;i++){ const f=i/4;                                          // tilled furrow lines — always visible, every stage
    g.beginPath();g.moveTo(cx-hw+hw*f,cy-hh+hh*f);g.lineTo(cx+hw*f,cy+hh*f-hh);g.stroke();
    g.beginPath();g.moveTo(cx-hw*f,cy-hh*f+hh);g.lineTo(cx+hw-hw*f,cy+hh-hh*f);g.stroke(); }
  if(stage===0) return;                                                       // freshly tilled — bare soil only
  const seed=c.seed;
  if(stage===1){                                                              // seeded — faint dotted rows, no colour yet
    g.fillStyle=inkize('#6a5a3a'); for(let i=0;i<8;i++){const a=vhash(seed,i*3)*2-1,b=vhash(seed,i*5+1)*2-1; g.fillRect(cx+a*hw*0.55,cy+b*hh*0.55,1.4*z,1.4*z);} return; }
  if(stage===2){                                                              // sprout — small green shoots, still desaturated/inked
    g.fillStyle=inkize(CROP_LEAF[crop]); for(let i=0;i<8;i++){const a=vhash(seed,i*3)*2-1,b=vhash(seed,i*5+1)*2-1;
      const px=cx+a*hw*0.55, py=cy+b*hh*0.55; g.fillRect(px,py,1.6*z,2.6*z); } return; }
  // stage 3 (mature) and 4 (ready): full crop, ready also gets a brighter colour pop to read as harvest-due
  const pop = stage===4 ? 1 : 0.7;
  g.fillStyle=CROP_LEAF[crop]; for(let i=0;i<8;i++){const a=vhash(seed,i*3)*2-1,b=vhash(seed,i*5+1)*2-1;
    const px=cx+a*hw*0.55, py=cy+b*hh*0.55-1.6*z; g.fillRect(px,py,1.8*z,3.2*z); }       // stalk/leaf clusters
  g.save(); g.globalAlpha=pop; g.fillStyle=CROP_COLOR[crop];
  for(let i=0;i<8;i++){const a=vhash(seed,i*3)*2-1,b=vhash(seed,i*5+1)*2-1;
    const px=cx+a*hw*0.55, py=cy+b*hh*0.55-3*z;
    if(crop==='rice'||crop==='millet'){ g.beginPath();g.ellipse(px,py,1.3*z,2*z,0,0,7);g.fill(); }            // grain head
    else if(crop==='daikon'){ g.beginPath();g.ellipse(px,py+2.6*z,1.6*z,1*z,0,0,7);g.fill(); }                 // pale root peeking at soil line
    else if(crop==='soy'){ g.beginPath();g.ellipse(px,py,1*z,1.3*z,0,0,7);g.fill(); }                           // pod cluster
    else if(crop==='tea'){ g.beginPath();g.arc(px,py-0.6*z,1.1*z,0,7);g.fill(); }                               // leaf bud
    else { g.beginPath();g.ellipse(px,py,1.2*z,1.7*z,0.3,0,7);g.fill(); } }                                     // eggplant fruit
  g.restore();
}
function drawPark(g,cx,cy,z){ const hw=TW/2*z,hh=TH/2*z; diamondPath(g,cx,cy,z); g.fillStyle='#4f9a52'; g.fill();
  g.strokeStyle='#3f8a4a';g.lineWidth=0.7*z; diamondPath(g,cx,cy,z*0.6); g.stroke();
  g.fillStyle='#8a6a3a'; g.fillRect(cx-1*z,cy-2*z,2*z,4*z); g.fillStyle='#2f6b34'; g.beginPath();g.ellipse(cx,cy-5*z,5*z,5*z,0,0,7);g.fill();
  g.fillStyle='#e85a8a'; g.fillRect(cx-hw*0.4,cy+2*z,2*z,2*z); g.fillStyle='#e8c24a'; g.fillRect(cx+hw*0.3,cy+1*z,2*z,2*z); }
/* ---- species classifier: picks one of 6 tree types from seed + position context.
   Zoning mirrors real Jomon-era planting logic: pine on rocky/outer edges, cedar+cypress on
   forested high ground, maple+zelkova near the settled core/buildings, sakura rare & scenic.
   Pure function of (seed,tx,ty,h) — never touched by RNG.random, so species stay stable
   across rebuilds/zoom and the tree count/placement (FOREST tile density) is unchanged. */
function treeSpecies(seed,tx,ty,h){
  h=h||0;
  const cxw=W/2, cyw=H/2, dn=Math.hypot((tx-cxw)/30,(ty-cyw)/30);      // 0=center .. ~1 = original core edge
  const P=agePal();
  if(seed < (P.bloom?0.22:0.045)) return 'sakura';                     // rare, scenic — wider only at Heian bloom peak
  const edge = dn>0.74;                                                 // outer ring / rocky margin
  const high = h>0.42;                                                  // forested high ground
  let nearBuild=false;
  for(const[dx,dy]of NEIGH){ const ax=tx+dx,ay=ty+dy; if(inB(ax,ay)&&occupied(grid[ay][ax])){nearBuild=true;break;} }
  if(edge) return vhash(seed,401)<0.68 ? 'pine' : 'cypress';            // outer/rocky: black pine dominant, hinoki mixed in
  if(high)  return vhash(seed,402)<0.55 ? 'cedar' : 'cypress';          // high ground: sugi + hinoki cypress
  if(nearBuild) return vhash(seed,403)<0.55 ? 'maple' : 'zelkova';      // settled core: maple + zelkova line the streets
  const r=vhash(seed,404); return r<0.30?'maple':(r<0.62?'zelkova':'cedar'); // open mid-ground mix
}
function treeShadow(g,cx,cy,rw,z){ const ox=cx-3.2*z, oy=cy+1.4*z;   // offset opposite the implied upper-left light
  g.save(); g.translate(ox,oy); g.scale(1,0.4);
  const R=Math.max(0.5,rw*z);
  const rg=g.createRadialGradient(0,0,0,0,0,R);
  rg.addColorStop(0,'rgba(18,14,9,0.20)'); rg.addColorStop(0.55,'rgba(18,14,9,0.10)'); rg.addColorStop(1,'rgba(18,14,9,0)');
  g.fillStyle=rg; g.beginPath(); g.arc(0,0,R,0,7); g.fill(); g.restore(); }
/* clumped, irregular canopy lobes seeded per-tree — replaces a single concentric-ellipse
   stack (which collapses to a flat circle once inkize removes hue, leaving only 1-2 tonal
   steps). Lobes are offset around the crown centre so the silhouette reads as a cluster of
   foliage masses, with highlight lobes biased toward the upper-left (implied light side). */
function canopyLobes(cx,fy,z,seed,n,baseR,spread){
  const out=[]; for(let i=0;i<n;i++){ const a=(i/n)*6.283+(vhash(seed,i*7)*2-1)*0.4;
    const rad=(spread*0.55+vhash(seed,i*11)*spread*0.35)*z;
    out.push([cx+Math.cos(a)*rad, fy+Math.sin(a)*rad*0.5, (baseR*0.75+vhash(seed,i*13)*baseR*0.4)*z]); }
  return out; }
function drawTree(g,cx,cy,z,seed,h,tx,ty){ h=h||0; const cold=false; treeShadow(g,cx,cy,8,z);
  const P=(VOID?AGEPAL[0]:agePal()), tg=P.dry>0?desatHex(P.tree,P.dry*0.7):P.tree;   // foliage timeless: fixed across ages
  const kind = (typeof tx==='number') ? treeSpecies(seed,tx,ty,h) : ((seed>0.6)?'pine':(seed<(P.bloom?0.34:0.10)?'sakura':'maple'));
  const mono = VOID && kind!=='sakura';   // cherry blossoms keep full colour; all other foliage -> ink-wash
  const ink = c=>mono?inkize(c):c;
  if(z<0.5||LOD){ // LOD: distant/overview foliage = a couple of blobs, not ~20 paths
    const lc = kind==='sakura' ? '#e3a8c6' : (kind==='maple'?mix('#7a3a28',tg,0.42):mix('#2c6230',tg,0.5));
    g.fillStyle=ink(lc); g.beginPath(); g.ellipse(cx,cy-7*z,7*z,6*z,0,0,7); g.fill();
    g.fillStyle=ink('#5a3e22'); g.fillRect(cx-1.5*z,cy-3*z,3*z,5*z); return; }
  if(kind==='pine'){ g.fillStyle=ink('#5a3a22'); g.fillRect(cx-1.5*z,cy-6*z,3*z,8*z);
    const tiers=5, dark=mix('#1f3a20',tg,0.6), lit=mix('#3f7a3f',tg,0.42);
    g.save(); g.globalAlpha=0.42; g.fillStyle=ink(mix('#2f5e30',tg,0.5));   // soft bloom behind the whole tier stack — softens the hard pine silhouette
    for(let i=0;i<tiers;i++){ const yy=cy-4*z-i*5.4*z, w=(12-i*2)*z*1.18;
      g.beginPath();g.moveTo(cx,yy-9*z);g.lineTo(cx+w,yy+0.6*z);g.lineTo(cx,yy+2.4*z);g.lineTo(cx-w,yy+0.6*z);g.closePath();g.fill(); }
    g.restore();
    for(let i=0;i<tiers;i++){ const yy=cy-4*z-i*5.4*z, w=(12-i*2)*z;
      g.fillStyle=ink(dark); g.beginPath();g.moveTo(cx,yy-8*z);g.lineTo(cx+w,yy);g.lineTo(cx,yy+1.6*z);g.lineTo(cx-w,yy);g.closePath();g.fill();   // shadow (right) half, deepened for real tonal range
      g.fillStyle=ink(lit); g.beginPath();g.moveTo(cx,yy-8*z);g.lineTo(cx-w*0.55,yy-2*z);g.lineTo(cx-w,yy);g.lineTo(cx,yy+1.6*z);g.closePath();g.fill(); }   // lit (left) half, closed down to the tier base so it doesn't float
    g.fillStyle=ink('#caa24a');if(seed>0.9){g.beginPath();g.arc(cx,cy-31*z,1.4*z,0,7);g.fill();}
    return; }
  if(kind==='cedar'){ // Japanese Cedar (Sugi) — tall, narrow, drooping conical tiers, dark dense green
    const top=cy-7*z;
    g.fillStyle=ink('#3a2818'); g.fillRect(cx-1.6*z,top-2*z,3.2*z,9*z+2*z);
    g.fillStyle=ink('#2a1c10'); g.fillRect(cx+0.1*z,top-2*z,1.5*z,9*z+2*z);   // bark-side shade strip so the trunk reads round, not flat
    const tiers=6, dark=mix('#1e3018',tg,0.55), lit=mix('#3a5c2e',tg,0.34);
    for(let i=0;i<tiers;i++){ const yy=top-i*4.6*z, w=(9-i*0.9)*z;
      g.fillStyle=ink(dark); g.beginPath();g.moveTo(cx,yy-6.4*z);g.lineTo(cx+w,yy);g.lineTo(cx,yy+1.4*z);g.lineTo(cx-w,yy);g.closePath();g.fill();
      g.fillStyle=ink(lit); g.beginPath();g.moveTo(cx,yy-6.4*z);g.lineTo(cx-w*0.5,yy-1.6*z);g.lineTo(cx-w,yy);g.lineTo(cx,yy+1.4*z);g.closePath();g.fill(); }
    return; }
  if(kind==='cypress'){ // Hinoki Cypress — narrow, dense, soft drooping fan-like sprays, clumped not smooth
    g.fillStyle=ink('#3e2c18'); g.fillRect(cx-1.5*z,cy-6*z,3*z,8*z);
    g.fillStyle=ink('#2e2110'); g.fillRect(cx+0.1*z,cy-6*z,1.3*z,8*z);
    const fy=cy-12*z, dark=mix('#28401f',tg,0.5), mid=mix('#3a5836',tg,0.42), lit=mix('#587a4e',tg,0.28);
    const lobes=canopyLobes(cx,fy,z,seed,5,4.0,5.0);
    g.fillStyle=ink(dark); g.beginPath();g.ellipse(cx,fy+1*z,7*z,8.5*z,0,0,7);g.fill();   // dark base mass, sits behind everything
    for(const[lx,ly,lr]of lobes){ g.fillStyle=ink(mid); g.beginPath();g.ellipse(lx,ly,lr*0.95,lr*1.05,0,0,7);g.fill(); }   // mid-tone lobes — the bulk of the visible texture
    const hl=lobes.slice().sort((a,b)=>a[0]-b[0]).slice(0,2);   // upper-left bias only, layered on top so it actually shows
    for(const[lx,ly,lr]of hl){ g.fillStyle=ink(lit); g.beginPath();g.ellipse(lx-0.8*z,ly-1*z,lr*0.55,lr*0.6,0,0,7);g.fill(); }
    return; }
  if(kind==='zelkova'){ // Japanese Zelkova — tall straight trunk, fan/vase-shaped spreading crown
    const trunkTop=cy-9*z;
    g.fillStyle=ink('#43301c'); g.fillRect(cx-1.6*z,trunkTop,3.2*z,cy-trunkTop);
    g.fillStyle=ink('#332313'); g.fillRect(cx+0.1*z,trunkTop,1.5*z,cy-trunkTop);
    g.strokeStyle=ink('#43301c');g.lineWidth=0.8*z;
    g.beginPath();g.moveTo(cx,cy-9*z);g.lineTo(cx-4*z,cy-14*z);g.moveTo(cx,cy-9*z);g.lineTo(cx+4*z,cy-14*z);g.stroke();
    const fy=cy-15*z; let fol=[mix('#28421f',tg,0.5),mix('#3e6234',tg,0.40),mix('#5e8a52',tg,0.26)];
    if(mono) fol=fol.map(inkize);
    const lobes=canopyLobes(cx,fy,z,seed,7,4.6,8.5);
    g.fillStyle=fol[0]; g.beginPath();g.ellipse(cx,fy+1*z,11*z,5.6*z,0,0,7);g.fill();   // dark base mass — wide, flat vase silhouette
    for(const[lx,ly,lr]of lobes){ g.fillStyle=fol[1]; g.beginPath();g.ellipse(lx,ly,lr*0.9,lr*0.62,0,0,7);g.fill(); }
    const hl=lobes.slice().sort((a,b)=>a[0]-b[0]).slice(0,3);
    for(const[lx,ly,lr]of hl){ g.fillStyle=fol[2]; g.beginPath();g.ellipse(lx-0.7*z,ly-0.9*z,lr*0.5,lr*0.32,0,0,7);g.fill(); }
    return; }
  // 'maple' and 'sakura' share the rounded clumped-canopy broadleaf base form
  let fol = kind==='sakura'?['#b85a82','#d98bb4','#f6c9de'] : kind==='maple'?[mix('#6a3420',tg,0.22),mix('#a8472e',tg,0.10),mix('#d99a52','#e8a85a',0.3)] : [mix('#1e3a1e',tg,0.4),mix('#2c6230',tg,0.5),mix('#54a557',tg,0.30)];
  if(mono) fol=fol.map(inkize);
  const trunkTop=cy-9*z;
  g.fillStyle=ink('#43301c'); g.fillRect(cx-1.6*z,trunkTop,3.2*z,cy-trunkTop);
  g.fillStyle=ink('#332313'); g.fillRect(cx+0.05*z,trunkTop,1.5*z,cy-trunkTop);   // bark-side shade — gives the trunk a round cross-section read instead of a flat plank
  g.strokeStyle=ink('#43301c');g.lineWidth=0.7*z;g.beginPath();g.moveTo(cx,cy-7*z);g.lineTo(cx-3*z,cy-12*z);g.moveTo(cx,cy-8*z);g.lineTo(cx+3*z,cy-13*z);g.stroke();
  const fy=cy-13*z;
  const lobes=canopyLobes(cx,fy,z,seed,6,4.0,5.6);
  g.fillStyle=fol[0]; g.beginPath();g.ellipse(cx,fy+0.8*z,8*z,6.6*z,0,0,7);g.fill();
  for(const[lx,ly,lr]of lobes){ g.fillStyle=fol[1]; g.beginPath();g.ellipse(lx,ly,lr*0.9,lr*0.76,0,0,7);g.fill(); }
  const hl=lobes.slice().sort((a,b)=>a[0]-b[0]).slice(0,3);
  for(const[lx,ly,lr]of hl){ g.fillStyle=fol[2]; g.beginPath();g.ellipse(lx-0.7*z,ly-1*z,lr*0.5,lr*0.42,0,0,7);g.fill(); }
  if(kind==='sakura'){ g.fillStyle='#ffe2f0'; for(let i=0;i<6;i++){g.beginPath();g.arc(cx+(inoise(seed*9+i,3)*2-1)*9*z,fy+(inoise(seed*4+i,7)*2-1)*8*z,0.9*z,0,7);g.fill();} }
  if(P.wet>=0.8 && kind!=='sakura'){ // painterly canopy: warm dappled light flecks (every lush age), kept subtle so it accents the lobes instead of smoothing them away
    g.fillStyle='rgba(248,242,200,0.4)'; for(let i=0;i<4;i++){ g.beginPath(); g.ellipse(cx+(inoise(seed*6+i,2)*2-1)*6*z, fy-3*z+(inoise(seed*3+i,5)*2-1)*4*z, 1.4*z,1.1*z, 0.6,0,7); g.fill(); } } }

function drawPeak(g,cx,cy,z,c){ const w=TW/2*0.8*z, tall=(11+c.h*28)*z, base=cy+TH/2*0.18*z; shadowEllipse(g,cx,cy,13,z);
  g.fillStyle=inkize('#5e584e'); g.beginPath();g.moveTo(cx,base);g.lineTo(cx+w,base);g.lineTo(cx,base-tall);g.closePath();g.fill();      // shadow face
  g.fillStyle=inkize('#897f70'); g.beginPath();g.moveTo(cx,base);g.lineTo(cx-w,base);g.lineTo(cx,base-tall);g.closePath();g.fill();      // lit face
  g.strokeStyle=inkize('#47423a');g.lineWidth=0.7*z;g.beginPath();g.moveTo(cx,base);g.lineTo(cx,base-tall);g.stroke();
  g.fillStyle=inkize('#766c5d');g.beginPath();g.moveTo(cx-w*0.5,base-tall*0.36);g.lineTo(cx-w*0.2,base-tall*0.5);g.lineTo(cx-w*0.34,base-tall*0.2);g.closePath();g.fill(); // rock facet
  if(c.ter===SNOW||c.h>0.7){ const sc=tall*0.44, sw=w*0.5;
    g.fillStyle='#eef3f8'; g.beginPath();g.moveTo(cx,base-tall);g.lineTo(cx-sw,base-tall+sc);g.lineTo(cx-sw*0.45,base-tall+sc*0.6);g.lineTo(cx,base-tall+sc);g.lineTo(cx+sw*0.45,base-tall+sc*0.6);g.lineTo(cx+sw,base-tall+sc);g.closePath();g.fill();
    g.fillStyle='#d6dee7'; g.beginPath();g.moveTo(cx,base-tall);g.lineTo(cx+sw,base-tall+sc);g.lineTo(cx,base-tall+sc*0.7);g.closePath();g.fill(); } }

/* ---- traffic + residents (detailed) ---- */
function drawPerson(g,cx,cy,z,a,dir,scale){ scale=scale||1; const Z=z*scale; const moving=a.moving!==false;
  if(a.drunk){ cx+=Math.sin((a.ph||0)*0.7)*1.3*Z; }                       // staggering lurch
  const era=(typeof S!=='undefined')?S.era:3;
  const sw=moving?Math.sin(a.ph):0, bob=(moving?Math.abs(Math.sin(a.ph))*0.7:0)*Z, skin=a.skin||'#ecc9a0', v=(a.v!=null?a.v:0.5), night=(typeof envNight==='function')?envNight():0;
  const hide=era<=1, modernDress=era>=8;
  let robe=a.col; if(hide)robe=['#6a4a2a','#7a5a36','#5a4028','#80603a'][(v*4)|0];
  // feet
  g.fillStyle='#2a2018'; g.fillRect(cx+(-1.7+sw*0.8)*Z,cy+1.4*z,1.4*Z,1.5*z); g.fillRect(cx+(0.3-sw*0.8)*Z,cy+1.4*z,1.4*Z,1.5*z);
  if(!hide){ g.strokeStyle='rgba(20,16,12,0.6)'; g.lineWidth=Math.max(0.3,0.3*Z);             // sandal strap, period dress only
    g.beginPath(); g.moveTo(cx+(-1.0+sw*0.8)*Z,cy+1.5*z); g.lineTo(cx+(-1.0+sw*0.8)*Z,cy+2.6*z); g.stroke();
    g.beginPath(); g.moveTo(cx+(1.0-sw*0.8)*Z,cy+1.5*z); g.lineTo(cx+(1.0-sw*0.8)*Z,cy+2.6*z); g.stroke(); }
  // lower garment
  g.fillStyle=shade(robe,-20); g.beginPath();
  g.moveTo(cx-2.6*Z,cy+1.6*z);g.lineTo(cx+2.6*Z,cy+1.6*z);g.lineTo(cx+1.9*Z,cy-3*z-bob);g.lineTo(cx-1.9*Z,cy-3*z-bob);g.closePath();g.fill();
  g.fillStyle=shade(robe,-32); g.beginPath();                                                  // center fold/seam — gives the garment a hint of drape
  g.moveTo(cx-0.5*Z,cy+1.6*z);g.lineTo(cx+0.5*Z,cy+1.6*z);g.lineTo(cx+0.35*Z,cy-3*z-bob);g.lineTo(cx-0.35*Z,cy-3*z-bob);g.closePath();g.fill();
  // sash / belt
  if(!hide){ g.fillStyle=a.obi||'#e8c24a'; g.fillRect(cx-2*Z,cy-3.6*z-bob,4*Z,1.5*z); g.fillStyle=shade(a.obi||'#e8c24a',-25); g.fillRect(cx-2*Z,cy-2.3*z-bob,4*Z,0.5*z);
    if(v>0.6){ g.fillStyle=shade(a.obi||'#e8c24a',30); g.fillRect(cx-0.6*Z,cy-3.3*z-bob,1.2*Z,0.9*z); } } // small woven-pattern fleck, comfortable households only
  else { g.fillStyle='#4a3320'; g.fillRect(cx-2*Z,cy-3*z-bob,4*Z,1*z); }
  // torso
  if(hide){ const rg=g.createLinearGradient(0,cy-7*z-bob,0,cy-3.6*z-bob); rg.addColorStop(0,shade(robe,14)); rg.addColorStop(1,shade(robe,-12)); g.fillStyle=rg; }
  else g.fillStyle=robe;
  g.beginPath();
  g.moveTo(cx-2.2*Z,cy-3.6*z-bob);g.lineTo(cx+2.2*Z,cy-3.6*z-bob);g.lineTo(cx+2.4*Z,cy-7*z-bob);g.lineTo(cx-2.4*Z,cy-7*z-bob);g.closePath();g.fill();
  g.fillStyle=shade(robe,12); g.fillRect(cx+(dir>0?1.6:-3)*Z,cy-6.6*z-bob,1.5*Z,3.4*z); // sleeve
  // collar / lapels
  if(modernDress){ g.fillStyle='#f4eede'; g.fillRect(cx-0.8*Z,cy-7*z-bob,1.6*Z,2.6*z); g.fillStyle=shade(robe,-22); g.fillRect(cx-2.4*Z,cy-7*z-bob,1.2*Z,2.6*z); g.fillRect(cx+1.2*Z,cy-7*z-bob,1.2*Z,2.6*z); }
  else if(!hide){ g.fillStyle='#f4eede'; g.beginPath();g.moveTo(cx,cy-3.8*z-bob);g.lineTo(cx-1.5*Z,cy-7*z-bob);g.lineTo(cx+1.5*Z,cy-7*z-bob);g.closePath();g.fill();
    g.fillStyle=shade(robe,-10); g.fillRect(cx-0.4*Z,cy-7*z-bob,0.8*Z,3.2*z); }
  if(hide && (a.type==='farmer'||a.type==='porter')){ // straw mino rain/work cape (Yayoi)
    g.fillStyle='rgba(120,96,52,0.55)'; g.beginPath(); g.moveTo(cx-2.6*Z,cy-6.2*z-bob); g.lineTo(cx+2.6*Z,cy-6.2*z-bob); g.lineTo(cx+2.1*Z,cy-2.4*z-bob); g.lineTo(cx-2.1*Z,cy-2.4*z-bob); g.closePath(); g.fill();
    g.strokeStyle='rgba(150,122,66,0.85)'; g.lineWidth=0.49*Z; g.lineCap='round';
    for(let i=-3;i<=3;i++){ const sx=cx+i*0.72*Z; g.beginPath(); g.moveTo(sx,cy-5.6*z-bob); g.lineTo(sx+i*0.34*Z,cy-2.2*z-bob); g.stroke(); } g.lineCap='butt'; }
  // head
  g.fillStyle=skin; g.beginPath();g.arc(cx,cy-8.5*z-bob,2.2*Z,0,7);g.fill();
  if(hide){ // painterly watercolor face + emotional weight (early ages)
    const hcx=cx, hcy=cy-8.5*z-bob;
    const fg=g.createLinearGradient(0,hcy-2.2*Z,0,hcy+2.2*Z); fg.addColorStop(0,shade(skin,16)); fg.addColorStop(1,shade(skin,-24));
    g.fillStyle=fg; g.beginPath();g.arc(hcx,hcy,2.2*Z,0,7);g.fill();
    g.fillStyle='rgba(255,246,228,0.32)'; g.beginPath();g.arc(hcx-0.7*Z,hcy-0.7*Z,0.85*Z,0,7);g.fill();   // cheek light
    if(v<0.42){ g.fillStyle='rgba(40,28,18,0.22)'; g.beginPath();g.ellipse(hcx,hcy+0.5*Z,1.6*Z,1.2*Z,0,0,7);g.fill(); // gaunt, hollow
      g.strokeStyle='rgba(40,28,18,0.5)';g.lineWidth=0.35*Z; g.beginPath();g.moveTo(hcx-0.9*Z,hcy+0.9*Z);g.lineTo(hcx,hcy+0.6*Z);g.lineTo(hcx+0.9*Z,hcy+0.9*Z);g.stroke(); } // downturned mouth (despair)
  }
  const hy=cy-9*z-bob;
  if(a.type==='monk'){ g.fillStyle='#d8b48a'; g.beginPath();g.arc(cx,hy,2.2*Z,Math.PI,0);g.fill(); }
  else { g.fillStyle='#161210'; g.beginPath();g.arc(cx,hy,2.35*Z,Math.PI*0.92,Math.PI*0.08,false);g.fill(); g.fillRect(cx-2.3*Z,hy-0.2*z,4.6*Z,1.5*z);
    if(era<=1){ g.fillRect(cx-0.5*Z,hy+1.6*z,1*Z,2.6*z); }                                 // loose tied hair
    else if(a.type!=='child'&&era>=2&&era<=7){ g.fillStyle='#161210'; g.fillRect(cx-0.7*Z,cy-11.2*z-bob,1.4*Z,1.8*z); g.beginPath();g.arc(cx,cy-11.2*z-bob,1*Z,0,7);g.fill(); } // chonmage
    // era headwear (a fraction wear it)
    if(a.type!=='child'&&a.type!=='noble'&&(era===4||era===5)&&v<0.5){ g.fillStyle='#15110d'; g.fillRect(cx-1.5*Z,cy-11.8*z-bob,3*Z,2.4*z); g.fillRect(cx-0.6*Z,cy-13.6*z-bob,1.5*Z,2.2*z); } // eboshi (Nara/Heian)
    else if(era===7&&v<0.5){ g.fillStyle='#3a2a1a'; g.beginPath();g.moveTo(cx-4*Z,cy-9.4*z-bob);g.lineTo(cx+4*Z,cy-9.4*z-bob);g.lineTo(cx,cy-12.2*z-bob);g.closePath();g.fill(); g.fillStyle='#caa24a';g.fillRect(cx-0.6*Z,cy-10*z-bob,1.2*Z,0.8*z); } // jingasa (Sengoku)
    else if(era>=8&&v<0.45){ g.fillStyle='#14f195'; g.fillRect(cx-2*Z,cy-10.6*z-bob,4*Z,1.4*z); g.fillStyle='rgba(20,241,149,0.55)';g.fillRect(cx-2*Z,cy-9.6*z-bob,4*Z,0.9*z); } // AR visor (Quantum Edo)
  }
  if(a.hat==='kasa'){ g.fillStyle='#c9a24a'; g.beginPath();
    g.moveTo(cx-4.4*Z,cy-9.2*z-bob);g.lineTo(cx+4.4*Z,cy-9.2*z-bob);g.lineTo(cx,cy-13*z-bob);g.closePath();g.fill();
    g.strokeStyle='#9a7a34';g.lineWidth=0.42*Z;g.beginPath();g.moveTo(cx-4.4*Z,cy-9.2*z-bob);g.lineTo(cx+4.4*Z,cy-9.2*z-bob);g.stroke(); }
  if(a.type==='monk'){ g.strokeStyle='#7a5630';g.lineWidth=0.63*Z;g.beginPath();g.moveTo(cx+(2.6*dir)*Z,cy+1.6*z);g.lineTo(cx+(2.6*dir)*Z,cy-10*z-bob);g.stroke();
    g.strokeStyle='#caa24a';g.lineWidth=0.84*Z;g.beginPath();g.arc(cx+(2.6*dir)*Z,cy-10.6*z-bob,1.2*Z,0,7);g.stroke(); }
  if(a.acc==='parasol'){ g.strokeStyle='#5a3d24';g.lineWidth=0.56*Z;g.beginPath();g.moveTo(cx+(2.6*dir)*Z,cy-6*z-bob);g.lineTo(cx+(2.6*dir)*Z,cy-15*z-bob);g.stroke();
    g.fillStyle=a.obi||'#c0392b';g.beginPath();g.moveTo(cx+(2.6*dir-5)*Z,cy-13*z-bob);g.quadraticCurveTo(cx+(2.6*dir)*Z,cy-17*z-bob,cx+(2.6*dir+5)*Z,cy-13*z-bob);g.closePath();g.fill();
    g.strokeStyle='#7a2018';g.lineWidth=0.35*Z; for(let k=-2;k<=2;k++){g.beginPath();g.moveTo(cx+(2.6*dir)*Z,cy-15*z-bob);g.lineTo(cx+(2.6*dir+k*2.4)*Z,cy-12.8*z-bob);g.stroke();} }
  if(a.type==='porter'){ g.strokeStyle='#7a5630';g.lineWidth=0.63*Z;g.beginPath();g.moveTo(cx-4.5*Z,cy-6.6*z-bob);g.lineTo(cx+4.5*Z,cy-6.6*z-bob);g.stroke();
    g.fillStyle='#a9863e'; g.beginPath();g.ellipse(cx-4.5*Z,cy-4.4*z,2.1*Z,1.5*z,0,0,7);g.fill(); g.beginPath();g.ellipse(cx+4.5*Z,cy-4.4*z,2.1*Z,1.5*z,0,0,7);g.fill();
    g.fillStyle='#5a8a3a';g.fillRect(cx-5.2*Z,cy-5.4*z,1.4*Z,1*z); g.fillStyle='#c0392b';g.fillRect(cx+4*Z,cy-5.4*z,1.4*Z,1*z); }
  if(a.type==='samurai'){ g.strokeStyle='#23211f';g.lineWidth=0.77*Z;                     // daishō at the hip
    g.beginPath();g.moveTo(cx+1.4*Z,cy-3.2*z-bob);g.lineTo(cx+5.6*Z,cy-1.0*z-bob);g.stroke();
    g.lineWidth=0.63*Z;g.beginPath();g.moveTo(cx+1.2*Z,cy-2.6*z-bob);g.lineTo(cx+4.4*Z,cy-1.2*z-bob);g.stroke();
    g.fillStyle='#caa24a';g.fillRect(cx+1.0*Z,cy-3.6*z-bob,1.1*Z,1.1*z); }
  if(a.type==='noble'){ g.fillStyle='#15110d'; g.fillRect(cx-1.5*Z,cy-12.4*z-bob,3*Z,2.6*z); g.fillRect(cx-0.7*Z,cy-15*z-bob,1.5*Z,2.8*z); } // tall court eboshi
  if(a.acc==='box'){ g.fillStyle='#8a6a3a'; g.fillRect(cx-2.4*Z,cy-5*z-bob,4.8*Z,3.6*z); g.fillStyle='#6a4a28'; g.fillRect(cx-2.4*Z,cy-5*z-bob,4.8*Z,1*z);
    g.strokeStyle='#4a3320';g.lineWidth=0.35*Z;g.strokeRect(cx-2.4*Z,cy-5*z-bob,4.8*Z,3.6*z); }
  if(a.acc==='hoe'){ g.strokeStyle='#7a5630';g.lineWidth=0.63*Z;g.beginPath();g.moveTo(cx+(2.6*dir)*Z,cy+1.2*z);g.lineTo(cx+(3.6*dir)*Z,cy-9.4*z-bob);g.stroke();
    g.fillStyle='#9aa3ad';g.fillRect(cx+(3.0*dir)*Z,cy-9.8*z-bob,(2.0*dir)*Z,1.2*z); }
  if(a.acc==='fan'){ g.fillStyle=a.obi||'#c0392b'; g.beginPath();g.moveTo(cx+(2.4*dir)*Z,cy-5.2*z-bob);g.lineTo(cx+(4.8*dir)*Z,cy-7.6*z-bob);g.lineTo(cx+(4.8*dir)*Z,cy-5.0*z-bob);g.closePath();g.fill();
    g.strokeStyle='#efe2c4';g.lineWidth=0.28*Z;g.beginPath();g.moveTo(cx+(2.4*dir)*Z,cy-5.2*z-bob);g.lineTo(cx+(4.8*dir)*Z,cy-6.3*z-bob);g.stroke(); }
  if(a.acc==='basket'){ g.fillStyle='#b89a5a';g.beginPath();g.ellipse(cx+(2.9*dir)*Z,cy-2.4*z,2*Z,1.4*z,0,0,7);g.fill();
    g.strokeStyle='#8a6a3a';g.lineWidth=0.42*Z;g.beginPath();g.arc(cx+(2.9*dir)*Z,cy-3.2*z,1.8*Z,Math.PI,0);g.stroke();
    g.fillStyle='#3f8a4a';g.fillRect(cx+(2.2*dir)*Z,cy-3.4*z,1.2*Z,1*z); }
  if(a.acc==='lantern'){ const lx=cx+(2.9*dir)*Z, ly=cy-5.2*z-bob; g.strokeStyle='#3a2a1c';g.lineWidth=0.42*Z;g.beginPath();g.moveTo(lx,ly-2*z);g.lineTo(lx,ly+0.4*z);g.stroke();
    g.fillStyle=night>0.34?'#ffcf6a':'#c0392b'; g.beginPath();g.ellipse(lx,ly+2*z,1.6*Z,2.2*z,0,0,7);g.fill();
    g.strokeStyle='#7a1f16';g.lineWidth=0.28*Z;g.beginPath();g.moveTo(lx-1.4*Z,ly+2*z);g.lineTo(lx+1.4*Z,ly+2*z);g.stroke();
    if(night>0.34){g.fillStyle='rgba(255,200,110,0.4)';g.beginPath();g.arc(lx,ly+2*z,4*Z,0,7);g.fill();} }
  if(hide && v<0.5){ // tasteful hardship: weary stoop, gaunt frame, elder's staff
    g.strokeStyle='rgba(30,22,14,0.26)'; g.lineWidth=0.7*Z;                                  // bowed back
    g.beginPath(); g.moveTo(cx-1.6*Z,cy-3.4*z-bob); g.quadraticCurveTo(cx-2.7*Z,cy-6.2*z-bob, cx-1.1*Z,cy-7.6*z-bob); g.stroke();
    g.fillStyle='rgba(20,14,8,0.14)'; g.fillRect(cx-2.5*Z,cy-6.9*z-bob,1*Z,3.2*z); g.fillRect(cx+1.5*Z,cy-6.9*z-bob,1*Z,3.2*z); // gaunt ribs/sides
    if(v<0.24 && a.type!=='child'){ g.strokeStyle='#6a4a2a'; g.lineWidth=0.63*Z;             // walking staff
      g.beginPath(); g.moveTo(cx+(2.9*dir)*Z,cy+1.7*z); g.lineTo(cx+(2.4*dir)*Z,cy-7.4*z-bob); g.stroke(); } }
  // ---- street-life dress (layered atop the standard body) ----
  const _hx=cx, _hy=cy-8.5*z-bob;                                                 // head centre
  if(a.hat==='tenugui'){ g.fillStyle='#d8cdb8'; g.beginPath(); g.moveTo(_hx-2.4*Z,_hy-1.2*z); g.quadraticCurveTo(_hx,_hy-3.4*z,_hx+2.4*Z,_hy-1.2*z); g.lineTo(_hx+2*Z,_hy-0.2*z); g.lineTo(_hx-2*Z,_hy-0.2*z); g.closePath(); g.fill(); }
  if(a.type==='leper'){ // bandaged, ailing — stylised period hardship, never gory
    g.fillStyle='rgba(120,150,120,0.16)'; g.beginPath();g.ellipse(cx,cy-5*z-bob,2.7*Z,3.1*z,0,0,7);g.fill();   // sickly pallor wash
    g.fillStyle='rgba(226,216,198,0.92)'; g.fillRect(_hx-2.3*Z,_hy-0.6*z,4.6*Z,1.4*z);                          // face wrap
    g.fillStyle='rgba(210,198,178,0.9)'; g.fillRect(_hx-2.3*Z,_hy-2.2*z,4.6*Z,1.1*z);
    g.strokeStyle='rgba(150,140,120,0.7)'; g.lineWidth=0.3*Z; g.beginPath();g.moveTo(_hx-2.3*Z,_hy-0.1*z);g.lineTo(_hx+2.3*Z,_hy-1.0*z);g.stroke();
    g.fillStyle='rgba(226,216,198,0.85)'; g.fillRect(cx+(dir>0?1.7:-3.1)*Z,cy-5.6*z-bob,1.4*Z,2*z);            // bandaged arm
    g.strokeStyle='#6a4a2a'; g.lineWidth=0.6*Z; g.beginPath();g.moveTo(cx+(2.7*dir)*Z,cy+1.5*z);g.lineTo(cx+(2.3*dir)*Z,cy-7*z-bob);g.stroke(); }
  if(a.geisha){ // courtesan — melancholic period figure: tall shimada, powdered face, hair pins
    g.fillStyle='#f3e8de'; g.beginPath();g.arc(_hx,_hy,2.3*Z,0,7);g.fill();
    g.fillStyle='rgba(176,60,80,0.5)'; g.beginPath();g.arc(_hx,_hy+0.7*z,0.7*Z,0,7);g.fill();
    g.fillStyle='#15110d'; g.beginPath();g.arc(_hx,_hy-1.6*z,3.1*Z,Math.PI,0);g.fill();
    g.beginPath();g.ellipse(_hx,_hy-3*z,3.3*Z,1.7*z,0,0,7);g.fill();
    g.strokeStyle=a.obi||'#e8c24a'; g.lineWidth=0.45*Z; g.beginPath();g.moveTo(_hx-2.6*Z,_hy-3.2*z);g.lineTo(_hx+2.6*Z,_hy-3.2*z);g.stroke();
    g.fillStyle=a.obi||'#e8c24a'; g.beginPath();g.arc(_hx+2.4*Z,_hy-3.2*z,0.6*Z,0,7);g.fill(); g.beginPath();g.arc(_hx-2.4*Z,_hy-3.2*z,0.6*Z,0,7);g.fill();
    g.fillStyle=a.obi||'#c0392b'; g.fillRect(cx-2.2*Z,cy-2.2*z-bob,4.4*Z,1*z); }
  if(a.acc==='gourd'){ const gx=cx+(2.7*dir)*Z, gy=cy-4.4*z-bob;                                                // sake gourd
    g.fillStyle='#caa86a'; g.beginPath();g.ellipse(gx,gy,1.3*Z,1.6*z,0,0,7);g.fill(); g.beginPath();g.ellipse(gx,gy-1.7*z,0.8*Z,1*z,0,0,7);g.fill();
    g.strokeStyle='#7a5a2a'; g.lineWidth=0.3*Z; g.beginPath();g.moveTo(gx-1*Z,gy-0.4*z);g.lineTo(gx+1*Z,gy-0.4*z);g.stroke(); }
  if(a.acc==='staff'){ g.strokeStyle='#6a4a2a'; g.lineWidth=0.6*Z;                                              // pilgrim shakujō + bundle
    g.beginPath();g.moveTo(cx+(2.7*dir)*Z,cy+1.6*z);g.lineTo(cx+(2.7*dir)*Z,cy-11*z-bob);g.stroke();
    g.strokeStyle='#caa24a'; g.lineWidth=0.5*Z; g.beginPath();g.arc(cx+(2.7*dir)*Z,cy-11.4*z-bob,1*Z,0,7);g.stroke();
    g.fillStyle='rgba(120,96,52,0.5)'; g.fillRect(cx-2.4*Z,cy-6*z-bob,1.4*Z,3*z); }
  if(a.acc==='yoke'){ // botefuri street vendor — shoulder pole + two laden baskets
    g.strokeStyle='#7a5630'; g.lineWidth=0.6*Z; g.beginPath();g.moveTo(cx-4.6*Z,cy-6.6*z-bob);g.lineTo(cx+4.6*Z,cy-6.6*z-bob);g.stroke();
    g.fillStyle='#b89a5a'; g.beginPath();g.ellipse(cx-4.6*Z,cy-4.3*z,2.1*Z,1.5*z,0,0,7);g.fill(); g.beginPath();g.ellipse(cx+4.6*Z,cy-4.3*z,2.1*Z,1.5*z,0,0,7);g.fill();
    const wseed=((a.ph||0)*1000)|0;   // STABLE per-agent seed (ph is set once at spawn) — was keyed off screen cx+cy, which changed every frame as the agent walked/camera panned, making the wares flicker through all 4 colours
    const wares=['#c0392b','#3f8a4a','#e8c24a','#46708f']; g.fillStyle=wares[wseed%4]; g.beginPath();g.arc(cx-4.6*Z,cy-5*z,1*Z,0,7);g.fill();
    g.fillStyle=wares[(wseed+2)%4]; g.beginPath();g.arc(cx+4.6*Z,cy-5*z,1*Z,0,7);g.fill(); }
}
function drawWheel(g,cx,cy,z,wx,wy,r,ph){ g.fillStyle='#4a3624'; g.beginPath();g.arc(cx+wx*z,cy+wy*z,r*z,0,7);g.fill(); g.fillStyle='#1e140c';g.beginPath();g.arc(cx+wx*z,cy+wy*z,r*0.34*z,0,7);g.fill();
  g.strokeStyle='#7a5630';g.lineWidth=0.49*z; for(let k=0;k<6;k++){const an=ph*2+k*Math.PI/3; g.beginPath();g.moveTo(cx+wx*z,cy+wy*z);g.lineTo(cx+(wx+Math.cos(an)*r*0.85)*z,cy+(wy+Math.sin(an)*r*0.85)*z);g.stroke();} }
function drawCart(g,cx,cy,z,a){ const dir=a.dir<0?-1:1, ph=a.ph;
  if(a.type==='ox'){ const back=dir<0?1:-1;
    g.fillStyle='#8a6a3a'; g.fillRect(cx+(back*1.5-2)*z,cy-5*z,4.4*z,3*z); g.fillStyle='#6a4a28'; g.fillRect(cx+(back*1.5-2)*z,cy-2.2*z,4.4*z,0.8*z);
    g.fillStyle='#cdb87a'; g.beginPath();g.ellipse(cx+(back*1.5-0.6)*z,cy-5.6*z,1.7*z,1.3*z,0,0,7);g.fill(); g.fillStyle='#bda968';g.beginPath();g.ellipse(cx+(back*1.5+1)*z,cy-5.4*z,1.5*z,1.1*z,0,0,7);g.fill();
    drawWheel(g,cx,cy,z,back*1.5,-1.3,2.4,ph);
    g.strokeStyle='#6a4a2a';g.lineWidth=0.63*z;g.beginPath();g.moveTo(cx+(back*1.5+2)*z,cy-3.5*z);g.lineTo(cx+(dir*2.2)*z,cy-3.2*z);g.stroke();
    g.fillStyle='#54453a'; g.beginPath();g.ellipse(cx+(dir*3.6)*z,cy-3.2*z,3.1*z,2.1*z,0,0,7);g.fill();
    g.fillStyle='#4a3c32'; g.beginPath();g.ellipse(cx+(dir*6.2)*z,cy-3.8*z,1.7*z,1.5*z,0,0,7);g.fill();
    g.strokeStyle='#d8c8a4';g.lineWidth=0.49*z;g.beginPath();g.moveTo(cx+(dir*6.6)*z,cy-4.9*z);g.lineTo(cx+(dir*7.3)*z,cy-5.7*z);g.stroke();
    g.fillStyle='#2a2018';g.beginPath();g.arc(cx+(dir*6.8)*z,cy-3.7*z,0.5*z,0,7);g.fill();
    const sw=Math.sin(ph*2)*0.7; g.strokeStyle='#43352b';g.lineWidth=0.77*z;
    g.beginPath();g.moveTo(cx+(dir*2.6)*z,cy-1.4*z);g.lineTo(cx+(dir*2.6+sw)*z,cy+1.4*z);g.stroke();
    g.beginPath();g.moveTo(cx+(dir*4.8)*z,cy-1.4*z);g.lineTo(cx+(dir*4.8-sw)*z,cy+1.4*z);g.stroke();
  } else if(a.type==='kago'){
    g.strokeStyle='#5a3d24';g.lineWidth=0.77*z;g.beginPath();g.moveTo(cx-6.5*z,cy-5*z);g.lineTo(cx+6.5*z,cy-5*z);g.stroke();
    g.fillStyle='#7a2d24'; g.beginPath();g.moveTo(cx-3*z,cy-4.6*z);g.lineTo(cx+3*z,cy-4.6*z);g.lineTo(cx+2.4*z,cy-7.4*z);g.lineTo(cx-2.4*z,cy-7.4*z);g.closePath();g.fill();
    g.fillStyle='#caa24a'; g.beginPath();g.moveTo(cx-3.2*z,cy-7.4*z);g.lineTo(cx+3.2*z,cy-7.4*z);g.lineTo(cx,cy-9.2*z);g.closePath();g.fill();
    g.fillStyle='#3a2418'; g.fillRect(cx-1.6*z,cy-6.6*z,3.2*z,2*z); g.fillStyle='#e8c24a';g.fillRect(cx-1.6*z,cy-6.6*z,3.2*z,0.5*z);
    drawPerson(g,cx-6.5*z,cy,z,{col:'#3b5fb2',obi:'#e8c24a',ph:ph,type:'kimono',moving:true,dir:dir,hat:'kasa'},dir,0.8);
    drawPerson(g,cx+6.5*z,cy,z,{col:'#3b8a5a',obi:'#c0392b',ph:ph+1.5,type:'kimono',moving:true,dir:dir,hat:'kasa'},dir,0.8);
  } else {
    const back=dir<0?1:-1;
    g.fillStyle='#8a6a3a'; g.fillRect(cx+(back*1.2-2)*z,cy-5*z,4*z,2.8*z);
    g.fillStyle='#5a8a3a';g.beginPath();g.ellipse(cx+(back*1.2)*z,cy-5.6*z,1.5*z,1.2*z,0,0,7);g.fill();
    g.fillStyle='#caa23a';g.fillRect(cx+(back*1.2-1.4)*z,cy-6.4*z,2.4*z,1.6*z); g.fillStyle='#c0392b';g.beginPath();g.arc(cx+(back*1.2+1.4)*z,cy-5.8*z,1*z,0,7);g.fill();
    drawWheel(g,cx,cy,z,back*1.2,-1.4,2.1,ph);
    g.strokeStyle='#6a4a2a';g.lineWidth=0.56*z;g.beginPath();g.moveTo(cx+(back*1.2+2)*z,cy-3.6*z);g.lineTo(cx+(dir*2.2)*z,cy-2.8*z);g.stroke();
    drawPerson(g,cx+(dir*3.4)*z,cy,z,{col:a.col,obi:a.obi,ph:ph,type:'kimono',moving:true,dir:dir},dir,0.92);
  }
}
function drawAgent(g,cx,cy,z,a,noShadow){ if(!noShadow) shadowEllipse(g,cx,cy,a.kind==='cart'?5:(a.kind==='animal'?2:3)*(a.scale||1),z);
  if(a.kind==='cart') drawCart(g,cx,cy,z,a); else if(a.kind==='ronin') drawRonin(g,cx,cy,z,a,a.dir<0?-1:1);
  else if(a.kind==='animal') drawCritter(g,cx,cy,z,a,a.dir<0?-1:1);
  else if(a.kind==='prop') drawHumanProp(g,cx,cy,z,a);
  else { const frozen=(a.act==='idle'||a.act==='temple'||a.act==='water'||a.act==='work'||a.watch>0);
    const posed=Object.assign({},a,{moving:a.moving&&!frozen});
    drawPerson(g,cx,cy,z,posed,a.dir<0?-1:1,a.scale||1);
    if(a.act==='temple') drawPrayerPose(g,cx,cy,z,a);
    else if(a.act==='water') drawWatersidePose(g,cx,cy,z,a);
    else if(a.act==='work') drawTendingPose(g,cx,cy,z,a);
    else if(a.watch>0) drawWatchPose(g,cx,cy,z,a);
    else if(a.talkWith) drawTalkCue(g,cx,cy,z,a);
    else if(a.act==='idle'&&a.nerve===undefined) drawLookAroundCue(g,cx,cy,z,a);
    if(a.nerve!==undefined){ if(a.respectful) drawRespectCue(g,cx,cy,z,a); else drawNervousCue(g,cx,cy,z,a); } } }
/* a brief downward bow of clasped hands at a temple/shrine — read at a glance as quiet reverence */
function drawPrayerPose(g,cx,cy,z,a){ g.save(); g.translate(cx,cy-7*z); g.rotate(0.16);
  g.fillStyle='rgba(20,16,10,0.5)'; g.beginPath(); g.ellipse(0,-1.2*z,1*z,1.6*z,0,0,7); g.fill();   // clasped hands, head dipped
  g.restore(); }
/* farmhand at work: a hoe rising/falling (till) or a hand sowing/watering — picked by a slow
   phase cycle so the same figure cycles through both gestures rather than locking to one. */
function drawTendingPose(g,cx,cy,z,a){ const dir=a.dir||1, ph=a.ph||0;
  const cyc=(ph*0.5)%2; // 0-1 till swing, 1-2 sow/water dip
  if(cyc<1){ const swing=Math.sin(cyc*Math.PI)*0.9;
    g.strokeStyle='#5a4226'; g.lineWidth=0.6*z;
    g.beginPath(); g.moveTo(cx+dir*1.6*z,cy-7*z); g.lineTo(cx+dir*(3.6+swing*2)*z,cy-2.5*z-swing*3*z); g.stroke();   // hoe handle
    g.fillStyle='#7a7a7a'; g.beginPath(); g.ellipse(cx+dir*(3.6+swing*2)*z,cy-2.2*z-swing*3*z,1*z,0.5*z,0,0,7); g.fill();
    if(swing>0.7){ g.fillStyle='rgba(120,100,70,0.4)'; g.beginPath(); g.ellipse(cx+dir*4*z,cy+0.4*z,1.6*z,0.6*z,0,0,7); g.fill(); } // soil kick-up at swing peak
  } else { const dip=Math.sin((cyc-1)*Math.PI)*0.7;
    g.fillStyle='rgba(20,16,10,0.45)'; g.beginPath(); g.ellipse(cx+dir*2.4*z,cy-3*z+dip*2*z,0.9*z,1.1*z,0,0,7); g.fill();      // hand reaching down to sow/water
    if(dip>0.5){ g.fillStyle='rgba(120,150,170,0.3)'; g.beginPath(); g.ellipse(cx+dir*2.6*z,cy-0.4*z,1.2*z,0.5*z,0,0,7); g.fill(); } } // water droplet glint
}
/* idling at the water's edge — a held fishing line (with an occasional catch), or just sitting still gazing at the lake */
function drawWatersidePose(g,cx,cy,z,a){
  if(a.fishing){ g.strokeStyle='#6a4a2a'; g.lineWidth=0.4*z; const dir=a.dir||1;
    g.beginPath(); g.moveTo(cx+dir*2.4*z,cy-7*z); g.lineTo(cx+dir*7*z,cy-9.5*z); g.stroke();        // rod
    const bob=a.caughtT!==undefined?Math.sin((a.ph||0)*9)*0.6*z:0;                                  // line jitters when a fish is on
    g.strokeStyle='rgba(220,228,232,0.55)'; g.lineWidth=0.18*z;
    g.beginPath(); g.moveTo(cx+dir*7*z,cy-9.5*z); g.lineTo(cx+dir*6.4*z+bob,cy+1.5*z); g.stroke();   // line into the water
    if(a.caughtT!==undefined){ g.fillStyle=a.caught||FISH[0];                                       // small caught-fish glimpse at the line tip
      g.beginPath(); g.ellipse(cx+dir*6.4*z+bob,cy+1.2*z,0.9*z,0.45*z,dir*0.4,0,7); g.fill(); }
  }
}

/* a faint glance-around motion cue for an idling pedestrian — keeps "idle" from reading as "frozen" */
function drawLookAroundCue(g,cx,cy,z,a){ const s=Math.sin((a.ph||0)*0.6)*0.5*z;
  g.fillStyle='rgba(255,255,255,0.06)'; g.beginPath(); g.ellipse(cx+s,cy-9.3*z,1.1*z,0.6*z,0,0,7); g.fill(); }
/* two paired idlers facing slightly inward, as if in conversation — a small standing group */
function drawTalkCue(g,cx,cy,z,a){ const lean=(a.talkWith.x>a.x?1:-1)*0.6*z;
  g.fillStyle='rgba(255,255,255,0.05)'; g.beginPath(); g.ellipse(cx+lean,cy-9.2*z,1*z,0.6*z,0,0,7); g.fill(); }
/* a witness too far to flee but close enough to stop and stare at a disturbance — frozen,
   leaning either fearfully back (curled inward) or curiously forward (craning to see). The
   split is a single seeded coin-flip per witness so the same figure reads consistently for
   the whole time they're watching, rather than flickering between the two each frame. */
function drawWatchPose(g,cx,cy,z,a){ if(a.curious===undefined)a.curious=Math.random()<0.5;
  const lean=(a.curious?0.9:-0.6)*z;
  g.save(); g.translate(cx+lean,cy-8.4*z);
  if(a.curious){ g.fillStyle='rgba(20,16,10,0.3)'; g.beginPath(); g.ellipse(0,0.6*z,0.9*z,1.3*z,0,0,7); g.fill(); }    // craning forward
  else { g.fillStyle='rgba(20,16,10,0.22)'; g.beginPath(); g.ellipse(0,1.1*z,1.1*z,0.9*z,0,0,7); g.fill(); }           // shrinking back, hunched
  g.restore(); }
function drawNervousCue(g,cx,cy,z,a){ g.fillStyle='rgba(40,20,10,0.18)'; g.beginPath(); g.ellipse(cx,cy-9*z,1.3*z,0.7*z,0,0,7); g.fill(); }
/* a brief deferential bow as a ronin warband passes — distinct from the wary/nervous cue: head
   dipped, no clenched/hunched tension. Reads as respect rather than fear. */
function drawRespectCue(g,cx,cy,z,a){ g.save(); g.translate(cx,cy-8.8*z); g.rotate(0.22);
  g.fillStyle='rgba(20,16,10,0.24)'; g.beginPath(); g.ellipse(0,-0.6*z,1*z,1.2*z,0,0,7); g.fill();
  g.restore(); }
/* small standing groups that appear to talk: pair up nearby idling residents for a few seconds.
   Purely cosmetic — never touches movement targets, economy, or simulation state. */
function syncGroupTalk(){ const idlers=[];
  for(const r of residents) if(!r.claimed&&!(r.flee>0)&&r.pause>0&&r.act!=='temple'&&r.act!=='water')idlers.push(r);
  for(const u of idlers)u.talkWith=null;
  for(let i=0;i<idlers.length;i++){ const u=idlers[i]; if(u.talkWith)continue;
    for(let j=i+1;j<idlers.length;j++){ const v=idlers[j]; if(v.talkWith)continue;
      if(Math.hypot(u.x-v.x,u.y-v.y)<0.9){ u.talkWith=v; v.talkWith=u; break; } } } }

/* ---- fire (detailed, animated) ---- */
function flameTongue(g,x,base,w,h,col){ g.fillStyle=col; g.beginPath();
  g.moveTo(x-w,base); g.quadraticCurveTo(x-w*0.9,base-h*0.5, x-w*0.2,base-h*0.82);
  g.quadraticCurveTo(x,base-h, x+w*0.2,base-h*0.82);
  g.quadraticCurveTo(x+w*0.9,base-h*0.5, x+w,base); g.closePath(); g.fill(); }
function drawFire(g,cx,cy,z,burn,t){ const inten=Math.max(0.5,burn/5), seed=cx*0.13+cy*0.09, tt=t*0.001;
  g.fillStyle='rgba(22,9,5,0.55)'; diamondPath(g,cx,cy,z); g.fill();                         // scorched ground
  const pulse=0.6+0.4*Math.sin(tt*9+seed*3);
  g.save(); g.globalCompositeOperation='lighter';
  // wide outer heat bloom
  const og=g.createRadialGradient(cx,cy-3*z,1, cx,cy-3*z,(30+10*inten)*z*(0.9+0.2*pulse));
  og.addColorStop(0,'rgba(255,140,40,'+(0.30*inten)+')'); og.addColorStop(0.6,'rgba(200,50,16,'+(0.14*inten)+')'); og.addColorStop(1,'rgba(120,20,10,0)');
  g.fillStyle=og; g.beginPath();g.arc(cx,cy-3*z,(30+10*inten)*z,0,7);g.fill();
  // core ember pool
  const gr=g.createRadialGradient(cx,cy-2*z,1, cx,cy-2*z,(18+6*inten)*z*(0.85+0.25*pulse));
  gr.addColorStop(0,'rgba(255,180,50,'+(0.6*inten)+')'); gr.addColorStop(0.5,'rgba(235,75,22,'+(0.34*inten)+')'); gr.addColorStop(1,'rgba(120,20,10,0)');
  g.fillStyle=gr; g.beginPath();g.arc(cx,cy-2*z,(18+6*inten)*z,0,7);g.fill();
  // flame tongues — taller, denser, three-colour layered
  const N=6+Math.round(inten*4);
  for(let i=0;i<N;i++){ const o=(i/(N-1)-0.5);
    const fxp=cx+o*11*z*(0.7+0.3*Math.sin(tt*4+i)), base=cy+1*z;
    const flick=Math.sin(tt*11+i*1.7+seed)*2.1*z + Math.sin(tt*23+i)*0.9*z;
    const ht=(12+inten*10+(i%2?4:0))*z*(0.8+0.28*Math.sin(tt*7+i*2));
    const w=(3.8-Math.abs(o)*2.2)*z*inten + 1.5*z;
    flameTongue(g,fxp+flick,base,w*1.3,ht*1.2,'rgba(190,34,14,0.82)');
    flameTongue(g,fxp+flick*0.7,base,w,ht,'rgba(255,120,20,0.9)');
    flameTongue(g,fxp+flick*0.5,base,w*0.62,ht*0.72,'rgba(255,216,80,0.96)'); }
  // detached licking flame curls
  for(let i=0;i<3;i++){ const cxp=cx+Math.sin(tt*6+i*2.1)*9*z, cyp=cy-(10+inten*8)*z-Math.abs(Math.sin(tt*5+i))*5*z;
    g.fillStyle='rgba(255,170,40,'+(0.5+0.3*Math.sin(tt*8+i))+')'; g.beginPath();g.ellipse(cxp,cyp,1.6*z,3.2*z,Math.sin(tt*3+i),0,7);g.fill(); }
  // white-hot heart
  g.fillStyle='rgba(255,248,210,0.92)'; g.beginPath();g.ellipse(cx,cy-2*z,2.6*z*inten,4.8*z*inten,0,0,7);g.fill();
  // rising embers — more, brighter
  const EC=Math.round(9*inten);
  for(let i=0;i<EC;i++){ const ph=((tt*0.7+i*0.29+seed)%1), ex=cx+Math.sin(tt*3+i*2+seed)*9*z, ey=cy-2*z-ph*(26+10*inten)*z;
    g.fillStyle='rgba(255,'+(150+((i*37)%90))+',45,'+((1-ph)*0.95)+')'; g.beginPath();g.arc(ex,ey,Math.max(0.4,(1.8-ph)*z),0,7);g.fill(); }
  g.restore();
  // smoke column — thicker, taller (normal blend, above flames)
  for(let i=0;i<5;i++){ const ph=((tt*0.26+i*0.22+seed*0.5)%1), sx=cx+Math.sin(tt*0.9+i+seed)*6*z+ph*4*z, sy=cy-10*z-ph*(30+8*inten)*z;
    g.fillStyle='rgba(58,54,52,'+((1-ph)*0.28)+')'; g.beginPath();g.arc(sx,sy,(3.5+ph*9+inten)*z,0,7);g.fill(); } }

/* ---- apparitions (japanese mythology, aesthetic) ---- */
const APP={
  ryu:(g,cx,cy,z,t)=>{ // serpentine dragon with head, horns, whiskers
    g.strokeStyle='#2fa862';g.lineWidth=2.38*z; g.beginPath();
    for(let i=0;i<12;i++){const a=t*0.004+i*0.5,x=cx+Math.cos(a)*i*1.4*z,y=cy-i*1.5*z+Math.sin(a)*3*z;i?g.lineTo(x,y):g.moveTo(x,y);}g.stroke();
    g.strokeStyle='#5ce8a0';g.lineWidth=0.98*z;g.stroke();
    const hx=cx+Math.cos(t*0.004)*0, hy=cy-1*z;
    g.fillStyle='#43c47e';g.beginPath();g.ellipse(hx,hy,3.4*z,2.6*z,0,0,7);g.fill();
    g.strokeStyle='#d8f8e8';g.lineWidth=0.56*z;g.beginPath();g.moveTo(hx-2*z,hy);g.lineTo(hx-7*z,hy-1*z);g.moveTo(hx+2*z,hy);g.lineTo(hx+7*z,hy+1*z);g.stroke(); // whiskers
    g.fillStyle='#2a7a4a';g.beginPath();g.moveTo(hx-1*z,hy-2*z);g.lineTo(hx-2*z,hy-5*z);g.lineTo(hx,hy-2.5*z);g.closePath();g.fill(); // horn
    g.fillStyle='#fff';g.beginPath();g.arc(hx-1*z,hy-0.5*z,0.7*z,0,7);g.arc(hx+1.4*z,hy-0.5*z,0.7*z,0,7);g.fill(); },
  tennyo:(g,cx,cy,z,t)=>{ const sw=Math.sin(t*0.004)*2*z;
    g.fillStyle='rgba(255,240,180,0.5)';g.beginPath();g.arc(cx,cy-9*z,4*z,0,7);g.fill(); // halo
    g.fillStyle='#ffd9ec';g.beginPath();g.moveTo(cx-2.4*z,cy);g.lineTo(cx+2.4*z,cy);g.lineTo(cx+1.6*z,cy-7*z);g.lineTo(cx-1.6*z,cy-7*z);g.closePath();g.fill();
    g.fillStyle='#e8c8a0';g.beginPath();g.arc(cx,cy-8.5*z,2.2*z,0,7);g.fill(); g.fillStyle='#3a2a40';g.beginPath();g.arc(cx,cy-9*z,2.3*z,Math.PI,0);g.fill();
    g.strokeStyle='rgba(255,245,200,0.7)';g.lineWidth=0.98*z;g.beginPath();g.moveTo(cx-6*z+sw,cy-3*z);g.quadraticCurveTo(cx,cy-5*z,cx+6*z-sw,cy-3*z);g.stroke(); }, // hagoromo scarf
  oni:(g,cx,cy,z,t)=>{ g.fillStyle='#b5402e';g.beginPath();g.moveTo(cx-3*z,cy);g.lineTo(cx+3*z,cy);g.lineTo(cx+3.4*z,cy-8*z);g.lineTo(cx-3.4*z,cy-8*z);g.closePath();g.fill();
    g.fillStyle='#9a3324';g.fillRect(cx-3*z,cy-3*z,6.8*z,1*z); // loincloth
    g.fillStyle='#c85440';g.beginPath();g.arc(cx,cy-9.5*z,2.8*z,0,7);g.fill(); // head
    g.fillStyle='#efe2c4';g.beginPath();g.moveTo(cx-1.6*z,cy-11.5*z);g.lineTo(cx-2.6*z,cy-13.6*z);g.lineTo(cx-0.8*z,cy-11.6*z);g.closePath();g.moveTo(cx+1.6*z,cy-11.5*z);g.lineTo(cx+2.6*z,cy-13.6*z);g.lineTo(cx+0.8*z,cy-11.6*z);g.closePath();g.fill(); // horns
    g.fillStyle='#3a1a10';g.fillRect(cx-1.6*z,cy-10*z,1.2*z,1*z);g.fillRect(cx+0.4*z,cy-10*z,1.2*z,1*z);
    g.fillStyle='#fff';g.fillRect(cx-1.4*z,cy-8.4*z,0.9*z,1.2*z);g.fillRect(cx+0.6*z,cy-8.4*z,0.9*z,1.2*z); // fangs
    g.strokeStyle='#6a4020';g.lineWidth=0.98*z;g.beginPath();g.moveTo(cx+3.4*z,cy-6*z);g.lineTo(cx+6*z,cy-11*z);g.stroke(); g.fillStyle='#7a5030';g.fillRect(cx+5*z,cy-12*z,2.4*z,2.4*z); }, // kanabo club
  tengu:(g,cx,cy,z,t)=>{ g.fillStyle='rgba(40,40,40,0.5)';g.beginPath();g.moveTo(cx-2*z,cy-7*z);g.lineTo(cx-8*z,cy-10*z);g.lineTo(cx-3*z,cy-4*z);g.closePath();g.moveTo(cx+2*z,cy-7*z);g.lineTo(cx+8*z,cy-10*z);g.lineTo(cx+3*z,cy-4*z);g.closePath();g.fill(); // wings
    g.fillStyle='#7a2d24';g.beginPath();g.moveTo(cx-2.6*z,cy);g.lineTo(cx+2.6*z,cy);g.lineTo(cx+2*z,cy-7*z);g.lineTo(cx-2*z,cy-7*z);g.closePath();g.fill();
    g.fillStyle='#d4806a';g.beginPath();g.arc(cx,cy-8.6*z,2.2*z,0,7);g.fill();
    g.fillStyle='#c0392b';g.beginPath();g.moveTo(cx,cy-8.6*z);g.lineTo(cx+6*z,cy-7.4*z);g.lineTo(cx,cy-6.8*z);g.closePath();g.fill(); // long nose
    g.fillStyle='#15110d';g.fillRect(cx-1.5*z,cy-9.6*z,1.2*z,2.4*z);g.fillRect(cx-0.6*z,cy-11.4*z,1.4*z,2*z); }, // tokin cap
  kitsune:(g,cx,cy,z,t)=>{ g.fillStyle='#e89a4a'; // multi-tail fox spirit
    for(let k=-1;k<=1;k++){g.beginPath();g.moveTo(cx-1*z,cy-2*z);g.quadraticCurveTo(cx-(5+k)*z,cy-(5-k*2)*z,cx-(7+k*0.5)*z,cy-(2-k*2)*z);g.quadraticCurveTo(cx-4*z,cy-1*z,cx-1*z,cy-1*z);g.closePath();g.fill();}
    g.fillStyle='#f0c890';g.beginPath();g.moveTo(cx-7*z,cy-2*z);g.lineTo(cx-8*z,cy-4*z);g.lineTo(cx-6*z,cy-3*z);g.closePath();g.fill();
    g.fillStyle='#e89a4a';g.beginPath();g.ellipse(cx+1*z,cy-3*z,3*z,2.2*z,0,0,7);g.fill(); g.beginPath();g.arc(cx+3.5*z,cy-5*z,1.8*z,0,7);g.fill();
    g.fillStyle='#fff';g.beginPath();g.moveTo(cx+4*z,cy-6*z);g.lineTo(cx+5.6*z,cy-8.4*z);g.lineTo(cx+5.8*z,cy-5.6*z);g.closePath();g.fill(); // ear
    g.fillStyle='#1a1a1a';g.beginPath();g.arc(cx+4.4*z,cy-5*z,0.6*z,0,7);g.fill(); },
  hitodama:(g,cx,cy,z,t)=>{ const fl=0.55+0.45*Math.sin(t*0.01); g.fillStyle='rgba(120,220,180,'+(fl*0.4)+')';g.beginPath();g.ellipse(cx,cy-6*z,6*z,8*z,0,0,7);g.fill();
    g.fillStyle='rgba(150,235,200,'+fl+')';g.beginPath();g.moveTo(cx,cy-12*z);g.quadraticCurveTo(cx+4*z,cy-7*z,cx,cy-2*z);g.quadraticCurveTo(cx-4*z,cy-7*z,cx,cy-12*z);g.fill();
    g.fillStyle='rgba(220,255,240,'+fl+')';g.beginPath();g.arc(cx,cy-7*z,2*z,0,7);g.fill(); g.fillStyle='rgba(150,235,200,'+(fl*0.6)+')';g.fillRect(cx-0.6*z,cy-2*z,1.2*z,4*z); },
  kappa:(g,cx,cy,z,t)=>{ g.fillStyle='#4a8a4a';g.beginPath();g.arc(cx,cy-4*z,3.2*z,0,7);g.fill(); // body
    g.fillStyle='#3a6a3a';g.beginPath();g.ellipse(cx,cy-4.5*z,2.4*z,2.8*z,0,0,7);g.fill(); // shell
    g.fillStyle='#6aaa5a';g.beginPath();g.arc(cx,cy-8*z,2.2*z,0,7);g.fill(); // head
    g.fillStyle='#cfe8c0';g.beginPath();g.ellipse(cx,cy-9.4*z,1.5*z,0.7*z,0,0,7);g.fill(); // water dish (sara)
    g.fillStyle='#d8b86a';g.beginPath();g.moveTo(cx-0.6*z,cy-7.6*z);g.lineTo(cx+2.4*z,cy-7.2*z);g.lineTo(cx-0.6*z,cy-6.8*z);g.closePath();g.fill(); // beak
    g.fillStyle='#1a1a1a';g.beginPath();g.arc(cx-0.8*z,cy-8.4*z,0.5*z,0,7);g.arc(cx+0.6*z,cy-8.4*z,0.5*z,0,7);g.fill(); },
  tanuki:(g,cx,cy,z,t)=>{ g.fillStyle='#7a5a3a';g.beginPath();g.ellipse(cx,cy-3.5*z,3.6*z,3.2*z,0,0,7);g.fill(); // round belly
    g.fillStyle='#cdb89a';g.beginPath();g.ellipse(cx,cy-3*z,2.4*z,2.4*z,0,0,7);g.fill();
    g.fillStyle='#6a4a2a';g.beginPath();g.arc(cx,cy-7.5*z,2.4*z,0,7);g.fill(); // head
    g.fillStyle='#2a1a10';g.beginPath();g.ellipse(cx-1.2*z,cy-7.6*z,1.1*z,1.4*z,0,0,7);g.ellipse(cx+1.2*z,cy-7.6*z,1.1*z,1.4*z,0,0,7);g.fill(); // mask eyes
    g.fillStyle='#fff';g.beginPath();g.arc(cx-1.2*z,cy-7.8*z,0.5*z,0,7);g.arc(cx+1.2*z,cy-7.8*z,0.5*z,0,7);g.fill();
    g.fillStyle='#5a3a22';g.beginPath();g.moveTo(cx-2.4*z,cy-9*z);g.lineTo(cx-1.4*z,cy-11*z);g.lineTo(cx-0.8*z,cy-9*z);g.closePath();g.moveTo(cx+2.4*z,cy-9*z);g.lineTo(cx+1.4*z,cy-11*z);g.lineTo(cx+0.8*z,cy-9*z);g.closePath();g.fill(); // ears
    g.fillStyle='#3a8a3a';g.beginPath();g.ellipse(cx,cy-12*z,1.6*z,0.9*z,0.5,0,7);g.fill(); }, // leaf on head
  yukionna:(g,cx,cy,z,t)=>{ const sw=Math.sin(t*0.003)*1.5*z;
    g.fillStyle='rgba(220,235,255,0.85)';g.beginPath();g.moveTo(cx-2.6*z,cy+1*z);g.lineTo(cx+2.6*z,cy+1*z);g.lineTo(cx+1.6*z,cy-7*z);g.lineTo(cx-1.6*z,cy-7*z);g.closePath();g.fill(); // white kimono
    g.fillStyle='#eef4ff';g.beginPath();g.arc(cx,cy-8.6*z,2.2*z,0,7);g.fill(); // pale face
    g.fillStyle='#15131a';g.beginPath();g.moveTo(cx-2.3*z,cy-9*z);g.quadraticCurveTo(cx-3*z+sw,cy-2*z,cx-1.6*z,cy);g.lineTo(cx,cy-3*z);g.lineTo(cx+1.6*z,cy);g.quadraticCurveTo(cx+3*z-sw,cy-2*z,cx+2.3*z,cy-9*z);g.quadraticCurveTo(cx,cy-11*z,cx-2.3*z,cy-9*z);g.fill(); // long black hair
    g.fillStyle='#eef4ff';g.beginPath();g.arc(cx,cy-8.6*z,2.2*z,0,7);g.fill();
    g.fillStyle='#8aa0c0';g.fillRect(cx-1.2*z,cy-9*z,0.9*z,0.8*z);g.fillRect(cx+0.4*z,cy-9*z,0.9*z,0.8*z);
    g.fillStyle='rgba(220,240,255,0.5)';for(let k=0;k<4;k++){g.fillRect(cx+(Math.sin(t*0.01+k)*6)*z,cy-12*z-k*2*z,1*z,1*z);} }, // snowflakes
  kasaobake:(g,cx,cy,z,t)=>{ const hop=Math.abs(Math.sin(t*0.008))*2*z;
    g.strokeStyle='#5a3d24';g.lineWidth=0.7*z;g.beginPath();g.moveTo(cx,cy-hop);g.lineTo(cx,cy-6*z-hop);g.stroke(); // single leg pole
    g.fillStyle='#7a5630';g.fillRect(cx-1*z,cy-1*z-hop,2*z,2*z); // geta clog
    g.fillStyle='#caa24a';g.beginPath();g.moveTo(cx-5*z,cy-6*z-hop);g.lineTo(cx+5*z,cy-6*z-hop);g.lineTo(cx,cy-11*z-hop);g.closePath();g.fill(); // umbrella canopy
    g.strokeStyle='#8a6a30';g.lineWidth=0.42*z;for(let k=-4;k<=4;k+=2){g.beginPath();g.moveTo(cx,cy-11*z-hop);g.lineTo(cx+k*z,cy-6*z-hop);g.stroke();}
    g.fillStyle='#fff';g.beginPath();g.arc(cx,cy-7.6*z-hop,1.4*z,0,7);g.fill(); g.fillStyle='#1a1a1a';g.beginPath();g.arc(cx,cy-7.6*z-hop,0.7*z,0,7);g.fill(); // one eye
    g.fillStyle='#c0392b';g.beginPath();g.moveTo(cx-1*z,cy-6*z-hop);g.lineTo(cx+1*z,cy-6*z-hop);g.lineTo(cx,cy-3.5*z-hop);g.closePath();g.fill(); }, // tongue
  bakeneko:(g,cx,cy,z,t)=>{ g.fillStyle='#3a3340';g.beginPath();g.ellipse(cx,cy-3*z,2.8*z,2.4*z,0,0,7);g.fill();
    g.strokeStyle='#3a3340';g.lineWidth=1.4*z;g.beginPath();g.moveTo(cx+2*z,cy-3*z);g.quadraticCurveTo(cx+6*z,cy-6*z,cx+5*z,cy-11*z);g.stroke(); // raised tail
    g.fillStyle='#4a4350';g.beginPath();g.arc(cx-1*z,cy-6*z,2.2*z,0,7);g.fill();
    g.fillStyle='#3a3340';g.beginPath();g.moveTo(cx-3*z,cy-7*z);g.lineTo(cx-2.4*z,cy-9.5*z);g.lineTo(cx-1*z,cy-7.4*z);g.closePath();g.moveTo(cx+1*z,cy-7.4*z);g.lineTo(cx+0.4*z,cy-9.5*z);g.lineTo(cx-0.8*z,cy-7.2*z);g.closePath();g.fill(); // ears
    g.fillStyle='#f5d020';g.beginPath();g.arc(cx-1.8*z,cy-6*z,0.7*z,0,7);g.arc(cx-0.2*z,cy-6*z,0.7*z,0,7);g.fill();
    g.fillStyle='rgba(120,200,255,'+(0.4+0.3*Math.sin(t*0.01))+')';g.beginPath();g.ellipse(cx-1*z,cy-12*z,2*z,3*z,0,0,7);g.fill(); }, // ghost flame
  nurarihyon:(g,cx,cy,z,t)=>{ g.fillStyle='#3a4a6a';g.beginPath();g.moveTo(cx-3*z,cy);g.lineTo(cx+3*z,cy);g.lineTo(cx+2*z,cy-7*z);g.lineTo(cx-2*z,cy-7*z);g.closePath();g.fill(); // robe
    g.fillStyle='#6a5a4a';g.beginPath();g.ellipse(cx,cy-11*z,2.4*z,4*z,0,0,7);g.fill(); // elongated gourd head
    g.fillStyle='#d8c8b0';g.beginPath();g.arc(cx,cy-8.5*z,2*z,0,7);g.fill(); // face
    g.fillStyle='#15110d';g.fillRect(cx-1.2*z,cy-8.8*z,0.9*z,0.6*z);g.fillRect(cx+0.4*z,cy-8.8*z,0.9*z,0.6*z);
    g.strokeStyle='#fff';g.lineWidth=0.42*z;g.beginPath();g.moveTo(cx-1.4*z,cy-6.8*z);g.lineTo(cx+1.4*z,cy-6.8*z);g.stroke(); },
};
const FLY=['tengu','tennyo','hitodama'], GROUND=['oni','kitsune','tennyo','hitodama','tanuki','nurarihyon','bakeneko','kasaobake'];

/* ============================ RENDER ============================ */
let hover=null, fx=0;
/* LOD (level-of-detail). Below LOD_Z, forms render as massing silhouettes (walls +
   roof shape + ink, no windows/props/emblems) and the ink dilation drops 8->4 dirs.
   At/above LOD_Z everything is full detail. 0.85 sits just under the 0.9 default zoom,
   so normal & zoomed-in play stay fully detailed; only the pulled-back overview simplifies. */
let LOD=false; const LOD_Z=1.05;
/* ---- watercolor ground: the whole terrain pass is rendered to an offscreen
   buffer, then composited back as a multi-scale blur. This is what dissolves the
   hard diamond facets into soft painted colour fields. Props draw crisp on top. ---- */
let gBuf=null,gctx=null,gB2=null,gc2=null,gB3=null,gc3=null,gB4=null,gc4=null;
let oBuf=null,octx=null,sBuf=null,sctx=null;   // LOCKED Layer 1: object colour buffer + sumi-e silhouette mask
let aBuf=null,actx=null,amBuf=null,amctx=null; // AGENTS-only colour source + agent ink working mask (two-tier ink)
function ensureGroundBuffers(){ const w=Math.max(1,cv.width),h=Math.max(1,cv.height);
  if(gBuf&&gBuf.width===w&&gBuf.height===h)return;
  const mk=(sw,sh)=>{ const c=document.createElement('canvas'); c.width=Math.max(1,sw|0); c.height=Math.max(1,sh|0); return c; };
  // blur radii are defined in CSS pixels (÷DPR) so the softening looks identical on
  // retina/phone screens instead of vanishing at high device-pixel-ratio
  const d=DPR||1;
  gBuf=mk(w,h); gctx=gBuf.getContext('2d');
  oBuf=mk(w,h); octx=oBuf.getContext('2d');   // solid objects (buildings/agents/trees) for the ink pass
  sBuf=mk(w,h); sctx=sBuf.getContext('2d');   // recoloured silhouette mask (structures)
  aBuf=mk(w,h); actx=aBuf.getContext('2d');   // AGENTS only — delicate-ink source
  amBuf=mk(w,h); amctx=amBuf.getContext('2d');// agent ink working mask (warm sumi + dry-brush)
  gB2=mk(w*0.62/d,h*0.62/d); gc2=gB2.getContext('2d');     // gentle blur (soft base)
  gB3=mk(w*0.32/d,h*0.32/d); gc3=gB3.getContext('2d');     // watercolor bleed
  gB4=mk(w*0.14/d,h*0.14/d); gc4=gB4.getContext('2d');     // faint halo
  for(const c of [gc2,gc3,gc4]){ c.imageSmoothingEnabled=true; c.imageSmoothingQuality='high'; }
}
// downsample chain + weighted re-composite onto the main canvas (device pixels, identity transform)
function compositeSoftGround(tg){ tg=tg||ctx; const w=cv.width,h=cv.height;
  gc2.clearRect(0,0,gB2.width,gB2.height); gc2.drawImage(gBuf,0,0,gB2.width,gB2.height);
  gc3.clearRect(0,0,gB3.width,gB3.height); gc3.drawImage(gB2,0,0,gB3.width,gB3.height);
  gc4.clearRect(0,0,gB4.width,gB4.height); gc4.drawImage(gB3,0,0,gB4.width,gB4.height);
  // ZOOM-AWARE softening: at low zoom (zoomed out) the diamond tile grid is denser on
  // screen and reads as a harsh geometric/checkerboard pattern, especially on the rim where
  // terrain type changes tile-to-tile. Fade the crisp layer down and the soft/bleed layers up
  // as zoom drops below LOD_Z so the far view dissolves into painted fields, not facets.
  const farT=Math.max(0,Math.min(1,(LOD_Z-cam.zoom)/LOD_Z)); // 0 at/above LOD_Z, ->1 as zoom shrinks further
  tg.save(); tg.setTransform(1,0,0,1,0,0); tg.imageSmoothingEnabled=true; tg.imageSmoothingQuality='high';
  if(S.era<=4){   // watercolor ages: facets MELTED into smooth painted fields
    tg.globalAlpha=1.00; tg.drawImage(gB2,0,0,w,h);   // soft base (0.62 scale)
    // Heavier watercolor-bleed (0.32-scale, blurry enough to dissolve the diamond grid) carries
    // most of the surface now, and the crisp per-tile layer is reduced to a whisper — so flat
    // ground reads as one continuous painted field instead of a facetted tile mosaic. Held
    // roughly flat across zoom (not climbing with farT) to avoid the puffy-cloud look far out.
    tg.globalAlpha=0.80; tg.drawImage(gB3,0,0,w,h);   // watercolor bleed — melts facets
    tg.globalAlpha=Math.min(0.30,0.20+farT*0.10); tg.drawImage(gB4,0,0,w,h);   // atmospheric halo
    tg.globalAlpha=Math.max(0.04,0.07-farT*0.03); tg.drawImage(gBuf,0,0,w,h);  // faint crisp whisper only
  } else {        // later ages stay crisp
    tg.globalAlpha=1.00; tg.drawImage(gBuf,0,0,w,h);
    if(farT>0){ tg.globalAlpha=farT*0.5; tg.drawImage(gB3,0,0,w,h); } // still soften the silhouette at a distance even in crisp ages
  }
  tg.globalAlpha=1; tg.restore();
}
function valColor(v){ const r=Math.round(220-v*180), g=Math.round(40+v*170), b=Math.round(40+v*40); return 'rgba('+r+','+g+','+b+',0.5)'; }
/* ============================================================================
   LAYERED RENDER (perf core).  The static world — terrain watercolor, roads,
   wires, trees, buildings and their sumi-e ink — is baked ONCE into wBuf and
   reused every frame. It is rebuilt only when the view truly changes (camera,
   era, day/night, overlays, or any tile edit via gridVersion). Each frame then
   costs ~1 blit + sky + a few dozen moving actors, instead of re-rendering 3600
   tiles, a 7-pass blur and an 8-direction ink dilation 60x/second.
   Accepted tradeoff: agents draw on a flat layer ABOVE buildings (a pedestrian
   behind a tall structure is not occluded). Tree<->building depth is preserved. */
let wBuf=null,wctx=null,_wkey='',gridVersion=0;
function ensureWorldBuffer(){ const w=Math.max(1,cv.width),h=Math.max(1,cv.height);
  if(wBuf&&wBuf.width===w&&wBuf.height===h)return;
  wBuf=document.createElement('canvas'); wBuf.width=w; wBuf.height=h; wctx=wBuf.getContext('2d'); _wkey=''; }
function worldKey(){ return cam.x.toFixed(1)+'_'+cam.y.toFixed(1)+'_'+cam.zoom.toFixed(4)+'_'+S.era
  +'_'+(ENV.night?1:0)+'_'+(S.overlay?1:0)+'_'+(S.ink!==false?1:0)+'_'+gridVersion+'_'+VW+'x'+VH; }

// Universal ink: dilate the alpha shapes already drawn into oBuf and stamp them
// behind the forms on target `tg`. Shared by the cached world + the live actors.
// Two-tier sumi-e ink. Structures (buildings/trees/ruins) and agents share one depth-sorted
// colour buffer (oBuf) so occlusion stays correct, but they are INKED separately: the bold
// confident contour traces structures only (agent bodies are erased from that mask), while a
// second, much finer pass gives the small figures a thin, warm, dry-brushed line — closer to a
// real ink-scroll figure than the old uniform marker outline.
function stampInk(tg,z){ const dw=oBuf.width,dh=oBuf.height;
  // (1) STRUCTURE mask = whole-scene silhouette with agent bodies subtracted
  sctx.setTransform(1,0,0,1,0,0); sctx.clearRect(0,0,dw,dh);
  sctx.globalCompositeOperation='source-over'; sctx.drawImage(oBuf,0,0);
  sctx.globalCompositeOperation='source-in'; sctx.fillStyle='#1a1208'; sctx.fillRect(0,0,dw,dh);  // warm sumi, not dead black
  sctx.globalCompositeOperation='destination-out'; sctx.drawImage(aBuf,0,0);                       // people don't get the bold line
  sctx.globalCompositeOperation='source-over';
  // (2) AGENT ink mask = agents only -> warm figure ink -> dry-brush gaps punched out
  let haveAgents=false;
  { amctx.setTransform(1,0,0,1,0,0); amctx.clearRect(0,0,dw,dh);
    amctx.globalCompositeOperation='source-over'; amctx.drawImage(aBuf,0,0);
    amctx.globalCompositeOperation='source-in'; amctx.fillStyle='#251a0d'; amctx.fillRect(0,0,dw,dh); // confident warm figure ink — still lighter than the structure line
    if(!BRUSHPAT)BRUSHPAT=amctx.createPattern(BRUSHTEX,'repeat');
    if(BRUSHPAT){ amctx.globalCompositeOperation='destination-out'; amctx.fillStyle=BRUSHPAT;
      // two phase-offset dry-brush passes — the surviving ink keeps an organic thick/thin
      // pressure modulation along its length (real sumi-e brush) instead of a uniform broken stipple.
      // Lightened from the original erosion (0.30/0.20) so more confident line survives — a
      // figure brushed with intent, not one that's mostly worn away.
      amctx.globalAlpha=0.16; amctx.fillRect(0,0,dw,dh);
      amctx.save(); amctx.translate(17,11); amctx.globalAlpha=0.11; amctx.fillRect(-17,-11,dw+34,dh+22); amctx.restore();
      amctx.globalAlpha=1; }
    amctx.globalCompositeOperation='source-over'; haveAgents=true; }
  tg.save(); tg.setTransform(1,0,0,1,0,0);
  if(S.ink!==false){
    // ---- STRUCTURES: bold but brush-laid. Soft halo + a varied-pressure core (cardinals carry
    //      the weight, diagonals trail off) so the line reads hand-pulled rather than uniformly thick.
    const od=Math.max(0.9,z*0.56)*DPR, bd=od*2.2;
    tg.globalAlpha=VOID?0.22:0.20;
    for(const[ox,oy]of [[bd,0],[-bd,0],[0,bd],[0,-bd],[bd,bd],[-bd,-bd]]) tg.drawImage(sBuf,ox,oy);
    for(const[ox,oy]of [[od,0],[-od,0],[0,od],[0,-od]]){ tg.globalAlpha=VOID?0.76:0.74; tg.drawImage(sBuf,ox,oy); }
    if(cam.zoom>=LOD_Z) for(const[ox,oy]of [[od,od],[od,-od],[-od,od],[-od,-od]]){ tg.globalAlpha=VOID?0.40:0.38; tg.drawImage(sBuf,ox,oy); }
    // ---- AGENTS: fine brush, raised to a clear-but-delicate line (Sesshū figure-ink range —
    //      thin, confident, never thick). Alphas lifted across the board from the original
    //      0.17–0.54 pass, which read as nearly invisible at gameplay zoom; offsets (ad) are
    //      UNCHANGED so the line stays the same fine width — only its visibility increases.
    if(haveAgents){ const ad=Math.max(0.62,z*0.36)*DPR;
      tg.globalAlpha=0.26; tg.drawImage(amBuf,ad*1.6,ad*1.6); tg.drawImage(amBuf,-ad*1.6,ad*1.4); // warm bloom beneath
      tg.globalAlpha=0.74; tg.drawImage(amBuf,ad,ad*0.7);                                          // down-right (gravity) — heaviest, confident core line
      tg.globalAlpha=0.66; tg.drawImage(amBuf,-ad,ad*0.7);                                         // down-left
      tg.globalAlpha=0.46; tg.drawImage(amBuf,ad*0.5,0); tg.globalAlpha=0.46; tg.drawImage(amBuf,-ad*0.5,0);
      tg.globalAlpha=0.30; tg.drawImage(amBuf,0,-ad);                                              // top — lightest (toward the light)
    }
  }
  tg.globalAlpha=1; tg.drawImage(oBuf,0,0); tg.restore(); }

// Wraps the whole landmass in a single soft contour + glow at overview zoom, so the island
// reads as one dramatic floating shape from a distance instead of a field of tiny diamond
// facets. Pure presentation pass — does not alter terrain data, the locked 3-layer tile
// system, or the per-face void-edge cliffs; it sits underneath them as a unifying wash.
function paintLandmassSilhouette(tg,z){
  const far=Math.max(0,Math.min(1,(LOD_Z-z)/LOD_Z));               // 0 at LOD_Z, ->1 the further out we go
  if(far<=0)return;
  let minX=1e9,maxX=-1e9,minY=1e9,maxY=-1e9; const pts=[], rimPts=[];
  for(let ty=0;ty<H;ty++)for(let tx=0;tx<W;tx++){ const c=grid[ty][tx];
    if(!c.shore||c.ter===WATER)continue;
    const[cx,cy]=s2(tx,ty); if(cx<-TW*z*2||cx>VW+TW*z*2||cy<-TH*z*8||cy>VH+TH*z*2)continue;
    pts.push(cx,cy); if(c.tundra)rimPts.push(cx,cy,c.seed||0);
    if(cx<minX)minX=cx; if(cx>maxX)maxX=cx; if(cy<minY)minY=cy; if(cy>maxY)maxY=cy; }
  if(!pts.length)return;
  tg.save(); tg.setTransform(1,0,0,1,0,0);
  // soft dark contact-shadow glow hugging the shoreline tiles — reads as the mass settling
  // into the void, strongest the further the camera pulls back
  tg.globalCompositeOperation='multiply'; tg.globalAlpha=Math.min(0.5,far*0.42);
  for(let i=0;i<pts.length;i+=4){ const px=pts[i],py=pts[i+1];
    const gr=tg.createRadialGradient(px,py,0,px,py,TH*z*2.6);
    gr.addColorStop(0,'rgba(8,7,14,0.55)'); gr.addColorStop(1,'rgba(8,7,14,0)');
    tg.fillStyle=gr; tg.beginPath(); tg.arc(px,py,TH*z*2.6,0,7); tg.fill(); }
  // HARSH RIM DESOLATION: extra dark, irregularly-sized stamps over the frozen-rim tiles
  // specifically, jittered in radius and offset so the broken wasteland reads as one ragged
  // dissolving mass from a distance rather than a ring of identical tile facets.
  tg.globalAlpha=Math.min(0.62,far*0.55);
  for(let i=0;i<rimPts.length;i+=3){ const px=rimPts[i],py=rimPts[i+1],sd=rimPts[i+2];
    const jr=TH*z*(2.2+sd*2.6), ox=(sd*173.7%1-0.5)*TW*z*0.7, oy=(sd*81.3%1-0.5)*TH*z*0.7;
    const gr=tg.createRadialGradient(px+ox,py+oy,0,px+ox,py+oy,jr);
    gr.addColorStop(0,'rgba(5,5,10,0.5)'); gr.addColorStop(0.6,'rgba(5,5,10,0.22)'); gr.addColorStop(1,'rgba(5,5,10,0)');
    tg.fillStyle=gr; tg.beginPath(); tg.arc(px+ox,py+oy,jr,0,7); tg.fill(); }
  tg.globalCompositeOperation='source-over';
  // a single unifying rim-light sweep across the whole silhouette's bounding shape — cool
  // moonlit edge on the upper-left mass, warm dusk on the lower-right, so the floating island
  // reads as one continuous form with real presence rather than scattered tile debris.
  // TONED DOWN + DESATURATED: the old near-white stop (210,222,232 at up to 0.30 alpha,
  // stamped as overlapping circles at every-other shore tile) summed into a pale cloud-bank
  // smothering the coastline instead of a subtle highlight. Dimmer, cooler-grey stop and a
  // much lower alpha ceiling keep it a thin accent; sparser sampling (step 5, smaller radius)
  // stops the circles from visually fusing into one solid puffy mass.
  tg.globalAlpha=Math.min(0.12,far*0.10);
  const rg=tg.createLinearGradient(minX,minY,maxX,maxY);
  rg.addColorStop(0,'rgba(150,162,176,0.5)'); rg.addColorStop(0.5,'rgba(150,162,176,0)'); rg.addColorStop(1,'rgba(90,68,48,0.35)');
  tg.fillStyle=rg;
  for(let i=0;i<pts.length;i+=5){ const px=pts[i],py=pts[i+1];
    tg.beginPath(); tg.arc(px,py,TH*z*0.55,0,7); tg.fill(); }
  tg.globalAlpha=1; tg.restore();
}
// Bake the slow-changing world into wBuf (transparent where there is no land, so
// it composites over the live sky). Runs only when worldKey() changes.
// ONE continuous painted coastline: gathers every shore-tile centre, orders them angularly
// around the landmass centroid, and fills/strokes a single oversized wobbling path that fuses
// the whole rim into one organic ink+wash silhouette. Drawn BEFORE the per-tile terrain, so
// individual tiles paint on top of it and the hard diamond edges never show through at the
// boundary. Pure presentation — terrain data and the per-face cliff drama are untouched.
// Cached WORLD-SPACE coastline rings, computed once per gridVersion via real edge-following
// (not an angle-sort, which breaks on concave/branching coasts and produces a different,
// self-intersecting order every time the camera moves — that was the stuttering-light bug).
// Each ring is an ordered loop of [tx,ty] tile centres walking the actual land/void boundary.
/* EDGE-DISTANCE FIELD — tiles from the nearest void/water, cached per gridVersion. Lets the
   outer tundra rim fade smoothly into the painted shoreline cliff instead of stamping noisy
   per-tile blobs right at the silhouette, so the rim reads as one continuous painted edge
   dissolving into the void (Master Spec §10). */
let _edgeDist=null,_edgeDistVer=-1;
function ensureEdgeDist(){
  if(_edgeDist&&_edgeDistVer===gridVersion)return;
  const D=Array.from({length:H},()=>new Float32Array(W).fill(99));
  let frontier=[];
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
    if(grid[y][x].ter===WATER){ D[y][x]=0; frontier.push([x,y]); continue; }
    for(const[dx,dy]of NEIGH){ if(!inB(x+dx,y+dy)){ D[y][x]=0; frontier.push([x,y]); break; } }  // grid border -> void beyond
  }
  let dist=0;
  while(frontier.length&&dist<40){ const next=[]; dist++;
    for(const[x,y]of frontier)for(const[dx,dy]of NEIGH){ const ax=x+dx,ay=y+dy;
      if(inB(ax,ay)&&grid[ay][ax].ter!==WATER&&D[ay][ax]>dist){ D[ay][ax]=dist; next.push([ax,ay]); } }
    frontier=next; }
  _edgeDist=D; _edgeDistVer=gridVersion;
}
let _shoreRings=null, _shoreRingsVer=-1;
function buildShoreRings(){
  const segs=new Map(); // key 'x1,y1,x2,y2' edge -> [ax,ay,bx,by] in world tile units, one edge per land/void boundary
  const corner=(tx,ty,which)=>{ // 4 corners of a tile's diamond footprint, in world (tx,ty) fractional space
    if(which===0)return[tx,ty]; if(which===1)return[tx+1,ty]; if(which===2)return[tx+1,ty+1]; return[tx,ty+1]; };
  const addEdge=(c1,c2)=>{ const k=c1.join(',')+'|'+c2.join(',');
    segs.set(k,[c1,c2]); };
  for(let ty=0;ty<H;ty++)for(let tx=0;tx<W;tx++){ const c=grid[ty][tx]; if(c.ter===WATER)continue;
    // 4 directional neighbours; an edge is drawn on whichever side faces void/water. All four
    // sides wind consistently CLOCKWISE around the tile — (0,0)->(1,0)->(1,1)->(0,1)->(0,0) —
    // so edges chain tip-to-tail across tiles without dead ends. (The previous south/west
    // directions ran the same way as north/east instead of reversed, so a lone tile's own
    // boundary didn't close on itself — north/east arrived at corner 2 but south/west both
    // started from corner 0/3, leaving no outgoing edge from corner 2 or 1. That produced dead
    // ends at the very first step of tracing almost every ring, fragmenting the coastline into
    // dozens of tiny disconnected pieces instead of one continuous loop.)
    if(!inB(tx,ty+1)||grid[ty+1][tx].ter===WATER) addEdge(corner(tx,ty,2),corner(tx,ty,3));   // south edge
    if(!inB(tx+1,ty)||grid[ty][tx+1].ter===WATER) addEdge(corner(tx,ty,1),corner(tx,ty,2));   // east edge
    if(!inB(tx,ty-1)||grid[ty-1][tx].ter===WATER) addEdge(corner(tx,ty,0),corner(tx,ty,1));   // north edge
    if(!inB(tx-1,ty)||grid[ty][tx-1].ter===WATER) addEdge(corner(tx,ty,3),corner(tx,ty,0));   // west edge
  }
  // chain edges tip-to-tail into closed rings by following shared endpoints. At diagonal
  // corner-touches (two land tiles meeting only at a point across a water/void diagonal) a
  // vertex has TWO valid outgoing boundary edges, not one — picking whichever happens to be
  // first in map-insertion order there cuts the true coastline into dozens of small fragments
  // instead of one ring. Resolve those branches deterministically by turning angle: always take
  // the most clockwise turn from the incoming direction, which is the standard rule for tracing
  // a single consistent boundary through ambiguous corner-touch vertices.
  const byStart=new Map();
  for(const[k,[a,b]]of segs){ const sk=a.join(','); if(!byStart.has(sk))byStart.set(sk,[]); byStart.get(sk).push([a,b,k]); }
  const used=new Set(), rings=[];
  const ang=(dx,dy)=>Math.atan2(dy,dx);
  for(const[k,[a0,b0]] of segs){ if(used.has(k))continue;
    const ring=[]; let cur=a0, prev=null, guard=0, startKey=a0.join(',');
    used.add(k); ring.push(a0); cur=b0; prev=a0;
    while(guard++<4000){
      if(cur.join(',')===startKey) break;
      const opts=(byStart.get(cur.join(','))||[]).filter(([,,kk])=>!used.has(kk));
      if(!opts.length) break;
      let nxt=null, nk=null;
      if(opts.length===1){ nxt=opts[0][1]; nk=opts[0][2]; }
      else{
        // branch point: pick the option whose turn (relative to the incoming heading) is the
        // smallest clockwise turn — i.e. hugs the boundary tightly rather than cutting across.
        const inAng=ang(cur[0]-prev[0],cur[1]-prev[1]);
        let best=-1, bestTurn=Infinity;
        for(let i=0;i<opts.length;i++){ const[,b,]=opts[i];
          const outAng=ang(b[0]-cur[0],b[1]-cur[1]);
          let turn=outAng-inAng; while(turn<=-Math.PI)turn+=2*Math.PI; while(turn>Math.PI)turn-=2*Math.PI;
          // most negative (clockwise) turn wins; ties broken by smallest |turn|
          if(turn<bestTurn){ bestTurn=turn; best=i; } }
        nxt=opts[best][1]; nk=opts[best][2];
      }
      used.add(nk); ring.push(cur); cur=nxt; prev=ring[ring.length-1];
    }
    if(ring.length>=3) rings.push(ring); }
  _shoreRings=rings; _shoreRingsVer=gridVersion;
}
// Computes (and caches per gridVersion+zoom) the smoothed organic coastline path for the
// island's main outer ring, as an array of [x,y] points in screen space. Shared by
// paintShorelineMass (the painted wash/ink) and clipGroundToShoreline (the hard tile-edge
// mask), so the visible tile boundary and the painted curve are always pixel-identical —
// no separate "smoothing" pass that can drift out of sync with what's actually painted.
let _smoothShoreline=null, _smoothShorelineKey='';
function computeSmoothShoreline(z){
  const key=gridVersion+'_'+z.toFixed(4)+'_'+VW+'x'+VH+'_'+cam.x.toFixed(1)+'_'+cam.y.toFixed(1);
  if(_smoothShoreline && _smoothShorelineKey===key) return _smoothShoreline;
  if(_shoreRingsVer!==gridVersion) buildShoreRings();
  if(!_shoreRings||!_shoreRings.length){ _smoothShoreline=null; _smoothShorelineKey=key; return null; }
  let mainRing=_shoreRings[0]; for(const r of _shoreRings) if(r.length>mainRing.length) mainRing=r;
  const scr=mainRing.map(([tx,ty])=>s2(tx,ty));
  const seedBase=(mainRing[0][0]*7+mainRing[0][1]*13)%97/97;
  const N=scr.length;
  const pathPts=[];
  // Pre-smooth the RAW ring geometry before computing tangents/normals or displacing anything.
  // A single-tile staircase tooth (out one tile, in one tile, out again) is a high-frequency
  // feature only ~2-3 tile-widths wide; pushing both its flanks outward by the same large
  // organic-curve displacement amplitude makes them cross each other before any blur ever runs
  // — blurring AFTER a fold can shrink the loop but can't undo the crossing. Smoothing the
  // geometry first removes those single-tile teeth from the tangent field entirely, so the
  // normals being displaced are already the gentle, large-scale shoreline direction.
  let geo=scr.map(p=>[p[0],p[1]]);
  for(let pass=0;pass<9;pass++){ const nx2=[];
    for(let i=0;i<N;i++){ const p0=geo[(i-1+N)%N],p1=geo[i],p2=geo[(i+1)%N];
      nx2.push([(p0[0]+p1[0]*2+p2[0])/4,(p0[1]+p1[1]*2+p2[1])/4]); }
    geo=nx2; }
  let totalLen=0; const segLen=[];
  for(let i=0;i<N;i++){ const a=geo[i], b=geo[(i+1)%N]; const dx=b[0]-a[0],dy=b[1]-a[1];
    const L=Math.sqrt(dx*dx+dy*dy)||0.0001; segLen.push(L); totalLen+=L; }
  const STEP=Math.max(3,TW*z*0.11);
  const nSamples=Math.max(24,Math.round(totalLen/STEP));
  let segIdx=0, acc=0;
  // Ring-wide winding sign (shoelace formula) instead of a per-point centroid test: a centroid
  // comparison picks the WRONG side for any point on the far wall of a concave bay/inlet (the
  // centroid sits across the water from it), which sent the old per-point displacement flying
  // outward across the inlet instead of along the real shore — the spiky zigzag artifact. Since
  // the ring is traced with a single consistent direction (see buildShoreRings), one global sign
  // gives every point the correct outward rotation of its local tangent, concave or not.
  let shoelace=0; for(let i=0;i<N;i++){ const a=scr[i], b=scr[(i+1)%N]; shoelace += a[0]*b[1]-b[0]*a[1]; }
  const cw = shoelace<0;   // screen-space y grows downward, so this matches our clockwise tile winding
  for(let s=0;s<nSamples;s++){
    const target=(s/nSamples)*totalLen;
    while(segIdx<N-1 && acc+segLen[segIdx]<target){ acc+=segLen[segIdx]; segIdx++; }
    const a=geo[segIdx], b=geo[(segIdx+1)%N], L=segLen[segIdx]||0.0001;
    const t=Math.max(0,Math.min(1,(target-acc)/L));
    const px=a[0]+(b[0]-a[0])*t, py=a[1]+(b[1]-a[1])*t;
    const tx_=(b[0]-a[0])/L, ty_=(b[1]-a[1])/L;   // unit tangent along travel direction
    let nx=cw?-ty_:ty_, ny=cw?tx_:-tx_;            // fixed 90° rotation — outward for the whole ring
    const u=s/nSamples;
    const huge=vhash(seedBase,Math.floor(u*2.3)*0.9+201)*2-1, huge2=vhash(seedBase,Math.floor(u*2.3)*0.9+201+0.9)*2-1;
    const tHuge=(u*2.3)%1;
    const big=vhash(seedBase,Math.floor(u*6)*1.7+1)*2-1, big2=vhash(seedBase,Math.floor(u*6)*1.7+1+1.7)*2-1;
    const med=vhash(seedBase,Math.floor(u*16)*3.3+7)*2-1, med2=vhash(seedBase,Math.floor(u*16)*3.3+7+3.3)*2-1;
    const fineP=u*6*Math.PI*2*3.7, fine=Math.sin(fineP+seedBase*6.28)*0.5;
    const tBig=(u*6)%1, tMed=(u*16)%1;
    const hugeAmp = TW*z*(0.70+seedBase*0.30);
    const lowAmp  = TW*z*(0.36+seedBase*0.16);
    const medAmp  = TW*z*0.16;
    const fineAmp = TW*z*0.05;
    const huge_ = (huge+(huge2-huge)*tHuge);
    const low = (big+(big2-big)*tBig);
    const mid = (med+(med2-med)*tMed);
    const disp = Math.max(TW*z*0.12, TW*z*1.05 + huge_*hugeAmp + low*lowAmp + mid*medAmp + fine*fineAmp);
    pathPts.push([px+nx*disp, py+ny*disp]);
  }
  const smN=pathPts.length; let sm=pathPts;
  // Many more passes than the old "harsh jag" tuning (which used exactly one pass to keep the
  // edge looking torn). A large per-point outward displacement on a tight tile-notch can push
  // adjacent samples past each other into a self-intersecting loop; a single weak blur pass
  // can't undo that. Repeated Laplacian smoothing relaxes the curve until it's a clean simple
  // loop with no folds, while the big/huge octave swings (much lower frequency than this local
  // smoothing) still survive to keep the coastline genuinely organic rather than a flat oval.
  for(let pass=0;pass<14;pass++){ const nx2=[];
    for(let i=0;i<smN;i++){ const p0=sm[(i-1+smN)%smN],p1=sm[i],p2=sm[(i+1)%smN];
      nx2.push([(p0[0]+p1[0]*2+p2[0])/4,(p0[1]+p1[1]*2+p2[1])/4]); }
    sm=nx2; }
  // Final safety net: remove any remaining local self-intersections. Pre-smoothing the raw
  // geometry and heavily blurring the displaced curve eliminate almost all folding, but the
  // very tightest single-tile teeth can still produce a small loop where two nearby segments
  // cross. Rather than chase that with ever more blur passes (diminishing returns, and global
  // blur softens the genuine large-scale organic bays/headlands we want to keep), directly
  // detect crossings within a local window and splice the loop out — replace the looped span
  // with a straight bridge between its entry and exit points. Window is local (not all-pairs)
  // since real loops only ever form between samples that are close together along the curve.
  sm = removeLocalLoops(sm);
  _smoothShoreline=sm; _smoothShorelineKey=key;
  return sm;
}
// TIGHT ground clip — a smooth curve that hugs the actual tile footprint (NOT the +1-tile
// outward wash curve from computeSmoothShoreline). Used to confine every per-tile diamond fill
// so the GREEN ground ends on a clean organic edge instead of a staircase of protruding diamond
// tips. The brown coastal wash (painted earlier, to the outer curve) keeps its margin beyond
// this, so the visible green->brown coast is one smooth surface with no blocky tiles. Pure
// Laplacian relaxation of the corner ring shaves the single-tile teeth into a mean line; a small
// centroid-outward pad keeps legitimate green from being eaten while still cutting the tips.
let _groundClip=null,_groundClipKey='';
function computeGroundClip(z){
  const key=gridVersion+'_'+z.toFixed(4)+'_'+VW+'x'+VH+'_'+cam.x.toFixed(1)+'_'+cam.y.toFixed(1);
  if(_groundClip&&_groundClipKey===key) return _groundClip;
  if(_shoreRingsVer!==gridVersion) buildShoreRings();
  if(!_shoreRings||!_shoreRings.length){ _groundClip=null; _groundClipKey=key; return null; }
  let mainRing=_shoreRings[0]; for(const r of _shoreRings) if(r.length>mainRing.length) mainRing=r;
  const N=mainRing.length;
  let geo=mainRing.map(([tx,ty])=>{ const p=s2(tx,ty); return [p[0],p[1]]; });
  // relax the tile-corner staircase into a smooth mean line (shaves protruding diamond tips,
  // fills single-tile notches). Kept modest so headlands don't collapse inward.
  for(let pass=0;pass<7;pass++){ const nx=[];
    for(let i=0;i<N;i++){ const p0=geo[(i-1+N)%N],p1=geo[i],p2=geo[(i+1)%N];
      nx.push([(p0[0]+p1[0]*2+p2[0])/4,(p0[1]+p1[1]*2+p2[1])/4]); }
    geo=nx; }
  // small outward pad along the centroid normal: restores most of the green the relaxation
  // pulled in, so we trim the staircase without visibly shrinking the island.
  let cx=0,cy=0; for(const p of geo){ cx+=p[0]; cy+=p[1]; } cx/=N; cy/=N;
  const pad=TW*z*0.18;
  const out=geo.map(p=>{ const dx=p[0]-cx,dy=p[1]-cy,L=Math.hypot(dx,dy)||1;
    return [p[0]+dx/L*pad, p[1]+dy/L*pad]; });
  _groundClip=out; _groundClipKey=key; return out;
}
// Segment-intersection test (returns true if segment p1-p2 crosses p3-p4).
function _segsCross(p1,p2,p3,p4){
  const d1x=p2[0]-p1[0], d1y=p2[1]-p1[1], d2x=p4[0]-p3[0], d2y=p4[1]-p3[1];
  const denom=d1x*d2y-d1y*d2x; if(Math.abs(denom)<1e-9) return false;
  const t=((p3[0]-p1[0])*d2y-(p3[1]-p1[1])*d2x)/denom;
  const u=((p3[0]-p1[0])*d1y-(p3[1]-p1[1])*d1x)/denom;
  return t>0&&t<1&&u>0&&u<1;
}
// Scans a closed point loop for local self-intersections (within a window of WIN samples
// along the curve — true loops only ever form between nearby segments) and splices each one
// out by replacing the looped span with its two endpoints, collapsing the fold to a flat edge.
function removeLocalLoops(pts){
  const n=pts.length; if(n<6) return pts;
  const WIN=40;   // generous window — loops observed so far span well under this many samples
  const out=pts.slice();
  let changed=true, guard=0;
  while(changed && guard++<60){
    changed=false;
    for(let i=0;i<out.length;i++){
      const p1=out[i], p2=out[(i+1)%out.length];
      for(let d=2;d<WIN;d++){
        const j=(i+d)%out.length;
        const p3=out[j], p4=out[(j+1)%out.length];
        if(_segsCross(p1,p2,p3,p4)){
          // splice out everything strictly between p2 and p3 (inclusive of the loop interior),
          // bridging p1 directly to p4 — collapses the fold to a single clean edge.
          const removeSet=new Set();
          let kk=(i+1)%out.length;
          while(true){ removeSet.add(kk); if(kk===j)break; kk=(kk+1)%out.length; }
          const newPts=[];
          for(let m=0;m<out.length;m++){ if(!removeSet.has(m)) newPts.push(out[m]); }
          if(newPts.length>=6){ out.length=0; out.push(...newPts); changed=true; }
          break;
        }
      }
      if(changed) break;
    }
  }
  return out;
}
// Even-odd point-in-polygon test against a screen-space loop [[x,y],...]. Used to cull trees
// whose tile centre falls OUTSIDE the smooth shoreline curve — those tiles have their ground
// clipped away by clipGroundToShoreline (the curve dips inside the tile in tight bays / on thin
// spits), so a tree drawn there would hover over the bare void. Center-in-poll keeps every tree
// that still has ground under it and drops only the genuine floaters.
function _ptInPoly(x,y,poly){
  let inside=false;
  for(let i=0,j=poly.length-1;i<poly.length;j=i++){
    const xi=poly[i][0],yi=poly[i][1],xj=poly[j][0],yj=poly[j][1];
    if(((yi>y)!==(yj>y)) && (x < (xj-xi)*(y-yi)/((yj-yi)||1e-9)+xi)) inside=!inside;
  }
  return inside;
}
// Clips everything already painted into the ground buffer (every per-tile diamond fill drawn
// by drawTerrain) down to the smooth organic curve from computeSmoothShoreline. This is what
// actually removes the tile staircase from the visible silhouette — painting a soft wash
// UNDER the tiles (the old approach) can only ever show through the gaps between tile edges,
// never round off the tiles' own hard corners. Must run AFTER the full per-tile terrain pass
// and BEFORE compositeSoftGround reads from the ground buffer, on every buffer that holds
// per-tile fills (gBuf here; ground-only, leaves agents/buildings/wires untouched since those
// live in their own buffers composited later).
function clipGroundToShoreline(g,z){
  const sm=computeSmoothShoreline(z);
  if(!sm||sm.length<3) return;
  g.save(); g.setTransform(1,0,0,1,0,0);
  g.globalCompositeOperation='destination-in';
  g.beginPath();
  for(let i=0;i<sm.length;i++){ const[px,py]=sm[i]; if(i===0)g.moveTo(px,py); else g.lineTo(px,py); }
  g.closePath();
  // generous outward feather margin baked into the curve already (TW*z*1.05+ base offset in
  // computeSmoothShoreline), so a hard clip here still reads as a soft coastline because the
  // painted watercolor wash from paintShorelineMass sits just outside it and the grain/blur
  // compositing passes soften the cut further.
  g.fillStyle='#fff'; g.fill();
  g.globalCompositeOperation='source-over';
  g.restore();
}
function paintShorelineMass(g,z){
  if(_shoreRingsVer!==gridVersion) buildShoreRings();
  if(!_shoreRings||!_shoreRings.length)return;
  g.save();
  let mainRing=_shoreRings[0]; for(const r of _shoreRings) if(r.length>mainRing.length) mainRing=r;
  for(const ring of _shoreRings){
    if(ring!==mainRing) continue;   // CLEAN: only the island's outer silhouette; skip lake/river internal rings
    const sm0=computeSmoothShoreline(z);
    if(!sm0||sm0.length<3) continue;
    const sm=sm0.map(p=>[p[0],p[1],0]);
    const seedBase=(mainRing[0][0]*7+mainRing[0][1]*13)%97/97;

    // bbox + per-sample outward-normal vertical sign (centroid->point), reused below so the
    // hanging crags/drips appear ONLY on the bottom/front faces (ny_out>0) and the top edge
    // simply dissolves — an isometric island has its underbelly toward the viewer, never above.
    let minXs=1e9,maxXs=-1e9,minYs=1e9,maxYs=-1e9;
    for(const p of sm){ if(p[0]<minXs)minXs=p[0]; if(p[0]>maxXs)maxXs=p[0]; if(p[1]<minYs)minYs=p[1]; if(p[1]>maxYs)maxYs=p[1]; }

    // LAYER 2 — watercolor wash body: luminous desaturated stone at the lit top, pooling to a
    // deeper pigment base. Replaces the old flat slab so the mass reads as washed paper, not a
    // cut-out. Stays near-grayscale (Jomon earthy, muted) per the void colour philosophy.
    const trace=()=>{ g.beginPath(); for(let i=0;i<sm.length;i++){ const[px,py]=sm[i]; if(i===0)g.moveTo(px,py); else g.lineTo(px,py);} g.closePath(); };
    const wash=g.createLinearGradient(0,minYs,0,maxYs);
    wash.addColorStop(0,'rgba(108,128,72,1)'); wash.addColorStop(0.45,'rgba(92,112,62,1)');
    wash.addColorStop(0.72,'rgba(88,62,34,1)'); wash.addColorStop(0.86,'rgba(72,46,20,1)');
    wash.addColorStop(1,'rgba(50,30,10,1)');
    trace(); g.fillStyle=wash; g.fill();
    // pooled-pigment edge bloom: a fat dark stroke clipped inside the shape darkens only the rim
    g.save(); trace(); g.clip();
    g.lineWidth=Math.max(6,TW*z*0.5); g.strokeStyle='rgba(34,44,24,0.5)'; trace(); g.stroke();
    // LAYER 2b — granulation flecks (seeded, gravity-weighted to the base) for the watercolour tell
    g.fillStyle='rgba(40,52,28,0.5)'; const bw=maxXs-minXs, bh=maxYs-minYs, flecks=Math.min(260,Math.max(60,(bw*bh)/900|0));
    for(let f=0;f<flecks;f++){ const u=vhash(seedBase,f*1.7+3), v=Math.pow(vhash(seedBase,f*2.9+8),0.6);
      const fx2=minXs+u*bw, fy2=minYs+v*bh, r=(0.5+vhash(seedBase,f*3.3+5)*1.3)*z;
      g.globalAlpha=0.10+0.22*vhash(seedBase,f*4.1+1); g.beginPath(); g.arc(fx2,fy2,r,0,7); g.fill(); }
    g.globalAlpha=1; g.restore();

    // DIRECTIONAL UNDERSIDE has moved to paintUndersideCrags(), which runs AFTER
    // clipGroundToShoreline so its hanging crags are not clipped to the island footprint
    // (the bug that left only stubs reading as blocks ON the surface). Here we keep only the
    // in-footprint wash body + the brushed silhouette stroke.

    // single thin, uniform sumi-e silhouette — soft and brushed, never a hard staircase outline.
    g.lineWidth=1.1*z; g.lineCap='round';
    for(let i=0;i<sm.length;i++){ const[px,py]=sm[i];
      g.strokeStyle='rgba(34,32,44,'+(0.20+0.10*vhash(seedBase,i*7+19)).toFixed(3)+')';
      const[qx,qy]=sm[(i+1)%sm.length];
      g.beginPath(); g.moveTo(px,py); g.lineTo(qx,qy); g.stroke(); }
  }
  g.restore();
}
/* HANGING UNDERSIDE — drawn into the FINAL world buffer AFTER the ground has been clipped to
   the island silhouette, so these crags hang freely below the bottom/front edge into the void.
   Anchored to FIXED shore TILES (not the zoom-dependent smooth-shoreline sample array), so the
   crags stay locked to the same island locations at every zoom and never reshuffle. Only tiles
   whose SW (ty+1) or SE (tx+1) face meets the void qualify — those are the viewer-facing lower
   silhouette; back-edge tiles meet void on their NE/NW faces instead and get nothing, so the
   top/back simply dissolves. Each crag's SHAPE is seeded by (tx,ty) -> identical across zooms;
   only its screen position scales. Pure presentation; runs in screen space. */
function paintUndersideCrags(g,z){
  if(_shoreRingsVer!==gridVersion) buildShoreRings();
  const hw=TW/2*z, hh=TH/2*z, M=Math.max(TW,TH)*z;
  g.save(); g.setTransform(1,0,0,1,0,0);
  // island vertical screen bounds (from all shore tiles) -> a lower-half threshold so crags
  // only ever hang from the FRONT/LOWER silhouette; the top/back half stays perfectly clean.
  let bodyMinY=1e9, bodyMaxY=-1e9;
  for(let ty=0;ty<H;ty++)for(let tx=0;tx<W;tx++){ const c=grid[ty][tx];
    if(c.ter===WATER||!c.shore)continue; const sy=cam.y+(tx+ty)*(TH/2)*z;
    if(sy<bodyMinY)bodyMinY=sy; if(sy>bodyMaxY)bodyMaxY=sy; }
  const lowerGate=bodyMinY+(bodyMaxY-bodyMinY)*0.46;   // keep only the lower ~54% of the island
  // gather qualifying front-edge tiles (stable per-tile gate -> clustered, not a dense fence)
  const fronts=[];
  for(let ty=0;ty<H;ty++)for(let tx=0;tx<W;tx++){
    const c=grid[ty][tx];
    if(c.ter===WATER || !c.shore) continue;
    // The tile DIRECTLY BELOW on screen is (tx+1,ty+1) (screen-down = +tx,+ty). Only hang crags
    // where that is void — i.e. the genuine lower/front silhouette with open void beneath.
    if(!isVoidFace(tx+1,ty+1)) continue;
    const[ccx,ccy]=s2(tx,ty);
    const by=ccy+hh;
    if(by < lowerGate) continue;                                 // suppress the entire upper/back half
    if(vhash(tx*0.137+3.1, ty*0.291+7.3) > 0.45) continue;       // ~45% kept, tile-stable
    if(ccx<-M*3||ccx>VW+M*3||ccy<-M*3||ccy>VH+M*8) continue;
    fronts.push({tx,ty, bx:ccx, by, s:vhash(tx*1.7+1, ty*2.3+2)});  // anchor at tile's bottom corner
  }
  // depth order: farther (higher on screen) first, so nearer crags overlap correctly
  fronts.sort((a,b)=>a.by-b.by);

  for(const ft of fronts){
    const {bx,by,s}=ft;
    const depth=M*(0.7+1.7*s);
    // 1) local soft contact shadow hanging just under this edge tile, fading to void
    const cg=g.createLinearGradient(0,by-hh*0.4,0,by+depth);
    cg.addColorStop(0,'rgba(14,18,8,0)'); cg.addColorStop(0.3,'rgba(14,18,8,0.34)');
    cg.addColorStop(0.75,'rgba(8,11,5,0.16)'); cg.addColorStop(1,'rgba(4,6,3,0)');
    g.fillStyle=cg; g.beginPath();
    g.ellipse(bx, by+depth*0.32, hw*1.25, depth*0.42, 0, 0, 7); g.fill();

    // 2) jagged rocky stalactites hanging straight down into the void
    const spires=2+((s*3)|0);                        // 2-4 sub-spires per cluster
    for(let k=0;k<spires;k++){
      const fo=vhash(s,k*17.3+1);
      const ox=(fo*2-1)*hw*0.8;
      const oy=vhash(s,k*13.1+4)*hh*0.5;
      const fw=hw*(0.22+0.34*vhash(s,k*11.3+9));
      const fd=depth*(0.5+0.55*vhash(s,k*9.7+4));
      const ax=bx+ox, ay=by+oy;                      // attaches AT the bottom edge, hangs DOWN
      g.beginPath();
      g.moveTo(ax-fw, ay);
      const lx1=ax-fw*(0.8+0.18*vhash(s,k*23+5)), ly1=ay+fd*0.28;
      const lx2=ax-fw*(0.4+0.2*vhash(s,k*29+6)),  ly2=ay+fd*0.66;
      const tipX=ax+(vhash(s,k*37+7)*2-1)*fw*0.5,  tipY=ay+fd;
      const rx2=ax+fw*(0.4+0.2*vhash(s,k*41+8)),   ry2=ay+fd*0.66;
      const rx1=ax+fw*(0.8+0.18*vhash(s,k*47+9)),  ry1=ay+fd*0.28;
      g.bezierCurveTo(lx1,ly1,lx2,ly2,tipX,tipY);
      g.bezierCurveTo(rx2,ry2,rx1,ry1,ax+fw,ay);
      g.closePath();
      const ig=g.createLinearGradient(0,ay,0,ay+fd);
      ig.addColorStop(0,'rgba(40,46,26,0.92)'); ig.addColorStop(0.45,'rgba(24,30,16,0.6)'); ig.addColorStop(0.8,'rgba(12,16,8,0.28)'); ig.addColorStop(1,'rgba(6,8,4,0)');
      g.fillStyle=ig; g.globalAlpha=0.65+0.3*vhash(s,k*53+2); g.fill();
      // jagged fracture seam for stony texture
      g.strokeStyle='rgba(8,12,4,0.4)'; g.lineWidth=0.6*z; g.lineCap='round';
      g.beginPath(); g.moveTo(ax+(vhash(s,k*61+1)*2-1)*fw*0.3, ay+fd*0.1);
      g.lineTo(ax+(vhash(s,k*67+2)*2-1)*fw*0.25, ay+fd*0.55);
      g.lineTo(tipX, ay+fd*0.92); g.stroke();
      // faint cool moon-rim catch on the spire's upper-left
      g.strokeStyle='rgba(150,168,120,0.16)'; g.lineWidth=0.8*z;
      g.beginPath(); g.moveTo(ax-fw*0.7,ay+fd*0.04); g.bezierCurveTo(lx1,ly1,lx2,ly2,tipX,tipY); g.stroke();
    }
    g.globalAlpha=1;
  }
  g.restore();
}
/* FLOATING-ISLAND CLIFF (Master Spec §10) — one continuous painterly earth-rock wall hung from
   the smooth outer shoreline curve, replacing the old jagged per-tile stalactite crags. The wall
   thickness is driven by each sample's OUTWARD-NORMAL vertical component, so it only grows on the
   front/lower silhouette (normal points toward the viewer, +y) and tapers smoothly to nothing on
   the side flanks and back, where the edge simply dissolves — isometrically correct for a slab of
   land seen from above. Painted as vertical watercolour ribbon strips so it fades cleanly into the
   void at the bottom regardless of local height, with sumi-e strata seams, granulation flecks, a
   light-catching soil lip, and a soft contour — the locked 3-layer style. Screen-space, drawn into
   the world buffer AFTER the ground composite, so it hangs freely below the clipped island edge. */
function paintIslandCliff(g,z){
  const sm=computeSmoothShoreline(z);
  if(!sm||sm.length<8)return;
  const N=sm.length;
  // winding sign of the smoothed screen-space curve (y grows downward) -> consistent outward normal
  let shoelace=0; for(let i=0;i<N;i++){ const a=sm[i],b=sm[(i+1)%N]; shoelace+=a[0]*b[1]-b[0]*a[1]; }
  const cw=shoelace<0;
  // Pan-invariant detail seed from the main ring's TILE coordinates. The old seed read sm[0],
  // which is a SCREEN point — it shifts every time the camera pans, so the seed (and therefore
  // every seeded fracture, granulation fleck, strata dry-brush gap and moss dab) was reshuffled
  // on each frame while moving the map, making the whole rim shimmer/jiggle. Tile coords are fixed
  // in world space, so the cliff detail now stays locked to the coastline across pans. (Matches the
  // seedBase used by computeSmoothShoreline / paintShorelineMass.)
  let _mr=(_shoreRings&&_shoreRings.length)?_shoreRings[0]:null;
  if(_mr) for(const r of _shoreRings) if(r.length>_mr.length) _mr=r;
  const seed=_mr ? ((_mr[0][0]*7+_mr[0][1]*13)%97)/97 : 0.371;
  const baseH=Math.max(9, TH*z*1.62);           // cliff drop on the fully front-facing edge — deeper slab so the island reads as a floating mass, not a thin rim ribbon
  // per-sample geometry: outward normal, front factor, organic (low-freq, non-jagged) wall height
  const nrm=[], hgt=[], curv=[];
  for(let i=0;i<N;i++){
    const a=sm[(i-1+N)%N], b=sm[(i+1)%N];
    let tx=b[0]-a[0], ty=b[1]-a[1]; const L=Math.hypot(tx,ty)||1e-4; tx/=L; ty/=L;
    const nx=cw?-ty:ty, ny=cw?tx:-tx;            // outward normal — same rotation as computeSmoothShoreline
    let f=(ny-0.03)/0.52; f=Math.max(0,Math.min(1,f)); f=f*f*(3-2*f);   // front-face smoothstep gate
    const u=i/N;                                  // smooth large-scale undulation so the underbelly waves gently
    const w1=vhash(seed,Math.floor(u*7)*1.3+2)*2-1, w2=vhash(seed,Math.floor(u*7)*1.3+3.3)*2-1;
    const wave=w1+(w2-w1)*((u*7)%1);
    // signed curvature (cross of incoming/outgoing unit tangents): +convex headland bulging
    // outward, -concave recess. Drives the buttress light/shadow and where the deep separating
    // crevices fall, so the flat curtain reads as a run of rounded rock masses.
    const pc=sm[i];
    let t1x=pc[0]-a[0],t1y=pc[1]-a[1]; const l1=Math.hypot(t1x,t1y)||1e-4; t1x/=l1; t1y/=l1;
    let t2x=b[0]-pc[0],t2y=b[1]-pc[1]; const l2=Math.hypot(t2x,t2y)||1e-4; t2x/=l2; t2y/=l2;
    let cr=t1x*t2y-t1y*t2x; if(cw)cr=-cr;
    nrm.push([nx,ny]); hgt.push(baseH*f*(0.74+0.40*(wave*0.5+0.5))); curv.push(cr);
  }
  // smooth curvature a touch so buttresses read as broad rounded masses, not per-sample noise
  { const c2=curv.slice(); for(let i=0;i<N;i++){ const p=curv[(i-1+N)%N],q=curv[i],r=curv[(i+1)%N]; c2[i]=(p+q*2+r)/4; } for(let i=0;i<N;i++)curv[i]=c2[i]; }
  g.save(); g.setTransform(1,0,0,1,0,0); g.lineJoin='round'; g.lineCap='round';
  const drift=h0=>0;  // (placeholder kept minimal — wall drops vertically; perspective drift below)
  const botPt=i=>[ sm[i][0]+nrm[i][0]*hgt[i]*0.10, sm[i][1]+hgt[i] ];   // slight outward lean for depth
  // ---- LAYER 2 (watercolour wash): each front strip filled top->void with an earth-rock gradient.
  // Two modulations stack on the base earth tone: (1) a seeded low-frequency warm/cool walk along
  // the wall length so it reads as varied strata rather than one slab; (2) DIRECTIONAL isometric
  // light from the per-strip outward-normal — faces turned toward the upper-left moon (normal points
  // left, nax<0) catch a cool, lifted highlight; faces turned away (right/SE, nax>0) sink into warm
  // shadow. That facing-based value split is what makes the rim read as a solid 3-D slab edge with
  // real volume instead of a flat brown band. The dissolve tail is long and low-opacity so the wall
  // melts into the void (Master Spec §10) rather than stopping on a hard line.
  const RGB=(r,g2,b,a)=>'rgba('+(r|0)+','+(g2|0)+','+(b|0)+','+a+')';
  for(let i=0;i<N;i++){ const j=(i+1)%N; if(hgt[i]<0.6&&hgt[j]<0.6)continue;
    const A=sm[i], B=sm[j], Ab=botPt(i), Bb=botPt(j);
    const topY=Math.min(A[1],B[1]), botY=Math.max(Ab[1],Bb[1]);
    const u=i/N; const t1=vhash(seed,Math.floor(u*9)*1.9+4), t2=vhash(seed,Math.floor(u*9)*1.9+5.9);
    const tone=(t1+(t2-t1)*((u*9)%1))*2-1;        // -1 cool stone .. +1 warm soil
    const wm=tone*9;                               // warm/cool red-channel push
    const cm=tone*6;                               // green follows a little
    // directional light: nax<0 -> face turned to the upper-left moon (lit), nax>0 -> shadowed
    const nax=(nrm[i][0]+nrm[j][0])*0.5; const lit=Math.max(-1,Math.min(1,-nax));
    // buttress volume: convex headlands (cv>0) bulge toward the moon and lift; concave recesses
    // (cv<0) sink into shadow — this is what turns the flat curtain into rounded rock masses.
    const cv=Math.max(-1,Math.min(1,(curv[i]+curv[j])*0.5*7));
    const vd=lit*20 + cv*16;                       // value split: facing + buttress, stronger rounded-rock read
    const lr=vd, lg=vd+lit*2+cv*2, lb=vd+lit*9+cv*6;    // gentle cool (blue) bias toward lit/convex
    const wg=g.createLinearGradient(0,topY,0,botY===topY?topY+1:botY);
    wg.addColorStop(0.00,RGB(116+wm+lr,99+cm+lg,68+lb, 1));     // soil lip just under the grass
    wg.addColorStop(0.16,RGB(97+wm+lr*0.85, 78+cm+lg*0.85,52+lb*0.85, 1)); // upper earth
    wg.addColorStop(0.44,RGB(74+wm*0.7+lr*0.6,58+cm*0.6+lg*0.6,40+lb*0.6, 1)); // umber body
    wg.addColorStop(0.70,RGB(48+wm*0.4+lr*0.38,42+lg*0.38,35+lb*0.38, 0.98));  // cool damp rock
    wg.addColorStop(0.88,RGB(28,24,28, 0.62));            // shadowed base
    wg.addColorStop(0.95,RGB(19,16,23, 0.28));            // long fade
    wg.addColorStop(1.00,RGB(14,12,20, 0));               // dissolves into the void
    g.fillStyle=wg; g.beginPath(); g.moveTo(A[0],A[1]); g.lineTo(B[0],B[1]); g.lineTo(Bb[0],Bb[1]); g.lineTo(Ab[0],Ab[1]); g.closePath(); g.fill();
  }
  // moonlight catch on the convex buttress shoulders — a soft cool sheen on the upper wall of
  // headlands that bulge toward the upper-left moon, so the rounded rock masses lift out of the
  // night. Skipped on shadowed/concave samples so recesses stay dark (that contrast IS the volume).
  for(let i=0;i<N;i++){ const j=(i+1)%N; if(hgt[i]<baseH*0.4||hgt[j]<baseH*0.4)continue;
    const nax=(nrm[i][0]+nrm[j][0])*0.5; const lit=Math.max(0,-nax);
    const cvx=Math.max(0,(curv[i]+curv[j])*0.5*7);
    const m=Math.min(1,lit*cvx*1.7); if(m<0.05)continue;
    const aB=[sm[i][0]+nrm[i][0]*0.04*hgt[i], sm[i][1]+hgt[i]*0.42];
    const bB=[sm[j][0]+nrm[j][0]*0.04*hgt[j], sm[j][1]+hgt[j]*0.42];
    const mg=g.createLinearGradient(0,Math.min(sm[i][1],sm[j][1]),0,Math.max(aB[1],bB[1]));
    mg.addColorStop(0,'rgba(150,164,152,'+(0.06+0.21*m).toFixed(3)+')');
    mg.addColorStop(0.5,'rgba(142,156,150,'+(0.03+0.10*m).toFixed(3)+')');
    mg.addColorStop(1,'rgba(142,156,150,0)');
    g.fillStyle=mg; g.beginPath(); g.moveTo(sm[i][0],sm[i][1]); g.lineTo(sm[j][0],sm[j][1]);
    g.lineTo(bB[0],bB[1]); g.lineTo(aB[0],aB[1]); g.closePath(); g.fill();
  }
  // band clip path (top forward, bottom back) for strata + granulation that must stay on the wall
  const band=()=>{ g.beginPath();
    let started=false; for(let i=0;i<N;i++){ if(hgt[i]<0.6)continue; if(!started){g.moveTo(sm[i][0],sm[i][1]);started=true;} else g.lineTo(sm[i][0],sm[i][1]); }
    for(let i=N-1;i>=0;i--){ if(hgt[i]<0.6)continue; const p=botPt(i); g.lineTo(p[0],p[1]); }
    g.closePath(); };
  g.save(); band(); g.clip();
  // LAYER 2b — granulation flecks, gravity-weighted toward the damp base (the watercolour tell)
  let bMinX=1e9,bMaxX=-1e9,bMinY=1e9,bMaxY=-1e9;
  for(let i=0;i<N;i++){ if(hgt[i]<0.6)continue; const p=botPt(i);
    bMinX=Math.min(bMinX,sm[i][0],p[0]); bMaxX=Math.max(bMaxX,sm[i][0],p[0]);
    bMinY=Math.min(bMinY,sm[i][1]); bMaxY=Math.max(bMaxY,p[1]); }
  if(bMaxX>bMinX){ const bw=bMaxX-bMinX, bh=bMaxY-bMinY, flk=Math.min(360,Math.max(60,(bw*bh)/700|0));
    g.fillStyle='rgba(28,21,13,0.5)';
    for(let f=0;f<flk;f++){ const u=vhash(seed,f*1.7+11), v=Math.pow(vhash(seed,f*2.9+5),0.55);
      const fx=bMinX+u*bw, fy=bMinY+v*bh, r=(0.4+vhash(seed,f*3.3+2)*1.2)*z;
      g.globalAlpha=0.08+0.20*vhash(seed,f*4.1+7); g.beginPath(); g.arc(fx,fy,r,0,7); g.fill(); }
    g.globalAlpha=1; }
  // LAYER 1b — vertical erosion fractures: seeded dry-brush channels running DOWN the wall from
  // the top lip, each a dark cut paired with a hair lit edge just beside it. These give the rock
  // face genuine fracture/weathering texture (the "realistic cliff" tell) and break up the smooth
  // gradient bands into carved stone. Sparse + seeded so they stay anchored across rebuilds; only
  // on samples with real wall height, deepening with the local drop.
  // LAYER 1b — erosion fractures, two kinds, IRREGULARLY spaced so the wall reads as weathered
  // rock rather than a regular palisade: occasional DEEP crevices that bite in at the concave
  // recesses (separating the buttress masses), plus scattered fine hairline cracks. A low-freq
  // seeded gate clusters them unevenly instead of seeding every-Nth sample. Each cut is paired
  // with a hair lit edge just beside it so it reads as a raised rock rib catching the moon.
  for(let i=0;i<N;i++){ if(hgt[i]<baseH*0.34)continue;
    const cluster=vhash(seed,Math.floor(i/3)*1.7+31);                      // ~3 samples share a gate -> uneven runs
    const major = curv[i]<-0.012 && vhash(seed,i*0.91+5)<0.5;              // deep crevice at a concave recess
    const minor = cluster<0.30 && vhash(seed,i*0.53+13)<0.45;              // scattered hairline crack
    if(!major&&!minor)continue;
    const deep = major?(0.55+0.40*vhash(seed,i*1.9+4)):(0.22+0.34*vhash(seed,i*1.9+4));
    const dep=hgt[i]*deep;
    const lean=nrm[i][0]*0.12 + (vhash(seed,i*2.7+8)*2-1)*0.06;            // slight outward + jitter, not dead-straight
    const x0=sm[i][0], y0=sm[i][1];
    const mx=x0+lean*dep*0.5+(vhash(seed,i*5.1+6)*2-1)*1.6*z, my=y0+dep*0.55;
    const ex=x0+lean*dep+(vhash(seed,i*7.7+9)*2-1)*1.2*z, ey=y0+dep;       // wandering tip
    const da=major?(0.40+0.26*vhash(seed,i*3.1+2)):(0.20+0.18*vhash(seed,i*3.1+2));
    g.strokeStyle='rgba(18,13,10,'+da.toFixed(3)+')';
    g.lineWidth=((major?1.4:0.6)+0.7*vhash(seed,i*4.3+1))*z; g.beginPath();
    g.moveTo(x0,y0); g.quadraticCurveTo(mx,my, ex,ey); g.stroke();
    g.strokeStyle='rgba(156,146,112,'+((major?0.16:0.09)+0.10*vhash(seed,i*6.7+3)).toFixed(3)+')';
    g.lineWidth=(major?0.9:0.55)*z; g.beginPath();
    g.moveTo(x0-1.0*z,y0); g.quadraticCurveTo(mx-1.0*z,my, ex-1.0*z,ey); g.stroke();
  }
  // sumi-e strata seams — thin broken horizontal ink following the wall at three depths, each
  // shadowed seam paired with a faint lit ledge just below it so the wall reads as layered rock.
  for(const[frac,al] of [[0.34,0.34],[0.58,0.27],[0.80,0.20]]){
    for(const[off,col,wmul] of [[0,'rgba(30,23,14,', 1.0],[0.045,'rgba(150,134,96,', 0.55]]){
      let pen=false;
      for(let i=0;i<N;i++){ if(hgt[i]<6){pen=false;continue;}
        const fr=frac+off;
        const x=sm[i][0]+nrm[i][0]*hgt[i]*0.10*fr, y=sm[i][1]+hgt[i]*fr;
        if(vhash(seed,i*0.7+fr*13)>0.82){pen=false;continue;}   // dry-brush gaps
        if(!pen){ g.beginPath(); g.moveTo(x,y); pen=true; } else g.lineTo(x,y);
        if(((i+1)%N===0)||hgt[(i+1)%N]<6){ g.strokeStyle=col+(al*wmul).toFixed(3)+')'; g.lineWidth=(0.8+0.5*frac)*z; g.stroke(); pen=false; }
      }
      g.strokeStyle=col+(al*wmul).toFixed(3)+')'; g.lineWidth=(0.8+0.5*frac)*z; g.stroke();
    }
  }
  g.restore();
  // mossy roots spilling just over the top lip — short green dabs where grass meets the wall,
  // only on the front faces, sparse and seeded so they cling to the same spots every rebuild.
  for(let i=0;i<N;i++){ if(hgt[i]<baseH*0.45)continue; if(vhash(seed,i*1.3+21)>0.30)continue;
    const x=sm[i][0], y=sm[i][1], dl=hgt[i]*(0.10+0.16*vhash(seed,i*2.1+6));
    g.strokeStyle='rgba(86,104,58,'+(0.34+0.18*vhash(seed,i*3.7+2)).toFixed(3)+')'; g.lineWidth=(1.1+0.8*vhash(seed,i*1.9+9))*z; g.lineCap='round';
    g.beginPath(); g.moveTo(x,y-1*z); g.lineTo(x+nrm[i][0]*dl*0.3,y+dl); g.stroke(); }
  // LAYER 1 (sumi-e) — soft contour along the hanging underside lip, brushed not hard
  for(let i=0;i<N;i++){ const j=(i+1)%N; if(hgt[i]<6||hgt[j]<6)continue; const a=botPt(i),b=botPt(j);
    g.strokeStyle='rgba(22,18,24,'+(0.16+0.12*vhash(seed,i*5+3)).toFixed(3)+')'; g.lineWidth=1.0*z;
    g.beginPath(); g.moveTo(a[0],a[1]); g.lineTo(b[0],b[1]); g.stroke(); }
  // crisp contact shadow where the overhanging sod lip meets the rock — a thin dark line a hair
  // below the top edge so the grass reads as jutting OUT over the wall, not a muddy gradient.
  for(let i=0;i<N;i++){ const j=(i+1)%N; if(hgt[i]<4&&hgt[j]<4)continue;
    const sh=Math.min(1,(hgt[i]/baseH)*1.5);
    g.strokeStyle='rgba(26,20,12,'+(0.34*sh).toFixed(3)+')'; g.lineWidth=2.0*z;
    g.beginPath(); g.moveTo(sm[i][0]+nrm[i][0]*1.2*z, sm[i][1]+hgt[i]*0.05+1.5*z);
    g.lineTo(sm[j][0]+nrm[j][0]*1.2*z, sm[j][1]+hgt[j]*0.05+1.5*z); g.stroke(); }
  // light-catching soil lip where the wall meets the grass — cool moon (upper-left) to warm dusk (lower-right)
  if(bMaxX>bMinX){ for(let i=0;i<N;i++){ const j=(i+1)%N; if(hgt[i]<4&&hgt[j]<4)continue;
    const tX=(sm[i][0]-bMinX)/(bMaxX-bMinX||1);
    const cr=Math.round(150+ tX*16), cg=Math.round(162-tX*34), cb=Math.round(176-tX*92);
    const f=Math.min(1,(hgt[i]/baseH)*1.4);
    g.strokeStyle='rgba('+cr+','+cg+','+cb+','+(0.20*f).toFixed(3)+')'; g.lineWidth=1.3*z;
    g.beginPath(); g.moveTo(sm[i][0],sm[i][1]); g.lineTo(sm[j][0],sm[j][1]); g.stroke(); } }
  // soft contact glow seating the mass in the void, just beneath the deepest front edge
  g.globalCompositeOperation='multiply';
  for(let i=0;i<N;i+=2){ if(hgt[i]<baseH*0.4)continue; const p=botPt(i);
    const gr=g.createRadialGradient(p[0],p[1],0,p[0],p[1],TH*z*2.0);
    gr.addColorStop(0,'rgba(8,7,12,0.30)'); gr.addColorStop(1,'rgba(8,7,12,0)');
    g.fillStyle=gr; g.beginPath(); g.arc(p[0],p[1],TH*z*2.0,0,7); g.fill(); }
  g.globalCompositeOperation='source-over';
  g.restore();
}
function rebuildWorld(){ const z=cam.zoom;
  { const _P=VOID?AGEPAL[0]:agePal(); TJIT = _P.dry>0.3 ? 0.6 : (_P.wet>=0.9 ? 1.1 : 0.85); }
  ensureGroundBuffers(); ensureWorldBuffer();
  wctx.setTransform(1,0,0,1,0,0); wctx.clearRect(0,0,wBuf.width,wBuf.height);
  // ground pass -> offscreen, then blurred into the world buffer
  gctx.setTransform(DPR,0,0,DPR,0,0); gctx.clearRect(0,0,VW,VH);
  paintShorelineMass(gctx,z);
  // Confine the per-tile ground fills to the TIGHT smooth footprint curve so the green surface
  // ends on a clean organic edge — the protruding diamond tips that read as "blocky tiles" at
  // the green/brown coast are clipped away. The brown wash (painted just above, to the wider
  // outer curve) stays UNCLIPPED beyond this, so the coast remains one continuous painted
  // surface with no staircase. Restored after the tile loop.
  const _gc=computeGroundClip(z);
  gctx.save();
  if(_gc&&_gc.length>=3){ gctx.beginPath();
    for(let i=0;i<_gc.length;i++){ const[px,py]=_gc[i]; if(i===0)gctx.moveTo(px,py); else gctx.lineTo(px,py); }
    gctx.closePath(); gctx.clip();
    // GREEN SURFACE MASS — fills the coastal VOID-water tiles (which draw nothing in VOID mode and
    // otherwise let the brown coastal wash show THROUGH the surface as a diamond staircase). With
    // this, the brown wash reads only as a smooth band OUTSIDE this curve, so the green->brown
    // coast is one clean surface. Matches the wash's green stops so it blends seamlessly with the
    // per-tile grass drawn on top. Confined to the clip, so it never bleeds past the smooth edge.
    let _gmnY=1e9,_gmxY=-1e9; for(const p of _gc){ if(p[1]<_gmnY)_gmnY=p[1]; if(p[1]>_gmxY)_gmxY=p[1]; }
    const _gg=gctx.createLinearGradient(0,_gmnY,0,_gmxY);
    _gg.addColorStop(0,'rgb(110,130,74)'); _gg.addColorStop(1,'rgb(92,112,62)');
    gctx.fillStyle=_gg; gctx.fillRect(0,0,VW,VH);
  }
  for(let sum=0;sum<=W+H-2;sum++)for(let ty=0;ty<H;ty++){const tx=sum-ty;if(tx<0||tx>=W)continue;
    const c=grid[ty][tx],[cx,cy]=s2(tx,ty);
    if(cx<-TW*z||cx>VW+TW*z||cy<-TH*z*6||cy>VH+TH*z*2)continue;
    drawTerrain(gctx,tx,ty,c,cx,cy,z,fx);
    if(c.road)drawRoad(gctx,tx,ty,cx,cy,z,c.br);
    if(c.civ===PARK)drawPark(gctx,cx,cy,z);
    if(S.overlay&&valueGrid&&(c.zone||c.civ)){ diamondPath(gctx,cx,cy,z); gctx.fillStyle=valColor(valueGrid[ty][tx]); gctx.fill(); }
  }
  drawSpiritWaterBody(gctx,z,fx);
  gctx.restore();
  // Cut every per-tile diamond fill in the ground buffer down to the smooth organic curve
  // computed above. The wash painted by paintShorelineMass already sits just outside this
  // same curve, so the visible coastline is now the curve itself — tile corners no longer
  // peek through past it (Master Spec §10: smooth organic coastline).
  clipGroundToShoreline(gctx,z);
  compositeSoftGround(wctx);
  // FLOATING-ISLAND CLIFF: one continuous painterly earth-rock wall hung from the smooth outer
  // shoreline, drawn into the final world buffer below the now-clipped island edge so it falls
  // freely into the void. Replaces the old jagged per-tile stalactite crags (which read as ugly
  // artifacts). Thickness is gated by the outward-normal so the wall lives only on the front/lower
  // silhouette and dissolves on the back/flanks — isometrically correct (Master Spec §10).
  paintIslandCliff(wctx,z);
  // DISTANT SILHOUETTE: when zoomed out, wrap the whole landmass in one soft ink contour +
  // faint glow so it reads as a single dramatic floating mass rather than a field of tiny
  // tile facets. Traced once from the already-computed shore tiles, drawn under the grain.
  if(z<LOD_Z) paintLandmassSilhouette(wctx,z);
  // ground-tooth grain (static, over the soft ground)
  if(!GRAINPAT)GRAINPAT=wctx.createPattern(GRAIN,'repeat');
  wctx.save();wctx.setTransform(DPR,0,0,DPR,0,0);wctx.globalCompositeOperation='soft-light';wctx.globalAlpha=S.era<=1?0.16:0.10;wctx.fillStyle=GRAINPAT;wctx.fillRect(0,0,VW,VH);wctx.restore();
  // wires (static)
  wctx.setTransform(DPR,0,0,DPR,0,0);
  for(let sum=0;sum<=W+H-2;sum++)for(let ty=0;ty<H;ty++){const tx=sum-ty;if(tx<0||tx>=W)continue;
    if(grid[ty][tx].wire){const[cx,cy]=s2(tx,ty); if(cx>-TW*z&&cx<VW+TW*z&&cy>-TH*z*4&&cy<VH+TH*z*2)drawWire(wctx,tx,ty,cx,cy,z);} }
  // NOTE: trees/ruins/buildings/civics are NO LONGER baked here. They draw every frame
  // in render()'s unified depth pass, interleaved with agents, so occlusion stays correct.
  // wBuf holds only the flat, always-behind base (ground + roads + wires) — safe to cache.
  _wkey=worldKey();
}

function render(){ ctx.setTransform(DPR,0,0,DPR,0,0);
  const z=cam.zoom, sc=skyNow();
  LOD = z < LOD_Z;   // overview -> silhouette forms + lighter ink for this frame
  let _shx=0,_shy=0;
  // 1) sky + celestial (dynamic, cheap)
  if(VOID){ paintVoid(ctx); }
  else { const sky=ctx.createLinearGradient(0,0,0,VH); sky.addColorStop(0,sc.top);sky.addColorStop(1,sc.bot); ctx.fillStyle=sky; ctx.fillRect(0,0,VW,VH); }
  drawCelestial();
  // 2) cached static world — rebuilt only when the view changes
  if(worldKey()!==_wkey) rebuildWorld();
  ctx.setTransform(1,0,0,1,0,0); ctx.drawImage(wBuf,0,0); ctx.setTransform(DPR,0,0,DPR,0,0);
  // 3) dynamic atmosphere over the ground
  if(S.era<=1) paintLandmassEarly(ctx);   // drifting dappled cloud light
  if(!VOID) drawFog();
  // hover highlight (follows cursor)
  if(hover&&inB(hover[0],hover[1])&&!S.hand){ const[cx,cy]=s2(hover[0],hover[1]); const c=grid[hover[1]][hover[0]];
    let ok=true; if(S.demo)ok=(c.zone||c.civ||c.road||c.wire); else if(S.douse)ok=c.burn>0;
    else if(S.tool){ if(S.tool.road)ok=isLand(hover[0],hover[1])&&!mountain(c)&&!c.civ&&!c.zone; else if(S.tool.wire)ok=c.road||(!occupied(c)&&isLand(hover[0],hover[1])); else ok=isLand(hover[0],hover[1])&&!mountain(c)&&!occupied(c); }
    diamondPath(ctx,cx,cy,z); ctx.fillStyle=ok?'rgba(243,227,168,0.32)':'rgba(200,60,40,0.32)'; ctx.fill();
    ctx.strokeStyle=ok?'#f3e3a8':'#c83828'; ctx.lineWidth=2; ctx.stroke(); }
  // 4) UNIFIED depth-sorted form pass. Trees, ruins, buildings, civics AND agents are
  //    drawn together, ordered by depth (tx+ty), into one buffer and inked once. Because
  //    everything 3-D shares a single painter's pass, occlusion is always correct — an
  //    agent behind a form is hidden, an agent in front draws over it, with no special
  //    cases and nothing to re-stamp (so no flicker). Agents use fractional depth, so
  //    they interleave even mid-tile. Flat ground/roads/wires stay cached in wBuf above.
  // ground litter — under the crowd, painted straight to the frame
  { const lit=[]; for(const p of decay) if(p.kind!=='prop') lit.push(p); lit.sort((a,b)=>(a.x+a.y)-(b.x+b.y));
    for(const p of lit){ const[lcx,lcy]=s2(p.x,p.y); if(lcx<-60||lcx>VW+60||lcy<-60||lcy>VH+60)continue; drawLitter(ctx,lcx,lcy,z,p); } }
  // ground blood pools — also under the crowd (flat paint on the ground, not a raised form), so agents
  // and buildings standing on/near a stain draw on top of it instead of it floating over everyone.
  // Was previously drawn in drawViolenceFX() AFTER the unified agent pass, which always painted it
  // on top regardless of depth — moved here to match the litter pre-pass pattern exactly.
  for(const s of stains){ const[scx,scy]=s2(s.x,s.y); if(scx<-90||scx>VW+90||scy<-90||scy>VH+90)continue; drawStain(ctx,scx,scy,z,s); }
  const acts=[];
  // VISIBLE-ONLY CULLING. s2 is linear, so invert the exact draw-cull window into a
  // tile range and scan only the on-screen anti-diagonal band instead of all W*H tiles.
  // Margins below mirror the per-object cull (cy up to 10 rows above / 2 below; cx 2
  // cols each side) so tall buildings whose anchor sits just off-screen are still caught.
  // Smooth shoreline curve (cached): trees whose tile centre falls outside it sit over void
  // (their ground was clipped away by clipGroundToShoreline) and must not be drawn floating.
  const _shorePoly = computeSmoothShoreline(z);
  { const hx=(TW/2)*z, hy=(TH/2)*z;
    let sLo=Math.floor((-TH*z*10 - cam.y)/hy), sHi=Math.ceil((VH+TH*z*2 - cam.y)/hy);   // tx+ty range
    let dLo=Math.floor((-TW*z*2  - cam.x)/hx), dHi=Math.ceil((VW+TW*z*2 - cam.x)/hx);    // tx-ty range
    if(sLo<0)sLo=0; if(sHi>W+H-2)sHi=W+H-2;
    for(let S=sLo;S<=sHi;S++){
      let txLo=Math.ceil((S+dLo)/2), txHi=Math.floor((S+dHi)/2);
      if(txLo<0)txLo=0; if(txHi>W-1)txHi=W-1;
      for(let tx=txLo;tx<=txHi;tx++){ const ty=S-tx; if(ty<0||ty>=H)continue;
        const c=grid[ty][tx];
        if(c.ter===FOREST&&!occupied(c)&&!c.civ){
          if(!_shorePoly){ acts.push({tx,ty,k:'tree',d:S}); }
          else { const[_tcx,_tcy]=s2(tx,ty); if(_ptInPoly(_tcx,_tcy,_shorePoly)) acts.push({tx,ty,k:'tree',d:S}); }
        }
        if(c.ruin)acts.push({tx,ty,k:'ruin',c,d:S});
        else if(c.zone)acts.push({tx,ty,k:'z',c,d:S});
        if(c.civ===FARM)acts.push({tx,ty,k:'farm',c,d:S});
        else if(c.civ&&c.civ!==PARK)acts.push({tx,ty,k:'c',civ:c.civ,d:S}); } } }
  for(const u of traffic){ if(u.claimed)continue; acts.push({tx:u.wx,ty:u.wy,k:'a',a:u,d:u.wx+u.wy}); }
  for(const u of residents){ if(u.claimed)continue; acts.push({tx:u.x,ty:u.y,k:'a',a:u,d:u.x+u.y}); }
  for(const h of farmHands) acts.push({tx:h.x,ty:h.y,k:'a',a:h,d:h.x+h.y});
  for(const e of encounters)for(const m of e.mob) if(m.state!=='down') acts.push({tx:m.x,ty:m.y,k:'a',a:m,d:m.x+m.y});
  for(const p of decay) if(p.kind==='prop') acts.push({tx:p.x,ty:p.y,k:'a',a:p,d:p.x+p.y});   // seated beggars / musicians / fortune-tellers
  acts.sort((p,q)=>p.d-q.d||p.tx-q.tx);
  octx.setTransform(DPR,0,0,DPR,0,0); octx.clearRect(0,0,VW,VH);
  actx.setTransform(DPR,0,0,DPR,0,0); actx.clearRect(0,0,VW,VH);   // agents drawn here too, for the fine-ink tier
  let drew=false;
  for(const o of acts){ const[cx,cy]=s2(o.tx,o.ty);
    if(cx<-TW*z*2||cx>VW+TW*z*2||cy<-TH*z*10||cy>VH+TH*z*2)continue;
    if(o.k==='tree')drawTree(octx,cx,cy,z,grid[o.ty][o.tx].seed,grid[o.ty][o.tx].h,o.tx,o.ty);
    else if(o.k==='ruin')drawRuin(octx,cx,cy,z,o.c&&o.c.scorch,o.c&&o.c.parkRuin);
    else if(o.k==='z')drawZoneBuilding(octx,cx,cy,z,o.c);
    else if(o.k==='farm')drawFarmField(octx,cx,cy,z,o.c);
    else if(o.k==='c')drawCivic(octx,cx,cy,z,o.civ,S.era);
    else { drawAgent(octx,cx,cy,z,o.a); drawAgent(actx,cx,cy,z,o.a,true); }   // colour+occlusion / fine-ink source (no shadow)
    drew=true; }
  if(drew) stampInk(ctx,z);
  // fire + ground apparitions (FX, never inked)
  const fxObjs=[];
  for(let ty=0;ty<H;ty++)for(let tx=0;tx<W;tx++){const c=grid[ty][tx]; if(c.burn)fxObjs.push({k:'fire',burn:c.burn,tx,ty,d:tx+ty+0.5}); else if(c.guard)fxObjs.push({k:'guard',tx,ty,d:tx+ty+0.45});}
  for(const a of apparitions) if(a.ground) fxObjs.push({k:'app',a,tx:a.x,ty:a.y,d:a.x+a.y+0.2});
  fxObjs.sort((p,q)=>p.d-q.d);
  for(const o of fxObjs){ const[cx,cy]=s2(o.tx,o.ty);
    if(cx<-TW*z*2||cx>VW+TW*z*2||cy<-TH*z*10||cy>VH+TH*z*2)continue;
    if(o.k==='fire')drawFire(ctx,cx,cy,z,o.burn,fx);
    else if(o.k==='guard'){ const yy=cy-22*z, pr=4.4*z, pu=0.6+0.4*Math.sin(fx*0.004+o.tx);
      ctx.globalAlpha=0.85; ctx.fillStyle='#14f195'; ctx.beginPath();
      ctx.moveTo(cx,yy-pr); ctx.lineTo(cx+pr*0.82,yy-pr*0.4); ctx.lineTo(cx+pr*0.55,yy+pr*0.8); ctx.lineTo(cx,yy+pr*1.05); ctx.lineTo(cx-pr*0.55,yy+pr*0.8); ctx.lineTo(cx-pr*0.82,yy-pr*0.4); ctx.closePath(); ctx.fill();
      ctx.strokeStyle='rgba(3,3,26,0.85)'; ctx.lineWidth=1*z; ctx.stroke();
      ctx.strokeStyle='rgba(20,241,149,'+(0.30*pu)+')'; ctx.lineWidth=2.4*z; ctx.stroke(); ctx.globalAlpha=1; }
    else { ctx.globalAlpha=Math.max(0,Math.min(1,Math.min(a_in(o.a),a_out(o.a))))*0.92; (APP[o.a.kind]||APP.hitodama)(ctx,cx,cy-6*z,z,fx); ctx.globalAlpha=1; } }
  // flying apparitions on top
  for(const a of apparitions){ if(a.ground)continue; const[cx,cy]=s2(a.x,a.y);
    ctx.globalAlpha=Math.max(0,Math.min(1,Math.min(a_in(a),a_out(a))))*0.9; (APP[a.kind]||APP.hitodama)(ctx,cx,cy-30*z,z,fx); ctx.globalAlpha=1; }
  drawViolenceFX(ctx,z);
  // 5) global grade + paper grain + vignette + weather (dynamic, full-frame)
  { const _P=agePal(); if(_P.wet>=0.8 && !_P.neon && !VOID) paintAtmosphereEarly(ctx); }
  // per-age grade mood — now applied in VOID too (gentle), so the emotional arc (warm Heian ->
  // ash Sengoku -> indigo Quantum) glazes the WHOLE painting and unifies buildings, terrain and
  // void into one sheet. Kept faint in VOID so the deep-black void signature survives.
  const grd=ERAS[S.era]&&ERAS[S.era].grade;
  if(grd){ ctx.save(); ctx.globalAlpha=VOID?0.55:1; ctx.fillStyle=grd; ctx.fillRect(0,0,VW,VH); ctx.restore(); }
  if(!PAPERPAT)PAPERPAT=ctx.createPattern(PAPER,'repeat');
  if(!GRAINPAT2)GRAINPAT2=ctx.createPattern(GRAIN,'repeat');
  // LAYER 3: paper grain over the entire canvas (void included), in two passes for a real tooth:
  // a warm multiply for pigment-on-paper body + a soft-light pass for the fibrous surface bite.
  ctx.save(); ctx.globalCompositeOperation='multiply'; ctx.globalAlpha=0.78; ctx.fillStyle=PAPERPAT; ctx.fillRect(0,0,VW,VH);
  ctx.globalCompositeOperation='soft-light'; ctx.globalAlpha=0.48; ctx.fillStyle=GRAINPAT2; ctx.fillRect(0,0,VW,VH); ctx.restore();
  drawVignette();
  drawWeatherFX();
  if(_shx||_shy){ cam.x-=_shx; cam.y-=_shy; }     // undo the temporary screen jitter — never persists into pan/zoom state
}

function drawVignette(){ const r=ctx.createRadialGradient(VW/2,VH*0.46,Math.min(VW,VH)*0.30, VW/2,VH*0.52,Math.max(VW,VH)*0.74);
  r.addColorStop(0,'rgba(0,0,0,0)'); r.addColorStop(0.7,'rgba(0,0,0,0)'); r.addColorStop(1, S.era>=8?'rgba(8,4,22,0.55)':'rgba(10,14,18,0.34)');
  ctx.fillStyle=r; ctx.fillRect(0,0,VW,VH); }
function a_in(a){return Math.min(1,a.t/1.2);} function a_out(a){return Math.min(1,(a.life-a.t)/1.5);}

/* ============================ TRAFFIC / RESIDENTS / APPARITIONS ============================ */
const traffic=[]; let roadList=[]; let decay=[], decayTimer=0;
const CART_TYPES=['ox','kago','hand'], PED_TYPES=['kimono','monk','porter'];
const KIM=['#b23b3b','#3b5fb2','#caa24a','#7a3ba0','#3b8a5a','#c0653a','#2f6b8a','#9a4a6a','#46708f','#8a8f3a','#a23c6a','#5a4a8a','#c08a3a','#357a6a','#b0506a','#406a4a','#8a3a3a','#2a4a7a','#6a5a2a','#4a6a8a','#7a4a3a','#3a6a5a','#9a6a4a','#5a3a6a','#b07a5a','#2f5a4a'];
const OBI=['#e8c24a','#c0392b','#2c3e6a','#3f8a4a','#efe2c4','#7a2d6a','#1f6a5a','#d4843a','#3a3f6a','#9a3a2a','#b08a2a','#5a2d4a','#2a5a4a','#8a4a2a','#d0c0a0','#6a3a5a'];
const SKIN=['#ecc9a0','#e3bd92','#d8ad82','#f0d2ab','#cfa074','#e8c69a','#c89a6e','#dab488','#bd8c60'];
const FISH=['#c0392b','#e8c24a','#46708f','#9a8f3a','#7a3ba0'];   // stand-in koi/ayu/funa colors for a caught-fish icon at the rod tip
const RONIN_ROBE=['#2c2a30','#332a26','#26302c','#3a2c2c','#2a2c36','#383228','#241e28','#2e342e','#34241e','#28282e'];   // desaturated, dirtier than villager KIM
const RONIN_OBI=['#3a2230','#2a2418','#402418','#1e2a28','#34201c','#241c2a','#2c2818','#3a1c1c'];
const RONIN_HEADGEAR=['none','none','hachimaki','kasa','shave','topknot','menpo'];   // weighted toward bare/topknot via repeats; menpo (half-mask) rarer, reads as a hardened veteran
/* build a varied citizen: type, dress, headwear, carried item */
function pedKit(q){
  // wealth factor: tracks the district when q is known, else random (back-compat)
  const v = (q==null) ? Math.random() : clamp(q + (Math.random()-0.5)*0.35, 0.05, 0.97);
  const poor = 1 - v;                                   // hardship weight 0..1
  const era=(typeof S!=='undefined')?S.era:3;
  const nightish=(typeof ENV!=='undefined') && (ENV.night>0.25 || ENV.t<0.26 || ENV.t>0.80);
  // ---- street-life archetypes (all ages; dress era-adapts in drawPerson) ----
  // gate scales with poverty: destitute lanes ~30% street-life, rich wards near 0
  if(Math.random() < poor*0.45){
    const h=Math.random(); let type;
    if(h<0.30) type='leper'; else if(h<0.56) type='drunk';
    else if(h<0.78) type='vendor'; else if(h<0.90) type='pilgrim'; else type='courtesan';
    if(type==='courtesan' && !nightish) type='vendor';           // courtesans bias to night
    if(type==='courtesan'){
      return { type, v, hat:null, acc:null, geisha:true, skin:'#f3e8de',
        col:['#b23b6a','#c0392b','#7a3ba0','#caa24a','#9a4a6a'][(Math.random()*5)|0],
        obi:['#e8c24a','#efe2c4','#1f6a5a','#d4843a'][(Math.random()*4)|0], scale:1 };
    }
    if(type==='pilgrim'){
      return { type, v, hat:'kasa', acc:'staff', skin:SKIN[(Math.random()*SKIN.length)|0],
        col:['#6a4a2a','#5a4028','#4a4a52'][(Math.random()*3)|0], obi:'#3a2c1a', scale:1 };
    }
    // leper / drunk / vendor
    const hat=(type==='vendor')?'tenugui':(type==='leper'?null:(Math.random()<0.3?'kasa':null));
    return { type, v, hat, acc:(type==='drunk'?'gourd':(type==='vendor'?'yoke':null)),
      drunk:(type==='drunk'),
      skin:(type==='leper'?'#cdb89a':SKIN[(Math.random()*SKIN.length)|0]),
      col:(type==='leper'?['#6a5a4a','#5a4a3a','#7a6a58'][(Math.random()*3)|0]:KIM[(Math.random()*KIM.length)|0]),
      obi:OBI[(Math.random()*OBI.length)|0], scale:1 };
  }
  const r=Math.random();
  if(era<=1){ // Jomon/Yayoi: foragers, fishers, porters, children, struggling families — no samurai/noble/monk
    let type='kimono'; if(r<0.18)type='porter'; else if(r<0.42)type='farmer'; else if(r<0.58)type='child';
    let acc=null; const ar=Math.random();
    if(type==='farmer')acc=ar<0.5?'hoe':'basket'; else if(type==='porter')acc='box'; else if(type!=='child')acc=ar<0.4?'basket':null;
    const hat=(type==='farmer')?'kasa':(Math.random()<0.2?'kasa':null);
    return { type, hat, acc, v, skin:SKIN[(Math.random()*SKIN.length)|0], col:KIM[(Math.random()*KIM.length)|0],
      obi:OBI[(Math.random()*OBI.length)|0], scale: type==='child'?0.72:1 }; }
  let type='kimono';
  if(r<0.07)type='monk'; else if(r<0.15)type='porter'; else if(r<0.25)type='merchant';
  else if(r<0.32)type='samurai'; else if(r<0.39)type='noble'; else if(r<0.48)type='farmer';
  else if(r<0.59)type='child';
  const hat=(type==='farmer')?'kasa':(type==='child'||type==='noble'||type==='samurai')?null:(Math.random()<0.26?'kasa':null);
  let acc=null; const ar=Math.random();
  if(type==='noble')acc=ar<0.7?'parasol':'fan';
  else if(type==='merchant')acc='box';
  else if(type==='farmer')acc='hoe';
  else if(type==='child')acc=ar<0.4?'fan':null;
  else if(ar<0.07)acc='parasol'; else if(ar<0.15)acc='fan'; else if(ar<0.24)acc='basket'; else if(ar<0.31)acc='lantern';
  return { type, hat, acc, v, skin:SKIN[(Math.random()*SKIN.length)|0],
    col:KIM[(Math.random()*KIM.length)|0], obi:OBI[(Math.random()*OBI.length)|0],
    scale: type==='child'?0.72:(type==='noble'?1.06:1) }; }
function isRoadAt(x,y){return inB(x,y)&&grid[y][x].road;}
function roadDirs(x,y){const d=[];for(const[dx,dy]of NEIGH)if(isRoadAt(x+dx,y+dy))d.push([dx,dy]);return d;}
function respawnAgent(a){ if(!roadList.length)return false; for(let t=0;t<14;t++){const r=roadList[(Math.random()*roadList.length)|0],dirs=roadDirs(r[0],r[1]);
  if(dirs.length){const d=dirs[(Math.random()*dirs.length)|0];a.x=r[0];a.y=r[1];a.tx=r[0]+d[0];a.ty=r[1]+d[1];a.dx=d[0];a.dy=d[1];a.p=0;return true;}}return false; }
function syncTraffic(){ roadList=[]; for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(grid[y][x].road)roadList.push([x,y]);
  // cart/vehicle traffic only — pedestrian citizens now come exclusively from residents[] (purposeful
  // home/work/leisure agents). Carts stay ambient/cosmetic since they aren't citizens.
  const target=Math.min(28,Math.floor(roadList.length/6)+Math.floor(devTileCount()/10));
  while(traffic.length<target){ const v=Math.random();
    const a={kind:'cart',type:CART_TYPES[(Math.random()*3)|0],spd:0.4+Math.random()*0.8,col:KIM[(Math.random()*KIM.length)|0],obi:OBI[(Math.random()*OBI.length)|0],ph:Math.random()*6,dir:1,wx:0,wy:0,v,hat:null,acc:null};
    if(!respawnAgent(a))break; traffic.push(a);}
  if(traffic.length>target){ // trim from the regular (non-laden) pool only — harvest carts are one-shot and must finish their delivery
    let over=traffic.length-target;
    for(let i=traffic.length-1;i>=0&&over>0;i--){ if(!traffic[i].laden){ traffic.splice(i,1); over--; } } }
  syncResidents(); }
/* count developed/civic tiles — drives population scaling so a bigger city visibly has more street life */
function devTileCount(){ let n=0; for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x]; if(c.dev>0||c.civ)n++;} return n; }
/* ---- farm groups: flood-fill connected FARM tiles, chunk into groups of 3 (remainder folds
   into the last group of its cluster), one crop type per group, seeded so it's stable across
   rebuilds. Recomputed only when gridVersion changes (cheap: farm tiles are rare). ---- */
function buildFarmGroups(){
  const seen=new Set(), groups=[]; let gid=0;
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const c=grid[y][x]; if(c.civ!==FARM)continue; const k=x+','+y; if(seen.has(k))continue;
    // BFS the connected farm cluster
    const cluster=[]; const stack=[[x,y]]; seen.add(k);
    while(stack.length){ const[cx,cy]=stack.pop(); cluster.push([cx,cy]);
      for(const[dx,dy]of NEIGH){ const nx=cx+dx,ny=cy+dy; if(!inB(nx,ny))continue; const nk=nx+','+ny; if(seen.has(nk))continue;
        if(grid[ny][nx].civ===FARM){ seen.add(nk); stack.push([nx,ny]); } } }
    // chunk the cluster into groups of 3 plots (remainder <3 merges into the previous chunk, or stands alone if it's the only chunk)
    for(let i=0;i<cluster.length;i+=3){
      let tiles=cluster.slice(i,i+3);
      if(tiles.length<3 && groups.length && groups[groups.length-1].clusterId===gid){ groups[groups.length-1].tiles.push(...tiles); continue; }
      const seed=vhash(tiles[0][0]*13+tiles[0][1]*7,gid*3.1);
      groups.push({id:gid++, clusterId:gid, tiles, crop:CROP[(seed*CROP.length)|0]});
    }
  }
  _farmGroups=groups; _farmGroupsVer=gridVersion;
  // stamp group/crop refs onto tiles + init grow-state fields if missing
  for(const grp of groups) for(const[tx,ty]of grp.tiles){ const c=grid[ty][tx];
    c.cropGrp=grp.id; c.cropType=grp.crop; if(c.stage==null){c.stage=0;c.stageT=0;} }
  return groups;
}
function farmGroups(){ if(_farmGroupsVer!==gridVersion) buildFarmGroups(); return _farmGroups; }
/* ---- farm growth: advances tilled->seeded->sprout->mature->ready on real elapsed time (dt),
   independent of the 1.5s tick(). A group is "ready" once every tile in it reaches stage 4;
   harvest collapses the whole group back to stage 0 and spawns one delivery cart. ---- */
const farmHands=[]; // one tending worker per farm group; parked on a field tile, pose follows group stage
function syncFarmHands(){
  const groups=farmGroups();
  // drop hands whose group no longer exists
  for(let i=farmHands.length-1;i>=0;i--) if(!groups.some(g=>g.id===farmHands[i].grp)) farmHands.splice(i,1);
  for(const grp of groups){ if(farmHands.some(h=>h.grp===grp.id)) continue;
    const[tx,ty]=grp.tiles[0];                                   // deterministic: the tile the player actually placed/sees, not a random pick
    const kit=pedKit(); kit.acc='hoe'; kit.hat='kasa';
    farmHands.push(Object.assign({grp:grp.id,x:tx+0.15,y:ty+0.1,tx,ty,ph:Math.random()*6,dir:1,moving:false,act:'work',scale:1}, kit));
  }
}
function updateFarmHands(dt){ for(const h of farmHands){ h.ph+=dt*2.2;
  // relocate onto the group's current lowest-stage tile so the worker visibly tends whichever
  // patch still needs attention (till->sow->sprout); once everything's mature/ready they idle.
  // SNAP rather than lerp: group tiles aren't guaranteed collinear/adjacent (BFS-chunked), so
  // interpolating x/y in a straight line can cut diagonally across tiles that aren't actually
  // between the two field plots on screen, visually crossing through unrelated ground.
  const grp=_farmGroups&&_farmGroups.find(g=>g.id===h.grp); if(!grp)continue;
  let lo=4,lt=null; for(const[tx,ty]of grp.tiles){ const c=grid[ty]&&grid[ty][tx]; if(c&&c.stage<lo){lo=c.stage;lt=[tx,ty];} }
  if(lt){ h.tx=lt[0]+0.15; h.ty=lt[1]+0.1; h.x=h.tx; h.y=h.ty; }
  h.act = lo>=3?'idle':'work'; h.moving=false; } }
function updateFarms(dt){
  const groups=farmGroups(); if(!groups.length)return;
  syncFarmHands(); updateFarmHands(dt);
  for(const grp of groups){
    let allReady=true;
    for(const[tx,ty]of grp.tiles){ const c=grid[ty][tx]; if(!c||c.civ!==FARM)continue;
      if(c.stage<4){ c.stageT+=dt; if(c.stageT>=FARM_STAGE_T[c.stage]){ c.stageT=0; c.stage++; } allReady=false; }
    }
    if(allReady && !grp.harvesting){ grp.harvesting=true; harvestFarmGroup(grp); }
  }
}
/* ---- harvest: reset the group's tiles to freshly-tilled soil, then hand the crop off to the
   existing hand-cart agent (reused as-is, just laden+spawned at the field) which wanders the
   road network like any other cart and quietly delivers (despawns near a MARKET tile). ---- */
function harvestFarmGroup(grp){
  const[fx,fy]=grp.tiles[0];
  for(const[tx,ty]of grp.tiles){ const c=grid[ty][tx]; if(c&&c.civ===FARM){ c.stage=0; c.stageT=0; } }
  grp.harvesting=false;
  // find the nearest road tile to the field itself — cart starts its wander from there, laden
  let start=null,bd=1e9;
  for(let r=0;r<8&&!start;r++)for(let j=-r;j<=r;j++)for(let i=-r;i<=r;i++){ const nx=fx+i,ny=fy+j;
    if(Math.abs(i)+Math.abs(j)!==r)continue; if(inB(nx,ny)&&grid[ny][nx].road){start=[nx,ny];break;} }
  if(!start) return; // no road reachable — nothing to spawn, crop simply sat unharvested-looking but resets silently
  const dirs0=roadDirs(start[0],start[1]); if(!dirs0.length)return;
  const d0=dirs0[(Math.random()*dirs0.length)|0];
  const cart={kind:'cart',type:'hand',spd:0.5+Math.random()*0.3,col:KIM[(Math.random()*KIM.length)|0],obi:OBI[(Math.random()*OBI.length)|0],
    ph:Math.random()*6,dir:1,x:start[0],y:start[1],tx:start[0]+d0[0],ty:start[1]+d0[1],dx:d0[0],dy:d0[1],p:0,wx:start[0],wy:start[1],
    laden:true,cropType:grp.crop,deliverT:0};
  traffic.push(cart);
  toast('🌾 Harvest', CROP_NAME[grp.crop]+' brought to market');
}
const CROP_NAME={rice:'Rice',millet:'Millet',daikon:'Daikon',soy:'Soybeans',tea:'Tea',eggplant:'Eggplant'};

function updateTraffic(dt){ for(const a of traffic){ if(a.claimed)continue; if(a.flee>0)a.flee-=dt;
    if(a.watch>0){ a.watch-=dt; if(a.watch<=0)a.watch=undefined; }
    // ---- laden harvest cart: once it wanders within 2 tiles of any MARKET, deliver + despawn ----
    if(a.laden){ for(let j=-2;j<=2;j++)for(let i=-2;i<=2;i++){ const nx=(a.wx|0)+i,ny=(a.wy|0)+j;
      if(inB(nx,ny)&&grid[ny][nx].civ===MARKET){ a.delivered=true; break; } } if(a.delivered){ a.ph+=dt*7; continue; } }
    // ---- nervousness near a ronin warband passing through (ambient, separate from active raid flee) ----
    // cart drivers are simply wary; a minority instead show deference — a brief respectful
    // pause/bow rather than a fearful one. Decided once when the ronin first come into range so
    // the same figure doesn't flicker between the two readings every frame.
    if(!(a.flee>0)){ for(const e of encounters){ if(!e.mob)continue; for(const m of e.mob){ const dd=Math.hypot(m.x-a.x,m.y-a.y);
      if(dd<2.6){ if(a.nerve===undefined){ a.nerve=Math.random(); a.respectful=Math.random()<0.22; } break; } } if(a.nerve!==undefined)break; } }
    else { a.nerve=undefined; a.respectful=undefined; }
    // ---- watching a nearby disturbance: frozen in place (too far to panic, close enough to stare) ----
    if(a.watch>0){ a.ph+=dt*1.5; continue; }
    a.p+=dt*a.spd*(a.flee>0?2.3:1);
  if(a.p>=1){a.x=a.tx;a.y=a.ty;a.p=0; if(!isRoadAt(a.x,a.y)){respawnAgent(a);continue;}
    let dirs=roadDirs(a.x,a.y).filter(d=>!(d[0]===-a.dx&&d[1]===-a.dy)); if(!dirs.length)dirs=roadDirs(a.x,a.y); if(!dirs.length){respawnAgent(a);continue;}
    const d=dirs[(Math.random()*dirs.length)|0];a.dx=d[0];a.dy=d[1];a.tx=a.x+d[0];a.ty=a.y+d[1]; if(!isRoadAt(a.tx,a.ty))respawnAgent(a);}
  a.wx=a.x+(a.tx-a.x)*a.p; a.wy=a.y+(a.ty-a.y)*a.p; a.dir=(a.tx-a.x)-(a.ty-a.y)<0?-1:1; a.ph+=dt*7; }
  // sweep out delivered carts (was a forced respawn into the general pool — these are one-shot, so they leave instead)
  for(let i=traffic.length-1;i>=0;i--) if(traffic[i].laden&&traffic[i].delivered) traffic.splice(i,1);
}
const residents=[];
function findWork(hx,hy){ let best=null,bd=1e9; for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x];
  const work=(c.zone===ZC||c.zone===ZI)&&c.dev>0, civ=c.civ&&c.civ!==FARM&&c.civ!==PARK;
  if(work||civ){const d=Math.abs(x-hx)+Math.abs(y-hy); if(d<bd&&d<24){bd=d;best=[x,y];}}} return best; }
/* nearest standing water tile to (hx,hy) within a short search radius — used for the
   "walk to the lake/river to idle or fish" behavior. Returns the LAND tile adjacent to
   the water (never the water tile itself, so people never stand "in" the lake). */
function nearestWaterEdge(hx,hy){ let best=null,bd=1e9;
  for(let y=Math.max(0,hy-10);y<Math.min(H,hy+11);y++)for(let x=Math.max(0,hx-10);x<Math.min(W,hx+11);x++){
    if(grid[y][x].ter===WATER)continue; if(!waterNeighbors(x,y).deg)continue;
    const d=Math.abs(x-hx)+Math.abs(y-hy); if(d<bd){bd=d;best=[x,y];} } return best; }
/* nearest temple/shrine tile — used for the "pray near temples" behavior (middle ages onward) */
function nearestTemple(hx,hy){ let best=null,bd=1e9;
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ if(grid[y][x].civ===TEMPLE){const d=Math.abs(x-hx)+Math.abs(y-hy); if(d<bd&&d<28){bd=d;best=[x,y];}} } return best; }
const TRAITS=['brisk','chatty','devout','angler','idler'];                          // persistent per-resident personality, rolled once at spawn
function syncResidents(){ const homes=[]; for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x]; if(c.zone===ZR&&c.dev>0||c.civ===TOWN)homes.push([x,y]); }
  // population scales with homes/development first — road network only adds DENSITY on top of an
  // already-settled town (more foot traffic per home as the city fills in), it can never invent
  // citizens for a long empty road. This pool now covers ALL pedestrian citizens, including what
  // used to be ambient traffic[] filler — every figure on the street has a home, and either a
  // workplace, a leisure habit, or both; none of them wander without a reason.
  const densityBonus=1+Math.min(0.6,roadList.length/900);   // up to +60% once the road network is substantial
  const target=Math.min(110,Math.round(Math.max(homes.length*0.85,devTileCount()*0.25)*densityBonus));
  if(residents.length>target)residents.length=target;
  while(residents.length<target&&homes.length){const h=homes[(Math.random()*homes.length)|0]; const work=findWork(h[0],h[1]);
    const kit=pedKit(); const carrying=kit.type!=='child'&&Math.random()<0.3;
    if(carrying&&!kit.acc) kit.acc=['basket','box','yoke'][(Math.random()*3)|0];
    residents.push(Object.assign({home:h,work,goal: work?'out':'home', ax:h[0],ay:h[1],x:h[0]+(Math.random()-0.5),y:h[1]+(Math.random()-0.5),tx:h[0],ty:h[1],
      spd:0.9+Math.random()*0.6,ph:Math.random()*6,pause:Math.random()*2,kind:'ped',dir:1,moving:false,act:'walk',trait:TRAITS[(Math.random()*TRAITS.length)|0]}, kit));}
  for(const r of residents){const c=grid[r.home[1]]&&grid[r.home[1]][r.home[0]];
    if(!c||!(c.zone===ZR&&c.dev>0||c.civ===TOWN)){if(homes.length){r.home=homes[(Math.random()*homes.length)|0];r.work=findWork(r.home[0],r.home[1]);r.x=r.home[0];r.y=r.home[1];r.goal='home';}}
    else if(!r.work)r.work=findWork(r.home[0],r.home[1]); } }
function updateResidents(dt){ const tod=(typeof ENV!=='undefined')?ENV.t:0.4; const dayTime=tod>0.28&&tod<0.78;
  for(const r of residents){ if(r.claimed)continue; if(r.flee>0)r.flee-=dt;
    // ---- nervousness near a passing ronin warband (ambient avoidance, distinct from active-raid flee) ----
    if(!(r.flee>0)){ let near=false; for(const e of encounters){ if(!e.mob)continue; for(const m of e.mob){ if(Math.hypot(m.x-r.x,m.y-r.y)<2.6){near=true;break;} } if(near)break; }
      if(near){ if(r.nerve===undefined){ r.nerve=Math.random(); r.respectful=Math.random()<0.22; } } else { r.nerve=undefined; r.respectful=undefined; } }
    if(r.watch>0){ r.watch-=dt; if(r.watch<=0)r.watch=undefined; else { r.moving=false; r.ph+=dt*1.5; continue; } } // watching a nearby disturbance — frozen, staring
    if(r.pause>0){ r.pause-=dt; r.moving=false;
      if(r.act==='water'||r.act==='temple')r.ph+=dt*1.5;
      if(r.act==='water'&&r.fishing&&!r.caught&&r.pause<=r.pause0*0.55&&Math.random()<0.35*dt){ r.caught=FISH[(Math.random()*FISH.length)|0]; r.caughtT=2; } // bite partway through the sit
      if(r.caughtT!==undefined){ r.caughtT-=dt; if(r.caughtT<=0)r.caughtT=undefined; }
      continue; }
    // choose destination: commute to work by day, leisure detour or home otherwise
    let dest;
    if(r.work && r.goal==='out' && dayTime){ dest=r.work; }
    else if(r.goal==='leisure' && r.leisureSpot){ dest=r.leisureSpot; }
    else { dest=r.home; r.goal='home'; }
    const gx=dest[0]+(r.goal==='home'?(r.jx||0):0), gy=dest[1]+(r.goal==='home'?(r.jy||0):0);
    const dx=gx-r.x, dy=gy-r.y, d=Math.hypot(dx,dy);
    if(d<0.18){ r.moving=false;
      if(r.goal==='out'){ r.pause=2+Math.random()*3; r.goal='home'; }      // worked a shift, head home
      else if(r.goal==='leisure'){ r.act=r.leisureAct||'idle';
        if(r.act==='water'){ r.fishing=Math.random()<0.6; r.caught=undefined; r.caughtT=undefined;
          r.pause=(r.trait==='angler'?20:14)+Math.random()*22; }                 // sit 14-36s (anglers linger longer) — a real fishing session, not a blink
        else { r.pause=3+Math.random()*4; }
        r.pause0=r.pause; r.goal='home'; r.leisureSpot=null; }                  // arrived at the water/temple — pause there a while
      else { r.act=Math.random()<0.4?'idle':'walk'; const pauseScale=r.trait==='brisk'?0.5:(r.trait==='chatty'?1.5:1);
        r.pause=(0.6+Math.random()*1.2)*pauseScale; r.jx=(Math.random()-0.5)*1.2; r.jy=(Math.random()-0.5)*1.2;
        const tookLeisure = dayTime && r.trait!=='brisk' && Math.random()<0.12 && (()=>{                 // a brief leisure detour before/instead of work or staying home
          const wantTemple=r.trait==='devout'?((typeof S!=='undefined'&&S.era>=3)) : r.trait==='angler'? false :
            (typeof S!=='undefined'&&S.era>=3)&&Math.random()<0.5;
          const spot = wantTemple ? nearestTemple(r.home[0],r.home[1]) : nearestWaterEdge(r.home[0],r.home[1]);
          if(!spot)return false; r.leisureSpot=spot; r.leisureAct=wantTemple?'temple':'water'; r.goal='leisure'; r.pause=0; return true; })();
        if(!tookLeisure){ if(dayTime&&r.work)r.goal='out'; } }
    } else { const v=r.spd*dt*(r.flee>0?2.3:1); r.x+=dx/d*v; r.y+=dy/d*v; r.ph+=dt*8; r.dir=dx-dy<0?-1:1; r.moving=true; r.act='walk'; } } }
const apparitions=[]; let appTimer=8, disasterT=0, ryuCool=0;
function tallest(){ let best=null; for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x]; if(c.dev>=2&&(!best||c.dev>best.dev))best={x,y,dev:c.dev};} return best; }
function highHealth(){ if(!healthGrid)return null; for(let i=0;i<30;i++){const x=(Math.random()*W)|0,y=(Math.random()*H)|0; if(grid[y][x].dev>0&&healthGrid[y][x])return[x,y];} return null; }
function firstFire(){ for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(grid[y][x].burn)return[x,y]; return null; }
function randLand(){ for(let i=0;i<40;i++){const x=(Math.random()*W)|0,y=(Math.random()*H)|0; if(grid[y][x].ter!==WATER)return[x,y];} return null; }
function nearTer(ter){ for(let i=0;i<60;i++){const x=(Math.random()*W)|0,y=(Math.random()*H)|0; if(grid[y][x].ter===ter){
  for(const[dx,dy]of NEIGH){const nx=x+dx,ny=y+dy; if(inB(nx,ny)&&grid[ny][nx].ter!==WATER&&grid[ny][nx].ter!==ter)return[nx,ny];} return [x,y]; } } return null; }
function cityTiles(){ const out=[]; for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x]; if(c.dev>0||c.civ||c.road)out.push([x,y]);} return out; }
function cityInfo(){ const t=cityTiles(); if(!t.length)return null; let sx=0,sy=0; for(const[x,y]of t){sx+=x;sy+=y;} return {tiles:t,cx:sx/t.length,cy:sy/t.length}; }
const APP_MSG={ ryu:['🐉 Ryū','a dragon coils above the rooftops'], tennyo:['🪷 Tennyo','a celestial maiden blesses the district'], oni:['👹 Oni','demons gather at the flames'], tengu:['🪶 Tengu','a winged tengu wheels overhead'], kitsune:['🦊 Kitsune','a fox-spirit slips through the streets'], hitodama:['🔥 Hitodama','a soul-flame drifts past'], kappa:['🟢 Kappa','a water-imp lurks by the shore'], tanuki:['🍃 Tanuki','a tanuki ambles out of the trees'], yukionna:['❄️ Yuki-onna','the Snow Woman drifts in'], kasaobake:['☂️ Kasa-obake','a one-eyed umbrella hops past'], bakeneko:['🐈‍⬛ Bakeneko','a ghost-cat prowls the streets'], nurarihyon:['🫖 Nurarihyon','the gourd-headed elder slips in'] };
function announce(k){ const m=APP_MSG[k]; if(m&&typeof toast==='function')toast(m[0],m[1]); }
const STREET=['kitsune','tanuki','nurarihyon','bakeneko','kasaobake'], CROSS=['tengu','hitodama'];
function spawnApparition(){ if(apparitions.length>=5)return; const fire=firstFire(); const ci=cityInfo();
  // ONI swarm to fires
  if((disasterT>0||fire)&&!apparitions.some(a=>a.kind==='oni')&&Math.random()<0.75){ let x,y; if(fire){x=fire[0]+(Math.random()<0.5?-1:1);y=fire[1];}else if(ci){x=ci.cx+(Math.random()-0.5)*4;y=ci.cy+(Math.random()-0.5)*4;}else{const p=randLand();if(!p)return;x=p[0];y=p[1];}
    apparitions.push({kind:'oni',x:x+0.5,y,t:0,life:10,ground:true,fx:fire?fire[0]:null,fy:fire?fire[1]:null}); announce('oni'); return; }
  if(!ci)return;                                                   // no city yet — nothing to haunt
  // YUKI-ONNA drifts across the city in snow / deep night
  const cold=(typeof ENV!=='undefined')&&(ENV.weather==='snow'||ENV.night>0.7);
  if(cold&&Math.random()<0.55&&!apparitions.some(a=>a.kind==='yukionna')){ const dir=Math.random()<0.5?1:-1;
    apparitions.push({kind:'yukionna',x:ci.cx-dir*9,y:ci.cy+(Math.random()-0.5)*5,vx:dir*0.3,t:0,life:18,ground:false}); announce('yukionna'); return; }
  // RYŪ circles the tallest tower (rarer now so it doesn't dominate)
  const tall=tallest(); if(tall&&ryuCool<=0&&!apparitions.some(a=>a.mode==='circle')&&Math.random()<0.1){ ryuCool=80+Math.random()*60;
    apparitions.push({kind:'ryu',mode:'circle',cx:tall.x+0.5,cy:tall.y,rad:4+Math.random()*1.5,ang:Math.random()*6,spd:0.6,x:tall.x,y:tall.y,t:0,life:20,ground:false}); announce('ryu'); return; }
  const r=Math.random();
  if(r<0.16){ const p=nearTer(WATER); if(p){apparitions.push({kind:'kappa',x:p[0]+0.5,y:p[1],vx:0,t:0,life:10,ground:true});announce('kappa');return;} }
  if(r<0.32){ const p=nearTer(FOREST); if(p){const k=Math.random()<0.5?'tanuki':'kitsune';apparitions.push({kind:k,x:p[0]+0.5,y:p[1],vx:(Math.random()-0.5)*0.15,t:0,life:10,ground:true});announce(k);return;} }
  if(r<0.46){ const h=highHealth(); if(h){apparitions.push({kind:'tennyo',x:h[0]+0.5,y:h[1]-0.3,vx:0,t:0,life:11,ground:true});announce('tennyo');
    if(Math.random()<0.5)apparitions.push({kind:'hitodama',x:h[0]+1,y:h[1]+0.5,vx:(Math.random()-0.5)*0.3,t:0,life:9,ground:false}); return;} }
  // DEFAULT — a yokai moving right through your streets (always near the player)
  if(Math.random()<0.45){ const k=CROSS[(Math.random()*CROSS.length)|0], dir=Math.random()<0.5?1:-1;
    apparitions.push({kind:k,x:ci.cx-dir*9,y:ci.cy+(Math.random()-0.5)*6,vx:dir*(0.5+Math.random()*0.5),t:0,life:18,ground:false}); announce(k); }
  else { const tl=ci.tiles[(Math.random()*ci.tiles.length)|0], k=STREET[(Math.random()*STREET.length)|0];
    apparitions.push({kind:k,x:tl[0]+0.5,y:tl[1],vx:(Math.random()-0.5)*0.25,t:0,life:10,ground:true}); announce(k); } }
function updateApparitions(dt){ if(disasterT>0)disasterT-=dt; if(ryuCool>0)ryuCool-=dt;
  appTimer-=dt; if(appTimer<=0){spawnApparition();appTimer=14+Math.random()*14;}
  for(let i=apparitions.length-1;i>=0;i--){const a=apparitions[i];a.t+=dt;
    if(a.mode==='circle'){a.ang+=a.spd*dt;a.x=a.cx+Math.cos(a.ang)*a.rad;a.y=a.cy+Math.sin(a.ang)*a.rad*0.6;}
    else if(a.kind==='oni'&&a.fx!=null){const dx=a.fx+0.5-a.x,dy=a.fy-a.y,d=Math.hypot(dx,dy);if(d>1.4){a.x+=dx/d*0.4*dt;a.y+=dy/d*0.4*dt;}}
    else a.x+=(a.vx||0)*dt;
    if(a.t>=a.life||a.x<-4||a.x>W+4)apparitions.splice(i,1);} }

/* ============================ RONIN — RANDOM STREET VIOLENCE ============================ */
/* Rare, brutal, painterly. Weighted outcomes: ~65% flee, ~22% mug, ~13% lethal (dismemberment).
   Ronin share drawRonin() and can later be reused by the arson/pillage raid trigger.
   Children are NEVER eligible victims. Blood is sumi-e ink-bleed; bodies/parts persist then fade.
   B-lite economy: each incident leaves a decaying "scar" that qualityAt() reads, temporarily
   cratering local land value / development demand. No $SORU theft, no permanent pop loss. */
const RONIN_VIOLENCE=true;                 // master toggle
const encounters=[], corpses=[]; let scarGrid=null, encTimer=22;

/* ===== RAID GORE FX — airborne blood sprays, persistent ground stains, collapse debris.
   All purely cosmetic: they NEVER write to economy/value (scars + dev still own that). ===== */
const sprays=[], stains=[], debris=[], clashSparks=[];
/* ===== BRUTALITY SCALE — per spec §4/§11, violence should ramp through the war ages and hit
   "rock bottom" in Sengoku, while staying gentler in the early/peaceful ages. One small read of
   S.era applied at the actual hit/clash moments (spray count, spark count) rather than threaded
   through every timing constant — escalation should be felt in IMPACT, not in pacing. */
function brutalityScale(){ const era=(typeof S!=='undefined')?S.era:3;
  if(era===7) return 1.45;          // Sengoku — rock bottom, per spec
  if(era===6) return 1.2;           // Kamakura — hardening, the slide already underway
  if(era<=1) return 0.85;           // Jomon/Yayoi — primeval but not yet this violent
  return 1.0; }
function addClashSpark(x,y){ if(clashSparks.length>40)clashSparks.shift(); const bs=brutalityScale();
  for(let k=0;k<Math.round((5+((Math.random()*4)|0))*bs);k++){ const a=Math.random()*6.283, sp=(1.4+Math.random()*2.6)*bs;
    clashSparks.push({ x,y, h:3+Math.random()*2.5, vx:Math.cos(a)*sp, vy:Math.sin(a)*sp*0.6, vh:4+Math.random()*4,
      life:0, max:0.22+Math.random()*0.12 }); } }
function addSpray(x,y,n,power){ power=(power||1)*brutalityScale(); for(let k=0;k<n;k++){ const a=Math.random()*6.283, sp=(0.5+Math.random()*1.7)*power;
  sprays.push({ x, y, h:(2+Math.random()*4), vx:Math.cos(a)*sp, vy:Math.sin(a)*sp*0.6, vh:2.4+Math.random()*3.2,
    r:0.5+Math.random()*1.3, life:0, max:1.0+Math.random()*0.6 }); } }
function addStain(x,y,amt){ if(stains.length>260)stains.shift();
  stains.push({ x, y, amt:Math.min(1,amt), t:0, life:36+Math.random()*18, seed:Math.random()*999 }); }
function addDebris(x,y,n,fire){ if(debris.length>400)debris.splice(0,n); for(let k=0;k<n;k++){ const a=Math.random()*6.283, sp=0.6+Math.random()*2.3;
  debris.push({ x, y, h:5+Math.random()*11, vx:Math.cos(a)*sp, vy:Math.sin(a)*sp*0.6, vh:3+Math.random()*4.5,
    r:0.8+Math.random()*2.2, rot:Math.random()*6, vr:(Math.random()-0.5)*0.5, t:0, life:1.4+Math.random()*1.2,
    col:fire?(Math.random()<0.5?'#241510':'#382214'):(Math.random()<0.45?'#5a4632':'#6e5640'), ember:fire&&Math.random()<0.45 }); } }

function updateGore(dt){
  for(let i=sprays.length-1;i>=0;i--){ const p=sprays[i]; p.life+=dt; p.x+=p.vx*dt; p.y+=p.vy*dt; p.h+=p.vh*dt; p.vh-=15*dt;
    if(p.h<=0){ addStain(p.x,p.y,0.16+p.r*0.05); sprays.splice(i,1); continue; }
    if(p.life>=p.max) sprays.splice(i,1); }
  for(let i=stains.length-1;i>=0;i--){ if((stains[i].t+=dt)>=stains[i].life) stains.splice(i,1); }
  for(let i=debris.length-1;i>=0;i--){ const d=debris[i]; d.t+=dt; d.x+=d.vx*dt; d.y+=d.vy*dt; d.h+=d.vh*dt; d.vh-=19*dt; d.rot+=d.vr;
    if(d.h<0){ d.h=0; d.vh=0; d.vx*=0.4; d.vy*=0.4; } if(d.t>=d.life) debris.splice(i,1); }
  for(let i=clashSparks.length-1;i>=0;i--){ const p=clashSparks[i]; p.life+=dt; p.x+=p.vx*dt; p.y+=p.vy*dt; p.h+=p.vh*dt; p.vh-=22*dt;
    if(p.life>=p.max||p.h<=0) clashSparks.splice(i,1); } }

/* one household member cut down at (hx,hy): corpse + dismemberment + arterial spray + pooling blood */
function raidKill(e,hx,hy){ const sk=SKIN[(Math.random()*SKIN.length)|0], cl=KIM[(Math.random()*KIM.length)|0];
  corpses.push({ x:hx, y:hy, t:0, life:30, lethal:true, skin:sk, col:cl, obi:OBI[(Math.random()*OBI.length)|0],
    blood:1, parts:makeParts(hx,hy,sk,cl), vic:null, vicIsTraffic:false });
  addSpray(hx,hy,14+((Math.random()*8)|0),1.6); addStain(hx,hy,0.6+Math.random()*0.3);
  addScar(e.rtx,e.rty,0.55,3); scatterWitnesses(hx,hy); }

/* ===== HOUSEHOLD DEFENDERS — visible victims the warband actually duels, not random points.
   Never drawn from the child pool: re-rolled if pedKit() returns a child. ===== */
function spawnDefenders(tx,ty,n){ const arr=[];
  for(let i=0;i<n;i++){ let kit=pedKit(0.5), tries=0; while(kit.type==='child'&&tries<6){ kit=pedKit(0.5); tries++; }
    if(kit.type==='child')kit.type='kimono'; kit.moving=false;
    const a=Math.random()*6.283, r=0.35+Math.random()*0.55;
    arr.push({ x:tx+Math.cos(a)*r, y:ty+Math.sin(a)*r, kit, state:'idle', t:0, dir:(Math.random()<0.5?1:-1), recoilDX:0, recoilDY:0, seed:Math.random()*999, guard:false }); }
  return arr; }

/* armed retainers — a household that rolled defended-resistance gets real swords, not just bodies to duel through.
   Drawn identically to plain defenders (drawDefender doesn't care), but they fight back via roninCombatTick-on-mob.
   weapon must match what drawGuardWeapon actually draws (sickle for farmer kits, bo otherwise) or the combat math
   (engage distance, cut pool) disagrees with what's on screen. One retainer per armed household has a chance to be
   a NAMED veteran — tougher (extra hit before falling) and called out by name in the toast, a cheap way to make
   "the household fights back" occasionally feel like a specific person rather than a generic statistic. */
function armDefenders(defenders){
  let namedRolled=false;
  for(const d of defenders){ d.guard=true; d.weapon=(d.kit&&d.kit.type==='farmer')?'sickle':'bo';
    if(!namedRolled && Math.random()<0.22){ namedRolled=true; d.named=RETAINER_NAMES[(Math.random()*RETAINER_NAMES.length)|0]; d.toughHits=1; } }
  return namedRolled?defenders.find(d=>d.named):null;
}
const RETAINER_NAMES=['Genzo','Hachirobei','Tadaoki','Kuranosuke','Shinpachi','Mokuemon'];

function updateDefenders(e,dt){ if(!e.defenders)return;
  for(const d of e.defenders){
    if(d.state==='struck'){ d.t+=dt; if(d.t>0.4){ raidKill(e,d.x,d.y); d.state='down'; } }
    else if(d.state==='flee'){ const dx=d.x-e.rtx,dy=d.y-e.rty,dd=Math.hypot(dx,dy)||1; d.x+=dx/dd*1.8*dt; d.y+=dy/dd*1.8*dt; d.dir=dx<0?-1:1; } } }

/* a blade actually connects with a person — the direct cause of the body that follows.
   A named retainer's first hit is absorbed (toughHits) as a stagger, not a fall — gives the
   one called-out defender in an armed household a beat of visibly outlasting the rest. */
function landHit(e,m,tgt){
  // FINISHING BLOW — check BEFORE this hit lands whether tgt is the last one still standing.
  // The household's last fall should read as a beat, not just another struck-defender tick.
  const others=e.defenders?e.defenders.filter(d=>d!==tgt):[];
  const isLast=tgt.toughHits<=0 && others.length>0 && others.every(d=>d.state==='down'||d.state==='flee');
  addSpray(tgt.x,tgt.y,(isLast?12:7)+((Math.random()*6)|0), (isLast?1.5:1.0)+(m.swingType==='sweep'?0.5:m.swingType==='thrust'?0.3:0));
  if(isLast) addClashSpark(tgt.x,tgt.y);
  if(window.SoruBattleSFX) window.SoruBattleSFX.impact({weight:m.swingType, gain:isLast?1.3:1});
  if(tgt.toughHits>0){ tgt.toughHits--; tgt.flinchT=0.3; tgt.recoilDX=(m.dir||1)*0.25; tgt.recoilDY=-0.08;
    if(typeof toast==='function') toast('⚔️ '+tgt.named+' staggers','the retainer takes the cut and stays on his feet');
    return; }
  tgt.state='struck'; tgt.t=0; tgt.recoilDX=(m.dir||1)*0.3; tgt.recoilDY=-0.1;
  e.struck=(e.struck||0)+1;
  if(typeof toast==='function'){
    if(isLast) toast(tgt.named?'🩸 '+tgt.named+' is the last to fall':'🩸 The last of the household falls','no one left at the door');
    else if(tgt.named) toast('🩸 '+tgt.named+' falls','the named retainer goes down under the blades');
    else if(e.struck===1) toast('🩸 Steel finds flesh','the household falls under the blades'); } }

/* mirror of landHit, but the VICTIM is an attacking ronin — fired when an armed guard's
   swing connects. Ronin don't get the soft 0.4s "struck" grace window defenders get;
   they drop fast once cut, since this is meant to feel like a real reversal, not a slog. */
function landHitOnRonin(e,guard,ronin){ ronin.hp=(ronin.hp==null?1:ronin.hp)-1;
  ronin.flinchT=0.22; ronin.dir=(guard.dir||1)*-1;
  const willDrop=ronin.hp<=0 && ronin.state!=='down';
  const othersStanding=willDrop && e.mob ? e.mob.filter(m=>m!==ronin && m.state!=='down' && m.state!=='flee').length : -1;
  const isLastRonin=willDrop && othersStanding===0;
  addSpray(ronin.x,ronin.y,(isLastRonin?9:6)+((Math.random()*5)|0), (isLastRonin?1.3:0.9)+(guard.swingType==='sweep'?0.4:0));
  if(isLastRonin) addClashSpark(ronin.x,ronin.y);
  if(window.SoruBattleSFX) window.SoruBattleSFX.impact({weight:guard.swingType, gain:isLastRonin?1.3:1});
  if(willDrop){ ronin.state='down'; ronin.downT=0;
    addSpray(ronin.x,ronin.y,10+((Math.random()*6)|0),1.5); addStain(ronin.x,ronin.y,0.55+Math.random()*0.25);
    corpses.push({ x:ronin.x, y:ronin.y, t:0, life:26, lethal:true, skin:ronin.skin||'#d8ad82', col:ronin.col||'#2c2a30',
      obi:ronin.obi||'#3a2230', blood:1, parts:makeParts(ronin.x,ronin.y,ronin.skin||'#d8ad82',ronin.col||'#2c2a30'), vic:null, vicIsTraffic:false });
    e.ronDown=(e.ronDown||0)+1;
    if(typeof toast==='function'){
      if(isLastRonin) toast('⚔️ The last ronin falls','the warband is finished, blade by blade');
      else if(e.ronDown===1) toast('⚔️ Steel turned back','a ronin falls in the street'); } } }

/* per-guard duel cycle, symmetric to roninCombatTick: seek a living attacker, close, wind up, cut, recover.
   Only runs for e.defenders that have .guard===true and only during 'duel' (the resistance-roll branch). */
function guardCombatTick(e,d,dt,mob){
  if(d.state==='flee'){ const dx=d.x-e.rtx,dy=d.y-e.rty,dd=Math.hypot(dx,dy)||1; d.x+=dx/dd*1.8*dt; d.y+=dy/dd*1.8*dt; d.dir=dx<0?-1:1; return; }
  if(d.blockT>0){ d.blockT-=dt; if(d.blockT<0)d.blockT=0; }
  if(d.dodgeT>0){ d.dodgeT-=dt; if(d.dodgeT<0)d.dodgeT=0; }
  const kit=kitFor(d.weapon?d:{weapon:'bo'}), engage=kit.engage;                        // unarmed-looking guards still swing a bo by default
  if(d.wind>0){ d.wind-=dt; const tgt=mob[d.target]; if(tgt){ const dx=tgt.x-d.x; d.dir=dx<0?-1:1;
      // a defender watching an incoming cut gets one chance to brace or break away before it lands —
      // reacts partway through the ronin's windup, same generous timing as the mirrored check above
      if(!d.reacted && tgt.wind!=null && tgt.wind<=tgt.windMax*0.55 && tgt.swing<=0){ d.reacted=true;
        const r=Math.random(); if(r<0.30){ d.blockT=0.30; d.blockDir=d.dir; }
        else if(r<0.46){ d.dodgeT=0.26; d.dodgeDX=(Math.random()<0.5?-1:1)*1.1; } } }
    if(d.wind<=0){ d.wind=0; d.swing=d.swingMax; d.hitFired=false; d.reacted=false; if(window.SoruBattleSFX) window.SoruBattleSFX.swing({weight:d.swingType}); } return; }
  if(d.swing>0){ d.swing-=dt; const tgt=mob[d.target];
    if(tgt){ const dx=tgt.x-d.x; d.dir=dx<0?-1:1;
      const elapsed=1-(d.swing/(d.swingMax||0.4)), cf=(d.swingType==='thrust')?0.5:(d.swingType==='sweep'?0.6:0.65);
      if(!d.hitFired && elapsed>=cf){ d.hitFired=true;
        if(tgt.state==='down'||tgt.state==='flee'){ /* target already down or routed — clean whiff, no contact sound */ }
        else if(tgt.blockT>0){ addClashSpark(d.x,d.y); if(window.SoruBattleSFX) window.SoruBattleSFX.parry({weight:d.swingType}); tgt.blockT=Math.max(0,tgt.blockT-0.08); }
        else if(tgt.dodgeT>0){ if(window.SoruBattleSFX) window.SoruBattleSFX.parry({weight:d.swingType,gain:0.5}); }
        else landHitOnRonin(e,d,tgt); } }
    if(d.swing<=0){ d.swing=0; const rTab={thrust:0.16,diag:0.24,chop:0.30,sweep:0.34}; d.recover=(rTab[d.swingType]||0.24)*kit.swingMul+Math.random()*0.10; } return; }
  if(d.recover>0){ d.recover-=dt; if(d.recover<0)d.recover=0; return; }
  if(d.target==null || !mob[d.target] || mob[d.target].state==='down' || mob[d.target].state==='flee'){
    let best=-1,bd=1e9; for(let k=0;k<mob.length;k++){ const m=mob[k]; if(m.state==='down'||m.state==='flee')continue;
      const dist=Math.hypot(m.x-d.x,m.y-d.y); if(dist<bd){bd=dist;best=k;} }
    d.target=best>=0?best:null; }
  if(d.target==null) return;
  const tgt=mob[d.target], dx=tgt.x-d.x,dy=tgt.y-d.y,dist=Math.hypot(dx,dy)||1;
  if(dist>engage){ d.x+=dx/dist*1.5*dt; d.y+=dy/dist*1.5*dt; d.dir=dx<0?-1:1;
    d.circ=(d.circ||0)+dt*0.6; d.x+=Math.cos(d.circ)*0.18*dt; d.y+=Math.sin(d.circ)*0.10*dt; }   // closing footwork drifts, not a straight beeline
  else { d.dir=dx<0?-1:1; const types=kit.types; d.swingType=types[(Math.random()*types.length)|0];
    d.wind=(0.16+Math.random()*0.10)*kit.windMul; d.windMax=d.wind; d.swingMax=((d.swingType==='thrust')?0.34:0.40)*kit.swingMul; } }

/* ===== WEAPON KIT TABLE — reach/engage distance and the cut set each weapon draws from.
   Previously `weapon:'yari'|'katana'` only changed the idle pose; it never touched timing
   or range. yari trades cut variety for a longer reach and a faster, narrower thrust — a
   spearman should keep a katana-ronin at arm's length, not just look different standing still.
   Guard improvised weapons (bo/sickle) hang off the same table so one stat source drives
   both combat math and the existing drawRonin/drawGuardWeapon poses. ===== */
const WEAPON_KIT = {
  katana:  { engage:0.8,  types:['chop','diag','sweep','thrust'], windMul:1.00, swingMul:1.00 },
  yari:    { engage:1.15, types:['thrust','diag'],                windMul:0.85, swingMul:0.92 },  // reach keeps it out of sweep/chop range, mostly thrusts
  bo:      { engage:0.85, types:['chop','diag'],                  windMul:1.05, swingMul:1.05 },  // blunt — no thrust, slower to recover
  sickle:  { engage:0.65, types:['chop','diag'],                  windMul:0.80, swingMul:0.85 }   // short reach, quick snapping cuts
};
function kitFor(a){ return WEAPON_KIT[a.weapon] || WEAPON_KIT.katana; }

/* ===== MORALE — a warband (or a defending household) that's lost most of its fighters
   shouldn't keep trading blows to the literal last man; real skirmishers break. Checked
   once per group per raid-tick from updateRaid, not per-combatant, so the whole side turns
   at once rather than peeling off one at a time (which read as confused, not routed). ===== */
function checkMorale(e,group,isRonin){
  const total=group.length; if(total===0)return false;
  const standing=group.filter(g=>g.state!=='down').length;
  if(standing===0||standing===total)return false;                 // nothing left to break, or no losses yet
  const ratio=standing/total;
  if(ratio>0.4)return false;                                       // still has enough of the warband/household to hold
  const brokenKey=isRonin?'ronMorale':'defMorale'; if(e[brokenKey])return false;
  e[brokenKey]=true; return true;
}

/* per-ronin duel cycle: seek a living defender → close the gap → wind up a STANCE → cut → recover → repeat.
   The hit is timestamped to the swing itself (fires once, partway through the strike) — combat, not coincidence. */
function roninCombatTick(e,m,dt,defenders,rtx,rty){
  if(m.state==='down') return;                                                          // dead weight — out of the fight
  if(m.state==='flee'){ const dx=m.x-rtx,dy=m.y-rty,d=Math.hypot(dx,dy)||1; m.x+=dx/d*m.spd*1.6*dt; m.y+=dy/d*m.spd*1.6*dt; m.dir=dx<0?-1:1; m.ph+=dt*9; return; }
  if(m.flinchT>0){ m.flinchT-=dt; if(m.flinchT<=0)m.flinchT=0; return; }                  // staggered by a counter-hit
  if(m.blockT>0){ m.blockT-=dt; if(m.blockT<0)m.blockT=0; }
  if(m.dodgeT>0){ m.dodgeT-=dt; if(m.dodgeT<0)m.dodgeT=0; }
  const kit=kitFor(m), engage=kit.engage;
  if(m.wind>0){ m.wind-=dt; const tgt=defenders[m.target]; if(tgt){ const dx=tgt.x-m.x; m.dir=dx<0?-1:1;
      // the defender is watching THIS ronin's windup (the tell) — reacts partway through, leaving enough
      // time for the block/dodge animation to actually establish before the cut lands at swing completion
      if(!tgt.tellSeen && tgt.guard && tgt.state==='idle' && m.wind<=m.windMax*0.55){ tgt.tellSeen=true;
        const r=Math.random(); if(r<0.22){ tgt.blockT=0.30; tgt.blockDir=tgt.dir; } else if(r<0.36){ tgt.dodgeT=0.26; tgt.dodgeDX=(Math.random()<0.5?-1:1)*1.1; } } }
    if(m.wind<=0){ m.wind=0; m.swing=m.swingMax; m.hitFired=false; if(window.SoruBattleSFX) window.SoruBattleSFX.swing({weight:m.swingType}); } return; }
  if(m.swing>0){ m.swing-=dt; const tgt=defenders[m.target];
    if(tgt){ const dx=tgt.x-m.x; m.dir=dx<0?-1:1;
      const elapsed=1-(m.swing/(m.swingMax||0.4)), cf=(m.swingType==='thrust')?0.5:(m.swingType==='sweep'?0.6:0.65);
      if(!m.hitFired && elapsed>=cf){ m.hitFired=true;
        if(tgt.state!=='idle'){ /* already down or struck — no hit */ }
        else if(tgt.blockT>0){ addClashSpark(m.x,m.y); if(window.SoruBattleSFX) window.SoruBattleSFX.parry({weight:m.swingType}); tgt.blockT=Math.max(0,tgt.blockT-0.08); }
        else if(tgt.dodgeT>0){ if(window.SoruBattleSFX) window.SoruBattleSFX.parry({weight:m.swingType,gain:0.5}); }
        else landHit(e,m,tgt); } }
    if(m.swing<=0){ m.swing=0; const rTab={thrust:0.16,diag:0.24,chop:0.30,sweep:0.34}; m.recover=(rTab[m.swingType]||0.24)*kit.swingMul+Math.random()*0.10; } return; }
  if(m.recover>0){ m.recover-=dt; if(m.recover<0)m.recover=0; return; }
  if(m.target==null || !defenders[m.target] || defenders[m.target].state!=='idle'){
    // FLANKING: prefer a defender someone else in the warband is ALREADY engaged with over the
    // nearest free one — ganging up reads as a real attack, not four duels happening to overlap.
    // Falls back to nearest-free when nobody's engaged yet (opening seconds of the fight).
    let best=-1,bd=1e9,bestEngaged=-1,bdE=1e9;
    for(let k=0;k<defenders.length;k++){ const d=defenders[k]; if(d.state!=='idle')continue;
      const dist=Math.hypot(d.x-m.x,d.y-m.y);
      if(dist<bd){bd=dist;best=k;}
      if(d.engagedBy>0 && dist<bdE){bdE=dist;bestEngaged=k;} }
    m.target=bestEngaged>=0?bestEngaged:(best>=0?best:null);
    if(m.target!=null){ const t=defenders[m.target]; t.engagedBy=(t.engagedBy||0)+1; m._tracked=m.target; } }
  if(m.target==null){ const dx=rtx-m.x,dy=rty-m.y,d=Math.hypot(dx,dy)||1; m.dir=dx<0?-1:1; return; }   // no one left standing — wait for destruct
  const tgt=defenders[m.target], dx=tgt.x-m.x,dy=tgt.y-m.y,d=Math.hypot(dx,dy)||1;
  if(d>engage){ m.x+=dx/d*m.spd*1.25*dt; m.y+=dy/d*m.spd*1.25*dt; m.dir=dx<0?-1:1; m.ph+=dt*9;
    m.circ=(m.circ||Math.random()*6.28)+dt*0.7; m.x+=Math.cos(m.circ)*0.2*dt; m.y+=Math.sin(m.circ)*0.11*dt; }          // close the gap, with live footwork drift
  else { m.dir=dx<0?-1:1; const types=kit.types; m.swingType=types[(Math.random()*types.length)|0];   // varied cuts, no repeating arc — pool drawn from the weapon kit
    m.wind=(0.14+Math.random()*0.10)*kit.windMul; m.windMax=m.wind; m.swingMax=((m.swingType==='thrust')?0.34:(m.swingType==='sweep'?0.42:0.40))*kit.swingMul; tgt.tellSeen=false; } }

/* staged raid driver — approach → [duel?] → assault → destruct → collapse → aftermath → disperse.
   The building consequence (applyRaid) is DEFERRED all the way to 'collapse', and is SKIPPED
   entirely if the defenders win the duel (raid repelled, see 'repelled' state below). */
function updateRaid(e,dt,near){ e.st+=dt; const arson=e.raidAction==='arson'; const c=grid[e.rty]&&grid[e.rty][e.rtx];
  switch(e.state){
    case 'approach':
      if(near){ e.st=0; e.struck=0; e.dmg=0; e.ronDown=0;
        const nDef=2+((Math.random()*2)|0);
        e.defenders=spawnDefenders(e.rtx,e.rty,nDef);
        for(const m of e.mob){ m.target=null; m.wind=0; m.swing=0; m.recover=0; m.hitFired=false; m.state=null; m.hp=1; m.flinchT=0; }
        if(typeof scatterWitnesses==='function') scatterWitnesses(e.rtx,e.rty);
        // ===== RESISTANCE ROLL — 40-60% chance the household has armed retainers/guards waiting =====
        const resisted=Math.random()<(0.40+Math.random()*0.20);
        if(resisted){
          // Reinforce: an armed defense calls in extra retainers rather than just arming the
          // original 2-3 household members. Without this, defenders were consistently outnumbered
          // by the 3-5 ronin warband and lost almost every duel regardless of the "coin flip" —
          // not a fair fight as the spec intends, just a near-guaranteed attacker win.
          const reinforce=spawnDefenders(e.rtx,e.rty,1+((Math.random()*2)|0));
          e.defenders=e.defenders.concat(reinforce);
          const named=armDefenders(e.defenders);
          if(typeof toast==='function'){
            if(named) toast('⚔️ '+named.named+' draws steel', arson?'a retainer of the household turns on the torchbearers':'a retainer of the household turns on the warband');
            else toast(arson?'⚔️ Guards in the smoke':'⚔️ Steel meets steel',
              arson?'retainers turn on the torchbearers':'defending ronin draw against the warband'); }
          e.state='duel'; e.st=0; }
        else { e.state='assault'; e.st=0;
          if(typeof toast==='function') toast(arson?'🔥 Torchbearers reach it':'🏴 The warband reaches it',
            arson?'they hurl fire and turn on the household':'steel drawn — the household fights back'); } }
      else if(e.t>(e.approachBudget||12)) e.state='gone';
      break;
    case 'duel': {                                          // a real two-sided skirmish — either side can break first
      for(const m of e.mob) roninCombatTick(e,m,dt,e.defenders,e.rtx,e.rty);
      for(const d of e.defenders) if(d.guard && d.state==='idle') guardCombatTick(e,d,dt,e.mob);
      // ambient blade-on-blade texture while both sides still have fighters swinging —
      // sparse and probabilistic so it reads as "a fight is happening nearby", not a metronome
      if(window.SoruBattleSFX){
        const roninSwingN=e.mob.filter(m=>m.state!=='down'&&(m.wind>0||m.swing>0)).length;
        const guardSwingN=e.defenders.filter(d=>d.guard&&(d.wind>0||d.swing>0)).length;
        const concurrent=Math.min(roninSwingN,guardSwingN);                       // overlapping pairs is what actually reads as "clashing"
        if(concurrent>0 && Math.random()<dt*1.1*concurrent) window.SoruBattleSFX.clash();
      }
      // tend struck defenders the same way the plain assault does (struck → down after 0.4s)
      for(const d of e.defenders){ if(d.state==='struck'){ d.t=(d.t||0)+dt; if(d.t>0.4){ raidKill(e,d.x,d.y); d.state='down'; } } }
      // MORALE — a side down to a remnant breaks and runs rather than fighting to the last man.
      // Ronin who flee are removed from targeting (handled inside both *CombatTick functions via
      // state==='flee' checks) but stay in e.mob so disperse/cleanup logic still sees them.
      // Fled defenders survive (no corpse, no scar) — they're routed, not cut down — but no longer
      // hold the line, so the household reads as cleared for the purposes of what happens next.
      if(checkMorale(e,e.mob,true)){
        for(const m of e.mob) if(m.state!=='down'){ m.state='flee'; m.wind=0; m.swing=0; m.flinchT=0; }
        if(typeof toast==='function') toast('🏴 Warband breaks','the survivors turn and run for the road'); }
      if(checkMorale(e,e.defenders,false)){
        for(const d of e.defenders) if(d.state==='idle'){ d.state='flee'; d.wind=0; d.swing=0; }
        if(typeof toast==='function') toast('🏃 Household flees','the defenders scatter rather than die at the door'); }
      const defendersLeft=e.defenders.some(d=>d.state==='idle'||d.state==='struck');
      const roninLeft=e.mob.some(m=>m.state!=='down'&&m.state!=='flee');
      // slight thumb on the scale for the attacker, per spec — only matters when both sides still have fighters
      if(!roninLeft){                                       // ATTACKERS BROKEN OR ROUTED — raid repelled
        e.state='repelled'; e.st=0;
        if(typeof toast==='function') toast(arson?'🛡 Arson repelled':'🛡 Raid repelled',
          arson?'the torchbearers are cut down in the street':'the warband is driven off, blades broken');
      } else if(!defendersLeft){                            // household cut down or routed — proceeds exactly like the old one-sided assault
        e.state='assault'; e.st=1.5;                         // skip ahead since the duel already did the work of clearing them
        if(arson){ if(c)c.burn=1; disasterT=Math.max(disasterT,5); if(typeof playFireBell==='function')playFireBell(true); }
      } else if(e.st>9){                                      // duel drags on too long — break ties (now a fair coin flip; reinforcements above already give the attacker their edge through numbers, not a rigged tiebreak)
        if(Math.random()<0.5){ e.state='assault'; e.st=1.5; if(arson){ if(c)c.burn=1; disasterT=Math.max(disasterT,5); } }
        else { e.state='repelled'; e.st=0;
          if(typeof toast==='function') toast(arson?'🛡 Arson repelled':'🛡 Raid repelled','the household holds the line'); }
      }
      break; }
    case 'repelled':                                         // brief stagger/retreat beat before the survivors flee
      for(const m of e.mob){ if(m.state==='down')continue; m.flinchT=Math.max(0,(m.flinchT||0)-dt);
        const dx=m.x-e.rtx, dy=m.y-e.rty, d=Math.hypot(dx,dy)||1; m.x+=dx/d*m.spd*1.4*dt; m.y+=dy/d*m.spd*1.4*dt; m.dir=dx<0?-1:1; m.ph+=dt*9; }
      if(e.st>1.1){ e.state='disperse'; e.st=0; }
      break;
    case 'assault':                                       // a real duel: ronin close on defenders and cut them down one at a time
      updateDefenders(e,dt);
      for(const m of e.mob) roninCombatTick(e,m,dt,e.defenders,e.rtx,e.rty);
      e.dmg=Math.min(0.3,e.dmg+dt*0.05);
      { const anyLeft=e.defenders.some(d=>d.state!=='down');
        if(e.st>7.5 || (!anyLeft && e.st>1.4)){ e.state='destruct'; e.st=0;
          if(arson){ if(c)c.burn=1; disasterT=Math.max(disasterT,5); if(typeof playFireBell==='function')playFireBell(true); } } }
      break;
    case 'destruct':                                      // household down — survivors turn their blades on the structure itself
      updateDefenders(e,dt);
      for(const m of e.mob){ if(m.wind>0){m.wind-=dt;if(m.wind<0)m.wind=0;} if(m.swing>0){m.swing-=dt;if(m.swing<0)m.swing=0;} if(m.recover>0){m.recover-=dt;if(m.recover<0)m.recover=0;}
        const dx=e.rtx-m.x,dy=e.rty-m.y,d=Math.hypot(dx,dy)||1; if(d>0.9){ m.x+=dx/d*m.spd*dt; m.y+=dy/d*m.spd*dt; m.dir=dx<0?-1:1; m.ph+=dt*8; } else m.dir=dx<0?-1:1; }
      e.dmg=Math.min(0.82,e.dmg+dt*0.20);
      if(Math.random()<dt*5.5) addDebris(e.rtx+(Math.random()-0.5),e.rty+(Math.random()-0.5),2+((Math.random()*3)|0),arson);
      if(arson&&c){ c.burn=Math.min(4,1+e.st*1.3);          // fire visibly spreads up the walls
        if(Math.random()<dt*3.6) addDebris(e.rtx+(Math.random()-0.5)*1.3,e.rty+(Math.random()-0.5)*1.3,1+((Math.random()*2)|0),true);   // rising embers, denser cadence than collapse debris
        if(Math.random()<dt*1.8) addStain(e.rtx+(Math.random()-0.5)*0.7,e.rty+(Math.random()-0.5)*0.7,0.18+Math.random()*0.12);          // soot scorch creeping outward as the fire takes hold
        if((e.lastScatter===undefined||e.st-e.lastScatter>1.1)&&typeof scatterWitnesses==='function'){ e.lastScatter=e.st; scatterWitnesses(e.rtx,e.rty); } }  // fire keeps pushing the crowd back, not just the initial breach
      if(Math.random()<dt*1.4){ const m=e.mob[(Math.random()*e.mob.length)|0]; if(m&&!m.wind&&!m.swing){m.swing=0.4;m.swingMax=0.4;m.swingType='chop';m.hitFired=true;}
        addSpray(e.rtx+(Math.random()-0.5),e.rty+(Math.random()-0.5),5,0.8); }
      if(e.st>2.4){ e.state='collapse'; e.st=0; applyRaid(e); }
      break;
    case 'collapse':                                      // ~2.0s — lean (the groan before it gives) -> give-way burst -> settle
      e.dmg=Math.min(1,e.dmg+dt*0.5);
      if(e.st<0.6){                                        // LEAN: structure visibly tilting, no burst yet — the held breath before the fall
        if(Math.random()<dt*2.2) addDebris(e.rtx+(Math.random()-0.5)*0.6,e.rty+(Math.random()-0.5)*0.6,1,arson);   // sparse trickle, not the full cave-in burst
      } else if(e.lastSt===undefined||e.lastSt<0.6){        // GIVE-WAY: the instant it tips past the point of no return
        addDebris(e.rtx,e.rty,18+((Math.random()*10)|0),arson); if(arson&&c){c.burn=6;disasterT=Math.max(disasterT,7);}
        addScar(e.rtx,e.rty,arson?0.55:0.45,arson?4:3);     // the structural groan resolves into a single heavy burst, plus a wider scar than the slow burn left behind
        if(window.SoruBattleSFX&&window.SoruBattleSFX.collapse) window.SoruBattleSFX.collapse();
        if(typeof scatterWitnessesWide==='function') scatterWitnessesWide(e.rtx,e.rty); }   // the loudest instant in the sequence — the crowd flinches at the fall itself, wider than the breach reaction
      e.lastSt=e.st;
      if(e.st>=0.6){
        if(Math.random()<dt*5.5) addDebris(e.rtx+(Math.random()-0.5)*1.4,e.rty+(Math.random()-0.5)*1.4,1+((Math.random()*2)|0),arson);
        if(arson&&Math.random()<dt*3) addDebris(e.rtx+(Math.random()-0.5)*1.6,e.rty+(Math.random()-0.5)*1.6,1,true); }   // embers keep lofting out of the rubble as it settles
      if(e.st>2.0){ e.state='aftermath'; e.st=0; }
      break;
    case 'aftermath':                                     // ~3s — smoke, embers, the warband melts away
      if(arson&&c&&Math.random()<dt*3.2) addDebris(e.rtx+(Math.random()-0.5),e.rty+(Math.random()-0.5),1,true);
      if(e.st>3.0) e.state='disperse';
      break;
    case 'disperse':
      if(e.t>22||e.mob.every(m=>m.state==='down'||m.x<-3||m.x>W+3||m.y<-3||m.y>H+3)) e.state='gone';
      break;
  } }

function ensureScar(){ if(!scarGrid)scarGrid=Array.from({length:H},()=>new Float32Array(W)); return scarGrid; }
function addScar(x,y,amt,rad){ const g=ensureScar();
  for(let j=-rad;j<=rad;j++)for(let i=-rad;i<=rad;i++){ const nx=x+i,ny=y+j; if(!inB(nx,ny))continue;
    const f=amt*Math.max(0,1-Math.hypot(i,j)/(rad+0.5)); if(f>g[ny][nx])g[ny][nx]=Math.min(0.6,f); } }
function decayScar(dt){ if(!scarGrid)return; const k=Math.pow(0.97,dt*60);   // fades over ~30–40s
  for(let y=0;y<H;y++){ const row=scarGrid[y]; for(let x=0;x<W;x++){ if(row[x]>0.001)row[x]*=k; else row[x]=0; } } }

function rollOutcome(){ const r=Math.random(); if(r<0.65)return'flee'; if(r<0.87)return'mug'; return'lethal'; }
function vpos(v){ return [v.wx!=null?v.wx:v.x, v.wy!=null?v.wy:v.y]; }
function pickVictim(){ const pool=[];   // wandering adult civilian — never a child
  for(const r of residents) if(r.moving&&r.type!=='child'&&!r.claimed)pool.push(r);
  return pool.length?pool[(Math.random()*pool.length)|0]:null; }

function spawnEncounter(){ if(!RONIN_VIOLENCE||encounters.length||!roadList.length)return;
  const vic=pickVictim(); if(!vic)return; const [vx,vy]=vpos(vic);
  const cx=Math.round(vx),cy=Math.round(vy);
  const crime=(crimeGrid&&inB(cx,cy))?crimeGrid[cy][cx]:0.4;
  if(Math.random()>0.22+crime*0.6)return;                 // danger clusters where police don't reach
  let edge=null,bestd=1e9;                                 // emerge from a road tile a few tiles off
  for(let t=0;t<10;t++){ const r=roadList[(Math.random()*roadList.length)|0]; const d=Math.hypot(r[0]-cx,r[1]-cy); if(d>3&&d<bestd){bestd=d;edge=r;} }
  if(!edge)edge=roadList[(Math.random()*roadList.length)|0];
  const n=2+((Math.random()*3)|0); const mob=[];           // 2–4 ronin
  for(let i=0;i<n;i++) mob.push({ kind:'ronin', x:edge[0]+(Math.random()-0.5), y:edge[1]+(Math.random()-0.5),
    ph:Math.random()*6, dir:1, spd:1.5+Math.random()*0.5, skin:SKIN[(Math.random()*SKIN.length)|0],
    col:RONIN_ROBE[(Math.random()*RONIN_ROBE.length)|0], obi:RONIN_OBI[(Math.random()*RONIN_OBI.length)|0],
    build:0.86+Math.random()*0.32, headgear:RONIN_HEADGEAR[(Math.random()*RONIN_HEADGEAR.length)|0],
    scar:Math.random()<0.3, armor:Math.random()<0.25, patch:Math.random()<0.4, bandage:Math.random()<0.2, hairSeed:Math.random()*99 });
  encounters.push({ state:'approach', t:0, st:0, mob, vic, outcome:rollOutcome(), tx:cx, ty:cy }); }

/* TEST/PvP: stage a ronin warband sacking a SPECIFIC plot — converge, slaughter (blood + dismemberment), disperse */
function spawnRaid(tx,ty,action){ const arson=(action==='arson');
  const vic={ x:tx, y:ty, wx:tx, wy:ty, claimed:false, raidV:true,
    skin:SKIN[(Math.random()*SKIN.length)|0], col:KIM[(Math.random()*KIM.length)|0], obi:OBI[(Math.random()*OBI.length)|0] };
  // ===== SPAWN POINT — sample more candidates and keep the CLOSEST viable one. The old version
  // only compared 16 random draws against each other with no real distance cap, so on sparsely
  // connected maps the warband could spawn 20-30+ tiles out and never reach the target before the
  // approach timeout — the raid would silently fizzle with no toast and no visible battle. =====
  let edge=null,bestd=1e9;
  for(let t=0;t<40&&roadList.length;t++){ const r=roadList[(Math.random()*roadList.length)|0]; const d=Math.hypot(r[0]-tx,r[1]-ty); if(d>2&&d<bestd){bestd=d;edge=r;} }
  if(!edge){ const a=Math.random()*6.283; edge=[tx+Math.cos(a)*3.5, ty+Math.sin(a)*3.5]; bestd=3.5; }
  const n=3+((Math.random()*3)|0); const mob=[];               // 3–5 ronin — a warband
  for(let i=0;i<n;i++) mob.push({ kind:'ronin', x:edge[0]+(Math.random()-0.5)*1.6, y:edge[1]+(Math.random()-0.5)*1.6,
    ph:Math.random()*6, dir:1, spd:1.8+Math.random()*0.7, torch: arson?true:(Math.random()<0.3),
    skin:SKIN[(Math.random()*SKIN.length)|0], col:RONIN_ROBE[(Math.random()*RONIN_ROBE.length)|0], obi:RONIN_OBI[(Math.random()*RONIN_OBI.length)|0],
    build:0.86+Math.random()*0.32, headgear:RONIN_HEADGEAR[(Math.random()*RONIN_HEADGEAR.length)|0],
    scar:Math.random()<0.35, armor:Math.random()<0.3, weapon:Math.random()<0.2?'yari':'katana', patch:Math.random()<0.4, bandage:Math.random()<0.2, hairSeed:Math.random()*99 });
  // approachBudget: scaled to the actual spawn distance (~1.6 tiles/sec average closing speed)
  // plus slack, instead of a flat timeout that silently fails whenever the spawn point is far.
  const approachBudget=Math.max(14, bestd/1.6+6);
  // raidAction/rtx/rty: the building consequence is DEFERRED until the mob ARRIVES (see applyRaid)
  encounters.push({ state:'approach', t:0, st:0, mob, vic, outcome:'lethal', tx, ty, raid:true, raidAction:action||null, rtx:tx, rty:ty, approachBudget });
  if(typeof scatterWitnesses==='function') scatterWitnesses(tx,ty);
  if(window.SoruGibberish) window.SoruGibberish.onRaidEvent(tx,ty); }

/* DEFERRED to the 'collapse' phase — the household is already cut down; now the structure falls,
   crushing a couple more under the wreckage, blood pooling in the rubble. */
function applyRaid(e){ const c=grid[e.rty]&&grid[e.rty][e.rtx]; if(!c)return;
  if(e.raidAction==='pillage'){
    for(let k=0;k<1+((Math.random()*2)|0);k++){ const ox=e.rtx+(Math.random()-0.5)*0.9, oy=e.rty+(Math.random()-0.5)*0.9,
        sk=SKIN[(Math.random()*SKIN.length)|0], cl=KIM[(Math.random()*KIM.length)|0];
      corpses.push({ x:ox,y:oy,t:0,life:30,lethal:true, skin:sk, col:cl, obi:OBI[(Math.random()*OBI.length)|0], blood:1, parts:makeParts(ox,oy,sk,cl), vic:null, vicIsTraffic:false });
      addStain(ox,oy,0.7); }
    addStain(e.rtx,e.rty,0.95); addScar(e.rtx,e.rty,0.6,3);
    c.dev=Math.max(0,c.dev-2); if(c.dev<=0){c.zone=0;c.own=0;c.ruin=1;}
    if(typeof rebuildCoverage==='function')rebuildCoverage();
    if(typeof toast==='function')toast('🏴 Sacked','the holding falls — blood in the rubble'); }
  else if(e.raidAction==='arson'){
    c.burn=6; disasterT=Math.max(disasterT,7); addScar(e.rtx,e.rty,0.4,2);
    for(let k=0;k<1+((Math.random()*2)|0);k++){ const ox=e.rtx+(Math.random()-0.5)*0.9, oy=e.rty+(Math.random()-0.5)*0.9;
      corpses.push({ x:ox,y:oy,t:0,life:28,lethal:true, skin:'#3a2c22', col:'#2a221c', obi:'#241c16', blood:0.4, parts:makeParts(ox,oy,'#3a2c22','#2a221c'), vic:null, vicIsTraffic:false }); }
    if(typeof playFireBell==='function')playFireBell(true);
    if(typeof toast==='function')toast('🔥 Torched','charred bodies in the embers'); } }

function scatterWitnesses(vx,vy){
  for(const r of residents) if(!r.claimed){ const d=Math.hypot(r.x-vx,r.y-vy);
    if(d<3.5){ r.flee=Math.max(r.flee||0,1.8); r.watch=undefined; }
    else if(d<6.5&&!(r.flee>0)){ r.watch=Math.max(r.watch||0,3+Math.random()*2); }
  } }

/* same flee/watch mechanics as scatterWitnesses, wider radii — for the single loudest beat in a
   raid (a structure actually coming down), which reads further across the street than the breach itself */
function scatterWitnessesWide(vx,vy){
  for(const r of residents) if(!r.claimed){ const d=Math.hypot(r.x-vx,r.y-vy);
    if(d<5){ r.flee=Math.max(r.flee||0,2.0); r.watch=undefined; }
    else if(d<9&&!(r.flee>0)){ r.watch=Math.max(r.watch||0,3.5+Math.random()*2); }
  } }

function makeParts(x,y,skin,col){ const parts=[], kinds=['head','arm','arm','leg'];   // flung out, then settle
  for(const k of kinds){ const a=Math.random()*6, sp=0.5+Math.random()*0.9;
    parts.push({ k, x, y, vx:Math.cos(a)*sp, vy:Math.sin(a)*sp*0.6, rest:0, rot:Math.random()*6, skin, col, settled:false }); }
  return parts; }

function strike(e){ const [vx,vy]=vpos(e.vic), lethal=e.outcome==='lethal';
  e.vic.claimed=true;                                       // freeze + drop from normal draw/move
  corpses.push({ x:vx, y:vy, t:0, life:lethal?26:16, lethal, skin:e.vic.skin, col:e.vic.col, obi:e.vic.obi,
    blood:lethal?1:0.55, parts:lethal?makeParts(vx,vy,e.vic.skin,e.vic.col):null,
    vic:e.vic, vicIsTraffic:traffic.indexOf(e.vic)>=0 });
  addScar(e.tx,e.ty, lethal?0.5:0.3, lethal?3:2);            // B-lite local value/demand drag
  scatterWitnesses(vx,vy);
  if(typeof toast==='function') toast(lethal?'☠ A killing in the street':'🩸 A mugging','ronin fell upon a passerby'); }


/* ===== STREET-LIFE / DECAY LAYer (ported from build 29) ===== */
function decayKind(seed, pov){ const r=(seed%1000)/1000;
  if(pov>0.62){ if(r<0.30)return'beggar'; if(r<0.44)return'musician'; if(r<0.54)return'fortune';
                if(r<0.78)return'trash'; if(r<0.92)return'pottery'; return'sewage'; }
  if(r<0.50)return'trash'; if(r<0.78)return'pottery'; if(r<0.90)return'sewage';
  return r<0.96?'beggar':'fortune'; }
function drawLitter(g,cx,cy,z,p){ const s=p.seed||1;
  if(p.kind==='sewage'){ g.fillStyle='rgba(40,46,32,0.42)'; g.beginPath();g.ellipse(cx,cy+1*z,5*z,2.4*z,0,0,7);g.fill();
    g.fillStyle='rgba(70,80,56,0.34)'; g.beginPath();g.ellipse(cx-1*z,cy+0.6*z,2.4*z,1.2*z,0,0,7);g.fill();
    g.fillStyle='rgba(150,160,120,0.18)'; g.beginPath();g.ellipse(cx+1.4*z,cy+1.2*z,1.4*z,0.7*z,0,0,7);g.fill(); return; }   // greasy sheen
  if(p.kind==='pottery'){ g.fillStyle='#9a7a5a';                                                            // broken shards
    for(let k=0;k<5;k++){ const a=(s*7+k*97)%628/100, rr=(1.6+(k%3))*z, ox=Math.cos(a)*rr, oy=Math.sin(a)*rr*0.5;
      g.save(); g.translate(cx+ox,cy+1*z+oy); g.rotate(a);
        g.fillStyle=k%2?'#8a6a48':'#a9885e'; g.beginPath();g.moveTo(-1.2*z,0);g.lineTo(0.6*z,-1*z);g.lineTo(1.3*z,0.4*z);g.closePath();g.fill();
      g.restore(); } return; }
  // trash heap (default)
  g.fillStyle='rgba(60,46,30,0.6)'; g.beginPath();g.ellipse(cx,cy+1.2*z,4*z,1.8*z,0,0,7);g.fill();
  const cols=['#6a5230','#4a5a32','#7a5a3a','#5a4a3a','#8a7a4a'];
  for(let k=0;k<7;k++){ const a=(s*13+k*131)%628/100, rr=(0.6+(k%4)*0.8)*z; g.fillStyle=cols[(s+k)%cols.length];
    g.beginPath();g.arc(cx+Math.cos(a)*rr*1.4,cy+1*z+Math.sin(a)*rr*0.6,(0.6+(k%3)*0.4)*z,0,7);g.fill(); }
  g.fillStyle='#3f8a4a'; g.fillRect(cx-2.4*z,cy-0.2*z,1.4*z,0.8*z);                                          // rotting greens
  if((s%3)===0){ g.fillStyle='rgba(20,16,10,0.7)'; for(let k=0;k<2;k++){ const a=(s+k*200)%628/100; g.beginPath();g.arc(cx+Math.cos(a)*3*z,cy-2*z+Math.sin(a)*1.5*z,0.28*z,0,7);g.fill(); } } }
function drawHumanProp(g,cx,cy,z,a){ if(a.sub==='beggar')drawBeggar(g,cx,cy,z,a); else if(a.sub==='musician')drawMusician(g,cx,cy,z,a); else drawFortune(g,cx,cy,z,a); }
function drawBeggar(g,cx,cy,z,a){ const robe=a.col||'#5a4a3a', skin=a.skin||'#cdb89a', dir=a.dir||1;
  g.fillStyle=shade(robe,-14); g.beginPath();g.moveTo(cx-3*z,cy+1.4*z);g.lineTo(cx+3*z,cy+1.4*z);g.lineTo(cx+2.2*z,cy-2.6*z);g.lineTo(cx-2.2*z,cy-2.6*z);g.closePath();g.fill();  // huddled body
  g.strokeStyle=shade(robe,12); g.lineWidth=0.4*z; for(let k=-2;k<=2;k++){ g.beginPath();g.moveTo(cx+k*1.1*z,cy+1.4*z);g.lineTo(cx+k*1.1*z,cy-2.2*z);g.stroke(); }   // ragged folds
  g.fillStyle=skin; g.beginPath();g.arc(cx,cy-4.2*z,1.9*z,0,7);g.fill();                                   // bowed head
  g.fillStyle='rgba(40,28,18,0.5)'; g.beginPath();g.ellipse(cx,cy-3.6*z,1.5*z,1*z,0,0,7);g.fill();          // face in shadow (despair)
  g.fillStyle='#161210'; g.beginPath();g.arc(cx,cy-5*z,2*z,Math.PI*0.9,Math.PI*0.1,false);g.fill();         // matted hair
  g.fillStyle='#8a6a3a'; g.beginPath();g.ellipse(cx+dir*2.6*z,cy+0.6*z,1.4*z,0.8*z,0,0,7);g.fill();          // alms bowl
  g.strokeStyle='#5a4428'; g.lineWidth=0.35*z; g.beginPath();g.arc(cx+dir*2.6*z,cy+0.4*z,1.3*z,Math.PI,0,true);g.stroke(); }
function drawMusician(g,cx,cy,z,a){ const robe=a.col||'#6a5a4a', skin=a.skin||'#d8ad82';
  g.fillStyle=shade(robe,-12); g.beginPath();g.moveTo(cx-3.2*z,cy+1.4*z);g.lineTo(cx+3.2*z,cy+1.4*z);g.lineTo(cx+2*z,cy-3*z);g.lineTo(cx-2*z,cy-3*z);g.closePath();g.fill();   // cross-legged
  g.fillStyle=skin; g.beginPath();g.arc(cx,cy-5.4*z,2*z,0,7);g.fill();                                       // head, tilted back
  g.fillStyle='#161210'; g.beginPath();g.arc(cx,cy-6.2*z,2.1*z,Math.PI*0.92,Math.PI*0.08,false);g.fill();
  g.strokeStyle='rgba(40,30,20,0.55)'; g.lineWidth=0.32*z; g.beginPath();g.moveTo(cx-1.2*z,cy-5.3*z);g.lineTo(cx-0.3*z,cy-5.3*z);g.stroke(); g.beginPath();g.moveTo(cx+0.3*z,cy-5.3*z);g.lineTo(cx+1.2*z,cy-5.3*z);g.stroke();  // closed (blind) eyes
  // shamisen across the lap
  g.save(); g.translate(cx,cy-2.4*z); g.rotate(-0.42);
    g.fillStyle='#7a5630'; g.fillRect(-1.4*z,-1.4*z,2.8*z,2.8*z);                                            // body
    g.fillStyle='#e8e0d0'; g.fillRect(-1.1*z,-1.1*z,2.2*z,2.2*z);                                            // skin head
    g.strokeStyle='#3a2a1a'; g.lineWidth=0.6*z; g.beginPath();g.moveTo(1*z,0);g.lineTo(8*z,0);g.stroke();    // neck
    g.strokeStyle='#cfc6b2'; g.lineWidth=0.16*z; for(let k=-1;k<=1;k++){g.beginPath();g.moveTo(0,k*0.4*z);g.lineTo(7.6*z,k*0.4*z);g.stroke();}
  g.restore(); }
function drawFortune(g,cx,cy,z,a){ const robe=a.col||'#4a4038', skin=a.skin||'#cdb89a', dir=a.dir||1;
  g.strokeStyle='#7a2d24'; g.lineWidth=0.6*z; g.beginPath();g.moveTo(cx-dir*3*z,cy-9*z);g.lineTo(cx-dir*3*z,cy+1*z);g.stroke();   // banner pole
  g.fillStyle='#7a2d24'; g.fillRect(cx-dir*3.2*z,cy-9*z,2.6*z,4.2*z); g.strokeStyle='#e8c24a'; g.lineWidth=0.3*z; g.strokeRect(cx-dir*3.2*z,cy-9*z,2.6*z,4.2*z);
  g.fillStyle='#e8c24a'; g.beginPath();g.arc(cx-dir*1.9*z,cy-7*z,0.7*z,0,7);g.fill();                        // charm glyph
  g.fillStyle=shade(robe,-10); g.beginPath();g.moveTo(cx-2.8*z,cy+1.4*z);g.lineTo(cx+2.8*z,cy+1.4*z);g.lineTo(cx+1.9*z,cy-3.2*z);g.lineTo(cx-1.9*z,cy-3.2*z);g.closePath();g.fill();  // seated elder
  g.fillStyle=skin; g.beginPath();g.arc(cx,cy-5*z,1.9*z,0,7);g.fill();
  g.fillStyle='#d8d2c4'; g.beginPath();g.arc(cx,cy-5.6*z,2*z,Math.PI,0);g.fill();                            // white hair
  g.strokeStyle='#cfc8ba'; g.lineWidth=0.4*z; g.beginPath();g.moveTo(cx-0.9*z,cy-3.4*z);g.lineTo(cx-0.5*z,cy-1.6*z);g.stroke();   // long beard
  g.fillStyle='#8a6a3a'; g.fillRect(cx-1.6*z,cy+0.2*z,3.2*z,1.4*z);                                          // low table of charms
  g.fillStyle='#c0392b'; g.fillRect(cx-1.2*z,cy-0.2*z,1*z,0.7*z); g.fillStyle='#3f8a4a'; g.fillRect(cx+0.3*z,cy-0.2*z,1*z,0.7*z); }
function drawCritter(g,cx,cy,z,a,dir){ dir=dir||1; const Z=z*(a.scale||0.7), ph=a.ph||0, gait=Math.sin(ph)*0.6*Z, col=a.col||'#6a5240', cat=a.type==='cat';
  const bx=cx, by=cy-1.6*z;
  g.fillStyle=col; g.beginPath(); g.ellipse(bx,by,3.4*Z,1.7*Z,0,0,7); g.fill();                       // body
  g.beginPath(); g.ellipse(bx+dir*3.3*Z,by-1.2*Z,1.5*Z,1.3*Z,0,0,7); g.fill();                        // head
  g.fillStyle=shade(col,-18);                                                                          // legs
  g.fillRect(bx-2.4*Z+gait,by+1*Z,0.8*Z,2.2*Z); g.fillRect(bx+1.6*Z-gait,by+1*Z,0.8*Z,2.2*Z);
  g.strokeStyle=col; g.lineWidth=(cat?0.7:1)*Z; g.beginPath();                                         // tail
  if(cat){ g.moveTo(bx-dir*3.2*Z,by-0.4*Z); g.quadraticCurveTo(bx-dir*5*Z,by-3*Z,bx-dir*4*Z,by-4.4*Z); }
  else { g.moveTo(bx-dir*3.2*Z,by-0.2*Z); g.quadraticCurveTo(bx-dir*5.4*Z,by-1*Z,bx-dir*5.2*Z,by-2.2*Z); }
  g.stroke();
  g.fillStyle=shade(col,-22);                                                                          // ears
  g.beginPath();g.moveTo(bx+dir*2.6*Z,by-2.2*Z);g.lineTo(bx+dir*3.4*Z,by-3.4*Z);g.lineTo(bx+dir*3.8*Z,by-2*Z);g.closePath();g.fill(); }
function syncDecay(){ if(!valueGrid)return; const cands=[];
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const c=grid[y][x];
    if(!(c.dev>0||c.civ===TOWN)||c.burn)continue; if(!roadAdj(x,y)&&!nearRoad(x,y,1))continue;
    const cr=crimeGrid?crimeGrid[y][x]:0; const pov=clamp((1-valueGrid[y][x])*0.8+cr*0.6,0,1);
    if(pov<0.42)continue; cands.push({x,y,pov}); }
  cands.sort((a,b)=>b.pov-a.pov);
  const want=cands.slice(0,Math.min(28,Math.ceil(cands.length*0.5)));
  const wantKey=new Set(want.map(t=>t.y*W+t.x));
  for(let i=decay.length-1;i>=0;i--){ if(!wantKey.has(decay[i].ty*W+decay[i].tx))decay.splice(i,1); }   // recovered tiles clean up
  const have=new Set(decay.map(p=>p.ty*W+p.tx));
  for(const t of want){ const key=t.y*W+t.x; if(have.has(key))continue;
    const seed=((t.x*73856093)^(t.y*19349663))>>>0, kind=decayKind(seed,t.pov);
    const human=(kind==='beggar'||kind==='musician'||kind==='fortune');
    const p={ tx:t.x, ty:t.y, x:t.x+((seed%7)/7-0.5)*0.55, y:t.y+(((seed>>3)%7)/7-0.5)*0.55, seed };
    if(human){ Object.assign(p,{kind:'prop', sub:kind, moving:false, dir:(seed&1)?1:-1,
      skin:SKIN[seed%SKIN.length], col:['#6a5a4a','#5a4a3a','#7a6a58','#4a4038'][seed%4], obi:'#3a2c1a', v:0.12, ph:(seed%628)/100 }); }
    else p.kind=kind;
    decay.push(p); } }
function updateDecay(dt){ decayTimer-=dt; if(decayTimer<=0){ syncDecay(); syncGroupTalk(); decayTimer=3.5+Math.random()*3; } }
/* ===== end street-life ===== */

function updateEncounters(dt){ decayScar(dt);
  if(RONIN_VIOLENCE){ encTimer-=dt; if(encTimer<=0){ spawnEncounter(); encTimer=18+Math.random()*30; } }
  for(let i=encounters.length-1;i>=0;i--){ const e=encounters[i]; e.t+=dt; const [vx,vy]=vpos(e.vic); let near=false;
    if(e.raid){
      const simpleMove=(e.state==='approach'||e.state==='disperse'), leaving=(e.state==='disperse');   // combat states drive their own footwork
      if(simpleMove) for(const m of e.mob){ const dx=vx-m.x,dy=vy-m.y,d=Math.hypot(dx,dy)||1;
        if(leaving){ m.x-=dx/d*m.spd*dt*0.7; m.y-=dy/d*m.spd*dt*0.7; m.dir=dx<0?1:-1; m.ph+=dt*7; }
        else if(d>0.6){ m.x+=dx/d*m.spd*dt; m.y+=dy/d*m.spd*dt; m.dir=dx<0?-1:1; m.ph+=dt*9; }
        else { m.dir=dx<0?-1:1; }
        if(!leaving && d<1.0) near=true; }
      updateRaid(e,dt,near); if(e.state==='gone')encounters.splice(i,1); continue; }
    const leaving=(e.state==='disperse');
    for(const m of e.mob){ if(m.swing>0){ m.swing-=dt; if(m.swing<0)m.swing=0; }
      const dx=vx-m.x,dy=vy-m.y,d=Math.hypot(dx,dy)||1;
      if(leaving){ m.x-=dx/d*m.spd*dt*0.7; m.y-=dy/d*m.spd*dt*0.7; m.dir=dx<0?1:-1; m.ph+=dt*7; }
      else if(d>0.6){ m.x+=dx/d*m.spd*dt; m.y+=dy/d*m.spd*dt; m.dir=dx<0?-1:1; m.ph+=dt*9; }
      else { m.dir=dx<0?-1:1; }                            // arrived: hold and face the target
      if(d<1.0)near=true; }
    switch(e.state){
      case 'approach':
        if(near){ if(e.outcome==='flee'){ e.state='chase'; e.st=0; e.vic.flee=2.4; } else { strike(e); e.state='loot'; e.st=0; } }
        else if(e.t>10) e.state='disperse';
        break;
      case 'chase':  e.st+=dt; if(e.st>2.8) e.state='disperse'; break;     // brief pursuit, victim escapes
      case 'loot':   e.st+=dt; if(e.st>(e.outcome==='lethal'?3:2.2)) e.state='disperse'; break;
      case 'disperse': if(e.t>12||e.mob.every(m=>m.x<-3||m.x>W+3||m.y<-3||m.y>H+3)) encounters.splice(i,1); break;
    } } }

function updateCorpses(dt){ for(let i=corpses.length-1;i>=0;i--){ const c=corpses[i]; c.t+=dt;
    if(c.parts) for(const p of c.parts){ if(!p.settled){ p.x+=p.vx*dt; p.y+=p.vy*dt; p.vx*=0.86; p.vy*=0.86; p.rest+=dt; if(p.rest>0.6)p.settled=true; } }
    if(c.t>=c.life){ const v=c.vic;                          // release the agent back into the sim
      if(v){ v.claimed=false; v.flee=0; if(c.vicIsTraffic&&typeof respawnAgent==='function')respawnAgent(v); else { v.pause=2.5; if(v.home){ v.x=v.home[0]; v.y=v.home[1]; v.goal='home'; } } }
      corpses.splice(i,1); } } }

/* ---- painterly drawing ---- */
function drawBlood(g,cx,cy,z,intensity){ g.save(); g.globalCompositeOperation='multiply';
  const r=(3+intensity*5)*z;
  const grad=g.createRadialGradient(cx,cy,0,cx,cy,r);
  grad.addColorStop(0,'rgba(120,14,16,0.88)'); grad.addColorStop(0.55,'rgba(96,10,14,0.5)'); grad.addColorStop(1,'rgba(74,8,12,0)');
  g.fillStyle=grad; g.beginPath(); g.ellipse(cx,cy,r,r*0.5,0,0,7); g.fill();
  g.strokeStyle='rgba(82,8,12,0.5)';                          // ink-bleed tendrils creeping on the paper
  for(let k=0;k<3+intensity*5;k++){ const a=k*1.9+intensity, len=r*(0.5+(k%3)*0.3); g.lineWidth=(0.3+(k%2)*0.4)*z;
    g.beginPath(); g.moveTo(cx,cy); g.quadraticCurveTo(cx+Math.cos(a)*len*0.5,cy+Math.sin(a)*len*0.3, cx+Math.cos(a)*len,cy+Math.sin(a)*len*0.5); g.stroke(); }
  g.fillStyle='rgba(110,12,14,0.7)';                          // splatter dots
  for(let k=0;k<4+intensity*6;k++){ const a=k*2.3,d=r*(0.4+(k%4)*0.22); g.beginPath(); g.arc(cx+Math.cos(a)*d,cy+Math.sin(a)*d*0.55,(0.3+(k%3)*0.25)*z,0,7); g.fill(); }
  g.restore(); }

function drawPart(g,cx,cy,z,p){ const s=z; g.save(); g.translate(cx,cy); g.rotate(p.rot);
  if(p.k==='head'){ g.fillStyle=p.skin||'#d8ad82'; g.beginPath();g.arc(0,0,2*s,0,7);g.fill();
    g.fillStyle='#141014'; g.beginPath();g.arc(0,-0.4*s,2.1*s,Math.PI*0.85,Math.PI*0.15,false);g.fill();
    g.fillStyle='rgba(120,12,14,0.85)'; g.beginPath();g.arc(0,1.7*s,1*s,0,7);g.fill(); }              // neck stump
  else if(p.k==='leg'){ g.fillStyle=shade(p.col||'#4a3c44',-8); g.beginPath();g.ellipse(0,0,1.1*s,3*s,0,0,7);g.fill();
    g.fillStyle='rgba(120,12,14,0.85)'; g.beginPath();g.arc(0,-2.7*s,0.9*s,0,7);g.fill(); }
  else { g.fillStyle=p.skin||'#d8ad82'; g.beginPath();g.ellipse(0,0,0.9*s,2.4*s,0,0,7);g.fill();
    g.fillStyle='rgba(120,12,14,0.85)'; g.beginPath();g.arc(0,-2.1*s,0.8*s,0,7);g.fill(); }            // arm
  g.restore(); }

function drawCorpse(g,cx,cy,z,c){ const fade=Math.max(0,Math.min(1,(c.life-c.t)/4)); g.globalAlpha=fade;
  drawBlood(g,cx,cy+1*z,z,c.blood);
  if(c.lethal){
    g.fillStyle=shade(c.col||'#4a3c44',-14); g.beginPath();g.ellipse(cx,cy-1*z,3.2*z,1.8*z,0,0,7);g.fill();   // headless trunk
    g.fillStyle='rgba(120,12,14,0.85)'; g.beginPath();g.arc(cx+1.2*z,cy-2*z,1.1*z,0,7);g.fill();               // neck wound
    if(c.parts) for(const p of c.parts){ const[px,py]=s2(p.x,p.y); drawBlood(g,px,py+1*z,z,0.4); drawPart(g,px,py,z,p); }
  } else {
    g.fillStyle=shade(c.col||'#6a5a44',-10); g.beginPath();g.ellipse(cx,cy-1*z,3.4*z,1.7*z,0,0,7);g.fill();    // slumped body
    g.fillStyle=c.skin||'#d8ad82'; g.beginPath();g.arc(cx-3*z,cy-1.4*z,1.6*z,0,7);g.fill();                    // head to the side
    g.fillStyle='#141014'; g.beginPath();g.arc(cx-3*z,cy-1.8*z,1.7*z,Math.PI*0.85,Math.PI*0.1,false);g.fill();
  }
  g.globalAlpha=1; }

const CUTS={ chop:{py:-7.4, a0:-2.2,  a1:0.55, len:12,   blurW:1.5},
             diag:{py:-8.1, a0:-1.65, a1:1.3,  len:12.5, blurW:1.4},
             sweep:{py:-6.0,a0:0.2,   a1:-3.0, len:13.5, blurW:1.8} };

function drawRonin(g,cx,cy,z,a,dir){ dir=dir||1; z=z*(a.build||1); const ph=a.ph||0, sw=Math.sin(ph), bob=Math.abs(Math.sin(ph))*0.7*z;
  const robe=a.col||'#2c2a30', skin=a.skin||'#d8ad82', hs=a.hairSeed||0;
  /* ---- weight shift / footwork: the WHOLE body leans back on the windup, then drives forward
     into the cut — real stance mechanics, not just an arm swinging in place. ---- */
  let lunge=0, leanAng=0;
  if(a.dodgeT>0){ const p=a.dodgeT/0.24; lunge+=(a.dodgeDX||1)*1.6*p; leanAng+=0.08*Math.sign(a.dodgeDX||1)*p; }   // snapping out of a cut's path
  if(a.blockT>0){ leanAng+=-0.06*dir; }                                                                          // braced low behind the blade
  if(a.wind>0){ const p=1-(a.wind/(a.windMax||0.2)); lunge+=-1.3*p*dir; leanAng+=-0.10*dir*p; }
  else if(a.swing>0){ const p=1-(a.swing/(a.swingMax||0.4));
    const Ltab={chop:1.7,diag:2.0,sweep:1.4,thrust:3.6}; const L=Ltab[a.swingType]||1.7;
    const fp=Math.sin(Math.min(1,p*1.25)*Math.PI); lunge+=L*fp*dir; leanAng+=0.12*dir*fp; }
  g.save(); g.translate(cx+lunge*z,cy); g.rotate(leanAng); cx=0; cy=0;
  const fL=cx+(-1.7+sw*0.8)*z, fR=cx+(0.3-sw*0.8)*z, fy=cy+1.4*z;                                                                      // foot anchors, reused below for zori straps
  g.fillStyle='#211b17'; g.fillRect(fL,fy,1.4*z,1.5*z); g.fillRect(fR,fy,1.4*z,1.5*z);                                                 // feet
  g.strokeStyle='#3a322c'; g.lineWidth=0.22*z;                                                                                         // straw zori thong crossing the instep — bare-foot ronin, not booted
  g.beginPath();g.moveTo(fL+0.7*z,fy);g.lineTo(fL+0.3*z,fy+0.5*z);g.moveTo(fL+0.7*z,fy);g.lineTo(fL+1.1*z,fy+0.5*z);g.stroke();
  g.beginPath();g.moveTo(fR+0.7*z,fy);g.lineTo(fR+0.3*z,fy+0.5*z);g.moveTo(fR+0.7*z,fy);g.lineTo(fR+1.1*z,fy+0.5*z);g.stroke();
  g.fillStyle=shade(robe,-18); g.beginPath(); g.moveTo(cx-2.6*z,cy+1.6*z);g.lineTo(cx+2.6*z,cy+1.6*z);g.lineTo(cx+1.9*z,cy-3*z-bob);g.lineTo(cx-1.9*z,cy-3*z-bob);g.closePath();g.fill();   // tattered hakama
  g.strokeStyle=shade(robe,10); g.lineWidth=0.4*z; for(let k=-2;k<=2;k++){ const jx=Math.sin(hs+k*1.3)*0.5; g.beginPath();g.moveTo(cx+k*1.0*z,cy+1.6*z);g.lineTo(cx+k*1.0*z+(sw+jx)*0.4*z,cy+(2.3+Math.abs(jx)*0.3)*z);g.stroke(); }   // frayed hem, ragged length varies per ronin
  if(a.patch){ const pk=Math.sin(hs*3)>0?1:-1, px=cx+pk*1.3*z, py=cy-0.6*z;                                                            // scavenged mismatched-dye patch — poverty detail, deliberately asymmetric
    g.save();g.translate(px,py);g.rotate(hs*0.3); g.fillStyle=shade(robe,pk>0?22:-30); g.fillRect(-0.7*z,-0.6*z,1.4*z,1.2*z);
    g.strokeStyle=shade(robe,-35); g.lineWidth=0.15*z; g.strokeRect(-0.7*z,-0.6*z,1.4*z,1.2*z); g.restore(); }
  g.fillStyle=a.obi||'#3a2230'; g.fillRect(cx-2*z,cy-3.6*z-bob,4*z,1.3*z);                                                            // sash
  g.fillStyle=shade(a.obi||'#3a2230',-20); g.beginPath();g.moveTo(cx+1.8*z,cy-2.3*z-bob);g.lineTo(cx+3.1*z,cy-1.5*z-bob);g.lineTo(cx+2.7*z,cy-0.6*z-bob);g.lineTo(cx+1.5*z,cy-1.2*z-bob);g.closePath();g.fill();   // trailing obi tail, sways loose at the hip
  // ---- torso: squared kimono shoulders + a hanging off-sword sleeve, so the top reads as a clothed human rather than a flat trapezoid ----
  const shY=cy-7*z-bob, shW=2.7*z;                                                                                                    // shoulder line — wider than the waist
  g.fillStyle=shade(robe,-16); g.beginPath();                                                                                         // off-sword sleeve, hanging open (behind the body)
    g.moveTo(cx-shW*0.7,cy-6.8*z-bob);g.lineTo(cx-shW-1*z,shY+0.4*z);g.lineTo(cx-shW-0.4*z,cy-3.6*z-bob);g.lineTo(cx-1.4*z,cy-3.6*z-bob);g.closePath();g.fill();
  g.fillStyle=robe; g.beginPath();                                                                                                    // body
    g.moveTo(cx-2.2*z,cy-3.6*z-bob);g.lineTo(cx+2.2*z,cy-3.6*z-bob);g.lineTo(cx+shW,shY);
    g.lineTo(cx+shW*0.5,cy-7.3*z-bob);g.lineTo(cx-shW*0.5,cy-7.3*z-bob);g.lineTo(cx-shW,shY);g.closePath();g.fill();
  // ---- neck + kimono cross-collar (replaces the oversized bare-chest triangle that read as a downward 'face') ----
  const hcx=cx, hcy=cy-9.3*z-bob;                                                                                                     // head anchor raised to clear a neck; all headgear below follows hcy
  g.fillStyle=shade(skin,-16); g.beginPath();g.moveTo(hcx-0.95*z,hcy+1.8*z);g.lineTo(hcx+0.95*z,hcy+1.8*z);g.lineTo(hcx+0.8*z,cy-6.5*z-bob);g.lineTo(hcx-0.8*z,cy-6.5*z-bob);g.closePath();g.fill();   // neck
  g.fillStyle=shade(skin,-8); g.beginPath();g.moveTo(cx-0.5*z,cy-6.9*z-bob);g.lineTo(cx+0.5*z,cy-6.9*z-bob);g.lineTo(cx+0.26*z,cy-4.6*z-bob);g.lineTo(cx-0.26*z,cy-4.6*z-bob);g.closePath();g.fill();  // narrow exposed throat/chest, a sliver not a slab
  const colW=0.85*z;
  g.fillStyle=shade(robe,-18); g.beginPath();                                                                                         // RIGHT collar band (under-lap)
    g.moveTo(cx+shW*0.5,cy-7.2*z-bob);g.lineTo(cx+shW*0.5-colW,cy-7.2*z-bob);g.lineTo(cx+0.05*z,cy-4.5*z-bob);g.lineTo(cx+0.6*z,cy-4.3*z-bob);g.closePath();g.fill();
  g.fillStyle=shade(robe,14); g.beginPath();                                                                                          // LEFT collar band (over-lap, catches light)
    g.moveTo(cx-shW*0.5,cy-7.2*z-bob);g.lineTo(cx-shW*0.5+colW,cy-7.2*z-bob);g.lineTo(cx-0.05*z,cy-4.5*z-bob);g.lineTo(cx-0.6*z,cy-4.3*z-bob);g.closePath();g.fill();
  g.strokeStyle=shade(robe,-34); g.lineWidth=0.13*z; g.beginPath();g.moveTo(cx-0.6*z,cy-4.3*z-bob);g.lineTo(cx-shW*0.5,cy-7.2*z-bob);g.stroke();   // collar fold shadow
  g.strokeStyle=shade(skin,-34); g.lineWidth=0.16*z; g.beginPath();g.moveTo(cx-0.05*z,cy-6.6*z-bob);g.lineTo(cx+0.12*z,cy-5.2*z-bob);g.stroke();   // faint old scar on the throat
  if(a.bandage){ g.save();g.translate(cx+(-2*dir)*z,cy-6.2*z-bob);g.rotate(0.3*dir);                                                   // wound wrap on the off-sword forearm — wears the cost of past fights
    g.fillStyle='rgba(214,202,182,0.92)'; g.fillRect(-0.5*z,-1.6*z,1*z,3.2*z);
    g.strokeStyle='rgba(150,40,40,0.4)'; g.lineWidth=0.12*z; g.beginPath();g.moveTo(-0.4*z,-0.6*z);g.lineTo(0.4*z,-0.2*z);g.stroke(); g.restore(); }
  g.fillStyle=skin; g.beginPath();g.ellipse(hcx,hcy,2.4*z,2.55*z,0,0,7);g.fill();                                                      // head — barely oval; the jaw shadow below supplies the chin taper
  g.fillStyle=shade(skin,-12); g.beginPath();g.ellipse(hcx-0.1*z,hcy+1.55*z,1.5*z,0.85*z,0,Math.PI*0.05,Math.PI*0.95);g.fill();       // chin / jaw underside shadow
  const hg=a.headgear||'none';
  if(hg==='kasa'){                                                                         // woven straw hat, low over the eyes
    g.fillStyle='#c2a875'; g.beginPath();g.ellipse(hcx,hcy-1.4*z,3.4*z,1.3*z,0,0,7);g.fill();
    g.strokeStyle='#8a7148'; g.lineWidth=0.3*z; for(let k=-2;k<=2;k++){ g.beginPath();g.arc(hcx,hcy-1.4*z,3.4*z*(0.4+Math.abs(k)*0.18),0,Math.PI,true);g.stroke(); }
    g.fillStyle='#141014'; g.beginPath();g.arc(hcx,hcy+0.2*z,1.9*z,Math.PI*0.85,Math.PI*0.15,false);g.fill(); }
  else if(hg==='hachimaki'){                                                                // headband over loose wild hair
    g.fillStyle='#141014'; g.beginPath();g.arc(hcx,hcy-0.3*z,2.5*z,Math.PI*0.85,Math.PI*0.15,false);g.fill();
    g.strokeStyle='#141014'; g.lineWidth=0.5*z; for(let k=-3;k<=3;k++){ const hx=hcx+k*0.7*z; g.beginPath();g.moveTo(hx,hcy-1.6*z);g.lineTo(hx+(k*0.5+sw)*0.5*z,hcy-3.3*z);g.stroke(); }
    g.fillStyle=a.obi||'#c0392b'; g.fillRect(hcx-2.3*z,hcy-1.5*z,4.6*z,0.7*z);
    g.fillStyle=shade(a.obi||'#c0392b',-15); g.beginPath();g.moveTo(hcx+2.3*z,hcy-1.2*z);g.lineTo(hcx+3.6*z,hcy-0.6*z);g.lineTo(hcx+2.3*z,hcy-0.2*z);g.closePath();g.fill(); }     // trailing knot-tail
  else if(hg==='shave'){                                                                    // shaved pate, ronin gone to seed
    g.fillStyle='#141014'; g.beginPath();g.arc(hcx,hcy+0.3*z,2.2*z,Math.PI*0.05,Math.PI*0.95,false);g.fill();
    g.strokeStyle=shade(skin,-20); g.lineWidth=0.25*z; g.beginPath();g.moveTo(hcx-1.6*z,hcy-1*z);g.lineTo(hcx+1.6*z,hcy-1*z);g.stroke(); }
  else if(hg==='topknot'){                                                                  // disciplined chonmage, shaved sides
    g.fillStyle='#141014'; g.beginPath();g.arc(hcx,hcy-0.2*z,2.1*z,Math.PI*0.55,Math.PI*0.45,false);g.fill();
    g.fillStyle='#141014'; g.beginPath();g.ellipse(hcx,hcy-2.6*z,0.9*z,0.5*z,0,0,7);g.fill();
    g.fillStyle='#141014'; g.fillRect(hcx-0.3*z,hcy-3.3*z,0.6*z,1.3*z); }
  else if(hg==='menpo'){                                                                    // iron half-mask, veteran reading as genuinely dangerous — distinct silhouette vs the bare-faced crowd
    g.fillStyle='#141014'; g.beginPath();g.arc(hcx,hcy-0.3*z,2.5*z,Math.PI*0.85,Math.PI*0.15,false);g.fill();                          // hair still visible above the mask line
    g.fillStyle=shade('#3a3530',-10); g.beginPath();g.moveTo(hcx-2*z,hcy-0.3*z);g.lineTo(hcx+2*z,hcy-0.3*z);g.lineTo(hcx+1.7*z,hcy+2.1*z);g.lineTo(hcx,hcy+2.5*z);g.lineTo(hcx-1.7*z,hcy+2.1*z);g.closePath();g.fill();   // riveted iron plate, jaw to cheekbone
    g.strokeStyle='#1a1714'; g.lineWidth=0.18*z; g.beginPath();g.moveTo(hcx-1.4*z,hcy+0.9*z);g.lineTo(hcx+1.4*z,hcy+0.9*z);g.stroke();   // hinge seam
    g.fillStyle='#0c0a08'; for(const rx of[-1.5,1.5]){ g.beginPath();g.arc(hcx+rx*z,hcy+0.1*z,0.18*z,0,7);g.fill(); }                  // rivets
  }
  else { g.fillStyle='#141014'; g.beginPath();g.arc(hcx,hcy-0.3*z,2.5*z,Math.PI*0.85,Math.PI*0.15,false);g.fill();                     // wild matted hair (default)
    g.strokeStyle='#141014'; g.lineWidth=0.5*z; for(let k=-3;k<=3;k++){ const hx=hcx+k*0.7*z; g.beginPath();g.moveTo(hx,hcy-1.6*z);g.lineTo(hx+(k*0.5+sw+Math.sin(hs+k))*0.5*z,hcy-(3.3+Math.abs(Math.sin(hs+k*2))*1.2)*z);g.stroke(); } }
  if(a.scar&&hg!=='menpo'){ g.strokeStyle='rgba(150,110,100,0.55)'; g.lineWidth=0.35*z;                  // old battle scar across the face — hidden under the menpo, which tells its own story instead
    g.beginPath();g.moveTo(hcx-1.6*z,hcy-1.2*z);g.lineTo(hcx+0.6*z,hcy+1.3*z);g.stroke(); }
  if(a.armor){ g.fillStyle=shade(robe,-25); g.beginPath();g.moveTo(cx-2.3*z,cy-6.6*z-bob);g.lineTo(cx-0.6*z,cy-7.6*z-bob);g.lineTo(cx-0.6*z,cy-4.6*z-bob);g.lineTo(cx-2.1*z,cy-4.2*z-bob);g.closePath();g.fill();   // single battered shoulder plate, salvaged not matched
    g.strokeStyle=shade(robe,-40); g.lineWidth=0.25*z; g.beginPath();g.moveTo(cx-2*z,cy-6*z-bob);g.lineTo(cx-0.8*z,cy-6.6*z-bob);g.stroke(); }
  // ---- face: brow, paired eyes, nose, hard-set mouth — reads as a face instead of a single dark bar ----
  if(hg!=='menpo'){
    g.strokeStyle='rgba(30,18,16,0.5)'; g.lineWidth=0.5*z; g.lineCap='round';                                                        // brow shadow tucked under the hairline
    g.beginPath();g.moveTo(hcx-1.45*z,hcy-0.45*z);g.lineTo(hcx-0.2*z,hcy-0.25*z);g.moveTo(hcx+1.45*z,hcy-0.45*z);g.lineTo(hcx+0.2*z,hcy-0.25*z);g.stroke();
    g.fillStyle='rgba(22,14,14,0.85)';                                                                                                // two narrow eyes — a wary, hardened stare
    g.beginPath();g.ellipse(hcx-0.85*z,hcy+0.2*z,0.45*z,0.28*z,-0.15,0,7);g.fill();
    g.beginPath();g.ellipse(hcx+0.85*z,hcy+0.2*z,0.45*z,0.28*z,0.15,0,7);g.fill();
    g.lineCap='butt'; g.strokeStyle=shade(skin,-30); g.lineWidth=0.17*z;                                                              // nose ridge
    g.beginPath();g.moveTo(hcx+0.08*z,hcy+0.15*z);g.lineTo(hcx-0.12*z,hcy+1.05*z);g.stroke();
    g.strokeStyle='rgba(70,44,40,0.45)'; g.lineWidth=0.16*z; g.beginPath();g.moveTo(hcx-0.6*z,hcy+1.6*z);g.lineTo(hcx+0.6*z,hcy+1.6*z);g.stroke();   // mouth, set hard
  } else {
    g.fillStyle='rgba(18,9,11,0.6)'; g.fillRect(hcx-1.5*z,hcy-0.5*z,3*z,0.7*z);                                                       // shadowed slit above the iron mask
    g.save(); g.globalCompositeOperation='lighter'; g.fillStyle='rgba(210,80,50,0.55)';                                              // cold glint of eyes behind the menpo
    g.beginPath();g.arc(hcx-0.8*z,hcy-0.15*z,0.22*z,0,7);g.fill();g.beginPath();g.arc(hcx+0.8*z,hcy-0.15*z,0.22*z,0,7);g.fill(); g.restore();
  }
  const bx=cx+(2.4*dir)*z, by=cy-5.4*z-bob;                                                                                            // drawn katana
  if(a.wind>0){                                                                          // ready stance — blade cocked for the coming cut
    g.strokeStyle='#2a2622'; g.lineWidth=0.7*z;
    if(a.swingType==='thrust'){ const hx=cx+(-2.2*dir)*z, hy=cy-6*z-bob;                 // drawn back at the hip, point trailing
      g.beginPath();g.moveTo(cx+(0.8*dir)*z,cy-5.4*z-bob);g.lineTo(hx,hy);g.stroke();
      g.save();g.translate(hx,hy);g.rotate(dir>0?Math.PI*0.92:Math.PI*0.08);
        g.fillStyle='#aeb8bd';g.beginPath();g.moveTo(0,-0.4*z);g.lineTo(5.5*z,-0.22*z);g.lineTo(5.9*z,0);g.lineTo(5.5*z,0.22*z);g.lineTo(0,0.4*z);g.closePath();g.fill();
      g.restore(); }
    else if(a.swingType==='sweep'){ const hx=cx+(-2.6*dir)*z, hy=cy-5.6*z-bob;            // cocked low to the side
      g.beginPath();g.moveTo(cx+(1*dir)*z,cy-5*z-bob);g.lineTo(hx,hy);g.stroke();
      g.save();g.translate(hx,hy);g.rotate(dir>0?2.5:Math.PI-2.5);
        g.fillStyle='#aeb8bd';g.beginPath();g.moveTo(0,-0.4*z);g.lineTo(6*z,-0.24*z);g.lineTo(6.4*z,0);g.lineTo(6*z,0.24*z);g.lineTo(0,0.4*z);g.closePath();g.fill();
      g.restore(); }
    else { const hx=cx+(-1.1*dir)*z, hy=cy-11.5*z-bob;                                   // chop/diag — raised high overhead
      g.beginPath();g.moveTo(cx+(0.6*dir)*z,cy-7.2*z-bob);g.lineTo(hx,hy);g.stroke();
      g.save();g.translate(hx,hy);g.rotate(dir>0?-1.0:Math.PI+1.0);
        g.fillStyle='#aeb8bd';g.beginPath();g.moveTo(0,-0.4*z);g.lineTo(6.5*z,-0.24*z);g.lineTo(6.9*z,0);g.lineTo(6.5*z,0.24*z);g.lineTo(0,0.4*z);g.closePath();g.fill();
      g.restore(); }
  } else if(!a.swing&&a.weapon==='yari'){                                                  // idle: spear held upright over the shoulder — reads at a glance vs the katana crowd
    const sx=cx+(1.8*dir)*z, sy0=cy+1.6*z-bob, sy1=cy-13*z-bob;
    g.strokeStyle='#3a2c20'; g.lineWidth=0.55*z; g.beginPath();g.moveTo(sx,sy0);g.lineTo(sx-0.4*dir*z,sy1);g.stroke();
    g.save(); g.translate(sx-0.4*dir*z,sy1); g.rotate(dir>0?-0.08:Math.PI+0.08);
      g.fillStyle='#aeb8bd'; g.beginPath();g.moveTo(0,-0.45*z);g.lineTo(2.6*z,0);g.lineTo(0,0.45*z);g.lineTo(-0.4*z,0);g.closePath();g.fill();
    g.restore();
  } else if(!a.swing){
  const sayaX=cx+(-1.6*dir)*z;                                                                                                       // empty scabbard tucked through the obi, opposite hip from the drawn blade
  g.save(); g.translate(sayaX,cy-3.2*z-bob); g.rotate(dir>0?-0.35:Math.PI+0.35);
    g.fillStyle=shade(robe,-30); g.fillRect(-0.55*z,0,1.1*z,6.4*z);
    g.fillStyle='#c9a24a'; g.fillRect(-0.6*z,0.3*z,1.2*z,0.5*z); g.fillRect(-0.6*z,2*z,1.2*z,0.4*z);                                  // two binding wraps (sageo mounts)
  g.restore();
  g.strokeStyle='#2a2622'; g.lineWidth=0.7*z; g.beginPath();g.moveTo(cx+(1.4*dir)*z,cy-4.6*z-bob);g.lineTo(bx,by);g.stroke();
  g.save(); g.translate(bx,by); g.rotate(dir>0?-0.5:Math.PI+0.5);
    g.fillStyle='#c9a24a'; g.fillRect(-0.5*z,-0.6*z,1.4*z,1.2*z);                                                                      // tsuba
    g.strokeStyle='#1e1b18'; g.lineWidth=0.8*z; g.beginPath();g.moveTo(-2.2*z,0);g.lineTo(0,0);g.stroke();                            // grip
    const bl=g.createLinearGradient(0,-0.4*z,9*z,0); bl.addColorStop(0,'#e8eef0'); bl.addColorStop(1,'#aeb8bd');
    g.fillStyle=bl; g.beginPath();g.moveTo(1*z,-0.55*z);g.lineTo(9*z,-0.35*z);g.lineTo(9.4*z,0);g.lineTo(9*z,0.2*z);g.lineTo(1*z,0.4*z);g.closePath();g.fill();
    g.strokeStyle='rgba(255,255,255,0.6)'; g.lineWidth=0.18*z; g.beginPath();g.moveTo(1.4*z,-0.3*z);g.lineTo(8.8*z,-0.15*z);g.stroke();
  g.restore();
  } else if(a.swingType==='thrust'){                                                     // mid-swing: linear lunging thrust
    const p=1-a.swing/(a.swingMax||0.4), ext=Math.sin(Math.min(1,p*1.2)*Math.PI)*11, sy=cy-6.6*z-bob;
    g.save(); g.globalCompositeOperation='lighter'; g.strokeStyle='rgba(255,250,235,'+(0.4*(1-p))+')'; g.lineWidth=1.2*z;
    g.beginPath(); g.moveTo(cx+(1.5*dir)*z,sy); g.lineTo(cx+(1.5*dir+ext*0.8*dir)*z,sy); g.stroke(); g.restore();
    g.save(); g.translate(cx+(1.5*dir)*z,sy); g.rotate(dir>0?0:Math.PI);
      const bl3=g.createLinearGradient(0,-0.5*z,ext*z,0); bl3.addColorStop(0,'#e8eef0'); bl3.addColorStop(1,'#aeb8bd');
      g.fillStyle=bl3; g.beginPath();g.moveTo(0,-0.5*z);g.lineTo(ext*z,-0.22*z);g.lineTo((ext+0.5)*z,0);g.lineTo(ext*z,0.22*z);g.lineTo(0,0.5*z);g.closePath();g.fill();
      g.fillStyle='rgba(120,10,14,0.6)'; g.beginPath();g.arc(ext*0.7*z,0,0.45*z,0,7);g.fill();
    g.restore();
    if(p>0.7){ g.save(); g.globalCompositeOperation='lighter'; g.fillStyle='rgba(255,90,40,0.5)';
      g.beginPath();g.arc(cx+(1.5*dir+ext)*z,sy,2.6*z,0,7);g.fill(); g.restore(); }
  } else {                                                                                // mid-swing: chop / diag / sweep — each its own arc + anchor height
    const cut=CUTS[a.swingType]||CUTS.chop;
    const p=1-a.swing/(a.swingMax||0.4), a0=cut.a0*dir, a1=cut.a1*dir, ang=a0+(a1-a0)*p, hcx2=cx, hcy2=cy+cut.py*z-bob;
    g.save(); g.globalCompositeOperation='lighter'; g.strokeStyle='rgba(255,250,235,'+(0.45*(1-p))+')'; g.lineWidth=cut.blurW*z;   // motion-blur crescent
    g.beginPath(); g.arc(hcx2,hcy2,cut.len*0.85*z,a0,ang,dir<0); g.stroke(); g.restore();
    g.save(); g.translate(hcx2,hcy2); g.rotate(ang);
      const bl2=g.createLinearGradient(0,0,cut.len*z,0); bl2.addColorStop(0,'#e8eef0'); bl2.addColorStop(1,'#aeb8bd');
      g.fillStyle=bl2; g.beginPath();g.moveTo(2*z,-0.6*z);g.lineTo(cut.len*z,-0.32*z);g.lineTo((cut.len+0.6)*z,0);g.lineTo(cut.len*z,0.32*z);g.lineTo(2*z,0.6*z);g.closePath();g.fill();
      g.fillStyle='rgba(120,10,14,0.65)'; for(let k=0;k<3;k++){ g.beginPath();g.arc((cut.len*0.4+k*2.2)*z,(k%2?0.4:-0.4)*z,0.5*z,0,7);g.fill(); }   // blood on the blade
    g.restore();
    if(p>0.78){ g.save(); g.globalCompositeOperation='lighter'; g.fillStyle='rgba(255,90,40,0.5)';                            // impact spark
      g.beginPath();g.arc(cx+(3*dir)*z,cy-1*z,3*z,0,7);g.fill(); g.restore(); }
  }
  if(a.torch){ const txp=cx+(-2.6*dir)*z, typ=cy-6.4*z-bob;                                  // raised torch (arson warband)
    g.strokeStyle='#5a3a1e'; g.lineWidth=1.1*z; g.beginPath();g.moveTo(cx+(-1.5*dir)*z,cy-4.2*z-bob);g.lineTo(txp,typ);g.stroke();
    g.save(); g.globalCompositeOperation='lighter'; const fl=0.7+0.3*Math.sin((a.ph||0)*2+cx);
    const tg=g.createRadialGradient(txp,typ-2*z,0,txp,typ-2*z,5.5*z); tg.addColorStop(0,'rgba(255,210,90,'+(0.9*fl)+')'); tg.addColorStop(0.5,'rgba(255,120,30,0.55)'); tg.addColorStop(1,'rgba(200,40,10,0)');
    g.fillStyle=tg; g.beginPath();g.arc(txp,typ-2*z,5.5*z,0,7);g.fill();
    g.fillStyle='rgba(255,240,200,0.95)'; g.beginPath();g.ellipse(txp,typ-2.4*z,1.1*z,2.6*z,0,0,7);g.fill(); g.restore(); }
  g.restore();
  }

/* ---- persistent ground blood pool: painted ink-bleed, lingers ~40s then fades ---- */
function drawStain(g,cx,cy,z,s){ const k=Math.min(1,s.t*3+0.25)*Math.max(0,Math.min(1,(s.life-s.t)/8));
  if(k<=0.01)return; g.save(); g.globalCompositeOperation='multiply'; g.globalAlpha=0.55*k*(0.55+s.amt*0.5);
  const r=(4+s.amt*7)*z, grad=g.createRadialGradient(cx,cy,0,cx,cy,r);
  grad.addColorStop(0,'rgba(92,8,12,0.92)'); grad.addColorStop(0.6,'rgba(70,6,10,0.5)'); grad.addColorStop(1,'rgba(54,6,10,0)');
  g.fillStyle=grad; g.beginPath();g.ellipse(cx,cy,r,r*0.5,0,0,7);g.fill();
  g.fillStyle='rgba(78,7,11,0.5)';                                                          // irregular lobes so it reads painted
  for(let i=0;i<4;i++){ const a=s.seed+i*1.7, rr=r*(0.45+((i*7)%4)*0.16);
    g.beginPath();g.ellipse(cx+Math.cos(a)*rr*0.7,cy+Math.sin(a)*rr*0.35,rr*0.4,rr*0.22,a,0,7);g.fill(); }
  g.restore(); }

/* ---- flung structural debris / embers, with a ground shadow while airborne ---- */
function drawDebris(g,cx,cy,z,d){ const k=Math.max(0,Math.min(1,(d.life-d.t)/0.5));
  if(d.h>0.6){ g.save(); g.globalAlpha=0.16*k; g.fillStyle='#000'; g.beginPath();g.ellipse(cx,cy,d.r*1.1*z,d.r*0.5*z,0,0,7);g.fill(); g.restore(); }
  g.save(); g.globalAlpha=k; g.translate(cx,cy-d.h*z); g.rotate(d.rot);
  if(d.ember){ g.globalCompositeOperation='lighter'; g.fillStyle='rgba(255,170,60,'+(0.85*k)+')'; g.beginPath();g.arc(0,0,d.r*0.6*z,0,7);g.fill(); }
  else { g.fillStyle=d.col; g.fillRect(-d.r*z,-d.r*0.5*z,d.r*2*z,d.r*z); g.strokeStyle='rgba(18,12,8,0.55)'; g.lineWidth=0.3*z; g.strokeRect(-d.r*z,-d.r*0.5*z,d.r*2*z,d.r*z); }
  g.restore(); }

/* ---- airborne blood droplet with a short motion streak ---- */
function drawSpray(g,cx,cy,z,p){ const k=Math.max(0,Math.min(1,(p.max-p.life)/0.3));
  g.save(); g.translate(cx,cy-p.h*z); g.strokeStyle='rgba(120,10,14,'+(0.5*k)+')'; g.lineWidth=p.r*0.7*z;
  g.beginPath();g.moveTo(0,0);g.lineTo(-p.vx*0.9*z,-p.vy*0.9*z);g.stroke();
  g.fillStyle='rgba(150,14,16,'+(0.9*k)+')'; g.beginPath();g.arc(0,0,p.r*z,0,7);g.fill(); g.restore(); }

/* ---- bright white-hot steel-on-steel/staff spark burst — a parried blow, not a landed one ---- */
function drawClashSpark(g,cx,cy,z,p){ const k=Math.max(0,1-p.life/p.max);
  g.save(); g.translate(cx,cy-p.h*z); g.globalCompositeOperation='lighter';
  g.strokeStyle='rgba(255,244,210,'+(0.85*k)+')'; g.lineWidth=0.5*z;
  g.beginPath();g.moveTo(0,0);g.lineTo(-p.vx*0.6*z,-p.vy*0.6*z);g.stroke();
  g.fillStyle='rgba(255,250,225,'+k+')'; g.beginPath();g.arc(0,0,0.7*z*k,0,7);g.fill();
  g.restore(); }

/* ---- damage overlay painted over a still-standing raided building: blood down the eaves,
   structural cracks, a collapse dust-shroud, and extra black smoke for arson ---- */
function drawRaidDamage(g,cx,cy,z,e){ const d=e.dmg||0; if(d<0.02)return; const arson=e.raidAction==='arson';
  if(e.state==='collapse'){
    let shk, lean=0;
    if(e.st<0.6){ const lp=e.st/0.6; shk=lp*0.35; lean=lp*lp*0.05; }              // LEAN: tremor builds, structure visibly tilting toward its fall
    else { const cf=Math.min(1,(e.st-0.6)/1.4); shk=Math.max(0,0.35+0.65-cf*2.4); }   // GIVE-WAY: sharp shudder the instant it tips, settling fast
    cx+=Math.sin((e.st||0)*47)*shk*1.6*z; cy+=Math.cos((e.st||0)*53)*shk*0.9*z+lean*22*z; }
  const hw=TW/2*z, top=cy-22*z;
  if(!arson){                                                                                // blood streaking down the walls (pillage)
    g.save(); g.globalCompositeOperation='multiply'; g.globalAlpha=Math.min(1,d*1.5);
    g.strokeStyle='rgba(96,8,12,0.85)'; g.fillStyle='rgba(96,8,12,0.7)';
    for(let i=0;i<5;i++){ const ox=-hw*0.55+i*hw*0.28, len=(4+((i*7)%5))*z*(0.4+d); g.lineWidth=(1+(i%2))*z;
      g.beginPath();g.moveTo(cx+ox,top);g.lineTo(cx+ox,top+len);g.stroke();
      g.beginPath();g.arc(cx+ox,top+len,(1+(i%2)*0.6)*z,0,7);g.fill(); }
    for(let i=0;i<Math.round(d*7);i++){ const a=i*2.1; g.fillStyle='rgba(110,10,14,0.6)';
      g.beginPath();g.arc(cx+Math.cos(a)*hw*0.7,top+6*z+Math.sin(a)*6*z,(0.6+(i%3)*0.5)*z,0,7);g.fill(); }
    g.restore(); }
  g.save(); g.globalAlpha=Math.min(0.7,d*0.7); g.strokeStyle='rgba(18,12,10,0.8)'; g.lineWidth=0.8*z;   // structural cracks
  for(let i=0;i<Math.round(d*5);i++){ let xx=cx+(-hw*0.5+i*hw*0.25), yy=top; g.beginPath();g.moveTo(xx,yy);
    for(let s=0;s<4;s++){ yy+=5*z; xx+=((i*7+s*13)%5-2)*0.9*z; g.lineTo(xx,yy);} g.stroke(); }
  g.restore();
  if(e.state==='collapse'&&e.st>0.5){ const cf=Math.min(1,(e.st-0.5)/1.5);                  // dust shroud, erupting at give-way rather than from the first tremor
    g.save(); g.globalAlpha=0.5*(1-Math.abs(cf-0.5)*1.3); g.fillStyle='rgba(120,110,100,0.5)';
    for(let i=0;i<8;i++){ const a=i*0.9, rr=(6+cf*16)*z;
      g.beginPath();g.ellipse(cx+Math.cos(a)*rr*0.7,top+8*z-cf*6*z+Math.sin(a)*rr*0.3,(4+cf*5)*z,(3+cf*3)*z,0,0,7);g.fill(); }
    g.restore(); }
  if(arson&&d>0.08){ const tt=fx*0.001, inten=Math.min(1,d*1.3);                            // fire visibly spreading up the structure: several climbing licks, not one blob
    g.save(); g.globalCompositeOperation='lighter';
    const N=2+Math.round(inten*4);
    for(let i=0;i<N;i++){ const ox=-hw*0.6+(i/(Math.max(1,N-1)))*hw*1.2, ig=((i*53+7)%100)/100;   // staggered ignition points along the eaves
      if(ig>inten*1.15)continue;                                                            // not every point has caught yet — reads as spreading, not uniform
      const flick=Math.sin(tt*10+i*2.3)*1.2*z, h=(5+inten*9+(i%2?2:0))*z;
      flameTongue(g,cx+ox+flick,top+3*z,(1.4+inten*1.4)*z,h*0.6,'rgba(255,120,20,0.6)');
      flameTongue(g,cx+ox+flick*0.6,top+3*z,(0.9+inten*0.8)*z,h*0.4,'rgba(255,210,80,0.7)'); }
    if(e.state==='destruct'||e.state==='collapse'){ const pulse=0.7+0.3*Math.sin(tt*9);    // glowing ember-bed at the structure's base, brightest once it's down
      const eg=g.createRadialGradient(cx,cy+1*z,0,cx,cy+1*z,hw*1.1*pulse);
      eg.addColorStop(0,'rgba(255,150,40,'+(0.5*inten*pulse)+')'); eg.addColorStop(1,'rgba(180,40,10,0)');
      g.fillStyle=eg; g.beginPath();g.ellipse(cx,cy+1*z,hw*1.1,hw*0.55,0,0,7);g.fill(); }
    g.restore();
    g.save(); g.globalAlpha=Math.min(0.65,d*0.55); g.fillStyle='rgba(22,18,16,0.55)';        // thicker, more varied black smoke as the fire climbs
    for(let i=0;i<6;i++){ const yy=top-(8+i*7)*z-((tt*7+i*1.6)%9)*z, xx=cx+Math.sin(tt*1.7+i*2.1)*9*z, rr=(4+i*2.1+inten*3)*z;
      g.globalAlpha=Math.min(0.6,d*0.55)*(0.5+0.5*Math.sin(tt*3+i)); g.beginPath();g.ellipse(xx,yy,rr,rr*0.78,0,0,7);g.fill(); }
    g.restore(); } }

/* ---- household defender: standing its ground, then struck and toppling — the visible CAUSE of the corpse that follows ---- */
function drawDefender(g,cx,cy,z,d){
  if(d.state==='idle'){ const sh=Math.sin((fx||0)*0.006+d.seed)*0.5*z;                  // a fearful shiver, standing its ground
    shadowEllipse(g,cx,cy,2.6,z);
    let lunge=0, leanAng=0, dir=d.dir||1;
    if(d.dodgeT>0){ const p=d.dodgeT/0.26; lunge+=(d.dodgeDX||1)*1.4*p; leanAng+=0.07*Math.sign(d.dodgeDX||1)*p; }
    if(d.blockT>0){ leanAng+=-0.05*dir; }
    if(d.guard){                                                                        // armed retainer — same stance mechanics as a ronin's cut
      if(d.wind>0){ const p=1-(d.wind/(d.windMax||0.2)); lunge+=-1.1*p*dir; leanAng+=-0.08*dir*p; }
      else if(d.swing>0){ const p=1-(d.swing/(d.swingMax||0.4));
        const Ltab={chop:1.4,diag:1.7,thrust:3.0}; const L=Ltab[d.swingType]||1.4;
        const fp=Math.sin(Math.min(1,p*1.25)*Math.PI); lunge+=L*fp*dir; leanAng+=0.10*dir*fp; }
    }
    g.save(); g.translate(cx+sh+lunge*z,cy); g.rotate(leanAng);
    drawPerson(g,0,0,z,d.kit,d.dir,1);
    if(d.guard) drawGuardWeapon(g,0,0,z,d,dir);
    if(d.blockT>0) drawBlockBrace(g,0,0,z,dir);
    g.restore(); return; }
  if(d.state==='struck'){ const p=Math.min(1,d.t/0.4), fall=p*p;                        // struck → staggers → topples
    shadowEllipse(g,cx,cy,2.6,z);
    g.save(); g.translate(cx,cy); g.rotate(d.recoilDX*1.1*fall); g.translate(d.recoilDX*4*z*fall,-d.recoilDY*3*z*fall);
    drawPerson(g,0,0,z,d.kit,d.dir,1);
    if(d.guard && fall<0.5) drawGuardWeapon(g,0,0,z,d,d.dir||1);                        // weapon drops/slips from grip as the hit lands
    g.restore();
    if(d.t<0.13){ g.save(); g.globalCompositeOperation='lighter'; g.fillStyle='rgba(255,235,225,'+(0.6*(1-d.t/0.13))+')';   // contact flash where steel met flesh
      g.beginPath();g.arc(cx+d.recoilDX*3*z,cy-6*z,2.6*z,0,7);g.fill(); g.restore(); }
    drawBlood(g,cx,cy+1*z,z,0.5+p*0.3); return; }
  if(d.state==='flee'){ shadowEllipse(g,cx,cy,2.6,z);                                    // morale broke — running for the road, not standing the ground
    d.kit.moving=true; d.kit.ph=(d.kit.ph||0)+0.32;
    drawPerson(g,cx,cy,z,d.kit,d.dir,1); } }

/* improvised weapon for an armed household guard — a wooden bo staff by default, or a
   farm sickle when the kit rolled 'farmer'. Deliberately plainer than drawRonin's katana
   (no tsuba/fittings, duller material) so the asymmetry between attacker and defender reads
   visually even mid-duel. Mirrors the same wind/swing stance math as roninCombatTick/drawRonin
   so the weapon tip always lines up with the body's lean. */
function drawGuardWeapon(g,cx,cy,z,d,dir){
  const sickle=(d.kit&&d.kit.type==='farmer');
  const bx=cx+(2.1*dir)*z, by=cy-5.2*z;
  if(d.wind>0){                                                                         // ready stance — weapon cocked for the coming cut
    g.strokeStyle='#3a2c1c'; g.lineWidth=0.65*z;
    if(d.swingType==='thrust'){ const hx=cx+(-1.9*dir)*z, hy=cy-5.8*z;
      g.beginPath();g.moveTo(cx+(0.6*dir)*z,cy-5.2*z);g.lineTo(hx,hy);g.stroke();
      g.save();g.translate(hx,hy);g.rotate(dir>0?Math.PI*0.92:Math.PI*0.08);
        g.fillStyle=sickle?'#8a8378':'#6b5436'; g.beginPath();g.moveTo(0,-0.32*z);g.lineTo(4.6*z,-0.18*z);g.lineTo(4.9*z,0);g.lineTo(4.6*z,0.18*z);g.lineTo(0,0.32*z);g.closePath();g.fill();
      g.restore(); }
    else { const hx=cx+(-1*dir)*z, hy=cy-10.2*z;
      g.beginPath();g.moveTo(cx+(0.5*dir)*z,cy-6.8*z);g.lineTo(hx,hy);g.stroke();
      g.save();g.translate(hx,hy);g.rotate(dir>0?-1.0:Math.PI+1.0);
        if(sickle){ g.strokeStyle='#7a756a'; g.lineWidth=0.55*z; g.beginPath();g.arc(2.4*z,0,2.6*z,Math.PI*0.15,Math.PI*1.05,false);g.stroke(); }
        else { g.fillStyle='#5c4a30'; g.fillRect(0,-0.35*z,6*z,0.7*z); }
      g.restore(); }
  } else if(!d.swing){                                                                  // resting grip
    g.strokeStyle='#3a2c1c'; g.lineWidth=0.65*z; g.beginPath();g.moveTo(cx+(1.2*dir)*z,cy-4.4*z);g.lineTo(bx,by);g.stroke();
    g.save(); g.translate(bx,by); g.rotate(dir>0?-0.5:Math.PI+0.5);
    if(sickle){ g.strokeStyle='#5c4a30'; g.lineWidth=0.7*z; g.beginPath();g.moveTo(-1.6*z,0);g.lineTo(0,0);g.stroke();
      g.strokeStyle='#8a8378'; g.lineWidth=0.5*z; g.beginPath();g.arc(2*z,0,2.2*z,Math.PI*0.1,Math.PI*1.0,false);g.stroke(); }
    else { g.fillStyle='#5c4a30'; g.fillRect(0,-0.32*z,6.4*z,0.64*z); }                  // plain wooden staff
    g.restore();
  } else {                                                                              // mid-swing — short motion trail, plain wood/iron tip
    const p=1-d.swing/(d.swingMax||0.4), ext=Math.sin(Math.min(1,p*1.2)*Math.PI)*7;
    g.save(); g.globalCompositeOperation='lighter'; g.strokeStyle='rgba(230,220,200,'+(0.28*(1-p))+')'; g.lineWidth=1*z;
    g.beginPath(); g.moveTo(cx+(1.2*dir)*z,cy-5.4*z); g.lineTo(cx+(1.2*dir+ext*0.8*dir)*z,cy-5.4*z); g.stroke(); g.restore();
    g.save(); g.translate(cx+(1.2*dir+ext*0.5*dir)*z,cy-5.4*z); g.rotate(dir>0?-0.4*p:Math.PI+0.4*p);
    if(sickle){ g.strokeStyle='#7a756a'; g.lineWidth=0.55*z; g.beginPath();g.arc(2.2*z,0,2.3*z,0,Math.PI*1.4,false);g.stroke(); }
    else { g.fillStyle='#5c4a30'; g.fillRect(0,-0.34*z,5.6*z,0.68*z); }
    g.restore();
  }
}

/* ---- unarmed defender bracing an incoming cut with a raised forearm — only shown for
   the brief blockT window; armed guards block with drawGuardWeapon's own swing instead ---- */
function drawBlockBrace(g,cx,cy,z,dir){
  g.save(); g.strokeStyle='#caa57a'; g.lineWidth=1.1*z; g.lineCap='round';
  g.beginPath(); g.moveTo(cx+(0.6*dir)*z,cy-5.4*z); g.lineTo(cx+(2.6*dir)*z,cy-7.6*z); g.stroke();
  g.restore(); }

function drawViolenceFX(ctx,z){
  // NOTE: ground blood stains are now drawn in the pre-pass above (with litter), so agents
  // standing on a stain are correctly painted on top of it instead of it floating over them.
  const list=corpses.map(c=>({k:'c',c,d:c.x+c.y}));
  for(const e of encounters) if(e.raid&&e.defenders) for(const d of e.defenders) if(d.state!=='down') list.push({k:'d',d,dd:d.x+d.y});
  list.sort((a,b)=>(a.d!=null?a.d:a.dd)-(b.d!=null?b.d:b.dd));
  for(const o of list){ if(o.k==='c'){ const[cx,cy]=s2(o.c.x,o.c.y); if(cx<-90||cx>VW+90||cy<-90||cy>VH+90)continue; drawCorpse(ctx,cx,cy,z,o.c); }
    else { const[cx,cy]=s2(o.d.x,o.d.y); if(cx<-90||cx>VW+90||cy<-90||cy>VH+90)continue; drawDefender(ctx,cx,cy,z,o.d); } }
  for(const e of encounters){ if(e.raid&&e.dmg>0){ const[cx,cy]=s2(e.rtx,e.rty); if(cx>-140&&cx<VW+140&&cy>-180&&cy<VH+140) drawRaidDamage(ctx,cx,cy,z,e); } }
  for(const d of debris){ const[cx,cy]=s2(d.x,d.y); if(cx<-90||cx>VW+90||cy<-90||cy>VH+90)continue; drawDebris(ctx,cx,cy,z,d); }
  for(const p of sprays){ const[cx,cy]=s2(p.x,p.y); if(cx<-90||cx>VW+90||cy<-90||cy>VH+90)continue; drawSpray(ctx,cx,cy,z,p); }
  for(const p of clashSparks){ const[cx,cy]=s2(p.x,p.y); if(cx<-90||cx>VW+90||cy<-90||cy>VH+90)continue; drawClashSpark(ctx,cx,cy,z,p); }
  for(const e of encounters){ if(e.state==='approach'||e.state==='chase'){ const v=e.vic, vx=v.wx!=null?v.wx:v.x, vy=v.wy!=null?v.wy:v.y; const[cx,cy]=s2(vx,vy);
    ctx.save(); ctx.globalAlpha=0.85; ctx.fillStyle='#b3261e'; ctx.font='700 '+Math.max(8,(8*z)|0)+'px serif'; ctx.textAlign='center'; ctx.fillText('!',cx,cy-15*z); ctx.restore(); } } }
/* ========================== END RONIN STREET VIOLENCE ========================== */

/* ============================ ECONOMY / DEVELOPMENT ============================ */
function tick(){
  rebuildCoverage();
  let pop=0,cap=0,comJobs=0,indJobs=0,powerCap=0,powerUse=0,civicCount={}, healthCov=0,eduCov=0,devTiles=0,validators=0;
  // power supply
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x]; if(c.civ===PLANT&&!c.burn)powerCap+=60;}
  S.powerCap=powerCap;
  // development pass
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){ const c=grid[y][x];
    if(c.civ){ civicCount[c.civ]=(civicCount[c.civ]||0)+1; if(c.civ===VALID&&!c.burn)validators++; if(c.civ===TOWN){cap+=12;pop+=8;} continue; }
    if(!c.zone)continue;
    const road=nearRoad(x,y,3), powered=!researchedElectric()|| (c.wire||nearWire(x,y));
    const q=qualityAt(x,y);
    const dem = c.zone===ZR?S.demand.R : c.zone===ZC?S.demand.C : S.demand.I;
    // growth / decay
    if(road && powered && dem>0.05 && q>0.3 && !c.burn){
      const maxDev = q>0.75?3 : q>0.5?2 : 1; const needHosp = (c.dev>=2); 
      if(c.dev<maxDev && (!needHosp || (healthGrid&&healthGrid[y][x])) && Math.random()<0.12*(dem+0.3)){ c.dev++; if(c.own===0)c.own=(Math.random()<0.2?2:CLIENT); }
      if(c.blight>0&&Math.random()<0.4)c.blight--;
    } else if(!c.burn) {
      if(Math.random()<0.10){ if(c.dev>0&&Math.random()<0.5)c.dev--; else c.blight=Math.min(3,c.blight+1); }
    }
    // abandonment
    if(c.blight>=3&&c.dev>0&&Math.random()<0.05){ if(c.own===CLIENT)toast('🏚 Abandoned','a plot you owned'); c.zone=0;c.dev=0;c.own=0;c.blight=0;c.ruin=1;c.guard=0; }
    if(c.dev>0){ devTiles++;
      if(c.zone===ZR){cap+=c.dev*5;pop+=c.dev*4;} else if(c.zone===ZC){comJobs+=c.dev*3;} else {indJobs+=c.dev*4;}
      if(researchedElectric())powerUse+=c.dev;
      if(healthGrid&&healthGrid[y][x])healthCov++; if(eduGrid&&eduGrid[y][x])eduCov++;
    }
  }
  S.pop=pop; S.cap=cap; S.comJobs=comJobs; S.indJobs=indJobs; S.jobs=comJobs+indJobs; S.powerUse=powerUse;
  S.healthPct=devTiles?healthCov/devTiles:0; S.eduPct=devTiles?eduCov/devTiles:0;
  S.electricity=researchedElectric();
  // demand model
  const jobsTotal=comJobs+indJobs;
  S.demand.R = clamp(0.3 + (jobsTotal - pop*0.5)/Math.max(40,pop+40), 0, 1);
  S.demand.C = clamp(0.2 + (pop*0.5 - comJobs)/Math.max(40,pop+40), 0, 1);
  S.demand.I = clamp(0.2 + (pop*0.45 - indJobs)/Math.max(40,pop+40), 0, 1);
  // economy — SOL creator rewards are paid from a shared global pool, split by
  // CURRENT ownership share. your cut = POOL * (yourProperty / allProperty).
  // Buildings that are burning/raided earn nothing. $SORU is buy-and-burn only.
  let myWeight=0, totalWeight=0;
  for(const r of grid)for(const c of r){
    if(c.burn) continue;                               // raided/burning property pays no one
    let w=0;
    if(c.dev>0 && c.own) w += c.dev;                   // a standing zoned plot (weighted by development)
    if(c.civ===VALID)    w += VAL_WEIGHT;              // a validator is high-value standing property
    if(w<=0) continue;
    totalWeight += w;
    if(c.own===CLIENT) myWeight += w;                  // validators set own=CLIENT on placement
  }
  const pool   = SOL_POOL_BASE + totalWeight*SOL_POOL_GROWTH;   // global pool grows with island activity
  S.solShare   = totalWeight>0 ? myWeight/totalWeight : 0;      // your live ownership share (0..1)
  const solReward = pool * S.solShare;                          // proportional payout
  S.wallet.sol+=solReward; S.netTurn=solReward;
  // global Kami — EXACTLY the $SORU burned across the island (added 1:1 in spend()).
  // ages turn only when collective burn reaches the thresholds; no random accrual.
  if(DEV_SIMULATE_KAMI && S.era<ERAS.length-1){        // dev/test toggle ONLY — ships false
    const gap=KAMI_REQ[S.era+1]-KAMI_REQ[S.era];
    const activity=clamp((S.recentBurn||0)/180,0,1); S.recentBurn=(S.recentBurn||0)*0.5;
    S.kami += gap*(0.03+0.06*activity); }
  while(S.era<ERAS.length-1 && S.kami>=KAMI_REQ[S.era+1]) advanceAge();
  // city-wide safety from the crime field (police coverage)
  let crSum=0,crN=0; if(crimeGrid)for(let y=0;y<H;y++)for(let x=0;x<W;x++){ if(grid[y][x].dev>0){crSum+=crimeGrid[y][x];crN++;} }
  S.safetyPct = crN? Math.max(0,1-crSum/crN) : 1;
  S.turn++; if(S.turn%5===0)periodicAdvice();
  forestTick(); fireTick(); rebuildValue(); refreshHUD(); gridVersion++;
}
function nearWire(x,y){ for(const[dx,dy]of NEIGH)if(inB(x+dx,y+dy)&&grid[y+dy][x+dx].wire)return true; return false; }
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
/* ---- forests: random ambient regrowth DISABLED (perf fix) — trees no longer spawn spontaneously
   during play; the only trees on the map are the ones generated at world creation (or intentionally
   placed/left by the player). Function kept as a no-op stub so the call site in advanceTurn() and any
   future hook stay valid without needing to touch the simulation loop. ---- */
function forestTick(){ /* no-op: random regrowth removed */ }

/* ---- fire ---- */
/* ===== fire-watch bell (hanshō 半鐘) — synthesized Web Audio alert ===== */
let _actx=null, _fireBellAt=0;
let _sfxGain=null;
function optGet(k,d){ try{ var v=localStorage.getItem(k); return v==null?d:JSON.parse(v); }catch(e){ return d; } }
function optSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function sfxCtx(){ try{ if(!_actx)_actx=new (window.AudioContext||window.webkitAudioContext)(); if(_actx.state==='suspended')_actx.resume();
  if(_actx&&!_sfxGain){ _sfxGain=_actx.createGain(); _sfxGain.gain.value=optGet('opt_sfxVol',0.9); _sfxGain.connect(_actx.destination); } }catch(e){} return _actx; }
function sfxDest(ctx){ return (_sfxGain&&_sfxGain.context===ctx)?_sfxGain:ctx.destination; }
function bellStrike(ctx,t0,freq,gain){ const parts=[1,2.01,2.69,3.76,5.42];   // inharmonic metal partials
  const dest=sfxDest(ctx);
  parts.forEach((p,i)=>{ const o=ctx.createOscillator(),g=ctx.createGain();
    o.type='triangle'; o.frequency.value=freq*p*(1+(Math.random()-0.5)*0.012);
    const a=gain/(i*1.4+1), dur=1.15/(1+i*0.7);
    g.gain.setValueAtTime(0.0001,t0); g.gain.exponentialRampToValueAtTime(a,t0+0.005); g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
    o.connect(g).connect(dest); o.start(t0); o.stop(t0+dur+0.05); }); }
function playFireBell(urgent){ const ctx=sfxCtx(); if(!ctx)return; const t=ctx.currentTime;
  const n=urgent?3:1; for(let k=0;k<n;k++) bellStrike(ctx,t+k*0.2,548,0.17);   // rapid clanging = fire nearby
  _fireBellAt=(typeof performance!=='undefined')?performance.now():0; }
function igniteRandom(){ const cands=[]; for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x];if((c.dev>0||c.civ)&&!c.burn)cands.push([x,y]);}
  if(!cands.length)return; const[x,y]=cands[(Math.random()*cands.length)|0];
  if(fireGrid&&Math.random()<fireGrid[y][x])return;          // fire-station coverage averts the blaze
  grid[y][x].burn=5;disasterT=6;toast('🔥 Fire!','douse it quickly'); if(typeof playFireBell==='function')playFireBell(true); }
function fireTick(){ let any=false; for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x];if(!c.burn)continue; any=true;
  const prot=fireGrid?fireGrid[y][x]:0;
  if(Math.random()<0.28)for(const[dx,dy]of NEIGH){const nx=x+dx,ny=y+dy;if(inB(nx,ny)){const n=grid[ny][nx];const np=fireGrid?fireGrid[ny][nx]:0;if((n.dev>0||n.civ)&&!n.burn&&Math.random()<0.4*(1-np))n.burn=5;}}
  c.burn--; if(prot>0.3&&Math.random()<prot)c.burn--;        // firefighters knock it down faster
  if(c.burn<=0){ if(c.civ&&c.civ!==TOWN){ if(c.civ===PARK||c.civ===FARM)c.parkRuin=1; c.civ=0;} if(c.zone){if(c.own===CLIENT&&Math.random()<1){const pen=Math.min(S.wallet.sol,c.dev*0.12);S.wallet.sol-=pen;} c.zone=0;c.dev=0;c.own=0;} c.ruin=1;c.guard=0; c.scorch=c.parkRuin?0:1; } }
  if(any && typeof playFireBell==='function' && typeof performance!=='undefined' && performance.now()-_fireBellAt>3400) playFireBell(false); }

/* ===== UI sound effects — click/build/raze/error/notification =====
   Real .wav assets sitting alongside index.html (same folder). Loaded by
   plain relative filename via fetch+decodeAudioData, same pattern as the
   gibberish-voice sample loader: lazy, cached by name, fire-once, failures
   remembered so a missing/renamed file doesn't retry every call. Routed
   through sfxCtx()/sfxDest() so they share the SFX volume slider and
   AudioContext with the rest of the game rather than spinning up their own. */
const UI_SFX_FILES = { click:'click.wav', build:'build.wav', raze:'raze.wav', error:'error.wav', notification:'notification.wav' };
const _uiSfxBuf={}, _uiSfxFailed={}, _uiSfxLoading={};
function _uiSfxLoad(name){
  const file = UI_SFX_FILES[name];
  if(!file || _uiSfxBuf[name] || _uiSfxFailed[name] || _uiSfxLoading[name]) return;
  const ctx = sfxCtx(); if(!ctx) return;
  _uiSfxLoading[name]=true;
  const resolvedURL = new URL(file, document.baseURI).href;
  fetch(file).then(res=>{ if(!res.ok) throw new Error('HTTP '+res.status+' at '+resolvedURL); return res.arrayBuffer(); })
    .then(ab=>ctx.decodeAudioData(ab))
    .then(buf=>{ _uiSfxBuf[name]=buf; _uiSfxLoading[name]=false; })
    .catch(e=>{ _uiSfxFailed[name]=true; _uiSfxLoading[name]=false;
      const msg='UI sfx missing/unreadable: '+file+' — looked for it at '+resolvedURL+' ('+(e.message||e)+')';
      if(window.__err) window.__err(msg); else console.warn(msg); });
}
function _uiSfxPreloadAll(){ for(const k in UI_SFX_FILES) _uiSfxLoad(k); }
function playUISfx(name,gainScale){
  _uiSfxLoad(name);                                            // ensure it's loading for next time even on a miss
  const ctx = sfxCtx(); if(!ctx) return;
  const buf = _uiSfxBuf[name]; if(!buf) return;                 // not decoded yet — silently skip this call, not an error
  const src = ctx.createBufferSource(); src.buffer = buf;
  const g = ctx.createGain(); g.gain.value = (gainScale!=null?gainScale:1);
  src.connect(g); g.connect(sfxDest(ctx));
  src.start(ctx.currentTime);
}
if(typeof window!=='undefined') window.addEventListener('pointerdown', _uiSfxPreloadAll, {once:true, passive:true});

/* ============================ HUD ============================ */
function fmt(n){n=Math.round(n);return Math.abs(n)>=1e6?(n/1e6).toFixed(2)+'M':Math.abs(n)>=1e4?(n/1e3).toFixed(1)+'k':n.toLocaleString();}
/* ===== LUNAR CYCLE · CHINESE ZODIAC · TAROT ===== */
const MOON=['🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘'];
const MOON_NM=['New Moon','Waxing Crescent','First Quarter','Waxing Gibbous','Full Moon','Waning Gibbous','Last Quarter','Waning Crescent'];
const ZODIAC=[['🐀','Rat'],['🐂','Ox'],['🐅','Tiger'],['🐇','Rabbit'],['🐉','Dragon'],['🐍','Snake'],['🐎','Horse'],['🐐','Goat'],['🐒','Monkey'],['🐓','Rooster'],['🐕','Dog'],['🐖','Pig']];
const TAROT=[['0','The Fool','new beginnings, a leap of faith'],['I','The Magician','will, manifestation'],['II','The High Priestess','intuition, hidden knowledge'],['III','The Empress','abundance, creation'],['IV','The Emperor','structure, authority'],['V','The Hierophant','tradition, guidance'],['VI','The Lovers','union, a choice of the heart'],['VII','The Chariot','drive, hard-won victory'],['VIII','Strength','courage, inner power'],['IX','The Hermit','solitude, inner light'],['X','Wheel of Fortune','cycles, turning fate'],['XI','Justice','balance, truth'],['XII','The Hanged Man','surrender, new perspective'],['XIII','Death','endings, transformation'],['XIV','Temperance','harmony, patient alchemy'],['XV','The Devil','attachment, the shadow'],['XVI','The Tower','sudden upheaval, revelation'],['XVII','The Star','hope, renewal'],['XVIII','The Moon','dreams, illusion, the tides'],['XIX','The Sun','joy, vitality'],['XX','Judgement','reckoning, awakening'],['XXI','The World','completion, wholeness']];
if(S.day==null)S.day=0; if(S.tarot==null)S.tarot=(Math.random()*TAROT.length)|0;
function moonPhase(){return (S.day||0)%8;} function zodiacIdx(){return Math.floor((S.day||0)/8)%12;}
function updateMystic(){ const mp=moonPhase(),zi=zodiacIdx(),tc=TAROT[S.tarot];
  if(typeof moonGlyph!=='undefined'&&moonGlyph){ moonGlyph.textContent=MOON[mp]; zodiacGlyph.textContent=ZODIAC[zi][0]; tarotName.textContent=tc[1];
    mysticPill.title=MOON_NM[mp]+' · Year of the '+ZODIAC[zi][1]+' · '+tc[0]+' '+tc[1]+' — '+tc[2]; } }
function drawTarotCard(){ S.tarot=(Math.random()*TAROT.length)|0; const tc=TAROT[S.tarot]; updateMystic();
  toast('🃏 '+tc[1],tc[2]); advise('The cards turn — <b>'+tc[0]+' '+tc[1]+'</b>: '+tc[2]+'. '+MOON_NM[moonPhase()]+', Year of the '+ZODIAC[zodiacIdx()][1]+'.'); }
function refreshHUD(){
  rGold.textContent=fmt(Math.round(S.wallet.soru)); rPop.textContent=fmt(S.pop);
  rNet.textContent='+'+(S.netTurn||0).toFixed(3); netRes.classList.remove('neg');         // SOL creator reward / turn
  if(netRes)netRes.title='SOL creator reward / turn — your share of the global pool: '+Math.round((S.solShare||0)*100)+'% of all standing property';
  rPow.textContent=S.electricity?(S.powerUse+'/'+S.powerCap):'—'; powRes.classList.toggle('neg',S.electricity&&S.powerUse>S.powerCap);
  rHealth.textContent=S.pop>20?Math.round(S.healthPct*100)+'%':'—'; hRes.classList.toggle('neg',S.pop>40&&S.healthPct<0.5);
  rEdu.textContent=S.pop>20?Math.round(S.eduPct*100)+'%':'—';
  rSafe.textContent=S.pop>20?Math.round(S.safetyPct*100)+'%':'—'; sRes.classList.toggle('neg',S.pop>40&&S.safetyPct<0.6);
  if(typeof rKami!=='undefined'&&rKami)rKami.textContent=fmt(S.kami);
  demR.style.width=(S.demand.R*100)+'%'; demC.style.width=(S.demand.C*100)+'%'; demI.style.width=(S.demand.I*100)+'%';
  wSol.textContent=S.wallet.sol.toFixed(2); wSoru.textContent=fmt(S.wallet.soru);
  ageName.textContent=ERAS[S.era].jp+' '+ERAS[S.era].nm;
  if(S.era<ERAS.length-1){const a=KAMI_REQ[S.era],b=KAMI_REQ[S.era+1],pct=clamp((S.kami-a)/(b-a),0,1);
    advanceBtn.disabled=false; advanceBtn.classList.toggle('ready',pct>0.9); advanceBtn.textContent='▲ '+Math.floor(pct*100)+'%';}
  else{advanceBtn.disabled=false;advanceBtn.classList.remove('ready');advanceBtn.textContent='量子 MAX';}
}
let advTimer=0;
function advise(s){document.getElementById('advisor').innerHTML='<b>DR. SOL</b> — '+s;advTimer=9;}
function toast(t,s,isError){const d=document.createElement('div');d.className='tmsg'+(isError?' err':'');d.innerHTML='<b>'+t+'</b>'+(s?' · '+s:'');document.getElementById('toast').appendChild(d);setTimeout(()=>d.remove(),2200);
  playUISfx(isError?'error':'notification',0.7);}
function worstDistrict(){ if(!healthGrid)return null; const GS=10,cols=Math.ceil(W/GS),bk={};
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){const c=grid[y][x];if(!c.zone||c.dev<1)continue;const noH=!healthGrid[y][x],noE=!eduGrid[y][x];if(!noH&&!noE)continue;
    const k=((y/GS)|0)*cols+((x/GS)|0);const b=bk[k]||(bk[k]={n:0,nH:0,nE:0,sx:0,sy:0});b.n++;if(noH)b.nH++;if(noE)b.nE++;b.sx+=x;b.sy+=y;}
  let best=null;for(const k in bk){const b=bk[k];if(!best||b.n>best.n)best=b;} if(!best||best.n<3)return null;
  return{cx:best.sx/best.n,cy:best.sy/best.n,n:best.n,needH:best.nH>=best.nE,both:best.nH>0&&best.nE>0}; }
function compass(cx,cy){const dx=cx-W/2,dy=cy-H/2,ns=dy<-H*0.12?'north':dy>H*0.12?'south':'',ew=dx<-W*0.12?'west':dx>W*0.12?'east':'';return(ns+ew)||'central';}
function adviseValue(){const d=worstDistrict(); if(!d){advise('Services reach your districts — land value looks healthy.');return;}
  const svc=d.both?'a hospital and a school':d.needH?'a hospital':'a school';
  advise('The '+compass(d.cx,d.cy)+' district is reddest — '+d.n+' blocks with no '+(d.needH?'hospital':'school')+' nearby. Build '+svc+' there.'); }
function periodicAdvice(){ if(S.wallet.soru<20){advise('Your $SORU is nearly spent — it\'s burned on every act. Keep buildings standing to earn SOL, then swap SOL→$SORU at the DEX.');return;}
  if(S.pop>20&&S.netTurn<=0){advise('No SOL is flowing — you earn it only from developed plots you OWN (🟢 marker). Zone HOUSING/COMMERCE by roads and let them grow.');return;}
  if(S.electricity&&S.powerCap>0&&S.powerUse>S.powerCap*0.9){advise('Brownouts loom — build another Power Plant.');return;}
  if(S.pop>40&&S.safetyPct<0.6){advise('Crime is climbing — drop a POLICE station in your densest wards to hold land value and protect your SOL rewards.');return;}
  if(S.pop>60&&Math.random()<0.4){const d=worstDistrict();if(d&&d.n>=4){adviseValue();return;}}
  if(S.demand.R>0.6)advise('Housing is in demand — zone more R beside roads.');
  else if(S.demand.C>0.6)advise('Commerce wants room — zone C near your dwellings.');
  else if(S.demand.I>0.6)advise('Industry is hungry — zone I on the edges.');
  else advise(ERAS[S.era].nm+' · pop '+fmt(S.pop)+' · $SORU '+fmt(Math.round(S.wallet.soru))+' · Kami '+fmt(S.kami)+'.'); }

/* build palette */
function iconCanvas(it){ const ic=document.createElement('canvas'); ic.width=58;ic.height=46; const g=ic.getContext('2d');
  if(it.ic==='zone'){ const c={zone:it.zone,dev:2,seed:0.4,own:0}; drawTerrain(g,0,0,{ter:GRASS,seed:0.3},29,24,0.62,0); drawZoneBuilding(g,29,30,0.5,c); }
  else if(it.ic==='road'){ drawTerrain(g,0,0,{ter:BARE,seed:0.3},29,20,0.66,0); drawRoad(g,0,0,29,20,0.66,0); }
  else if(it.ic==='wire'){ drawTerrain(g,0,0,{ter:GRASS,seed:0.3},29,26,0.66,0); drawWire(g,5,5,29,26,0.66); }
  else { drawTerrain(g,0,0,{ter:GRASS,seed:0.3},29,24,0.6,0); drawCivic(g,29,30,0.5,it.civ,Math.min(S.era,3)); }
  return ic; }
function buildPalette(){ const el=document.getElementById('builds'); el.innerHTML='';
  for(const it of CATALOG){ const d=document.createElement('div'); d.className='bbtn'; d.dataset.id=it.id;
    const locked=it.era>S.era; if(locked)d.classList.add('lock'); d.appendChild(iconCanvas(it));
    const nm=document.createElement('div');nm.className='nm';nm.textContent=it.nm;d.appendChild(nm);
    const co=document.createElement('div');co.className='cost';co.textContent='$'+it.cost;d.appendChild(co);
    if(locked){const lk=document.createElement('div');lk.className='lk';lk.textContent='🔒';d.appendChild(lk);}
    d.onclick=()=>{ if(locked){advise('That needs the '+ERAS[it.era].nm+' age.');return;}
      playUISfx('click',0.5);
      S.tool=it;S.hand=false;S.douse=false;S.demo=false;S.pillage=false;S.arson=false; ['handBtn','douseBtn','demoBtn','pillageBtn','arsonBtn'].forEach(b=>document.getElementById(b).classList.remove('on'));
      markSel(); cv.style.cursor='crosshair'; };
    el.appendChild(d);} markSel(); }
function markSel(){ document.querySelectorAll('.bbtn').forEach(d=>d.classList.toggle('sel', S.tool&&!S.hand&&!S.douse&&!S.demo&&!S.pillage&&!S.arson&&!S.guard&&d.dataset.id===S.tool.id)); }

/* ============================ INPUT / ACTIONS ============================ */
let lastPoorMsg=0;
function spend(g){ if(S.wallet.soru<g){ if(performance.now()-lastPoorMsg>1200){ lastPoorMsg=performance.now();
    toast('Need $'+g+' SORU','have $'+fmt(Math.round(S.wallet.soru)),true); advise('Out of $SORU — it is burned on every act. Earn SOL from the buildings you keep standing, then swap SOL→$SORU at the DEX.'); } return false; }
  S.wallet.soru-=g; S.burned+=g; S.recentBurn+=g; S.kami+=g; return true; }   // 100% burned → Kami (1:1, exactly $SORU spent)
function place(tx,ty){ if(!inB(tx,ty))return; const c=grid[ty][tx]; gridVersion++;
  if(S.demo){ if(c.civ===TOWN)return;                          // RAZE: tear down your OWN works only — rivals must be PILLAGED
    if(c.own&&c.own!==CLIENT){ toast('Not yours','use PILLAGE on rivals',true); return; }
    if(!(c.zone||c.civ||c.dev||c.road||c.wire||c.ruin)){ return; } // nothing to raze here
    if(!spend(500))return;                                       // 500 $SORU burned — cleanup tool
    c.zone=0;c.civ=0;c.dev=0;c.own=0;c.wire=0;c.blight=0;c.ruin=0;c.burn=0;c.guard=0;c.scorch=0;c.parkRuin=0; c.stage=null;c.stageT=0;c.cropGrp=null;c.cropType=null; if(c.road)c.road=0;
    syncTraffic(); rebuildCoverage(); refreshHUD(); playUISfx('raze',0.6); return; }
  if(S.douse){ if(c.burn){c.burn=0; for(const[dx,dy]of NEIGH){const n=grid[ty+dy]&&grid[ty+dy][tx+dx];if(n&&n.burn)n.burn=Math.max(0,n.burn-2);} toast('💧 Doused');} return; }
  if(S.guard){ const mine=(c.dev>0&&c.own===CLIENT)||(c.civ&&c.civ!==TOWN);
    if(!mine){ toast('Guard your own','shield a building you own',true); return; }
    if(c.guard){ toast('Already shielded','a retainer already stands watch',true); return; }
    if(!spend(2000))return;                                       // 2,000 $SORU burned — ronin retainer's fee
    c.guard=1; toast('🛡 Ronin hired','this building shrugs off the next raid'); refreshHUD(); return; }
  if(S.arson){ if(!(c.dev>0||(c.civ&&c.civ!==TOWN)))return;     // TEST: self-target allowed
    if(!spend(4000))return;                                      // 4,000 $SORU burned per attempt — win or lose
    if(c.guard){ c.guard=0; toast('🛡 Arson repelled','ronin retainers drove the arsonists off'); refreshHUD(); return; }
    const prot=fireGrid?fireGrid[ty][tx]:0, mine=(c.own===CLIENT);
    if(mine||Math.random()<0.70*(1-prot)){ spawnRaid(tx,ty,'arson'); toast('🔥 Arsonists inbound','torch-bearers close — it ignites on arrival'); }  // fire starts only when they REACH it
    else toast('🪣 Arson foiled','the fire-watch held');
    refreshHUD(); return; }
  if(S.pillage){ if(!(c.dev>0))return;                         // TEST: self-target allowed
    if(!spend(5000))return;                                      // 5,000 $SORU burned per attempt
    if(c.guard){ c.guard=0; toast('🛡 Pillage repelled','ronin retainers held the gate'); rebuildCoverage(); refreshHUD(); return; }
    const guarded=policeGrid&&policeGrid[ty][tx], mine=(c.own===CLIENT);
    if(mine||Math.random()<(guarded?0.35:0.80)){ spawnRaid(tx,ty,'pillage'); toast('🏴 Ronin inbound','the warband closes — they sack it on arrival'); }  // building falls only when they REACH it
    else toast('🛡 Pillage repelled','the watch held the line');
    refreshHUD(); return; }
  const it=S.tool; if(!it)return;
  if(it.road){ if(!isLand(tx,ty)||mountain(c)||c.civ||c.zone)return; if(c.road)return; if(!spend(it.cost))return; c.road=1; c.br=(c.ter===WATER)?1:0; if(c.ter<GRASS&&c.ter!==WATER)c.ter=BARE; syncTraffic(); refreshHUD(); playUISfx('build',0.5); return; }
  if(it.wire){ if(mountain(c)||c.civ||c.zone)return; if(!isLand(tx,ty)&&!c.road)return; if(c.wire)return; if(!spend(it.cost))return; c.wire=1; refreshHUD(); playUISfx('build',0.5); return; }
  if(it.zone!=null){ if(!isLand(tx,ty)||mountain(c)||occupied(c)||c.civ||c.ruin)return; if(!spend(it.cost))return; c.zone=it.zone; if(c.ter<GRASS||c.ter===FOREST){c.ter=GRASS;}
    c.dev= nearRoad(tx,ty,3)?1:0; if(c.dev>0)c.own=CLIENT; render(); refreshHUD(); playUISfx('build',0.5); return; }
  if(it.civ!=null){ if(!isLand(tx,ty)||mountain(c)||occupied(c)||c.civ||c.ruin)return; if(it.civ===VALID&&S.era<8){advise('Validators need the Quantum Edo age.');return;}
    if(!spend(it.cost))return; c.civ=it.civ; c.zone=0;c.dev=0; if(it.civ===VALID)c.own=CLIENT; if(c.ter===FOREST||c.ter<GRASS)c.ter=BARE; if(it.civ===FARM)c.ter=BARE;
    rebuildCoverage(); syncTraffic(); refreshHUD(); playUISfx('build',0.5); return; }
}
let dragging=false,dragPan=false,last=null,downPt=null,moved=false,pinched=false; const ptrs=new Map(); let pinch=null;
function evp(e){const r=cv.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top];}
cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('pointerdown',e=>{ try{cv.setPointerCapture(e.pointerId);}catch(_){} ptrs.set(e.pointerId,evp(e));
  if(ptrs.size>=2){const p=[...ptrs.values()];pinch={d:Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]),z:cam.zoom,mx:(p[0][0]+p[1][0])/2,my:(p[0][1]+p[1][1])/2};pinched=true;dragging=false;dragPan=false;return;}
  last=evp(e); downPt=last; moved=false;
  const touch=(e.pointerType==='touch'), forcePan=(e.button===1||e.button===2||S.hand);
  if(forcePan){ dragPan=true; cv.style.cursor='grabbing'; }
  else if(touch){ dragging=false; dragPan=false; }          // touch: decide tap vs pan on move/up
  else { dragging=true; place(...pick(...last)); render(); } // mouse: paint immediately
});
cv.addEventListener('pointermove',e=>{ if(ptrs.has(e.pointerId))ptrs.set(e.pointerId,evp(e)); const[mx,my]=evp(e);
  if(pinch&&ptrs.size>=2){const p=[...ptrs.values()];const d=Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]);setZoom(pinch.z*(d/pinch.d),pinch.mx,pinch.my);return;}
  if(downPt){ if(Math.hypot(mx-downPt[0],my-downPt[1])>7)moved=true; }
  const touch=(e.pointerType==='touch');
  if(dragPan&&last){cam.x+=mx-last[0];cam.y+=my-last[1];last=[mx,my];render();return;}
  if(touch&&moved&&last){ cam.x+=mx-last[0];cam.y+=my-last[1];last=[mx,my];render();return; }   // one-finger drag pans
  if(dragging&&last){last=[mx,my]; if(S.tool&&(S.tool.road||S.tool.wire||S.tool.zone!=null)||S.demo)place(...pick(mx,my)); render();return;}
  if(!touch){ hover=pick(mx,my); render(); } });
function endPtr(e){ const touch=(e.pointerType==='touch');
  if(touch&&!moved&&!dragPan&&!pinched&&downPt&&ptrs.size<=1){ place(...pick(downPt[0],downPt[1])); render(); } // tap = build
  ptrs.delete(e.pointerId); if(ptrs.size<2)pinch=null; if(ptrs.size===0)pinched=false; dragging=false;dragPan=false;downPt=null; if(!S.hand)cv.style.cursor='crosshair'; }
cv.addEventListener('pointerup',endPtr); cv.addEventListener('pointercancel',endPtr);
cv.addEventListener('wheel',e=>{e.preventDefault();const[mx,my]=evp(e);setZoom(cam.zoom*(e.deltaY<0?1.12:0.89),mx,my);},{passive:false});
function setZoom(z,mx,my){z=clamp(z,ZMIN,ZMAX);const a=(mx-cam.x)/cam.zoom,b=(my-cam.y)/cam.zoom;cam.zoom=z;cam.x=mx-a*z;cam.y=my-b*z;render();}
function fit(){cam.zoom=clamp(0.62*60/W,ZMIN,ZMAX);cam.x=VW/2-(W/2-H/2)*(TW/2)*cam.zoom;cam.y=VH/2-(W/2+H/2)*(TH/2)*cam.zoom-30;render();}
document.getElementById('zin').onclick=()=>setZoom(cam.zoom*1.2,VW/2,VH/2);
document.getElementById('zout').onclick=()=>setZoom(cam.zoom*0.83,VW/2,VH/2);
document.getElementById('zfit').onclick=fit;

function toolBtn(id,prop){ const PROPS=['hand','douse','demo','pillage','arson','guard'], BTNS=['handBtn','douseBtn','demoBtn','pillageBtn','arsonBtn','guardBtn'];
  document.getElementById(id).onclick=function(){ playUISfx('click',0.5); S[prop]=!S[prop]; if(S[prop]){S.tool=null; PROPS.forEach(p=>{if(p!==prop)S[p]=false;});}
  BTNS.forEach(b=>document.getElementById(b).classList.toggle('on',document.getElementById(b)===this&&S[prop]));
  markSel(); cv.style.cursor=S.hand?'grab':'crosshair'; };}
toolBtn('handBtn','hand'); toolBtn('douseBtn','douse'); toolBtn('demoBtn','demo'); toolBtn('pillageBtn','pillage'); toolBtn('arsonBtn','arson'); toolBtn('guardBtn','guard');
document.getElementById('valBtn').onclick=function(){S.overlay=!S.overlay;this.classList.toggle('on',S.overlay);if(S.overlay)adviseValue();render();};
function advanceAge(){ if(S.era>=ERAS.length-1)return; S.era++; S.electricity=researchedElectric(); buildPalette(); refreshHUD();
  toast(ERAS[S.era].jp+' '+ERAS[S.era].nm,'a new age dawns across the island'); advise('The age turns to <b>'+ERAS[S.era].nm+'</b> — the island\'s collective Kami reshapes the world. New works unlocked.'); }
advanceBtn.onclick=()=>{ if(S.era>=ERAS.length-1){advise('<b>Quantum Edo</b> — the legendary final age. The island can rise no further.');return;}
  const a=KAMI_REQ[S.era],b=KAMI_REQ[S.era+1],pct=Math.floor(clamp((S.kami-a)/(b-a),0,1)*100);
  advise('Ages turn from <b>collective Kami</b> (⛩) — every $SORU burned across the island fuels it, never one player. Next age <b>'+ERAS[S.era+1].nm+'</b> at '+pct+'%.'); };

/* ---- DEV: manual era jump (curation only) ----
   Sets S.era directly, skips Kami/turn logic entirely, then refreshes everything
   that's keyed off era: build menu gating, electricity flag, HUD text, and the
   render cache (worldKey() already includes S.era, so bumping gridVersion just
   forces an immediate repaint rather than waiting on the next natural redraw).
   Lives inside the Options modal (not a floating panel) so it never sits on top
   of the canvas blocking the view during normal play — see optDevEraRow. */
function jumpToEra(n){
  n=clamp(n|0,0,ERAS.length-1); if(n===S.era)return;
  S.era=n; S.electricity=researchedElectric();
  buildPalette(); refreshHUD(); gridVersion++; render();
  updateDevEraPanel();
  toast(ERAS[S.era].jp+' '+ERAS[S.era].nm,'dev: era jump');
}
let _devEraBtns=null;
function updateDevEraPanel(){ if(!_devEraBtns)return;
  _devEraBtns.forEach((b,i)=>b.classList.toggle('on',i===S.era));
  const val=document.getElementById('optDevEraVal'); if(val)val.textContent=ERAS[S.era].nm; }
function initDevEraSwitch(){
  const row=document.getElementById('optDevEraRow'); if(!row)return;
  if(!DEV_ERA_SWITCH){ row.style.display='none'; return; }
  row.style.display='';
  const host=document.getElementById('optDevEraBtns'); host.innerHTML='';
  _devEraBtns=ERAS.map((e,i)=>{
    const b=document.createElement('button');
    b.type='button'; b.textContent=i+' · '+e.nm;
    b.style.cssText='all:unset;cursor:pointer;padding:5px 8px;border-radius:4px;'
      +'color:var(--ink);font:11px/1.2 ui-monospace,Menlo,monospace;white-space:nowrap;'
      +'background:#262b31;border:1px solid var(--edge);';
    b.onmouseenter=()=>{ if(i!==S.era)b.style.background='#323840'; };
    b.onmouseleave=()=>{ if(i!==S.era)b.style.background='#262b31'; };
    b.onclick=()=>jumpToEra(i);
    host.appendChild(b);
    return b;
  });
  const styleEl=document.createElement('style');
  styleEl.textContent='#optDevEraBtns button.on{background:var(--sol)!important;color:#06311f;font-weight:700;border-color:var(--sol)!important;}';
  document.head.appendChild(styleEl);
  updateDevEraPanel();
}
initDevEraSwitch();
// DEX
function dexPrice(){return S.dex.sol/S.dex.soru;}
function openDex(){document.getElementById('dexModal').classList.add('show');refreshDex();}
function refreshDex(){dxPool.textContent=S.dex.sol.toFixed(1)+' SOL / '+fmt(S.dex.soru)+' SORU';dxPrice.textContent=dexPrice().toFixed(5);
  dxSol.textContent=S.wallet.sol.toFixed(3);dxSoru.textContent=fmt(S.wallet.soru);}
document.getElementById('dexBtn').onclick=openDex;
document.getElementById('dxClose').onclick=()=>document.getElementById('dexModal').classList.remove('show');
document.getElementById('dxBuy').onclick=()=>{const amt=Math.max(0,+dxAmt.value||0);if(amt<=0||amt>S.wallet.sol)return;
  const k=S.dex.sol*S.dex.soru,newSol=S.dex.sol+amt,out=S.dex.soru-k/newSol; S.wallet.sol-=amt;S.wallet.soru+=out*0.99;S.dex.sol=newSol;S.dex.soru-=out; refreshDex();refreshHUD();toast('Swapped','+'+fmt(out*0.99)+' SORU');};
document.getElementById('dxSell').onclick=()=>{const amt=Math.max(0,+dxAmt.value||0);if(amt<=0||amt>S.wallet.soru)return;
  const k=S.dex.sol*S.dex.soru,newSoru=S.dex.soru+amt,out=S.dex.sol-k/newSoru; S.wallet.soru-=amt;S.wallet.sol+=out*0.99;S.dex.soru=newSoru;S.dex.sol-=out; refreshDex();refreshHUD();toast('Swapped','+'+(out*0.99).toFixed(3)+' SOL');};

// OPTIONS
function openOptions(){
  const mv=Math.round(optGet('opt_musicVol',0.16)*100), sv=Math.round(optGet('opt_sfxVol',0.9)*100);
  optMusicVol.value=mv; optMusicVal.textContent=mv+'%';
  optSfxVol.value=sv; optSfxVal.textContent=sv+'%';
  optNoWeather.checked=!!optGet('opt_noWeather',false);
  updateDevEraPanel();
  document.getElementById('optModal').classList.add('show');
}
document.getElementById('optionsBtn').onclick=openOptions;
document.getElementById('optClose').onclick=()=>document.getElementById('optModal').classList.remove('show');
document.getElementById('optModal').addEventListener('mousedown',(e)=>{ if(e.target.id==='optModal')document.getElementById('optModal').classList.remove('show'); });
optMusicVol.oninput=function(){ const v=(+this.value||0)/100; optMusicVal.textContent=this.value+'%'; optSet('opt_musicVol',v); BGM_TARGET_VOL=v;
  if(bgmOn){ bgmFadeTo(v,0.15); } if(v<=0)bgmOn=false; };
optSfxVol.oninput=function(){ const v=(+this.value||0)/100; optSfxVal.textContent=this.value+'%'; optSet('opt_sfxVol',v);
  sfxCtx(); if(_sfxGain)_sfxGain.gain.value=v; };
optNoWeather.onchange=function(){ optSet('opt_noWeather',!!this.checked); if(this.checked){ENV.rain.length=0;ENV.snow.length=0;ENV.lightning=0;} };

/* ============================ LOOP / BOOT ============================ */
let lastT=0, tickAcc=0, fireAcc=0, bootFitT=0, lastVPH=-1;
function loop(t){ const dt=lastT?Math.min(0.05,(t-lastT)/1000):0; lastT=t; fx=t;
  try{
    // During the first ~2s, re-fit whenever the viewport height changes (mobile URL-bar collapse, late layout)
    // Uses clientHeight (the canvas's own local box) to match resize(), not getBoundingClientRect()
    // (post-transform screen box), which would compare the wrong value on rotated mobile portrait layouts.
    if(bootFitT<2.2){ bootFitT+=dt; const h=Math.round(cv.clientHeight)||0; if(h>0&&h!==lastVPH){ lastVPH=h; resize(); fit(); } }
    updateEnv(dt); updateTraffic(dt); updateResidents(dt); updateFarms(dt); updateApparitions(dt); updateEncounters(dt); updateCorpses(dt); updateGore(dt); updateDecay(dt);
    if(window.SoruGibberish) window.SoruGibberish.update(dt);
    if(window.SoruAmbientZoom) window.SoruAmbientZoom.update(dt);
    tickAcc+=dt; if(tickAcc>=1.5){tickAcc=0;tick();}
    fireAcc+=dt; if(fireAcc>=40){fireAcc=0; if(S.pop>90&&Math.random()<0.18)igniteRandom();}
    render();
  }catch(err){ if(window.__err)window.__err('loop: '+(err.message||err)); }
  requestAnimationFrame(loop); }
try{
  resize(); genMap(); rebuildCoverage(); rebuildValue(); syncTraffic(); syncDecay(); buildPalette(); refreshHUD(); fit();
  S.tool=CATALOG[0]; markSel();
  document.getElementById('mysticPill').onclick=drawTarotCard; updateMystic();
}catch(err){ if(window.__err)window.__err('boot: '+(err.message||err)); }
const BGM_FILE="ost.opus"; // loaded by filename from the same folder as index.html
/* ===== ambient background music — Web Audio API, gapless loop =====
   Decoupled from sim/raid/combat state by design: never read, never modified by any
   gameplay system. Volume is user-controlled via the Options menu (real-time) and persisted. */
let BGM_TARGET_VOL=optGet('opt_musicVol',0.16);
let bgmGain=null,bgmSrc=null,bgmBuf=null,bgmOn=false,bgmLoading=false,bgmReady=false;
function bgmEnsureGraph(){ const ctx=sfxCtx(); if(!ctx||bgmGain)return ctx; bgmGain=ctx.createGain(); bgmGain.gain.value=0; bgmGain.connect(ctx.destination); return ctx; }
async function bgmLoadBuffer(){ if(bgmBuf||bgmLoading)return; bgmLoading=true; const ctx=bgmEnsureGraph(); if(!ctx){bgmLoading=false;return;}
  const bgmURL=new URL(BGM_FILE,document.baseURI).href;
  try{ const res=await fetch(BGM_FILE); if(!res.ok)throw new Error('HTTP '+res.status+' at '+bgmURL); const ab=await res.arrayBuffer(); bgmBuf=await ctx.decodeAudioData(ab); bgmReady=true; }
  catch(e){
    if(typeof BGM_DATA_URI==='string'){                       // legacy fallback for older saved copies carrying the inline payload
      try{ const res2=await fetch(BGM_DATA_URI); const ab2=await res2.arrayBuffer(); bgmBuf=await ctx.decodeAudioData(ab2); bgmReady=true; }
      catch(e2){ bgmReady=false; const m='bgm load failed: '+(e2.message||e2); if(window.__err)window.__err(m); console.warn(m); }
    } else { bgmReady=false; const m='bgm missing/unreadable: '+BGM_FILE+' — looked for it at '+bgmURL+' ('+(e.message||e)+')'; if(window.__err)window.__err(m); console.warn(m); }
  }
  bgmLoading=false; }
function bgmStartSource(){ const ctx=bgmEnsureGraph(); if(!ctx||!bgmBuf)return;
  if(bgmSrc){ try{bgmSrc.stop();}catch(e){} bgmSrc=null; }
  bgmSrc=ctx.createBufferSource(); bgmSrc.buffer=bgmBuf; bgmSrc.loop=true;            // sample-accurate gapless loop, no re-trigger seam
  bgmSrc.connect(bgmGain); bgmSrc.start(0); }
function bgmFadeTo(vol,secs){ const ctx=bgmEnsureGraph(); if(!ctx)return; const now=ctx.currentTime;
  bgmGain.gain.cancelScheduledValues(now); bgmGain.gain.setValueAtTime(bgmGain.gain.value,now); bgmGain.gain.linearRampToValueAtTime(vol,now+secs); }
async function setMusic(on){ const ctx=bgmEnsureGraph(); if(!ctx)return;
  if(on){ if(ctx.state==='suspended')await ctx.resume();
    if(!bgmReady)await bgmLoadBuffer();
    if(!bgmReady){ bgmOn=false; return; }
    if(!bgmSrc)bgmStartSource();
    bgmFadeTo(BGM_TARGET_VOL,1.4); bgmOn=true; }
  else { bgmFadeTo(0,0.6); bgmOn=false; } }
function firstGesture(){ if(!bgmOn&&BGM_TARGET_VOL>0)setMusic(true); sfxCtx(); window.removeEventListener('pointerdown',firstGesture); }
window.addEventListener('pointerdown',firstGesture,{once:true});
advise('Build something beautiful. Every act costs <b>$SORU</b> (top-left) and <b>100% is burned</b> into <b>Kami</b> (⛩) that ages the whole island through 9 Ages. Buildings you keep standing pay you <b>SOL</b> — swap it for more $SORU at the DEX. Guard your wards with FIRE & POLICE; raid rivals (🔶) with ARSON / PILLAGE.');
requestAnimationFrame(loop);
setTimeout(()=>{resize();fit();},120); setTimeout(()=>{resize();fit();},500);


/* ==================================================================== */
/* === ykMascot === */
/* ==================================================================== */
/* ============================================================
   SORU SHITI — Helper Guides  (Myo, Borg & Suiko-bun)
   A self-contained UI overlay on top of the canvas.
   • First run: choose a guide → it HATCHES from an egg.
   • Toggle fully on/off (👁 in the zoom cluster).
   • Switch guide later from the ⚙ settings panel.
   Never touches sim/economy — reads state, wraps place() for one tip.
   ============================================================ */
(function(){
  "use strict";
  if (window.__guides) return; window.__guides = true;
  var IMG = {"borg": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAAICCAYAAAC+6BRQAAEAAElEQVR42uy9e3xcdZ3//zpn7plMZpLJPQ0JtEl6CSm0NG3pnaq0tqBL0VW2VEHLd9W6C4t+FfX7A3ZXXXd1YRVd166wIuuqa1kXWykotLRUoKVIY9v0CklLmtukySSZzEzmcn5/zPmcfM6Zc2bOOXPmkjbvx2MelEkyl3M+53le7+uHwYzNmLwxlY/uRKTjMMs5nAwAMMEABwCWtnZu4OHtca0v2LhtRz2ARQDq+UcpADcAL4AyAMUA7ACsAMwAWP7B8S/BAYjzjxj/iAAIA5gAMAbAD+AygACAUQD9AC4A6BuJm8cADIw883h/qs9ZumW7iXM4GWvTAg4AN/Dwdo76DDN2JS3ymUMwYzzsmEjHYYZzOBkmGOCGd+2MqYCEw1Vkt5pC4yYAzEjczHrYqAmAiQdZFYD6kbj5Og8bXQZgMYDqmL047QcyhcYVf6bm7xVeLwhgGMAAAB+AdwCcBdAzEjefBNA/8szjfUrfl4L/DBBnADhj09VW7X6bOf7U91le5cTl1Nyq3W8zF3/5724AswFcMxI3zwIw18NGq3jlVg7ABcDBA4/l/2vmHxYAJhpWptA4RuJmAR5EUVLrULQeOYczecEGA0pfiwYSx/+t8LoeNsqkgicPyGEA5/nHWwBOADjuD4Tfk94QKh/dyU6ePcHyx28GiDMAnLFCV3e8giEXLH0xM0Xnj80GcN1I3HwTgBYArR42OgtAecxezOpRagC4kbg5DoBjggEGAFvs9TJVzsTLOWrqRL+8zikWnWUNzUkveLn7jOwb7QuYkp4L9vYAAPoDcfI5uZG4mYCXQJIDwHrYKCsHR1NofBzAuwDeBHAEwGEAnV1PPzGh4DbPAHEGgDOWT6t8dCdL3NmRZx6PSn/u2Xp/lYeNtgC4iX9cPxI3X+cqshfJwY2CmNzaYeSUmoeNAgATsxejysnCUVOHdc4YyhqaUTarHHETYGET0LJwkaS/jzAW4WcRxiL7O+ksynGIxhLvcfk9nwiiBJjB3h4CSCkcOQ8bZQGwUhXLA/EtAAcAvOoPhE8N79o5ITnGZiYY4Frv+Vz84OYbZmA4A8AZyzb0eJcsJlF4TOO2HQ0AFo3EzTfzwGv1sFGvjHtKQMfxLi3jdtoQsxcnqTZarckpNWKxykp4HXEBdgDAxCcxCROsiAn/JaCiLW4C2Jj6Y2A2yf+ymWFSQpIbCGEwGBTBkYBxbCLEMcEAxzmccd6VNskA8RyAN0bi5t8DeIMJBs7QLrPEXY7PrNYZAM6YgUpPGp9q3LZj1kjcvMTDRteOxM0rPGx0bsxe7JRctNxI3BzjXVOGhx1T7i0RQa6soVmAGAARyFQtMB52cmZFrCCOoxwgoxyHge5hERS7zl2EKTTO+QNhjnM4OV7pSoE4CeDESNx8wMNGfwfgcNfTTwzS5wwA07J4yYwynAHgjOk5Z6VbtrPSUpTGbTsWjMTNH/Cw0Q8CWByzF5dK1R0TDMT5c85KYbdl/uyE69ZQngS5SDwZVESZxU36v0ihAFAtGENRFpff84lU4rnBCTDBQJwA0VVkN0nCCAMAXgeweyRu/t3IM493kZ+RzPLwrp1xzMQMZwA4Y9rUXuO2Hc0APgTgwwDaY/ZiswzwWKm6o5VdtZNJCbpsWqEDUCsQu85dFLnMfGKFpWA4jkTc8FcjcfNv6XpEz9b7zdd/7JOxGVU4A8AZk6g9Gnr19325bGwitNHDRj82EjffQhIXPPRifKJCpPDk1F2uYXclADAdECP9QQwGg9h18jyCvT3wDY2Cd5fjHjaKmL3YRMFwEMBuAP85MXvhPqLmS7dsN+ktNJ+xGQBesWrPs/X+mz1s9C4AH4rZi2dJoMcAYIq9XqZxTr2g8AoNeFcS/NIBkcQQpeoQgBwMjwL46Ujc/AuqEJvc/Gbc4xkAXh0mvfs3btvhBXAHgG0AVsbsxSSBEfMHwgBfV0eg516yUsi4FhrwrnT4pQNipD+I06eO4bfn+qTKkI3ZixkehEMAnh2Jm58ceebx1+l1MQPCGQBeNW6uZ+v9N3jY6CcBfCRmL66VqD2WcziZORVF+OCcakHpEZvgrChiJgv+S18tEJSD4aWuy7jcfQa/PdcnJFHcThtHVCF/k3sRwL/5A+H/JWtjBoQzALyiwde4bccHAXwGwAdj9mKWUnukiwKNc+qxZf5sWK+pFUA3wVkBYFqA72oFoBwMiZu86+R5XDzeSatCobTGFBo/OhI3f9/DRn/e9fQTwRkQzgDwigKfa81ms6l+zh0eNvp52s0diZujTDBgIsmMD86pFlxcAr3JGAeriZlW4LtS4CdNgEQ5LqPXudR1GbtOnkfXuYsYHxoC53DGPGyUobLIx02h8e8C+GnX00+EZkA4A8BpZ/yCjfFursXDRj8O4K+RGBEF8L2zTDAgxPZotUegB2Bagm+6wi9VJ4mc6YEheY9QlMW5Q38Q3GMkkia0e3wSwD+PxM0/HXnm8UnpupqxGQAWNPhcazabvQ2NHxuJm//Gw0Zv5H8lTpIas6+pSFJ7I1GLAD1iM/ArDNgZCUE59/iZlw4ogfCPAP5pqLvrF2Ov7I7zHSaYKZ+ZAWChgY+4KEzjth13AvgCgPZ04JOqPalNp0QH6fe9koGnBMBMXGXaPU4BwkMAvt719BPPkzUnN/FnxmYAmDOT3o09W++/3cNG/y+AFfyvCImN2ddUoPkDH0Z7tQ0ecwQTnBXBUBQmi0kWfNMRgFcL9JRAl24YQwYgBIkRmkLjvwbwd11PP/HWjFs8A8BCAd/7PGz0SwDeJ6f4mj/wYayssydUUoxDLBJLC75Ch1+hqr5cQE8JcFreOxUQpSA8f2EQVJcJyw9i+OFI3PwNvs0uqdJgxmYAmA3wMZGOw8JCa9y2YzmALwO4XcnVLbt5DawmRnBzRRCZUX7THnx6AahGFZoZBlGOw6kDb+C35/oICGOkfMYUGu8B8PWew4f+LXLqj/EZt3gGgFk7fvQdtnHbjtaRuPlLfMsaC4DzB8JxACY6xuewm2XBlw6AM3V+0wt+RrnQqb4fyRo/dewSxoeGOLfTFqfigwcBfKXr6SdenXGLZwBoqElKWur4GN+nARQBgD8QjgEwFXu9uGdhrSrwXQkAnAFf7mFoZhihjvBPHWcBgPOw0XjMXmwyhcZjAH4A4JGup5+4XPnoTrZl8RJuZurMDAD1urtCnK90y/YizuH8nIeNPhizF1fR7Wqkju/Da5fDYTcDgJDcuFIAWGhJjisNfFpgqBAfpN3icwAe6nr6iV/NqMEZAGbs7nq23v9RDxv9/wAs4H8e8wfCrNtpY+pb5wngo5Mb6QCnxgoFgjNxvsJUhHR8UMEtfmYkbv6/I8883jvTSTIDQD3u7g0eNvp3ADbT4OMcTub6tiahcyOd4tMLwRkAXp3w01pYLeMW09niCwD+uuvpJ359tavBGQCqVH2lW7Y73E7bQyNx8xc8bNQBSWZ36/rVIvABSOnuTncVOAPA6QFB4hZ/57n9GB8agttpi4Hfr9kUGv+ePxB+aHjXzoBrzWbz2Cu7ozMAnDEAiVgfNaV3HedwfsdVZL+RivOZ6CJmq4lRBT6tEJSDXSGMvCrEIucZGCofl1CUxc4X35BTg28C+D9dTz/x1tXoEs8AMIXLu/6Oj1jPF1c9CuD/IlHWIhvn0wo+LRAsxMxvIff0Xs2JEB1qMBqzF5tNofExAH/T9fQT/y69+c8A8CqFX+mW7fPcTtuPAKxEop6Pk7q7JMFBLFsALLQhp1fTUIMrBYD0cYn0B/HDo8dx/I23pS7xv/oD4QeHd+0MXi1xwRkAUseCivfd7nba/h1ABYCoPxA2uZ02ZtvSZqGDIxPVp1X9FdrA01wBkJ6MMgNA44BIjs3xV17Hd197B0jUDXK8S/zaSNz8FyPPPP7u1RAXnAEgfxwqH93JDDy8Pd64bcffAPgnyuU10arPCPBNN/fXiljS5ubZhmA6gClNW7maYKe0obuWY6zgEvcC+ETX00/87kqPC171AKTjHY3bdnwbwIOgMrytS2/AlvevFFSfEeBTC8BCgmCuFeDVBjYjFJ8exUxc4sd2v4DzFwYFlxjAJIDPdD39xJP8NcJdiRA0Xc0LicCvcdsOO66/+Sd2Jv5/MJXoYG/5xL3YtGg2JidjiEYTMWHWxBp38Nn0F7mFiRXgosn+dcDOADDlsZHLUMT5hxaLA7AUW7D0xhZcCMZx8d0e1m41xwGYY/biD5UtuMHc8y//72VyvQT2/+aKguBVu8qoZEcx53D+t4eNbkAi3md2O224+ePbsLLOLri8wsWfQwV4tSZAZtRf5mpQ73E//srrePqNMxiJm+m44JMjcfP/GXnm8eiVliG+KhVg5aM72aEfPBJv3LajNGS2P+dho+8j8Cv2evE3d3wA19aX5hV+RP1FYCooFTij/qaHGtRjcQDVjfVYUFePt0+eYkbiZhTFQrGYvXhxUSx0A66/effQd78aLt2y3RTqfOuKUIJXHQApt7cUwHN2Jr6awG/2NRXY/omPgPWUYHIyGTpcnDPMBVbr/kZgKhgI5ir7OwPA/ELQXVqEBXX1OPrOe8yYf4x1sPFozF48rygWWoPrb/7tyC9+MHalQPCqAiCBn2fr/e4Qx+6xM/EVNPw+/vE7YbKYRLV9RitAq4lRBT8AiFCnpxAAmAv1N+P+5h+CkzETSsvsuKWxEaf7e9HrGyUQbCyKhTbg+ptfHPnFD4auBAheNQCk4FfiYaO/sTPxlbmGn1rlpwTDfELQKPVnTnGhzsCvMCDIspyQHFncNh9nuy7QEKwuioVu8yxsf7Hv5z8cmO4QvCoASOBXumW702Nj/wfAOi3wA4zJ/mYyACHfKtAo9RenYMdKHjM2ZVGOE7K6Wo6N0e4wy3JYfuNcIUPsYOMxAGUAbvcsbP99389/2Odas9k82X1mWiZGrngArtr9NjPUewmWWbMtHhv7CwAbtcLPKADGOP0KMN8q0Ej3d0bppYefFET0Ix0QjYQgsSVNtXSZTCxmL/aw0cnbPQvbXxp47plez9b7zaGO16cdBK90ADJj4Rg79INH4va2ZT+xM/GP6IGfUQBU4wIXMZOwMDEhAVIIEDQ6+TGj9tSp5FQ/TwfDbEOQV4JuAB/C9Tf/buSZx3unoxK8kgHIuNZsNvmf/3mscduO79mZ+Kf1wi9XAKTr/Uj/b75dYaPhN6P+jHVj5dQhcZ+zYcub69BFKUEAJXYm/iHPwvbfDTz3TN90iwleqQBkPFvvN43+5umoZ+v9f2dn4l8AVee3/RMf0QQ/IwGYyg2mwRZRODW5LIo2MvExE+fLHgS1qEcj1KkMBN0ANnsWtr8w3RIjVyQAPVvvN48883i0dMv2v/HY2K+DH2pQ7PUyH713GyodkK3zywUAU6lANQDMpQtsZOJjBn6FBzM9NgkTGMTlIOgB8EHPwvbdfT//4bQpkbniAFi6Zbtp5Bc/iJVu2X6X22n7N1BDTD9y36dRb4tohl+uAajk/pL44HR0fbUE8WcsMxWY7ZtiNGYCGFkIlgF4v2dh+7N9P//h6HToHb6iAEj6exu37Vhlt5p/BcDkD4QZt9PG3PzxbZjvYZIGmHJxdefHKACmKoUh6k6q/nIJPqPVn9QFnoHf9Icgy05BUCY7XMlGJ1cycxb+YugHj4QLHYJXDABJf2/plu2z7VbzXl6Sc+FIjL3lE/diZZ1dUH4miwntlSXwTUaEKS/ZBqDaDhAagPkAH7EYWEMgSPajOHXwNfziZC/qLQ64PA5EOW4GhlcABFmWk2aHozF78TUONr7Qesf2XwLgAvt/M6MAs2yMc93tjNVbXeR22p4D0MK7vqbWpTdg06LZwmADh92MG8uKAQAXA5OqFWAmfcBaCqBpAE73zg+yR+2/vXAEvzl6HoNdFzFks2FpU92MK6wjhFAoFo2ZEGVZcCzAxViwLIeFTfU4946oY6TFNnjxmp5/+X+/5uOBhXlzuUJcXzKi57sA2sGPsW9degM+vmGVCH5tHicAoGMkoDoLbLKYDJ0Eo2Rk/BWxVKUw2QSfEfDjWCuiHId/ff5N/KnjLFxFdnAO5wzJMriZSB95BQe/ROKmRGLEihj+6hN3YPY1FfAHwmZTaDwasxd/snHbjoeHd+2MVT66syDF1rQHIDXX7xNup+1eULV+W96/UhZ+ADAZy11YQs17SeGXLwhOGuAUcGziM9PwM4XGMaeiCNs/sHSGZlegRWMmmE0xfPzjd6LY64U/EDaZQuMxAI80btvxiYGHt0c9W+83z7jABhqJ+3m23j/HY2OfBWDzB8JMsdfLbLr7brjNcXBxLgl+HSMB2UywXFLEKOUX49LXACqVvky3BIgFcfzgt2+I4FfuLcFffeIO2M1xRDlupiB6GrvFcY7lb3T0TS/hDrutUSysrsbbZ99hkBi4zCFRHnOw76fffbfQymOmMwAZq7eadcxfzPI9vvMBxMORmGn9X2wVMr7VTgYtbpfoD5Vif1ycS4KgkeUvgDIAIylOxXQCoJlh8L3fHpmB3xUMQJblEOdYMJw8BEvL7FhQV4/XT5whALQgUR6zq+/nPxwupMzwtHWByRaWAD4PYD2opEd7tU2AX4OrRPR33WOjaWN/2Yj3WU2MrmkwuR6Hb2H1f3cyUj0V/GbMIJezQI4lK7mU4iYgFGVR21iGbUub4Q+EWQCxmL24DsAvGrftsBMBMwPADFxfPu431+20/R0Su7ixs6+pwIfXLleEHwD4Y6kvcALHXCU+CsmMgN/Tb5yBh40K8Htg860i+M2oP2MsV8cxGjMJD60QbFm7Cq1LbyDxwGjMXrwUwBP8XM6CuLimJQAjHYfJ2f8XAMX+QJhzO21M8wc+DJPFBIfdLAs/AEn7fKSCYL4t1+ovEo8hEo9pvkDI/rJPv3Fm6hjai7F1/WpYqhyC2zsDv2mmMmWglw6G0vX0qY1LpZnhTzVu2/HZkWcej7rWbM57UmTaAZDq9rjH7bR9AEAMgKm+dR7aq22wmhhRwkPq/qo1IyGo1fUtYibzuhOc2kxwNJZQyZe6LuPxX+4W/ezB29eitrFMUH4z7u/0d4HVgo+oQGIkMzwSN5tMofE4gH9u3LZj+dgru6OlW7bnVQlOKwDyrm/cs/X+GgDfBMD5A2GGuL6p4Ee7v7l0bfXE/fJR/ycHQfJIBb/Bd/vxzEsHRD+7/6ObRfCbsSvb4mkup2ongwdvXwsPGyUXgw3AfzRu21FmaWvnVu1+O2+uwbQCIO/6ckww8I8AqsD31jd/4MNJpS7TwcWdLiYHQjJO7JmXDsA3NIqYPdFds21psyz8Ztzfq9ci8Rgqrq2SJkWaAXx/4OHt8eNPfT9vHJo2UX7K9d1gt5r/EVTW9/0LrxPa21KZltY3o3aA071oCmw/YCDRH8zFWDBmC5j4JP7thSPo6+5BzF4MU2gc25Y2o3XNMlnlN9P2ZrByyXJ/sBZ3V1oOI6sSOQ6V1zbiwkSE7hluK1twQ2/fz3/4Zr7qA6eLAmQsbe1c47YdRf5A+DsA4A+EUez1on31OlRY89cpqbe8Zbq4wkruzr8+/yYuHu8U4FffOk8RfjPqLztWKMc1rpKVkXgMH167HLOvqcBI3Mzy8cDvNG7bsYBvl8s5j6YFAKle3wfcTtt88ImPxjn1mF0UVcz45gJ+blNMsdXNiHa7QoIgG0uUypzef1AEv3JvCT6z8aaCvkhnTCNcTTGYTek9kLhGR6nayWDr+tXwsFEWAGL24mIAP66/78u2SMdhpvLRnTldMAUPQCrxcS2AL4Kq+fv4hlWq435a3F217q/bFEtZV6i38Fn6KBT4kaTHU8cuieD38Y/fKUx+SXKlZhIhVwUIVYd2+Hhgfes8+ANhltQHmkLjjwzv2hmLdBzOKZOmiwvMMcHA3yOx9wAHgFnz51sNgZ/Drr0UKRaJocIaR4OrRFVd4XQzaUE0gR9JephC48LPtq5fjfqiKEJR5aUU5Tjhkep3Zky9pTueuQIhq4ONkvpAMjThi56t96/lGxxylpsoaACWbtlu4qvGl7udtj8n6q916Q34s1qbYfCTTolOBz9SaN0xEjBc/RUaBC3sVEfMzhffEDK+JOlR21iGUJRVrRKULtwZV1k9+MjxKoTxWHGTvrVlYU3Yun413E4bGZpg8rDRH3q23u+ytLVzuYoHFjQAo75eDgDDqz8T6fjY8v6Vul6PQMlkMWFptRtuUyxJwaUrkZGW21yJ7XKkI8TCTu2cJ4371bfOQ8vaVYhynCHHIDY8U5qkpJrpRyrQ5RqCBH5aWygbXCVocJXIlca0eNjotwYe3h6nur2uTgCWbtluGntld7x0y/bNbqftFiRq/kz1rfNwk7dY9+s67Gbh7wcn2SSIkX/LgTAWiamaKag3KzzBWfOe9CB3ZwtrQiQeE8X9AAhxP+lcP461CnMAtSrB46+8ju88+xt877dHZlzhVG5ogarkBlcJ5rhLMcddqvlGe93qm+l+4RiAzzRu27ExV65woQKQsbS1c56t91sAPAwA/kCYK/Z68fENq3S/aJvHmTQRWml/YPI8+RkZsEAs1VSZTLK/hTT9hShAEvcjxc5b168Wjo8UegSEamBI9gv57bk++IZGcfF4Jwa6h0Wu3gz08ufe0t1ASl1B0hjgHHdpyjVFQ5L83ofXLkex1wtMTYh5wrP1fk8uukQKEoCk7IUJBu50O22Lifpb9Wd3GJL4AKaGIkghFovEYDUxONwXxuP//kv8ev9rorif6sWjE4K5VoDS4Qfk/8lxOXfoD0lxv4prq4SbRypLBUJyUdvNcThq6oTnd508L/ztjGlPdmQKy3QtkHTMj8BP2mPf4CoRQZD8nhSM5HqqdjK4Z2Et7Qpf52Gjf5+LLpFCDGAxS/7pSY41m23hSOxpu9Vc6Q+EMfuaCuZDq29AlT3zC6NjJIBoNK44AXpyMoZdT/4HxvxjGOjpg3Pejdh8jVv0ex6bDX3hqKILrGYHOEUo5bgLxMKaEKcusjjHwWxOuL7/9uJrorjfhg8k4q+aBsUyJuHBcDHhIiU7w9VbHHj9xBnE7MUYu3QJC+rq4fHYruqd4+I8zOKS51I9yLFiJduQamkTiKnQRAwnBmKc41BmdyRdH2ORCEwMi2s9HpTZHfDYkhOXY5EIIvEYShvq0ROMkS6RGIAluP7mAyO/+EFWp0gXnAIs3bKdPbj5Bg7AnW6n7Xokyl7Y5g982BD11z02imAoqqherCYGv97/GvyBMNxOG9xOGxZ7zapjfUZ1heQrFkiKnYnrK1wY9mJ8eO1yWdWsN45F/l02qxzl3hKhvIaowJl4HzRleZUSJ9leL3IqkCi8dF4T/XPiCo/EzQwA1sNGv9e4bUcRnxXOyp2w4AA4vGtnfP0dH7H6A+H/i8S0F8y+pgLt1TZDXp8kPujBp8QcdjMmL1zCxeOdcDtt8AfCqG+dh6XVbtnXcptiIhhkqyUul24wcXGkJS/3LKxFtZNR5fqmfC/GknTR2s1xfHBOtQDaYG9PorRGobh6Jh6YPdOzIyAby+ymaGFNGAqygivMBAPEFW4F8EW+CywrrCooAPJZH+58cdXtbqetjVZ/RsCFTnzIZX6J+vAHwgnAOW0pky4NrhIsrXYLn20yxuV0tzkjXWD634Pv9suWvMQiMV11X2qsZe5ClHsTasA3NIpzh/4wQ7w0IDQKhukSHVq8Kz3W4CqB1xEXssJ8gTTpFf5S47YdCwYe3p6VXuGCAmDrPZ+Ll27ZbvIHwn/Dqz9u9jUVmF2Zea8vcX2J+qPvWCTJIaf+1LjdbR4nbvIWo8IaT4LhdAGinOtLSl6I6yuFpVEXc5TjYKlywFFTJ7jB+wImRBjLTIG0hpBCrixuSi6AjpsyV4Ek7EMVSHMxe7EDwGMAGL420NAvXDAALN2y3cTH/ta4nbblvPozNX/gw/CyYbgz7EeU69mlT9hkjMMzLx1Qrf6U7mSk1IYAkZ5UowWKuS6HkXN9yWIkrq9a9WfhIrBwEcWfKbnGW+bPFtzgrnMXMfhuv+Amz1j2IKjH7aVBSNZF3ASc8w/rVoFkb2yqV9hkCo3HYvbi9zdu27GVrw1kr0gAWtraySr/DDBV9ze7sgRDcZtiMLV7bBQdI4GUbWm0+pODoMNuxuG+MM5fGBTU37alzRknXUgQOBUUC8FI14ec60tKXrS4vhHGgghjSYKdEvxIyQudDDGFxnG5+8wM3dJYrnuClWwoyGKk25eRK0y8C3/MhC3vX0lcYcYUGucAfLP+vi+XD+/aGTcyIVIQAKx8dCfL9/zOAbCJV39s45x6RaC9OTSOFwYjOBVyIBiKIhiKKh74VBNbTBYTJmMczrz4a+G5Yq8X1avWZuW70lBMNUorl1lgJddX2u2h1f2lEx5K8CM/Y+KTSTWB+wImESBnLBl+eRcurAkj3T7813/9Co//cjfeOfAHROIxXRCkRY7HHMHW9asJo+Ixe3GdKTT+CADOyIkxBQFA0vfHBANb3U6bwx8Ix91OG9O+ep0s+E6FHBiKJ7LCntiEADI9O8GRomda/RlZcJ3uhFdY4xm790aYnOtLuj1MFlPGsT+iCtMZ7QYHe3sQ6Q+mhOd0tUh/MOUEHSWlp1TekslNYjLDcuDL3Wdw/sIgAOB7L/8J7xzQn8AioZ8JzgpPQzlpkyMJkf/j2Xp/u5FtcoUAQIYfde8AcBd5rr51HoosUx9PCj7aRkxFilliOdeYZIFNFhOCoaig/owuuVFr6fYqJj3C2egVTuf6Gj3sQQ6CpMmfAIHOBg8Gg1dcHPD4K6/jsd0v4Ls/eVYYApHu+6WK8xH40W2IWloSMw2fuJck3FUgETt/+o0zGHy3X5cKnOMuFbyiCc6KD69dThIiiNmLzR42+u3SLdtNVMhsegOQBDX9gfB6t9PWBL6ovf76JeIYQzw1lJRUlNTFpIcdWE0M/EdeFdQfABhVcqPGusdGhbpENW4wcZuNgiAZeJAq65uVi4ZXgxHGIoLfd3/yLL7z3H4AQJUzcVyuxKLofQETfEOj8A2N4gevvaVK9REI0uUvagGnBEaj4EimPNP2zEsHNO8xTbu/5Nr1OuLCxBg+IbLK7bT9xcDD2+NGqMCCSYK4nba7eBDGtZa+eGITsu4vqfuTwo/8OxiK4rfn+pLU32SME9296ETLm0Pjwr+7x0Z1B3yJ8ksHWwI74pKT+KFal5RMdlGydw78QTbrG4lnr+ZPDog7X3wD5y8MYnxoCP2BqSQRKYrmWKsqF3o62DpnTFC6wd4eXOq6LFv0Tas+qftrpLKzIpaUCaanAqVba5Jd3wAA5y8M4sfPv6Hr+rCwibi81cRggrOi7OY1ooTISNz8t43bdnh4FchMWwC61mxmeX++xh8IbyRsogPh6WzEVKToptHqj/4dov5+vf81WfUXi8QwOMnizaFxvDk0jr4Ah2AoKrweKWUZnGTRF+CE36PBmM5SZa2lJhePJCOIpAtV+pxSXJS4vk+/cUZQf8T1JXduo2v+pEamyRAXPOrrRdTXizbL1LHpD8Rx+T2fkCi5Emxe2xKUe0vQH4jDNzSqOdudDbeW7AJH1hBJ1pFHulFXdBEzcYUvHu/U7QrT17A0IeIqsjcA+AKvAtlpC0Dy/m6n7Xa30+YhyQ+p+6vXvVSa6UfUX9e5i0Lig1Z/cnuEKEGWfp4GIwGiEvzUFkinS8ZIFyr9HJCoy1JyRWj3ku71zQX8mPgkTBYT+gKJ+suh7q4EHMwRLJ7fJHymK7EcxlRqwgfnVAsjxn57rg+R/qCq1j+98CNDbqVrIRpLdH+YLFPgS6XM0im3j3/8ziRXuC/A6a4PJCrQek2tNCHyV56t91/Hl8Ww0xKAjls+RGp6PoZE6QtX7i0xpPNDmliQ9uz+ev9rGB8aEp6j1Z9uV4LfIpM8JmNcEgS7x0YFeZ8p/NLdAJTAJ93ZDYDQ60v+Rm/8RouKsXARQYUT23DHpkQMcHJMFDO7UowATtr6d/rUMdnf1xrvUwMv0glFxEA68NE321QQjMQTMzOlrvCv978mrEnpGn2jz4+OkQDO+YeFkJJSaGjL/NkkIRKP2YtdHjb6MBJlMcy0AyCp/Yt0HJ4P4Gbel2ebP/BhQ15frvRFSf21Lr0B7dW2lFNi1Mp1KRBpd5ckPbKdZEkHv74AJ8Q+SeLjutU3C79DpvvGIjHDQUhcWQsXwfFXXsfxN95G08gFAMDq1mvFSolXSHQcUA4m0ylDTLf+SVVgbDgREqC/D2kHTNVdQ69vJj4pAhz9IO2OJosJ15WV4rqyUsO3lI3EY2hZu4qoNcEVHun2Ja2lBleJsC/PBGeFP2ZSrIiYjHHSDpE4gLsat+1YlElZTN4AOHn2BHF/twCw+gPhmNtpY2pKizN+7XSbFdHqz+20of76JYZBSanVrWMkoCrpIf0b+kHukuS/WuFH7Nf7X0tKfJCMMB3rua6sVCiSNgqEBGSXui7j6TfOIOrrRWfUgnavQ3B9AWDx/CYMdXcJ2WASB6ThQGAyXfuFyxqaUe4tQZWThW9oFJ0dR2QhR2fNU7rWFhM41ioq8yIPGnh6oadmbREIUlOeBVd4KMhm5Ar7Yya6LIaL2YvNAL46LWOAI888Hqt8dKfZHwj/GXlOWvun1qQlMkrxNTn1V986zxD1lwsjd0nyX6XFl8oNUqr5I+1wcm4PDcJMYJgq7rdifXLfdbvXIbiIcsrvUtdl/Ovzb+L4K69PK/ARcNc2lsFRUwff0CjKvSWCCjQzjKaMdywSS4oFy8WG1QCOPM75h5MeREWqMTLailgqV1iLsHDYzfSewnEAtzVu23GTXhWYFwCSsVeRjsM3UmOvTEYlP5RqBpXU35Vi6e6ucjV/H9+wSoBfqguFgJB0hUTiMU1AZOKT4FgrYpFYUtyvYm6z/KJftlYoiaETIWaGQaQ/iGdeOoCLxzvx23N9uNR1edq5wySuRccCOzuOCMdLLfz03rilsFNKlBCTmwKTaq1dt/pmAquUrrBW49Ulw3PDAuCLgGieQGEDMOrrJT7L7QBYfyAcK/Z6kYn7S+4qSsqIqL9gb4+g/sq9JWivtmWl4yHXlu6uamFNSTV/H5xTDbcpPfykICRlETQQyaInUJRewCR+t/PFN3DxeKco7ke7vsQ2rl2Ndc6YAOp9AZMAtwhjwWAwKCgnPaUkhawCSZhALcy1Krx3LouBl01TcoXJelXbBkpCR8FQFA67GY1z6uEPhE08BD/s2Xr/9QMPb+e0qsB8AJAZe2V3lP+gm8hzjXPqdbm/xAj4UpWXHB2KipRHtro+cj0ZmmTOUsFPmviob50nJD4yCYRLa8UIFOmEBYEhyTxX9pyVjfsRW3RDO8pdLpQ1TCnDYG8PojHx6xLlFLMXT8tMMfkuUhV47tAfEvHONC2S6W7ctEv7zuVh4eYUN2W/zCmVK+w/8qoIvFpmZpLvS4E1HrMXWz1s9K95GBa2AiSjbNxOWxu954dRrmiqljm5nl+5ur/p5PKe8w+n7SUGkhMfW+bP1qT89ECRvtBJ0TWBn1Lcb9EN7VhQXwHf2BiaKssFMJCCaHLhV1xbhQ/OqYZvaBRVTjZlR0WhGknqyKnAS12XFbdslVN/UtjRwCNdPSaLSXBhs6385FxhEnZ6+o0zGOn2CUkVNYKBhqREBbL8uKw/L92y/drhXTs1TY7OOQCDL/8v6f29FYDZHwjHi73ejLO/qe4iJosJh/vC8A2NynZ9TFeTDkeQ6xGmEx+0+qu4tior8KPVBzm2g+/2C7FHAj9S76cEPwAoc5qF8VhyBdG0QvQNjU6rLTXprC4ZBktgT1zF0/sPpoSgyWISoEdPOZdmgOkQhXRt5DLWKXhrgTB2nTyPSFxfXzsRLHRdIIBit9P2GWBqulShusBxJGr+1pMnMnV/ifKTK38ZMRUBAC7+6YhQnFns9WKx15wV9VeIGyPRHR/0sAO5TF+m/c1EgUTiCfeMwM83NCpkfeXgt3rZChH8AKDc5cI6Z0xQRsTNlTtndF+ttFym0GOBTHwSFddWCSqQ2Pde/hMG3+1XpQSVupVInE+up1fp+WwYVcMnSojonXweDEVhvaaWvCZJiGwr3bK9YnjXTsKYwgJg5aM7mbFXdsdLt2yvAnCT0Z+hN5K4m5AZgQDgZcOIRWKi0pfGOfVw2M1ZUX/53ANEupikZS9AIvFBd3xIf59cMFIwvnN5OCUYCfgACDEmGn6VPWcToJMUOwPArStXoqHCI4KfnMoL9vaIzlnZrHLMHu8XoEGrwFyqOLpkRTrpRukhp76lKtDttOFnjz2mGoJK8V8lBUgDMheu8IfXLhd6hYnKVasApcJCogJZXlhVuZ22vwDAebber4rq5pzK/sQk1xiApVTvL5vtUhRS+kL2+W1fvQ6TsewM2SwkBeiPmZLKXuiOD6ULRulWScAoejomXpSxSAwWvtbvvyj4dUYtSRnflrkLcR2/5agc/ACgwuEQQWFwkkW1ZSoBYK+pxtDxdwE0UipwdqK2MccurdSucZenjd9d8PvAsVaRCrx4vFP4zp1RCx7/5W488sVPwmIxKdZrTodwTbUzhg/Oqcb3+AEkvqFRTF64BE9DOUaiFs3XzmSME1Tg8TfeZvjw1l82btvxo66nHw/yKpArGAVoaWsn/1xB3GGjen+lbi9xfYlyILGHcm8J6m2RK6L0JR3I+g7uV+z4ULpLq1ET9IOONRG3NxaJ4b/+61cp4bfohna0N81K+z2qPOLYsGlgQPT/ow1zE94FrzABFERJDMl8V8l9J+p5aaaXVoHl3hLMM0cw1N2FJ558VoBfrhIY2bghk9FWUhWYDn5ynhVRxLyAIiqwBcBtADg1k2JyCkB+g2MagIyW0Vd6gqVyyY9sWj5dYJIUUSp7oUddpXJV9Fxg5OKMRWL47k+eTQm/W1euTIr3yZlvbAxOu0m0T4gUbmS2HgCwHUcBINFRUQDJre6xUfTLPN/PP7rHRmHm6+BI4kYuFjjPHMHptzrw4+ffSK3S05yfQrAKaxwfnFMtxOOJCkx37cgBkuzn015tI/MCyQt8FgD4WGBhAJBPTXOlW7bXAVhA3j/b7q9c8kN6B8kGBPO9H7Bc2YsW9Zgp/Ij7RsOvZe5CbFy7GpWl7rTwI0YnQoDkyTBlDc2YZ55ydsnvFerG6iTJdMHvE4FPqgIF0VDXJEDw+Btv4/T+g5qAlqsYX7obM60Cq1etTVKB6cJHStcTme35wTnVAEAKo1c2bttxM88bU0EAkEpNX+922txk9l8233MobktKfugNJk8Xc5ti6Atw6Dp3UbP605MRpOG388U3hNa1oe4uUaHz6mUrBJdXLfxoyBGQk0SIUviCuML5LowmYJPW50l/Lvt9Z5WL4p7EmkYuCPttTGdX2G2KEWBpUoFKXt5kjIN7yUoUe73wB8Jxnms71Px9zgDIOZwEdjdnM/5HzMuGcX5gNC99v2QeYD7Vnyk0nrhDSgadGqkWpPDrOncRptC4AL8V61cJqk8py6vKbXI4hKkwAET7qJTNKofLLV5DvqFRBHt7hI3VC8XUxpxNlsTA1P5APAmElT1n8cxLBxLJJrbwh3fIZXn9MRPcS1aKvlsm2Xuytze/jS7Lq8DbG7ftmJ2uMDpnALQ2LSBX1k25iP8R9xdAUt+v1gWpFX75vLPSRc9AosZSqewlHQhT/Q0dkJeD3233fgq3rlypW/XR1ljuEgOCSoSQTHBn1JKkAqfzhkplDc0i6NOQP39hEDtffGNaeyrVTkYUC7x4vBOTFy4Jg4TpUFI6VUi3x7mdNoZXgU4An5J4n3kDIDPw8HbOs/V+J4C2bL+3lw3jYtiCi8c7heRHtmGbLlaRK1MqejY0nEHB78fPi+G3uvVafP7BB7GprQmsmc0IfAScrJmVTYSkCmUQFdgXmJ7baZJkCIkD2muqUTG3GZ1RC5pGLgj7bWiJB+Yr7idnRAWSWCDpDtF7HZH2OL7ljrBlW+O2HZ7hXTvjNz3wFSZvACT9v0wwsIBzOGtItiabLunhA/uEuwup/cuVqT15kxcuJR4GQJNWf2qKntWYnIslhd/F450i+H3ts59SleHVYiQRQkwa35MbqEBUoP/Iq9MOfuR80d958NQZLJ7fhHavA51Ri+AK9wU42XhgPpMfaoubq50MHDV1QndI17mLiQ4PHV6UQntcHYAtALjzFwbZvAGQ9P8CaPOwURaAIf2/SjYUt4lq/+pb5wm1f9l0f7W4wZMXLuHxX+7G47/cjct/eMVQ9UeKnqtXrdXdb6kWfiSOc8OmjfjaZz+VsbubyiWUxn3oc0gywS53ieAu+oZGsS8w/ZJe5NiT71zuLRFcfHqABD1kVA6ghRLzS6UCeWABAMaHhjK6YU3GOKCuBuXeEiJ+OAD3lW7ZblIqickJAM3lNUTiLCPPVTnZjPt/ldzf8wOjotq/XA89TaXoyM9ouZ9pxlIu9kdm/Rm1iboS/HxDo6hvnYd/3LQiuy6hwzF1Q+VvbnJwHPOPwl5TLajAYG+PMEVmOrvB88wRHHopUQKzuvXaJFeYVoG5To5oBZ9ILPCdHMRT++25PtWbhkmNlMTwtb4ELkvcTtsqQBjEnHsADu/aGW9ff6uZiv9lNQEirf2TZpqz3QGS6uRZTYwwmJXYOmdM9WBItbE/ov4AaG44V2qazxf8gOSOkFRQWzy/SaQCp2MyROoGD9Q1Ycw/Knw/ongre84K348+b9OpXY6ue/QNjeJwX1jX65CSmMVeMymMjiHRDvdpKLTEZR2Aq3a/zQDgznquqQAwlwAwW6pM6v42zqkXBiLk24j6Mw0MiCr9yxqaVc3006v+tN6d6fgRgZ8/ZsITTz6bF/jJdYSIFKBMKYxUBU7XZIh7yUqRG3z0ZCK2SRIiABQTInIQzAYY9U50oVUgXRJDqjf0GCmJ4dcKKYy+vXHbjga5kpisA/D4U98n77HQ7bS5/IEwl80C6HTubyH0/0rVGupqsqb+aDdFr9vrj5nw5FM/F42gzxX8hO8lSYTQLXHSc3r05FlRYsQ3NDrtkiEEVCRRQNzgUG+foALJplEkIUIrdfomRvduZys+qBeCRBQolcToNWr3uDgAFxJ7j9P5iNwAkCqAXkggHbMXZ6UA2suG07q/+TRhXwNKoTpq6nSf6GzH/khPsRR+25Y25xR+ciaNmxLFJ4qh8ZstVfacnZYj81O5wYA4IcJ2HMU7B/6QUtEXYrkMWfukk4NcF3rDFmTvH2r3OHJx3d24bYdt7JXd0ZwC0Nq0gGRfyCgYhq/YvmLdX7kkCHkuGIoK7q8R3Sly6k/JnVYLRXqgApnqQsNv49rVeblY5DLBqYxWgYXYGaLne9NuMJDIehNX+Lfn+jA4yeYk/kcSH5kkQOhrg+rkgNuZuI6DoWhGryuZErMAQFIyJNsAZAYe3h5v3LbDBmA+eS5rJyUSz2v2V40dHYoKChWAaDiDVlNSf5kubNJPXEjwA5IzwXRLHBmLBUBwEwkgiEKabjvHEZCRbDAZj0XbivWrhOfYjqOGlVTpWTeZmjQZcnRIf02gJBlCFMld0t/NKgBJAfRI3NwA4DoCwGyAycuG0Ts8Lip+lqszzJUaVCqFoQO85d4SOOz6AShVf+4lK3UnUwodfkDq2YB0fFDJNS6UMVmZuMFAoiha6uoTFfj0G2eE4uhsWqaJD9nrha/hk7tWtJokGUI4t6l0y/by4V07SXY4uwAkPXhMMLDA7bRZyQSYbBRAD8VtSb2/9bYIhuI20XDUXEOQPEiPI70vMQlu6+kECYaiSeqv2smogpzc3Tod/O6+bVNeQZAuE6zGDfYNjU7bmkDiBpPxWNLvSJfFZDvhY4TbKxsuMzGi80s6Q/TAT3JdkcnQlVRNIJt1AFIJEDIAIV7uLclKATQ5YMSkF4p0SnRelEBPryj+RyS/VpnvNsVEHQB61J90NzmSUFGCXza6O7RaqkywND5IG3GD6Zq56eYGexrKRWuajgPmSwUaCT45N9gUGof/yKu6k4TU3xESTvoD4VEAsLS1c1kHYODNV0gChGSAs1YATUZfpYv/5ROCu06eF1z0cm8JYpWVul6nL8CJCqkdNXWq1F8qt5fewKgQ4Sdn0sxuvG1xWje4pPvUtKsJJOUt65wxwUWk45xyKlCuRU5r7C5bSk/qIdH/T3eGyJ1jtTFAqRbjVWC3pa39FQAYeHh71gHIRE79MV5/35etkEmATETihr4Z7f6S8pdUm6TnC4L0dBq98T//kVdFhdQfXrtcV+xvOsIvldIjSkjORSQqMNTbNy0HJEi/O10OI6cCLx7vVK0CpRlduf2mjcr4Ksb/KKNV/sXjnRllg3khRLhTFuk4XAEAq3a/jawCkCRATKHxOUhMZQCy2AFCKyJS/qIlZpBNEJL2N9pFJydZz9gfstcHANS3ztOt/gj8Hv/l7mmj/KSZYOl567e6UqrAMX9iQMJ0nKZMPAYCc6kbrFUFZlPdySk96UNxXfLdL0TQEDdY6zU6GePQHrsMqvHC63baaoCpBo2sAZBUXPsD4Wa5BIiRccCJSFwYxa7GpPHAXNjRoagwpZm+m2uNb0jVn5a9PpTgV+4tEeB3/0c3F7Tb67SLVb1cUkOuKJpOhpR0n8JI9/RJhpAODmF8VEOTKgVMD0oolBifGmhRc/1EAxL0dHGRmwY/JBX+QPga+udZAyA1AeZG4oeTOXVGW+/wuGjf3/rrl6hyf3NpdIdKJu1vUvVnvaZWs/vrNsVwev9BAX4ABPhtamsqWPgBQEWxFVWTqT8fXRNIG+0GT7eaQKnnMFDXlBQHlIK+kJI+Wm/0tBvsGxoV1J8WFUh+l1/jRCG1AkDU15vdMhiSZcHUDnBonFOPIgub1fif3ja7bPcIk/IXAEL7m1b3d/LCpYzVH4Hf02+cEVQfgGkBPwBgzawi4GhbdEN7Sjf46Mmz03JzLHpGoFwckKhAEgskHTBSFZgr91cKQbUgpN1g4vnoLYqmE69up20WAJjq52RVATIDD2+P19/3ZRsAktLJyWYZWtrscuEKk/gfAY0/ENbdoSItfLZeU6v5NX645w8i+JV7S/DA5lunBfx8Y2MpS2FoF7ei2JoEQVodhXr7pmVNYNmscuHfA3VNSXFA8j1JLFA6DizbmV0j1CBxg+miaAN6ucmbNgPAyDOPxwAwWQEgybCMTYTKATSQD5CtBAidXACgKQFCQJjNRMjRoSh9B9LV/jZ54VLGbW//tfegaJwVgV9706yCh58eW1BfoegGj/lHBXgWakJEOsQgEo+JFI3c1pm0CiRusJIKzLWp3eSIXuOCl8dng9Vsa6vwcwLAa2564CtW8LWBWQEgybAwwcA8t9PmzOYIrPMDozCFxkX1f5nE/7IBQmn8j/QqalkUmbS9BUNRWfh97c7bpyX86HIQOWVAu8irl62QdYOBRBZVaU+NQjAlYCm1/UlVYKENhdVc8C9xg9X0Bstdu9JSmPMXBkuJUMsKAKkOEOJzxGL2YmQjA0zcSrKxSrb2GcnEpO1vSidRCYTSCdJqC5/dplgCfv/1KxH8FrgY/MPWLYZvXlSI1lDhEQFTWhNI9xMXkuJLNb6K/j5KZT807GeP9wsqMNNhGblUiyaLSVVvMBEtqYQLEUgAPG6nrZEItawAkAkKpfat5DmyB8hEJG5oEkQ6XEAvXOlYoFEJEWn8j7obqbpLEhjqKXxWam2rb52Hr332UxltVJ5vo2sBU7g8gi2pr5QFw5h/VHacfKEpvqQLXtJBpFQcTmKeY/7RglCBWpJ+ZH8POoFBRmTR16cab40XRWS/YAZAFZDIBGcFgK33fI4QTkiASFvgjIKgVBkVmmUS/yMwlJa+pOsgSVXgTAaZTmflR9cCSsdiSc03NobKUjda5i5MAgMgbo2bDsXRkXgMXkc8aa3LZb2BqVhgvlWg1ooHeptL4VxSI7LUhqpikRhq2RBRkuRDVAOJTHA2AMgc3HwD17htRxEAkpKV9dcyhSCZ/6dWXWk58EbZnHdeT4r/aVkwekpfSI0fec9CmehimAIstooAIOfGsmbx0r6u2i36/2y3xsm5s2oeapWiNBMul/CRqkDyu7kCntakh9xrxCorDRuRRYXMmgAgdvGc8QAkLXD+QLgOQD1/8StmgDOBID3/r1CNBOnp+J+aBUHUn9bSl//am6jxo++ahd7dodWkcJOaNElAymduXblS1g2mEyl6AKUXZJmYNBHkGxsTfT85FUi8ib4AN21igdRMP0Hxa+0KkakFrAMSzRqGA5DMAARQ7XbabABSZoAzSYjQd4Nir7fgEiD0/D9d7r3MzL9U70Vnegkwp0uBs1oj3yNdJrTc5RJ9Z6krLOcGq4nB5QN26eKAwd4e9I+Eklx9qQoUalGn2TAIWjz5hkaBnt6M7x9AolnDcACSFhMA1/P/jZMMsNEdILRla6N1vUbiFFr2/yCqjyhEuZl/SqB85ulfyNb4ZQt+5S5X2ke2TPraxK1L1yIndYWn64SYSDyWpIy6hkcAAI3l8sfd5S5BZc9ZkQrM9vo3SkQs9oqLoi93n9H7+uSPatrX32oeeHh73Gz0FyctJpgqgOaqnNkB03RKgADp9/8gk6Pp6dH096OTH8KU6QuX8F+SUVYLXAwe2LrF8EwvDZ4TFwfRNTyCy91nZKeSLLqhPadlNmpiW8QVXr1sBQ68fgj2mmohNrYvYMJ1eU6C0B0aZOS8UteG1IW93H0GaGtCZakbt65ciRdeFQN9xfpV2Pvsnqk42JFXUb12VUZbKOTKBBd2aOpcbdEYV6y/fgmOv/G2EBU467mmBMBlwwFI7QJHovWMo6ZOsQd4IhLXpdyykQAZMRUJLdNau0mUXHRSnygtgE4HwcN9YdnkBw3JvoP7k+J9ZO8OqQtoBPi6B0dw4PVDOHryLAZPncGlSz2yv3/s5X04NO8gHvrql7NWblPW0Ayc6+NVX7UmF7qhwiO4iod6+zDmH0VF9ykMBZej2skURDZYTbvaOmcMvyU325NnAewR/i0dlGCvqYbLXYLz/I1yX8CE6izCT2/iI8nV5/f2WOeM4Wmids9dRGxtTFVXiIICLHE7bY5hAEYDkBl4eHv8pge+wpy/MDhb8qYpYaYVgtlOgAzFbYZAEOD7f1u1DUCQ1jdar6kV4AeQtjax6qE3LjICOgR8h8++h9OnjmHvs3sE6NXW1qG2tk4WgrW1dTjd2YnjvYNoqPBkFRSpCoFTQfC6ajdOn5p6TiiKvrZq2rjC5CZAjsOTT/xI+Zc7E7HklnmA31uSSCZcuISKa6sMV4FGwY9+vbKGZoC/2ZtC4zg6FEV7tUksXhTMi6mN0ohD5Q+EXcgCAAEA5y8MOgFUqFVnmcbuCrEDRLoBkpbYiVzfL/lZMBTFr/e/Jvo5YPw0l3KXC4fPvoefPfsrQe3R0CP/3zJvnpBRXTy/SVCHC29Zl1SAbKTRxdAki1tCg0HF97t15UocPXlWVCJSMY0AKC2IVroh0UZPkPnd83uweH4TyhqadQ3WyAX8SLaXlMMQr+jin46gvXqlajFTU2ohYoxDogW4GsApQwFY+ehOhp+1fw2AclICk42Tb1QHSNYWp8YECG1yfb8AZON92Rpo8NPf7BEUHw2+2to6LLxlHRbPb8LqZSvgtJtEscG7bwMGhv1gzayhbrickaTHqI6/JVnhxfObsJffZvLoybNwL1mJamfhT4z2x0xw2BOxYRIrrpjbjIq5zULWVy5UcelSDxbObUa/1SWoxtraOlTMbcb7N24yDIRGX0vSOCAdH1f9OvZijA8NcW6njXE7bZWGu8DSEhh+CnTWyVRoCRCricGrfVEh/geo3wBdqe938N1LQnEzifeVe0vw6MfvQHN1qaHKb0/HWeHCIBdNbW0d7t1xn5DcoEEife/KUrfs80aadDI0DUVpq1wqu3XlShx66SDG/KOw11QLbrARI6NS7Z2bjZFU79+4CZvamkQ3IxK+oGODod4+oMHFu8TzMOYfxbGX92Hw1Bnc9cADuiBotPKj4Ud7ksTz6Q/EcTFsQb1NXTtckYVFlZPF+JDQDVJquAtMlcCQK4QDkLYERk8MUM8dINMToKb4MhaJASYz5rzzukjFqUmAEHBKkx9kgGk2431S95JWfBvu2ITVy1YI8bx075eLzG+xPTHwk578MtowFyXdpzSrQJIhJZOijXKDsz13z22KiRIhJBNMH3861rl4fhMwvwmHXjoo/NxeU43TnZ3C+b7cfQbVGgGYLfhJjQ5zmULj6B0eR321TetMTy5mL4YpNF4MZG8gahMtO1UtFg01gtnIAKeDn9z/p4pZyHWAaHDtyYo6tevk+R4efhwNv2y1tZEEwV9/5Su4d8d9+MY/fgN337ZJyOYWSkG1w8zIAm+0YS48Lqem1ypraBa6JfYFTNOiNAQy8U7SESJV9NI+YXtNtXD99FtdWHjLOrjcJWiZN09V/JQGX67gJ+npTQqDaYorJvbmKTdcAVL7gAgbj2SjBrB3eDzv8Yh0C0OrQiUJDl7iC6GEi8c7yR2EAXI3ur69aRbam2blTNEZYSXdpxIA1Bh1aSz1JGAKwN59CsFQohym0EEo/Xwl3acQCC0TlR75xsawoL4Cb7099XuL5zch9NJB+HmYkNgfXWWQa6WnVlzQcUBdobILg+QLVmVTAXrpN81GgoJkVgsxAxyLxNAfiAvxPzUDLIFE54ckY+whN6lybwm+/omP5Kytjai9QoUfa2YVj2u6XmHp96zy2LHOGRPc6UKaEZh2rVVWCjHwfqsL/SPy4kCpTxiYSroZ1b2RKwv29mQy/NhrOACHd+2M8Uolq6kkWvrG7MVZywArxRbS3a0uxe3CFphupw3nrlumyp2Q6xv2B8Io95bgH7ZuuWJH1+uBs1KrndqbjdRNpF3oy91npo0bLB2NNhgMyh4vaZ8w7QaTOXuFavTePdK+4Azaa0uMBiADAKVbtjsxVZqv6ZaiZ1hqttrspAdf+kgFQWmRdk1pcUr3Qa7zg1jr0hvwvU9/FE67aQZ+GoCm9VhpiX0Vmq1zxoSSoFQtgXSf8OL5TZg93j/lXqZQvbmI9ZksprShpUQ9X3HStaaHUwAchgKw8tGdoF7YnW4MVjoQppO+Ir8+T3clOWVoNTFJGeBaNqRK1dLQ9AfCogGmM5Zdayz1CP/eFzAVtCLSq5qVpsXQbrAc/ArJiixsUiJEZ8dWceWjO82GK0Ak4lbOTF/M6NH5uTQ6A0zubimBzic/iPvrD4TRuvQGocxlxrJvJA6oRhEVmqXLBNMQpKfhKLnB+YKemkSIlw3rFj0SMVZcdP6YyzAAUkXQtQDItnOMGkWnBoTkNaQlMPkyubuOXK1fuhIYq4mB/8irIvU3+5oKPLx+2QyVMoSBFnWkNGJrOlogFFOMkZa7XKKZiEpucC5LXLR6WnKusQ6h5gRgHACpIuhqzuEEEoNQDc/QSn3+bNUAqjnoSgdeawnMb8/1iZIfD2y+FU67CTOm3bR0gRgBz0KwWGUlRhvmompyDMHeHoyHIilhL90eIJ0bnC/1pwZ+Wq81eiACgGLDAEjNASQOOqe2CFqr0SUw+TYpCKUnMl1W8vyEeWpSLx/3a2+ahXg0jhnTZnRXSKbw3BcwFVz8S8mkmWAyHFXJ6OJo2g0m4Zh8lMNoGXEvFT06PUyrPxB2GAbA2MVzwjoiAMx2hhZAwdQAEgheitvhGxoV4JyqBMZqYnD4wD4R0JcuuRm+sTFNtWwzNmVau0Boq/IUi29YmY9ez5lpKf8hxdFlDc0iNzjY25O32KfauX5Sr0tLOIxsj8n/r9nttFkNu8qoLpBZEl/bUCv0KTBSuZ2qBEY6Mqu+dR7KnOYZ9ZcBBMqc+pqbfGNjV0zYQW38kowrI+PMtPxtPs2AUhiSn7AbRg9LW7toz00ge10ghWxqB7VaTQzQ06t5y8sZUwczPXYlJULUDKyQK4vJh+uvcaqzIH4MsLJs0MmTzYNV6PuAECMQTFUDuOvkeeH3Zl9TgdaaRPRgxv1VbyTuR4YiZLoZ03RNhJDPXTU5JtrmMx0EG8tdoh3ygr09QE9vzuKABH4k4UE3GyiZVFRpGYrA5yUI4d2GXWkDD28nfpsrWy6wUrCzkOoFpS66UnCXzP0j7u8H51SjocIz4/5moHCMgBddEE3O03S0eDSu6mZAVCC9o142lW8sEhM9pPDLtlU5WdpDMwyApA2uCEApEwxk7Qv0B6YfIOSyxEeHoqKJ0S1zF860umlwVeVuFJmUwAivUWwVEgpqlVQ+jbirpBSGKOLB8UnVN5L2plkiFTgdvrdB3l+JIQCk2uDc/APg2+CMUmdE9pIhA0D+agAzPUlWEyO0vpFhB6RPs1DcXzX7/OZyL+AkBR3lRBfqaMNcxSnRWlSl9Pj7j7yKYChakCUxcp+ppPsUPxZLW3sYrZ5JV4iRbjCt+Iilc3VVrwWVtYCU60wOnNOoeYBks5Fi/pEVy/ZOcEYoPaWTQVSg1xJGb8QqtL4R97ey1C3spZEv4NEgkNv3V26rRQDCxjoVDgeuq3YnvVZWPAHJ2Kd1zhgqiq2GHod1zlgCsvtfE5WZ0LCQbkwETNW0ZTuORr8+qQXUOhWbWFNlufg7DAwAWdgfJBdurgazG70rnI1/ZN0KoQhar50fGBX2C5G6v/FoPOsQjLlcqKIAFQjF8E5fYu8IeiOdvsEhVa/3YvlUGcWNdZXCxjz0/iFGg3AwGBQGoK5zxtAyd6GwF0mmVtbQDPBdEdL6un0Bk/AzAFiXhXiZXCxTDrQCqCQKUOtWob6xMZQ5zaINlvSMxk8ZAjLYq6b3BwF07y9uNQSAVB+wi1KDWU8jFdogVLVGEiX+QBizr6nAddXurCc/iLLxjY2h++x7eJGHXai3D6c7OzHsG0IokMhYM0X2xN1M7RkcSijDMAe85esDjnXgxfJq2KteRLvXgRXrV+HWlSsNAxS5QEm8q6yh2dBZiXKxRKW4GHleUItGmFxLmso2tdGGuUBvj+xcwHTrg95fZF/AhI9D3QT0fJuWYmh+KjT5X4vRClDoAnE7bUy2wAGo32sknydDLkZ5MWxJcn+lZoQKJK9BZuOR3cEOvXQQpzs70c9ZwPmmXFobA9iddtnXCqsMf4nO+FAfgr4+vALgwMlz2PvsHmy4YxM2rl2d8XaZA8P+tMDSff74Xlmi/MoamtFaU4GWkXEMBoPTpjaQbJCkxtUn1jJ3YWIUGF1qRjmJWuOgJObnwUTW3d/e4XHMrtRcG2i4C0wCCVy2FRpps6OnxBR60bWXDeP8cDjJ/TXSCPgqS904cXEQz+8/gEMvHcSBk+eo37KoVnhhDWue/l0bQ73+UB/e8vXhjz0DOPTSQdz7uR26FVu5y4UzfcMitZVJ+5vSe2xcuxqBUEzY95jsiEfvukZUezCa+OKLQpGk5IMWJZYKrmrUJe3+St1oaVy2e3AEx3sHRTFeALD29iHsH4W1+yz2UCGGsobmxPh9HhmTMU5RHQ7FbfDEJrIa99PKFgkfhKGohgCQmgTj5RxOMMFAThRakYUVZZnzDUG5jLe0d5F2f2+uthvm/tLgO3z2Pfz9D36MYy/vQz9nmbppMBH0cxZYh/oMBV+qvycQtDHAJK8GD3zufjz0+Xtw922bNEPQNzYGjy2xH8jRk2cTCRin2dAYI3mtdDvhEZXeUGpQ9ptXbPT7xaNxBKMcVgMIxzhEIsl1iWSL0P6RVgG4S6+tFsBHewB02INeG0nWMwCcPAfgVbzLJKbLkA3UF89vQtnNa+Cwm1OCcMRUJAKh4WEdb0mmo/GMUYDUJBhyK876IASlEpN8QjBdT6LU/SW1V8EoB4eZkYWaGqMVnxh8FlTxi7efs+QMftLXIhDkfH0JEHqr8c3vPYWjJ8/i8S/drxlerJnFrStXomXuQsXRTkaC0Kjf02OVpW7V70928SPP7ek4i8vdZ2TDHjYmMbRTzkrLvbLPX7rUg0uXenDs5X1oeekgVqxfhbKb18BkMSXd6HNZ3EyExez167Ve/1ajXeCsflu19T5EieULhEoZalLGQ9zfRTe0865JaoUBJDK3ohCA5AL46W/2YO+ze/DHngFUMRDAN+zjM7ne6ryHAAgIrUN9mPRW48WXXsX9AL722U9pfi3WzF4Vm0Sp/X7ExSVKj6yFJOCpCHsIayYFEE93duJ0ZydaXjqID375IdTYJ9EbUVeG5GXDmezmpuraVll/bDYEgEwwQDRDWZIMZqzwcJMZv8d0GY+farvOMy/+WuT+Wixm/PQ3e1DW0IymynLYTIygBElcaZyPKw2+26cYIyIxviomgipGeSFrjeNlQwUKt14KggB0KcGZzpkp8O3pOIvfPb9HUP/WoT7VwFMLRCUQjj30EOZ84e+wsg6yECTT04fiNkxE4th/4FVYX9+PMX/Cfa2Y24y5d38mH4LFZAgALW3tHHbtBIAyvg2OycagAq1tcIWUGCGj/Gn39wc/+QmOvbxPiK+43OIsFlkgly4pK99+zmII+PJhNAR/Or9JV0xwBnxn8Zsnf0wludSFOYwE4aVLPbj0N/fCf8s6vP/Tnxb9bChuw+G+MC7+6YgAPel6vnSpB6HePtz81b/THgbLLAZoTBkMNQihVPozI9SfgOvQuC7w5NMdlrq/RB2WNTRj8Nk9qK2tm4LcpR7Nr0tc3XTwI7BJp/qY8mpReUw2VSD9ub75vacAYAaCKuF34uIgdv7sPwUFXcVE8n7jIzdz9+a7cfFPR1DSfUooqk9npzs7UTUwqqeUJRNjjQAgKXwGpsbhM0a7wFLT2gecbxAS9xcAFrgYLL22Gr+b24xjL+9DbW2dAELpnVHPHTqVTXqrBYVAoMTwnRz2qjqYy2sQ9SUmIZvLa4S/I88BQKg/8bm0gFJNyc2TT/xI6B6ZgaA8+Ei898knfiSo/2HfEIYL5DMee3kfwINQq81553VwlR/IZbiMNSwJUrpluwn8ZsPZUlBGuaK5BqGc+xtzubD9rr/AN/g7JA3ASzqUoK47V3k12Ko62HnYCckbZyMAiPquCQw5hxPFMmAM9ffoVo5EBfZzFnzvO9/B3//dV2dop6D6vved7/Dx3vypvmHfkGKmWK/V1tbh3HXLoHcksNbNkQQCGvUFor5eFlnuAzZyEEIu9x2Wur8tcxeCGfajvL4CG+7YlNX3DnOJx6S3Gqvnz0EVE8Gktxrs/MWwV9UJcCNwph+y0JSMOjOX18BcXoPiBTfBsWCxoCa1qj9iB06ew9//4Mc5nSwzHeD309/swY5Pf1pIdg37hnTDb9JbLXpkCsNMPgsxl7sk1+5vYv0a9kLlNU5KATK5GFU1XTLD0uzvddVuBEIxYHAEG9euxtGTZwVXOCMVTt2VyYJctLANFXOb8f6Nm3C5+wwODwVhlwDMqMES5vIaFPMudCaKcCYpMgW+gWE/7v/W43jxpVd1qz4CORLisMoLmKQQh1IyhawzI9XnivWrwGm47g3y4LiMAVj56E5m4OHtHBKDEER1gCOMVfhvNuKARkE0W+4w6VShq9XpwZNAothZyRXWY6S6f/WqlVixfhXmtS1BY5kDb7zbh++9/KckYNHwIyrQaBCGqVo0tfbYL1/EohvaUeWxX7Xw29NxFj977DG+tjOiGTqT3mrYq+pEIYtU54yYNMQR6u9RlVnW6xrX1taBW5bT2J9w+Rl55bsgiQFmC3pGj8LKppKUc39FsYsohyqPHXc98AAAZAzB1fPn4KHP34O/+fKXsHrZCpTYLHinz49nXjqQEn7pjq2eYy51jdXWGFYxEYT6e7DzZ/95VbrCxOX99he/gEuXejTDj4Q4ihfcJAKb3puZvaoO7PzFgvrr5yyKn0WPKrTdenu+DnU0YwVIjcIqhqS7hihA6b+NAON0GYVFT7BZ4GLQWO5KuL+UBUIx3NTWhHt33Icnn/iRrvepra3Dhjs2YemSm2EzMRgPRRDhK2R+ePQ4zg1OAA5nWreXdKrE7MUI102FpCdARijwF9nZE1C79QGtCOMnjyq6aFIIvvjSq9izcRM2UQMIrga7/1uPCyUlWsCiRfHpASFWb8bCajsWz2/Ck0/8CH2DQ8h05lNtbR3aV69T7akZLFaiRrbCEfc37SxAPS6xlp2fCsXOD4yKhjYunt+UaG+LJm8DGOLjgaRvs7a2TlU2mIBvXtsSVBRZReArtlvw6Euv408dZ9MqPwK/Yq8XE3XJubj3tS/EpmssaHCV4I0+P462L8TFPx1B17mLGB9Sd9c31c+BubwG4yfeTFmXSNtvnvwxNj3+D1cN/Egvtxb4TXqrUbzgJliz+Lmivl54WlrREQE+u+RmtDyxEE9+/wkhKaPXbLfeLoDNoPY2TfrNSADapQD0cJMi5ScHQjUu83TdW5js+0G7v0oDDpx2E57ff0AT/Bbesg533XEnqjzFGA9FMB6aWojFdguO9w4K8GOCARR7vWhsaxJBmbZir1ek+oh9aeNi3E4NHbi92o3bqwEs2IDn+vz41vNHEek4nPbzEsVYvOCmRNC9vydJ9Un//3RnJw6ffe+K7/std7lklV++FJ9U/UV9vRibCMFVZMfZAR9aayrw6Qf+Bnjsn3VDkFZ/RlzjOhRi5gCkRmG5KADKAi4V/PQqw0I2ujap3FuCKk+x0OMrBz+17m/LvHlYsX4VVi9bgXCME4EPACwWMwYnJvGd5/aDCQbAOZzgHE6E62YjMHsRJoJWFJ0/lvS6cvADgKUpJq7cXu3Gf7YuwmDPedVKEAA8La0Y59UgGdMlZ/2cBadPHRNNOrla3F4l9Zcr8MndwMaQmFsYriyHqdSETz/wNxh75BFRokYt/OJti/HKL54BIJ7uRCpI6DBXOkCqab2VgeOkkQqwdDovQPrgGKU46ezvB+dUw2k3JcX/nHYT3ni3D08+8SNR8oOoQLpVjri7i25oR7HdkgQ+wa0wMfjBa29hfGgIHB/3szYtwKzWRXCefx2zWpfhPSAJgkXnj2FidvKA1v+5FMZf1sq7zb8bCeC942+hSEObottpQ4xXnFhwE3DytZQXz9GTZ3H3bVeX25tO9ZlzDD8AwlraFzBhKYDYcAwlNgvueuABXPriF4TOFDU2UNeEcvoaoa4V2kMp95YoAlJv8TMl0gwFoEeqAPWYnAqUkjvbw1al76cHiNJykrKGZln3t38khJ899pjiXZK4wi3z5uG2ez+F1pqKJHdXqv4E15cfTlvs9aKChx8AAYJOxyS6zl0U9VgXnT+Gcm8JLniuFZ776QuH8FNagTomUX/9Esx553X89lwfIhcG4ddyfHnI2nrOo9jrxfj85WgauaCoIqSlQ1ci/OTCHrT6Ky33wl/ZmFb1FXu9smq+xZG4pk4HrcKx16LYTfVz4CqyY2wihGBvDyKRKBwsg9FwBK01Fbh3x31CP7cql58aZkogR0QD/TPfUGIDsehbHcLvHH/jbaMqQaaXAoz6evNy51MDzFSQ/Pwt16O1pgIj4Ths9FaGZgaP/ew/FUtfaNXXumYZnBOsIvho9bfr5HmR69s4px7SfC2BYcWtH4Hz/Os4HbTC1nNeWHSRC4cTMcM59aK77sU/HcHF4504/sbbSedDblHSNwKlGGOx14uKajuqFOKeV6ICpGN+6WK+BH50Akt6gyXHln62bfFi3HMtgwZXiTA/8oeXwvjpC4cQrpuNYkAVBIXz1nMeriI7+gNxBEJheFxOBMOJm3HL3IW4sa4yrSvcz1nwgfUrsf3O29E1PILfPb8H+595SviO3oZGnKZg5x7ognTDAz+AIZ/4ufrWeXkHICklZzKlM4kPFko8MNNi6Za5C+EwMwjzm8qEYxzKnGY8v/+AYgfIpUs9aJk3D3/78ENgzSy6LgcRYVMHeOXUn6WtHYHZiwAAgdnLBPBJQTirdRGcjklBIWxsX4hN1iCqPMXCvhgAgAUbAGzA4bPv4YdHj+NPHWfhYaOyFyUZ/EpKasIyMUdbz3mMTYQw2jYXC28B3/EwdQFVMREsnn9llcGQOr908CNQ8MvcYOh/+wNhWcX3r23Jsdu/rLXh2OLF6Dh6NC0E3U4bJmYvTDpvYxMhDAaDwl4swTgHS5UDFXObE6P0U8Cviolg+11/gSqPHQvqm3C5uwl7BnsRGOyFqbsHq1uvBVqvpf7qWmE/ajIezk/tCuAe6IK/slH1sZe4zZmXwZjLa4jLe1YcLyjGjE0tVJL8CMc42EwM+kdCOPTSQVnwAYkM79c++ymhCd7Bpi+4klN/LY5JkfqTgyAB4emgFS2OSXx8wyq835N6o6H2pllob5qF59Yux7eeT9T2SdMYaneDcBXZ0XXuIh68PdEXTRb8ivWrsj72Ph/WPTiCvc/uEYU66HMPAIH5y1Hs9cI0ERKOEfhQBanVFK0xSfw2VSvqxkqgI82anZi9MOX5u9x9BpBspn7XHXdi8NQZQQWSxBb97y/807exoL4C3YMjKHdB2JCJgfKuhPaaatF/ydaTB46/K6hGna23WakDhD8QBhMcBxxlV8yiVTNFpqa0OKmdrNxbkrRrmdNuwoHXDwklL3Iu78a1q0XKTm4zHKn66x8ZV1R/UAHBFsckvvmxDaJx++ns9mo3HH+2FI/8zxsZHd8x/kJ/4N5Pwmk3CUrpSi19cblLAH6PDWnc96znGiGW5yqyC2EIos6Le84LMBQp747Dgrt68U9H8Jx3OaqdiRtnX4CDw25GORvCr/cfAWAV4oBEpRNVrubGRRIhAOBgGQSHY6jyFCepQAI/e1Ud/u6LO7D02moMDPuFyefkZsfxine0YS5Kuk+pOobtXgfeYjwo95agprRYT52goWUwpbgKTOtBrpocg8005f4Cif5feitCGn53PfAAll5bjcuBKMqc6k+PzcTg9KljKdWfFIK0C3w6aMVjd96kCX7E3u9xovhDN+IL//tH9WEBPijfJVUVNRXC/w8M+zPeH7kQzWk34d7P7cDpU1NZeLKN5TMvHUAxNfk84dpOio4Z5tQLMCTKm8RvTaFxFJ0/hi57Mb7F/04LFdogv2fjX9uiEnh0yEJRFdpieP/GTcJYfgI/zteHBz5/Dza1NQnnlCQEiVur1UYb5qJ+893YmNmpyEoShMNVZkqqMOrrxeJbkpu8g1EOi+c3CaUPcvDTauEYh6eOXUq4E3zmN9q8HEizmXVg9jK8d/wtfGnjYrS79I8jWl5WirtvXYGfvnBo6kJVeVGRtrp9AROWxjjYXS6YxsauSPgRu67ajfYm8Si0w2ffE237EK6brXgsk56nVCLJ0m+oYXFdWalwU+sH8OZQOw73hfH7w8eS4Ch9ffJaxOjfozPBxGLDMdQ2lmHhLevw4kuvop+zYPX8OVix/h6sXrYiaUN7qbpX2wM/2jBXVftcCmN45Rw2MgZ4HR1DMCIGeKUURtMJEAKrpUtuxtFbpsZg0fAjijGmchCAxWLG2QFfwo3k3d/GOfVQg1Hn+dfxvvYlok4PvfaXtTbsa12E08ff0gRB+qICEjve+a6CG+fAsF/Y9tI3NobBYFDotiAQUgpXSI3A6e5bVyjWbFYB2OQtxiZvMT674Bb84MQQfn/4mHrIUkYywU578ntt/dhdQunSrStXgit1g6HgR9RfIBTTPPzXAPiJHDojFaDgu8TsxShyGNOZOB0hSMpDzOU1KGtolu3+AIDtd/0FujZuQoXDgSpPsS7lR9xfafIjMHuZqum0gdnL8NkFHsO++7o6B356XN3vBmYvA46/lXAbHE70B+JpY51XqgVCMWHXPxqCWkIKf7npZrS71FVgVAF4dIEXwMKUEJQ7V/Rns1jMGA1HRCrQwTJoXbMMtSVeYNgvgh8x1sxifDwkqnV0uUswmWX4STZWG8/Yx7C0tSftB5LtTdELMS5ISmXook6304bGUo9I/UmVW2tNBao8xYq/o9b9JeqJCQbgKrKjjB/TQdcdytncopiuuJ+SLXLpnyc4NhFCMM6JVMLVZNK4MInTkv+mUn/bP7BUVwjj0QVetC1eLOsGKynCsYmQUAojq+TjHKz+OExpEliBUBihQChnyq93eFxU9O922vyZkooZeHh7vPLRnSxRgFFfr7Al5kRwElerRX29WOBiUGy3pFQ14RiXBD8tMLRYzBgZC+Dc4ITQqiStCUsFwfZqY2crNrhKdLm/gns0efWsGTrGOR6KoN/qAhMMgAkGks5hYPYy4UE/dzpoxfvaF2J5mf4c5D3XMrKKTw68JFufbhSaJcWGk7RHxISmtnMiZS5ZdnuBqWlVfkNc4ODL/1tkLq/J2UB/Pdtj5soS8O8w5nuOjQFp4oA2E4PBYFDk/s5qXST7e3JwrbAWltKiVYWcCrwSEyP9vGrqD8TB8THctO4opco2XWPJ6P3bXSVoW7wY4ZOvJUEvnfpMWv8sg2CcS+t5AMDpU8dATjE5rdISmCzAT/TyhgDQXF5jJS6wubyGsc1fDgCGxgFnTNl2nZwqTaDdX6cZkIYVpSBscGXnvpXuwiGB/RbHJP6kRSFSUCQwJM9NVzhKXUWi5KXlU7KeRvPyjLL3xCpNUVzU+DdyxdAkhOG0m1KGMaQJPs5emgvlJ1KA/kA4mNGKWbX7bUG9YmoeICpNuQ1kjzDWgoRkv9Ul9O7qCe7TC4gsLDkXmlw0riJ7kuvkNCceSoqwe2zU0O+s9vVoQGoN+NPHhz5G5P/VPArN4pOTgntJbgxq7FqbMddaTWlx2psW+Xk6hWoqNWl+f2kXSBbhx/FdNDG30xbJCICnjx4hOrccMnsCZzMGWKjQo1QxfEOjCITCQjwkEokKD1WhBT5WksqdiESiCPb2CJM6lC4cJRD6YyZDv/dbYzbNbhOBoKvIjgqHIzfA0QDLQk7I5GprCDUurbDWJti0axpITvrkwu2lurQmAYQyAiC1H0gFABNUjMM30gqxPEZtT6IaGBJ1R1rDUhmtHlIuTrMYhucNrITqB7CvJ5jRa7DWwrmpsWZWeGTTyl0u2Yyq05wAj9IjF6DT815lTrPsTUNaDkba4HIFPwkIwxm7wJSVSuRl1m06ZJj9gbBiqYAUhqmeVyqIVnKLtSz2Y76QYd/3ByeGMrrYgEQQPd/9v9mAXjo1WeXWV4jeO2xMQpB+nUwgayo1Je3kF4xySfAzjY0ltcGNNsyFkfuJ09vyyl0+AAIZnWWqD5jocC4RjyrOOliY4LjgBnu4yYJQg6RPmOyhQG82rdd8Y2OydXrBOIeKIisW1FckjQM3m9WpOqcZuBzm8FyfP+PP+VyfH6cmTBkpkyoni2K7JW/nL5vgkz6X5Dk0VKpS7Hrd0nQ2EDOnfL10bemkJa6ehw0BnlITACCeflNa7kX99UsMc+nl4MdvrEY+UADAmFFnW9gPhEyVIArNKKVGMstKX1bukS+jVTCp7tfjElssZqE7pMRmEcBXbLfgpoZKNFR45F0QTr2qK7MxeH4g4b5mAr//vDhV+pDKbZOqC1KAOzYRgqOmLm32cDqAT0/s0KRC9dIwJI9TEyb8biSQ0ed9rs+Py2FOgJzc+yhZoCgu8kZo9ZcKftJj0zJvHmZXlhgKvzTPBSxt7RMZnXWqD1h0+5KWv0wEJ1M+1FilKVqQ06ClpnQH0+uuEiC6q0sRjHOolwHfOmdinxFXkV1VRb+cPdLh1wzBfgAPnxgSwU+LhWOcaLrIOmcM5S5XygsnG5aPZIf0/WI6N4AvszF49kJU9w2sH8DzAxCVTqkxzuFEy9yFooRHRZFV8FrSQiosPtZKRdBqYKdT+AQHHt4eN+q2R7y0gmqDy5cKpNvh9EKPVoLdgyOoAnBTQ6WsO0xGKQGJcUcDMbOuUqRHOvw4rKKMpR+J0epffCvh9pbp2B3baYaoyd9VZBd9j3yZ1uxwIWSMA9FE/FXPDeyRDu3hD1Kn2N40C83VpTCVmhCfnBRuzNKNv5LcZTODkbGAqA+43+rSBTwdRu6uEwCQEa2oPuAyPiaoL3aWw4RGrl1kkupXM9FZDoQWizntPiCtNRWiWrpABqVhT5zl8PCJIRweGxVdUP0ADo+NCuDb1xOE0yxWDloeUve3cU49NrWJR9/LBc+vZJPWQ6q9iTnNiRjeIx1+1e7wnqFxTfAzm82iG9acCmH+MW4s8cJSpb58iTWzGAwGVfcB09etgTYKAEbVQAiSR83+nKncZTWmBbS5VoFFFlbUDqf2zpbOBfaNjSVl14g1VHhQ5WRxbjAx2tJ85jXg+iWiC2ggZtZ0MT1xloPT7E9SGkCIh1hmAfhAFCL3d8v82SL1cDWBj3ahCASjzcsBfqBZpSmq+vz99J0oXrUNYWWdHW0ep8hj6AfwRp8fR4eieDdshoZ5uyjjQqLhutLr/MYSr/Aeao0pssMcSnSBNH/gw0nDho2eBCXZD+SyEQAkq9Sp9wVo9acGhkZkVrN1gOXMNzRqyIiny4EoylOw9INzqvHdwXeEOGC95OcEhlpAqOY5vWY+85pI+WxqaxK5SDQAg1FOGKFOnneYGVxpVuVkhXFNpAaUnDe1N7NrbQlYPnshimcv+BX+ziz8XiqTKtCucxeFgntyw0qC2nBqVRmOcQIsmPJqoLxatnA4TQmLEczqzxSAzMDD2znXms1mAKSIKWerciBmRoPBccJswZAMjgzGOV2uMFGC/ZRSkNrSJTcDr70jxAFPTSzC3KJYykWtFobZiFm9d+6i4P7+1fLr0qoHGohXIvySbjbnXwcUauLSucb0zY4+x9K/0xInfjdsFs0pbJL0AMudp5Q3dKo6wl5Vl49DPARkGAMEAHN5jSsXAOQcxaLykvDJ15IUpBEwzDTWMBGJi4o5h7q7VBVDqzF/37Diz5qrS3F9W5PQEfIeP7wy3YWS675tADh/7KhI/X3gtk0i9XA1uL9yZTeOmjpRR0+m9bTk/Bpxnsk5G5sI4fq2JjRXJw8v0JqE4XxTnSB09UQ2wlYTwUmy2TphVCAjALrWbKaLoIt5GKas17uaTFqyk2o+mhYVmKrE4C8Xtwr/njx7Ahf/dETVRWTkhZLufS6Hp0pfxiZCuGdhraBq1YLvaosP5tM4R3GiSJrfFB2AovsbGhxR/bpKfcDZitkzwaSOGX9GAHTc8iFBwYLaEjNTSmupDcymGVlUTcv9YJwTPbRa/4hy5qy9aZagAsleu6eHgpqVhBSIel0n+vdIIH/whf8WnptTUYS7efWntf2NZIinKwxle2X5oRaFZExwHB1HjwpToOdUFInitbSlG92l9HNvQ2NW4ScV3/xAhEFDXGAkdtgjn5wxSkFIi6WLHFZh71K53801HFMZ2R+Y2L6A8jADPSA8k8IV/ubHNoguosEX/huD4yFD3SklSMpBk/43uZCI+ntg863C66erHVMLw0weubZglEsCPzk+p4NWOdWSc/V38U9HMHn2hLCmtq5fLfu7A8P+lMXwcvBjyqtz+n38gTAZ1sIB6MsIgNQkGKENLttfgC6ylqS0c6oI5RSiVCnSxdBqN3pWa6PhiKJiqgLwj3d/SBRLOv3cLw2BYCZGX0gkjtTeNEu4eArBjAKj2r91mBkR+D84ZwoIpKA9F+eMcxSLHuS5wfGQKPN7fVuTovqTdnakgl8gFJvaEN3Xl3HjgA4Lg68DNEIBeqUAzIcLW0iuMyCukzoxxol2zkqlBNW4xw6WSekK39RQiUc+tqEgIEhUBH0hzakowpMf26Dq4sm3pco405BTA710cN24drVIvZ9+7pdgguOazhkNsVSQkwJP+rtMcBynn/ulsIZcRXb846YVsu/ZLRP7I3vdyCm/cIzTvSF6JjdgmsEAQkYBsIwct1yNwpqWMR8dm/2kgmAwzqV0hTe1NRUEBN87vA9dVMmLq8iOxx/4lGrXqVBVobROMdXfpzOigMtdLtyzsFZ0zg7+z7PCOVPzSKXqtNjvDx8TztfYRAgP3r5WthDfNzaW6OmmzmG6WGAkEkVndGrqj9bmCa3CiGY7zyg/Ms0CU6OwSqR3j6zdjakDJdnfs+BMqRRGKwgJBKUwdLBMSleYQPCvll+XBMGukZDuC0OtAhmImfH7w8fwp46zIvg99X8+IqplLGT1ZzRE1UDy7ts2icqZyDl76ZVDGBwPgQmOo8hhNWy/HdrIa753eF9SuELJ9b0ciGqCX56NfDjf8K6dAQCMEZWwxTwQuZi3NWffxBQal3V5ScKE/LdQ7HL3GTTe0A49g4ukECTF1A6WQdfloGKLHLmgyhrO4pGf7xXcq/d++0uY59TDNn85KoqnIJhJ0J24TYPjIXQcPQpbz3nYANj4i8hVZMcv//pjos/araFs4kq37sERYZjAkx/bgJ86Y/jua+8I58zWcx5v8lBqnFOPaPNyXGuLgnMUC+tcbwiI/H3w8mW8dPgYJs+eFcGPDlfQRjwQrdALhMII9fP7WPOJkFxkgKO+XsDZCAA+ACjdsp3VDUBT/RxBjBTaYsp3LHCEscJRViYMRs22nbg4iAX1FSmVIAARBP/UcRaucxfRUTcbLY5J1F+/RLciZILjeO/wPpwOWgXwESMxv8cf+BTKFVwnqQt1tdrAsB+VpW7RjeuZlw4IPd70uUPHWbzHb4LV4piEbf5yVJrEQFR7rQQvXxbitJOU2yuN1aaL+6kxso1rrhkgSZoKH143AGMXzwk3EOndJBcAIlOh85nZTGdupw1DvsS/j548i0U3tAtusFF7X5B9WM/0DctW59MQrHK78X9/+r+iliZbz3n8aSKR7SMXE5Boxpf2/pLuG6l1nbsoek06cP5Xy68Tav2krhOtHuRUxNUGxWCUE0FwE+967uk4i10nzwvHmYYhOX+ucxdxGpA9h9LStIGYWTiX0vgsgR8APHjHbSmVn1aLRKKwmSwpw0XZED7keWp+6UDGAKReTIgBFtIsQDVKMNsucrm3BEPd8j+TxgIzASKJB6aD4E0NlXj5a9vx09/swW/P9SUpC1vPeXQRgHWclS3KlW6+RH6HvnCub2vClvmzcVNbk2zvcqoL6GpXgsEoJ3KHaRD6xsbwxrt9STAUHT8eiACEc3g6xTmkzzF9/h5csTjJq+hH6nZMLeGgXBvfBicIWN4l1h8DtLS1c9i1EwDImcr6yrXNXw7seX5aLGQPNykai3VijEMgFDbmIpFJiBAIHj77Hn727K8weOoMNtyxSVZ93X3bJtwNCL97Ymwc/kBYGHQpvTCkF4jcReMqsuP6tiZ8ee3SlBBOpx5m3OHkmKBwQ3W5sKnNJYQ03uweQGfHEewLmBSBmM7I38ypKMIH51RjXtsS3MTvTzIw7McLr74KAFi9bIWhCQ7O15fzQmgADN8F0puxAhx4eHuSAsylkdhaJi631lFcWuOAtJFMcJXbLZsJzsQtJkAssVnwRscRHHt5HwDgySd+hEMvHcTnH3xQNkbY3jQL7V+6H+BhePrUMaFHs9/KijLtVU4WVc4iOGrqRC4vUXtKWUI65tc/ElLVE610oV1tYOweHIHTblJMct3UUImbGhI3s34A3Wffw2AwiF0nzwtxL7lqiTkVRUJFxZb5s9FUWS66aQ0M+/GNHz2FYy/vw7BvCGEOOPrnd+KBez+pG4JKI+HsVXUZhbHUeHnBy5chEWmjGQOQMkE2ZLOeB5CPZTQU8AKuv34J3s5AsRJQqgVjJBJFy9yFqK2tw6VLPaitrcPpzk7s+PSnsfCWdbjrjjuF7gtZGDbNwt23qbswBycmUa8wol/u98dDkYwHQtAX39UCw8uBKAKhEcUNsIQbFIAq/txKb0b9Mr8rZycuDmLnz/5TAF9puRel5V4M+4aweH6T7u8ghR+5yXK+PkDDKCxpZYcW4cO3wbFIlML4SBhP74ok/XTAVBIkqytyIjgJBhBlVsMnXwPW3GrY62cjJkh/3nSlMHqKpaVK0Gm34a4HHsBvnvwxTnd2AgBqa+tw7OV9OPbyPrTMm4cV61dh0Q3tKTPHqayhwqPqxuMbG8PlQFQY7W+kXS2uMvmOZ/qGUeY0pyx5SgXHVOfo+f0HcOilgzjd2ZkEvtJyL9Z+9E4sXXKzZvWndhBwqutOCjk93p5k7uUYgEskjJfRqly1+23m+FPft2PGZM1RVibKBO8LmLAoAyVILJUiDMY5NJZ68PkHH8Rbbx/G3mf3iPZfPd3ZidOdnXgSP0JtbR1c7hLYa6qFO3xZQzMqHA5UeYqFNjCSlVS94Ib9GBxPfGaLxWw4/K5Gt9lmYnA5EEU86td8PqTAe+PdPlzuPiOCHpDYmxeACHx33XEnqjzFquCnZ/I5GRuXibpLuzZOvoaor5czl9cwvPs7QsJ4Ga3M4099n8XUJJisW7ZLXuQOeqaqkM4El3SfQnD5oow/Z7p4IYkJLl1yM1rmLsTpU8eExU7bpUs9wKUeoLNTiBvKWW1tHf76K19Be9Ms9COxh208Ghd1MIRjXNKexrmA3tUUF7SZGIyE4xjpG4bNxIjig7SSo29oxN0M9fZhzD+KS5d6RLux0WqPgI+ES66rdiMQihkSvqCNDEIAxHto56h5YXT2NRXhNw2KAVoB5LQBmFZU00IFSjLBmbq5ms50OAKn3YalS27Gohva8dbbh3H05FkMnjojUoXp7NKlHpw+dQwelxOj4Ujasf4Wi1mAYbZBWOCtV1lzicMxDuFAFP0jgyi2W3Dg9UP4ziPfTMDs4KvYL/O3ROGR/9Jqb9mqlUJopMpjRyAUE5JW6c6hFuWX7nxlsYaYvHHfm499I0rCeJmuTjulAK/IW7HSCdHTbkcywRWOzJtnaJCmU4NBfhLN0iU3Y+mSmzEajqDf78fl7jMihQAgaUoHDUqbiVG1p4kRm0DNuMbqQAiY4TAzKGtoFsXtaMBJYUf+vaCtDffuuA8tcxeiylMsHC+14NN7ruk1lotRWHwXCFkI7wGJNrjhXTv17YrjWrOZGXtlN4dEBtieI4IDgGgoaq5nAsp9TyUIkuflMsGs1WqoElRbQkNGcjlYBo2lHjRVJoBIL2ZSq0hA/bNnf5XSPc7kAsmFm3w1AHYkHEdrTQW+8E/fxu+e35PkZtprEvV2i+c3oayhGZe7z+A7j3wTQKK+D4Cw97TRik9pDeZRwPiAqWEuulag45YPYeyV3Yj6eovM5TXClZfYyzS7VuVkhUa+Qp4IQ0NRmgmualti+PtpqSMUhitIFqODZeC0JyIaTrsNxXaLoBaOnjwrgqURluuYoVpXTC28Ur1Grl3zcIxDa00Fln42MWqMHrTqtIsnkr/jcKC03ItLl3pwvHcQrTUVKY+/EYqe7IgYn5zUFH4xwiSbIQ2KxEgmL2wur7EDEJr7nObcQSVXilOvm0wGtJJMMG0lNktBQpueOhOMJ4ZZLp7fJHKpsmXTwW2eDmq0fySEy4GoaCBp/0hIeFwOROG021BbW4dh35DQliY9/pFIVHhk07JdO0wmHFGblHXz/8/pBiAZhx/19doIAKW7oOXigJlC4wWz+KR7mNAmjXO4q0vR0DQLVZ5isFarYYMRjHCrM9m72AgI5uKiMwKChQpJOSVH3FqSnCq2W+BylyAUCMkqRCOPv56Nv4w2vv2NsO49IxWglQchhys0CWI0tI+ePCs0lNsrPKhvqER9QyUammahoWkWPC6nIUDMBIZyizbU25czMBVKbJBWUdLHtF6PZkaICx49eVbkLht1jokXQaYVEcvFKCza+CJowqc4EoXQiVkGyLAMJurrtfLKLycAlCqr6TASS2oHjr+LwYe+KipALmtoRpXbjcYyB9zVpZCWuYYGR4Q6u2A8dSkN/TMjx27lU8HMmMGhDqp+k06WZAo/uRundIgvkIgp23Ikl/giaOKhjgEYAoDgy/+LjAEo/XuzeWbxypk0E0wKkEm9Fomx1dbWoWJus1DESsoT7BUe2FNAkV5sUjjqhWB8chKgYpVj/tGcuMfZaJubsWS4LZ7fhL38eTVK0UrVXonNgjKnGTGXC1VI9CR3DY/k7DtTOQMi0HzgkyB8FUvGALRRb5ATo0diRX29GIiZUVHgi49zFIsywQtvWSeq1Ker9E90dAhFrKXl3iQoljU0o7HUg/L6Ctgx1edJGt79fcMYGQuISm30QjASiaKsoVkMRbstr3HCGStARUlBz8EysFjMcPPTZegp4C/+Zg+efOJHCHMQFKBt/vJcftTLw7t2hmhmZQRAc3lNkdrfHQ5FUWq/+u7spB5Q2sGy6IZ2BOMc5rUtQXxyUoiN0MXJpGPj0qUeoRavtjYRT5S60ASKZOGNjAUUXWM1MJxurvOMaTe7045Ll3owGo6gxGbR7ALT7q3FYhapPVA35jc7zuJ3z+/B3qeeEd6XmHTCk9HXnqQIeggAXGs2s2Ov7I5nDMCor9cpl/0dDkVzBsFAFAWvAAFxTzAZjkqgV+FwCN0hVW1LMI+vEyRgJKUKpI0NSAw1oHt4yWAD0s6UabE1UXu02z4YDAp1gjMqcPq6v+EYl6zsNZRmkXNfUWSFnR/TJZ04c+LiIN56+7Bo4EJNQx1qa+twoqMjX4fiAi/chIWri0bUlpjCbJ5c7glMu5PmM68B7esKfhHSPcH+QFjotJBmxfr9fgGK5L+kcJpWizQUQ719CSBe6sGYfxRHT57F1o/dZahrk88LljYj44O56lcuFPBJjcSeB4NBeFxOTa9tsZhFMwrJQFYyVJfuN6+trRMGLJw+dQxvHevIWRKEb5bgaABS/Mo4BlikVv1Jf65XCcolWnK1EVMmJo1dKplcn7BUyaWC4qGXDiLU24d+vz/l9Gm1rm6FwyEMWCULP5jjdqZsQMtmYoQNekgySe1r2kwMxkMRFNsteS+J0Zu5JeuM7hXWevz6kYjr0cCjR2uR2ZMtcxeKAMtNhABn9qfoMcFxUitMgHc5iSdGAzBTS+cml9rN024izERwMinWcbn7DCrmLszMRaWsyu1GxdyFOPTSQYz5RzW33GmNERaiutECsOO9g/jd83uweH4TWuYuRGO5CyPhuCIISQHxeCiCH/zkP4U9V4xuDywkaKbyAMIxDo9963EhrgcANQ11WNDWhoq5zXj/xk2ocrtRYrNgNBzByFhACJ/kygZiZlIETQB4ifcgOaMAKGSBY/ZilNrNaRWgGqWYDoLSgQiFrv4AcSY41N+DfQET5lmtQDCY5AbrmRZDJ1IyAanSc3IXj1yNVyFd2FKQEbiNhyL42WOP4URHB47xmXYCMwI5+m8J/PpHxvEv3/gGTnR0oLTci73P7klSN9NB/QEQYBQKhBLhlMpy2cJlJRsNR4T489oN70tSeqRmlVQk5DPUYC6vIaPwuwDRhm7IdB/LrG2KPhyKCo9U0CzkgQhSN53ESe1VdSjpPqUImkEZKGpxa7LVbE7ijrmcaZgpINS011261IPvPPJN/PM/fAvHexPz9WwmRvi7imIrjvcO4l++8Q1cutQjjJ1yuUtyCj+130etkYoCtapPdOGzDGpr6xCbGMaK9auwetkKsFaroPbI69DeRK5bHANRoUsNUV9vkLjApAjaCADmRNNKQUjvP1xI/cDprNxbglB/Ak4nxoyPHZHFpjeuk/IcpHjNQuj31AIRi8WMux54AMtWrZwKrZR7cbqzE9/+4hfw2JP/geO9g7BYzCi2W/DCq6/i21/8gnBjGfYNYdmqlfj8gw9m5cKWgq5Q+qOl6trlTvS4Hz15FuEYl3YTL7l1MhDLnio0n3lNtIQBjANTRdBGuMB5GWtCZ1Snk9E9wfRwVCW1p2d4Kt3jOS8LY7dSQVDqChdqqUwkEkVTZTke+uqXcbx3UHCHSVZ0/y9/JWwgBUC0lcCwbwhrP3onPvuJT4iAqsc1LwSoMSH9G52Ttab5PYvsCAVConrAbEafkIgB9lra2keI62uUAjTLqbJcmj8QVh13zKdNBCdhm78cdmobQOJSTgdTMxKLNMCTR6ErwfFQBK01FfjK3z6KtR+9UwAc+a6nOzvx+sFXk+D3wL2fFAFMSbEpKbdCUnRRHREkaQiE7ieW+13p79MlMOGTr2Xvpiwugu4beHg7V7plu4l6Tp8CpLIoxAXO220+6utFNBoFYC74bhM6E0xc4XRGq0MjRunrMeL60cWzmSjDQjKS8Hjg3k/i+MZN+N3ze4R9cWnwlZZ78eAjD2H1shXC9OTpZNIbkhHnZPH8JuxBop94NBxJcn3zHSuW5Ad8KRWcTrMV4smWU4SFAEaSCR4/8abYTVWZ8DBqPxEtJnXP9Sg7aa9oIarBSARoqixH672fRD9fsEtaEkmpTJWneFrCL1vHDABMRaW4dKlH6DfXA71sVXHw+QGy+N41DIAkswIgL3sC00XFgLgdLpdteHqs2OsFSdv0W12aF4yakhky6LJQlUihKkICQo/LidXLVgj7ZQCJurcZ+InPI+0RDAaDqCqg+lGKAwwNQLoLBNAZAySNxMhiGYwWdSfJ9mj621xakcOKxjn1iTtHVR3OXxjMeEAk+ftcD5rMdOBqIccKSXyQfhRaFjYT99fI82532jVXHdA3aKOnwZBrPBqNSoughwBxEbReANIEFRRgtmf7J0EvRyP4s2mpWuIKxS53n8GwbygxlkuiNqdLPeDVrNKU4Cf3fLrzOZ3ON1UDyEZ9vTEAvcDUJOiMFCAAuNZsNiNPSZBMBq/mUwVKM8Gh/p5ES1yGcb1sqT85V1Vu4Kr0MWP5V3tqVZ9ZJQFSnVehmyRPrq4Kr9AP4CIADDy83RgAAjBhalP0nMKF9AMLJ13j/sD5hKC0J3hfwFQQbqkaU9sjrPVzTKfymUJVefSx03IMOXtp2htauvNpd9pVVwiQxBKQKK3KdB4giesrgJDjPcURc3mNbMdEJgBkkadCaEDcD5xpO5xc2122jGSCSRlMSfcpQ18/VU2WXjWhJ6liVIxwxrSrdLXnh26ZzFeMM9P9fJSuWYko6hvetTNsNABNACz5imNJ2+G0wiuX0JNasXeqqPjEGJfzBIYWI3ds0vaUa0U6A8H0N4pCMTXnmwz0BQB/ZWO2BQtRRu8CSCqCNtIFznldA5104bM9hsYU6ANsNChJJhhItMRl0/INVyNig1cTBFN9VyNDBUbUdxLvQE2XEJAY9ktUJxMaRsuiNhQ5rLLXVqbXm8QrHACSS2AyAiA/YsZUKAsn0Q1ivBkJPulrkWSIkQHkMf8oAAibKBllevs+jYLh1eQSS0Fn5Henj/2wb0hT/E5qatftYDAI1mrF5e4z6O3uAVNkB2cvhaOmTrYIWio85ERJuutsfGgIABjeQ73IMyvpIOpOp0Z9vQUDwFy54ZkWU5O/TWSCE4XcJBaYaihCPi3U25dRw7xs3CWDglm9ILia9y+Ru+EQeKlVb0aGU7iJxCAEuRpAIwQHJYbIST+ruBYzWcf5AqDcQQpEc/femZ4kUsZD4EdnxgrZjIJIPkpmcq0glVRcukdOb258ciuTMqzYxHDa16hwONDv9wsDVAHAunozKortIlFhBPzIa/GiiPCtPxsAtNAADMxellvV1yy+e5jPvJbTVrd0g1rTqUhvQ2PKmIwRcR0jQDXmHwVnLzXcpZbC8EpzWfOpONOVsJDPRit7PeeA3LjlBqsqub9kBFbr0hsU4ZWp8RNmyN1kHHwXiLQIWhcAXWs2kzNrzacL7CyAoS9yiRK18Ypy71RW9Q99oaxdCEaC0SiFQrvArNWa1T1IHCwjeuRKGedKzWVSiB6NJ+Cl9fhL15PLXQLWak16ngzv6Pf78eQTPxJUZ01DHZxtq7JdgUFOwAD4vUCkRdC6AOi45UOgAJg3DJnN5oJvh0sl7ekstpExTCPH4Q8Gg1kZr08mh+Ri86VcuZn5Unx6j2MmYRctLjNrteJ3z+8Rqb9r7/mMSO1luSTNN/bK7pAEioa4wDYUUBZYazdIvhSinAtPWuKMMqMn7WZjcm8+W+cyAaH0b/NZtG3EMdRT3ymsW77oXq5CYDAYRJXbjc6OI9j71DOwOxNToIuWrMCs9nVZU3/DoSi6zl2kYdfDe66yrMsEgPZ8A5Buh+sPxKfFZGjahaenQ+8LmDhMFW4WnJU1NGcNVvmKAWoFlxz4pqulgpdaIyVXqeD3nUe+Kbi+TJEdN2zamPXvJpkDeCYV6zQDMNJxmKEUIDFB/2erHk/O6Ha46bQ50nAoiopiu8iFL+k+xVS53aycTDfKndX1WakR8YWuZoxwk9O5uflwdfX056oFOQBEXBZdn4kYnSCTwo/s/cGEhnHD3fdkVf0Rk4zBShlfykQBWmm/2mbK/cKocrJCKYmR3SA5VrAcABw4/u5JAG9UOBwZH0i53l2tpQ4kc5cPKxQY5qNUJVfTdWj1ZhnTPuiVxIdNRaUiIMrBLzzUi1lbd6DpQ1uzDr9oNEpi6uQ6UiyCzhSAeRuEQFSmdAZhLtWnEVbfmth1zF5Vh1B/j+eL921/bjAY3FPldutOC9MlCUYkGfIxXZoE9tkCmjB8JRlpSTOz2juG5MpayhqahXP1zM9/hq9/8eEk+C2/97M5CVFR9cDEmzoLyJfAGAVAXbfEaDSa9NBjJI4W9fXmrBjaYGN4FVs77Bv6+oMf/XjTvz/2z6cAjFc4HJqObYXDAZe7BExoOCnLRzZb1+MKyw1DzSb8rlbLteKVjsLSYkdPnkVsYhgL2toE1fftL34Be77/PSFpFgqEcMNff8VQ+KWqFSy1m8kcQLoGcBgABh7ebrgLLChALeUomcAuifY5Lr422kgrEOfrA+fr4wDE7U578/69v1/41Xvuwc+e/VVUj/tKtjpUuqC0QJBU+ucKTHKu35U6ZDUfg2TJeaT7gLW+d3xyEoOnzoABUDG3WVB9vd09cFbUCOrv5kf+3lC3dyAQwXuH96nhh7AVJoDLqYSa5jo+aqKCJZ2LKryJygnO0Wg0o2nP4dj0ycoNhxLf1V5Vh6CvD0x5NYOhPiYUCHF2p50JBULFe596hjv28j5u4S3rmPdv3JS2X5i1WoWsnhFzATMZhWW0IlK6SLMNZvK+cu+jB1p6d04z0i53nxEKktW6vcSI2jv62mEUVdRg/y9/JQqThId6UdPSivpvPo1ZHrth8POHojj73YcBAC29PSi/9WOyvyfZC/i9sVd2T/BCL260AjTTZE3VmZGt2Jw08eI8/3pW389oK7VPFXNzvj6UlntR01DHkAVld9qZ3u4eZu9Tz+Cr99yDJ7//hJCY0OOSVjgcwmO6W65ihNL3IfCiIUbHLKWPfLu5qdzX2to6VLndqv+uyu0WdXWEOQhqj1+vuOGvv4LWx36GRgPhB4hH3J+/MCh7jQ+HotIxWH0AULplO5MOYpkAULW6M0oFkp/T0FW70XihWbHXizFyl6tsRMuiNpiHRhE9sh+93T3CwgoFQti/9/d4/eCrWNDWhg13bEJZQ7MAs8FgMOXFpQd6RtSK5Tpelm0okteXg+J0MXJeK+Y2C2tHbn2Q5yscDrBWKzo7juDJJ34k6uoIAUKBc+sDfyuAL181uZIawHMSr9VQAGa1CFoNMEk7HGklOx20YtE0A2DjnHqhUCkB8bZEn/CG2wUQ0tsOhgIhvLXvBRx97TBqGuqw8JZ1wsbd2e6pDRSgCiR1edLyFCPq9aQbuiuVwJDjPh1ASAZcAPIZYOLuVjgcqHK7EZ+cxOlTx3DopYPYv/f3ohsyExpGTUsrrr3nM5jVvk5QYfkyma0w0/b7GQFAYVUEonEALGwZNjRocWHdTht6TiSUkq3nPICl004FMuXVJBEC39CoMCiBBuFQdxfiJ48iFAiBs5fC7rSjt7sHff/6Pez31giqMFUch8QQ1arBbA1XNfJiDvIQVAu8TFrg1KrDQnN5pevgREeHUL+npPb6/X5cPnUMe5/dgxMdHSJXl8QPqzd8BuW3fgyldnNBdGHxW2HSob0BQLkGMFMAJiVBbIgjDBZhAyCYzsJgYcb07QYhd8tEJvjfU/5eubcE5d42YFEb2I6juHSpR3CPOXspQoEQjr52GCc6OlBa7oWpqBRj/lGwVisqqAWuBX7SC7dQ277ik5OCMnXabUmfVwrGVEruSjfWasXlU8cQGOzFrHmtQgaYxAE7O47g6MmzCPX24XRnp7DGmKIp8AFA/Z1/gbl33SeAL9/wI2EzqgSGARBGYi8Qsj+w4QC0SYFkQzzr4KNhC7CocrIg+U7SDZJJJjnXRmeCgcQeIeXeNuULvm0xqtsWi9zj8FCvAMJhJMobTnR04LFHHhFihcSdkbo5qYyu9C8UoyGXzmWnYXg1T4Qm57zKasWhlw4CABbesg5ls8ox+J4Pl08dw9GTZ3Hg+LtTx2xwSHB1cbkXdm8NrKs3o3XpDXC2rcq7u6tGX4BPgoy9sjs3CjAXyo+8D/nwFzzXJuISpCCad5+nCwTpTLAWI+5xNQC246jgphAYAhDFClvmzcOK9avQMnehCIapLphCBF0gFNYMRaU44dWg+IhV8W7t6wdfhamoFIOnzuAnf/stkdIrWrJiSmAwU8mNlkVt8Ky/ExXF9oIGH1UCwwDoN5fXpA1bG6YApXCaUmnqgab294mrDQAtjkm8TqQw3w3itptF2WS1CZV82exrKvA2/2+SCNHkBrYtxry2xfDJqEIA6O3uwXudx7F/7++xeHk7KuY24/0bNwmujxIMM900J6N4TigsCza1ClCLKswGGHMZ+5OLPZIYHpAoexk8dQaXLvUIbuxb+15ANA6YikrBhIZh84pvwhUbt6C+dR6cbavy6upqqQ3mS2DIyTw/vGtnrHTLdtPwrp0xwwBIBRSFIXH0WCotwFMLwnTKkh4rRRdDT5d6QGlPs16TqkISK2RCw4Ir+9a+F8C9dhj7f/krUTkNDUMSKwpzQHWFN+cXdKag0wrDbIAwG2UySqBDMIjL3WeE+N2Yf1R07klnEB3O4OylMIeGAYUNrwopxkepO4E3clCUlMD08KKIyakCVAM6rX9H4CcHyEQ73PPIxB3Pt7scbV6umAnWrUBkYoUkgwwkl9MQF7msoRlNLmfiIpnIfNOcQgGeFigaCUKt8KNLeywWMyKRqOD2d3YcERQdDTpybknbopmd6vPl7KUwgd//g4cdqSIobWiFv7IR3oZGDHV3IdTfA3tVnbBfTaHP16TDXTIlMF2qrn0DAJiX6LINcUSjcVE3SKi/J9EN0rZKUyySVoq5huFwKJrUReMPhGHUCL5UqpB2kftOJ1xku9OOBW0JFzzRLdCedGESSFypPbpyYNTjMqcq1qYhBwCRSBTBOJdwXflun3SgkyaohP8PDQvnl5Su0LAT1gUAUuIePdKFEB/Wr2+dVzClLRL3NrEuqcoPQQhNlcCQRdop8VgNB2DexnaIFWJ82l9gZrMZxQtuwtgru8HLduCaCuPjUrwqTAVDogzJBXWiowNf2vE51NbWweUuwYr1iQwg6UJx2m1JFzG58J12m2zSohDVn5J7nM5lTgU5+tgQI4qui3dbpTE6AjlyA0oFOvq8AYkC5cTw2jrU1tZhoK5J5Eko9fP4hkbRz1mm9TVEhb7IGKyBbCtASyoiZw94UniwgvoDprpB9Gak86EGS+1muJ02oSUuF0a7yHSRtfSiCgVC6A1M1R3u3/t7MEV22JjEptot8+bBXlMtFEu3zF0oXPgjY4kkXJWnWGmxIhIRqwwpVAoFjlKQCypOA+TSua3EPZUDHe26AkgCHa3qiCwoV/ndKnvOgm4ktc1fXnDub7oaX34OAMkAXwa/E9zwrp1c1gGYdwVVXgP0J3eDaM0u5zMuWN86D+/9FhTM23LyvnSRtU8GhtKLksQGQwB6A4nsMgC8wAI2b40wPr+2tg6XLvUkZgnOFWeRCSxJdplWkhYAtiKrIjCVwJlt87icQrglHOMEyA2qgBy5qcgpOtptpVUdDTp/5QrMM0eSFJ1W0ClZZzRxKVuH+uBtXyFsWF4o3pHUqpyKgkgogXHc8qE+3qO6sgHoNLNwO20YV6kg1cJQKYNMAq75hGU2YVjfuhHBRQn4EjcZgMg1o8FILmCOUotMaBjvdR6HqagUfaePI/rSC1PHigX28kCllSSBpstdIgxfoFvwpKU4SokZWjFaLOa0WzWMhyJJCo/AWCvkotTSkiYiCOxIMoI8J3VbAci6rkaATsncA4n436S3WphSXkhGJTgUTbITXB+/BzBjOAAtbe0cdu1M+lunmeV7gXNvSu1wamCnVSVmo7RmOBTNSiZYj9HlBrZbb8e1/HPVfKyIuExpwQgk/ZteoXanXRin1BtIvJa0bOMFFkkxLiFsoJAlorcEIOZylyjuYAZA9F1Ky72i11CCnNRlpb8nIykt0aLmkEXQqYn/RZsLx/1VqgGUKxuTlMCcAoDSLdvZVDWAV4wLTJs/EBZATMcB06nATNxlY5QsRC1xRmaCjYAhUYiOmjqgdZ4IjORCquw5i86oBe6BLuFvSOyQmLSvFBJoiOAp+Tz03xBoSv++73TCJdd6LyaKrW/ouODWS91VUUmJxKaUHKCUhMiFmtNqQ91T58peVQe33Vww8MtAIXYD6WsAMwVgwfh94brZUwfD14toNC4kR5RqCrNxsjJxhcloL/p7ZCMTbDQU6RgmWufhBur3HDV1qH3hORx97bAAP9eazeJj55vatTDU3wOGj0WFual4o5zJQYizlwrPm9nk2CWJr0n/lrOXCrBNgpxGd9XI2FwuzTrUB8/qW/NS/qLm+qHXifS68Yei0ikwF4D0JTBXDADpdjg1Li8NQbqtLhPLNA5YajeLhqPmMhGSTTDS4BGA43BOKaz6OVMqmPq3BQATDIgugODB3UBZDRwLFssOwE3c7htF/x+/0CXAa/KaG5N+R/p7pC2MXbIZ88wRRcjZeDesvHd6DuKFaJ0Bk95qNM6pz9vnoK8frWEmmRKYU5JwnXEQC778v8LalVNgBaEIYxzS8UiuTCYTdWiECqSHo14pRjKMAD/30OEUgY0AkQkGRGCUgpJcqEx5NUz1c0SwVLLYxXMInvkjUFYDy61/rhizCbz5igBpm7cG87beI4oz1csAPjjNwUfCFqI1XADxPzn4pdvtUVICMw7AByjvBEdbJtKHTf7wmQ5C1f73JN5nr6oT9QSngx/5rzT2Z4QazMSY8kRUjSRCpqMReFw83gn3QJfs9oucwyk8pLCTM46Pjao9x1JogleU9IM8F7/QJbjGpeVe4fMHe3uEx5VoQ91dsA71wTrUl9f4XzrRkG6zs9NBK0L9PXQPsI8sm2wC0NCjlQk8yfaYof4eoR3Oadb/1Wgw5sqmhqNOX6PB17f3OVz81X9ODdVUaLpXdVPgYcXZS3WNDlOCLnGt6QRMb3cP3n3qXxF+4bmk73WlmXugC5PexM3B09Kacs/dfKk/SuElXe+C59ZznobdxbFXdocqH93JqgGg5m9MDRc0G/fFM1OO6Wq91ELPqASJXndY63DUQgJfsLcHF493ijZzEllZjSb1Jjqevl5wEyEhg5wV5U3FKftOH0ff6ePg+EERtbV18PFxQFodTncj5S9GxP/Sxe3krgUjSsoC0ThMoXF6bb0HAJGOw6qgoAdiUgAytCtqBAzNZlaAolmHktO7OZJU9ekpoNa6aMiQycHxUFImeLqovlTgY4rscCxYDHN5jSj+JxfzSwco5pobNf2NvaouEQNMoSzN5TVwrNqMUH8PuAtdSQkbAYb2wxjkB0UMXAEwlIZXjGp/U5rBaWT9rNCRAxZOM0tKYAiXjvM3zawB0BAXWK3qo0talA86K9sOp+ZvsxXTSHfCCfyKHFZMBBO9r9MpE0xU37tP/au84pNxP1P9fzaNxA+V3p8kVWK8igieOCqU30j7ot/a98IVAUMS/wMA6+rNhnQzyb2GmmtBr/JrrigWPARMTYG5mE2IMQC40i3bTVFfr8VI0MlBjfytHpDRijQajcNtN6PUbsZ74/pGOKl1kVOdbLqyvaFiqqxiODT1fKFnggn43t7zPCaOHErEz+zy00mARB3fxJFDYPlZc3TZi1oVqHfPZ3N5TSK5kea9yM9M9XMQu3hOVHtIf6fYxNRgWSkM2fmL0e51INjQJByjQo//9XsTnUdlXm/G9X9S+GWzPdRsZgX4BS9fJurPxP/3AgA4bvlQnExXMlzFRX29Zih0gkQNcIX1vAbdDyw3OaKutAgA4AxF4Q9F86IMaejRVmo3Y3A8hOFQIsBbCC1xSuALv/AcOjs6EB7qBeylQvbU5q3Bsg0fEfXI0mP54xe6MHGhSwTCXKhApsiuWExNw48JBjB+4k1wZ/4oAD02MYxZ81qx8JbEnreDp87gBPnulDoMD/UCB3fjFf65xcvb4bj19oKGIIn/MeXJ8T9yoybrUi/MjFR+ZFirubxGgB8ADMTMws8AjAB4BwD4XuCsubFm5HEeoJyLTPcD+wNh1EvuGCIQDk9kHYLSws6GihLUmqO4FE0+5EUOKzCeuEjLbIW5e9nF450YfH7XFNSo7ogFy2+V3ZP40EsH8frBV9OCUEtMT5Pr63DCxgDh0DCivt6k96LhN/bKbuByr0jBrr/jI8L8QwDA/CZsuGOTML+PbEQlVb1HXzuM+rom1LfOK0gIpqv/o2/UFbyHomVvDiPgp9Z1Dp8UbYU5OM8cGT2s4X3YDABozjXo6IcWN1paElNXWqQLfqQ8Ru4hBz/pCZSDn/RvSCaYjtXkU/UBEEpapBe73WnH2o/eqbgh+4r1q/DgIw9hzYc/ArvTLiqFiV/owsSRQwi8+QpiF89l7TuQMg85N5pzOBG7eE4EPyY0DLvTjg33bBXDj7LF85vgcpck9TPTNvj8roJVgCT+x/nE9X/RaBR1pUWoNUdFN+e60iIhWReNRkUPo+EXBouGihJRSc7poLLWonaCA4Bzh196IYypjpCcALAgJItcP3Aqc1IxRrUmFwOU7oVsNptRV1okuNxaTe82mdmA38XjnfjjvyknOUKBEPb/8lfY++yelK9FQLho3a2KIBzf+wvELp5L6hLJ1MjNhPP1Jb127OI5TBw5BG4iJMzrq25pxYOPPCQaxSW1J5/4EV569r9Tr8ehXpx+q6NgawjJjYGMyKdvwkpeSl1pERoqStBQUYKKYrug0mgY0iVgWhQjERHEvR0cn7q5XDPyrijUJXLlxTvBXQAA15rNrBaQ6TETCqgXWPaAUu1wcgWedaVFCAyOawYf/W+i/myIC+DTI+Ollu9MsKOmDuEXnsPF19I7EyQZcKKjQ9hlTsk23LEJG+7YJOsak2QJU2QHU16N4gU3GRIjNNXPAcpqgMu9Ijc48OYrongfExpG+/pbU37+oyfP4tjL+9B3+rjshvFk7BVRyhNHDuFiQ2PBucK0Gib7fwyOhwSVp8aKHNZE6Ia3nuEJ0ZrXsu5JOUtdaXESEM1TkEt8bgrYADA+NAR7VR0RYe/oUXJ6AWjK5UkjMl0pdqdlIAKtAtXEAuW6QmxIuNaldrNoIUhdAT0QzHcmWK60paZBrGToOYCcvVQTCFesX4UV61fh0EsHRRtzExDizB8xeqEL7DWNonBAqL9HVQ+w1JjyanCXexE/eRTm8hrZeN+aD39E0eUl8Nv/y18J0CaJn0lvtTBIAUjM/KNHdQ0+vwvl3nsKMv5HWgSNqP+T83gmgpOqXrtBwVtKiA3xtSfdfkNSAnMCUDcFRi8AyYRVkQJscWR/d7C60iJMBCfh13GylACVSgVKC7FJHDEV8KQnPwxW8wEmCyZfmeC+vc8J05zpGXfSQaNk5L0RICTKSrpBE0mY2J12hDP4TsULbsKYrw+hQAih53/Fy7UpiK396J0pXd69z+7hS15Khb9jmm+EdcFNYH29mOABGAqEUNuWOE4E6uGhXvTtfQ7X3vOZglGBpP5v0lstar8sclgVE3V6TKoStYqTUrs1CaD0OHyqBIZFYgJZH6BuCsy0UoAEQkUOKzASko3dJfoD/z1J4mtRgTT0SN2g3hM4HIrK3sHkjLgPwp1v/nLhu+Ta7aXdO+l0ZKnV1tYJIKQvehqER187jMXL21OCcPH8Jiye3yTKrtLucSgQSpTcXOhCgI/rmTQqQaa8Ghyl1JhQIt537477Uv7dk0/8SLghCH/bfKOii072QaH3Ye47fRz+Pc+jZVH+i9qHursQ5gAbkziOdPJNKf6Xa5sITgp1iSo6zEgG2Ad+EKraEhjNAHSt2Uy2bswpAOksrjlF8sJeVSfAz3n+dWD+ClXKMjA4nngPM6sreUE6OWhYSoPCqf5WrsQgl9OhSY3fH187LCpvSQU/KQiVXGMAmkBISk1o91hOFTInjopa7JQsdvGcqLOD2KJ16eN9xOWl4Ve0ZEUCvvxEGXN5jWyt4YK2NlGZTPDgbvgKKB4Y5oBZkniakguban8cEl/XKxRSeUGJ92VFdb10Uunin47QNYC9Y6/sHspLDDAwexmcSCQeKp0WBKJxBMIxY4YUxDhdf3c6aEWLyt+lCyu1WM/whHCHsiEOKBSNyj03EZwUMl1yVfS5nA4d7O3Bseefn1I4RXYsW7USAFLupaGkCMmFL9yiNYJQ6h4PnjqDo68dFoFQmjQhRbLAVHlLqL9HFJ9T6/IeeulgYvtPeoJ0WQ1cazYnzTMktYZyBTHSeGD0yH4E81zUHurvSdRGcol4mlIHSM/whHBjVhpkEI1GMTjO/62OgmklDyvAl66R5EiqdYupDHAXL9LYsVd2x7MNQFbOt7OZGCFWdzocNOSEkdcUuaySgQlq3GejjCwMpT1EpPsKk9oq6d8rgZEsjFztE+yoqcPbe54XZUQXLWyDvaYaod6+tBsKyRmtfkS+CgVCNTHCVKpQeM2JEDheFRJ4k+ellk710fE+usuFdnnlynQmvdVghv4Izl6KYd+QoIjlXOHa2jrY8twlMumtBnx9ihNgaPjJx8eTd0XUkvkl105gfBI2HpzkGiHelJrhKnxChwCwk2JT7gFI9+sWOaxw2iYNaYuTg4M/FBW9djQaV1SbmcwFJCcjORbBqhqlTxaR1JVQc6cs95Yk5voge6UwpNZv4sghAX41DYmtKUO9UwMEjIIgU2QXsq9akiVyqvDYy/uS2u3kwEdifQtvWZdS9ZF4X2Lyy9TrOVZtTrTtQdw5onq9UiqQs5fiREcH5rUtzrsLnCoDrAV+asI8SaJGwqdANI4zKkvS6BvHUHcXXQJzQc9x0ARAxy0fIjFAMwVARg42TjOLAQPcYKmCI4kQud+jJ8JkAr1hvl9Y+hnoqdFqB6bSboJaF2E4FM1JAW2wtweDz+8SAaplnvy+sC53iWaXWOoCkr08SDJCLwhJ0oS4q6c7O5O25ySbiy/bkLq8RRrvo11ex4LFMNXPmRrISk2vpmHI+fpECRuSCKHjo9KscPWG23MOPWkLHAldSdd+Ie9zTWoCuwdHaTEGACcBbSUwmShAq5I6I1ZXWoSBgF93rM9mYhCOcXDb9Sk4W895YPESzfG8VHMI5aCndkqMnkWV7VKYvr3PiRQa7frKGdmwXC0EaReQKFnnTWvALLgJ4yfeFOJzUhAuW7UyLbSkqpCAjHx2e011WsVHx/sSfyQf75NLspDnxk+8CVzuFRR0uuNA3OTqPAGE8/UJMVNp33kmgw+yZYFoPGlT9J7hCWkPcBj8GKyorzd7AKSmrJJJMOQDwGxmkwKaTpspZTKEhp7TZhKpyEA0jnAslvUx3T38YARBRZrZgjjx0ebslcKQuF/w9HGR61sxt1kRfgCEn2lRg7QKjF/oAsPH0lKB8JVf/zdeP/iqJhDS8UK1RlxeGl5M841w3rRG5PIm3Zj450k3CZcCfnLHIRQIwTc0WnAdIuncXpIQMWLKi5IHpXZvHrIPCO8C9wAYBEQT61XH8nQJLDW/JBd/C8c4AXxOmwmVTgtunOVGc0UxmiuKhT7aVLE7JUjRi3UsxQgkIvdP9o4KNYAkqZKNuKUeIxulE5PeBY2I+3EU/FrmzUsJv1RucToVKLqY+P1dCUScN61BycY7wV7TOHUeKRB+55Fv4tBLBw09tkdPnsV3HvlmUryPvaYRzpvWyK4nKfxiF88pwm/YNyR7HEirHMBnhHMMPzJYgwyI1ar2tLa46QWjmvCSZB+Q7rFXdo/xPcA5AaCDUoCKsKsrLYLTZkpSepVOC+bXlAjAS6XKtAwwdVF7RjDBQEqYdY2EkmBK/p0NEGpdONLFqbQxdDbjfmqsYm5zWhDSFz6p06ThkksQ7n12D/Y+9Yxoso2QOZYZmKAEP/oGYnfasXh5uyoVSKy3uwe+odG8DUtQO3DDSOAZucXE+JDoJtPFfyfNCYdMASgb/6OtuaIYN85yY35NSUroEVV2ZnAcA4GIEAeUA1GmcCIZp0Jxd5XMm6ZQVY/6O/3W1EBPOu6n12i3WAmE9IWfCjJqQZhu+kwq1ffWvhfEF8A1jXCt2SxkqMdPvKkcP6PgR9vaj96JirnNU8eET4QUogok5nba8rILnNIIOa1xQV4QEGXVwYsEzQDUewRsRh0QknkixdMEfLTLPBGcVFVpLh2JpfR+9Kh9Na61mpOqZVy+Gtej1G4WNX4bUQqjpuQlE6NBqhQf5CZCssNJ5UDILLgJY6/sFu3PoSdrvPfZPThKJttQqo9keTkkupxGn/8VcOaPCAAiV5iYHPw23LNVSLbsd9pTzgiUxgJ7u3tgzlMsUDpUYLpYlXOq/tdeVcdKFCCXawAKb6h2QACBXTQal838ytlwKCq8/kRwEuEYp6q8Rq6LJJVLnYmy1LKtphoQDoeiqHKyhk6FoV1fu1Pe9SUQ0wNFOgNLg1CaDVZrnMOZqFc788fESCsgqY7wKL91pVydH13eAkmsT9rLyzmcKFqyIuHa8j3HNATTwU8Kt1QxUfpY5Ls7ROuk59x+tuS9gC54rsWsGEcSICyACIAzADC8a2d2AUhJTE2NfxPBSXSNhGSBJFV76YCodXQPXcA8EZw0rEUvF4vPqPgQyfpKQXC6szP5lzs7UVtbJ7izqcpitIBQlAXVMdaK9P2On3gzafvK3u4e9D71DPbz02ta5s3DmH80reqTmql+DoqABATP/BHjvj641mwWZaqV4EfgRgYn0B0hxFzuEthrqrEAED5bLlUgPSSETFVJtf6yFf/L1CQbpQ+5B7reG5MIsmwrQKsW+J0eCiZBjcAuVa8v+RkNsUz2H9YKz3xtqyl8V4M2SJK6viRORYAk3XC8bzARYK6u8KLWPypcuBmBkIKt3DaVai5eZ/0cUfkMfH2iuX7kO/WdPi4Cn5LqQwoIkgEKo2R8Vhr4AYmEkHnfC+D4z0KDjz4mLncJ7JS7nA8VmMvkix74pfLG+BtFHIl5BO+813l8HDon07OZADDU35M2myTncmodcBAIxzARnEwUK8souFSvF5XAM5vqL91eIUl3nzSuh1GfNXpkf3IMaGIYsYlhIS5HP2gQvnWsA6c7OxHq7csoWUJASyanZLIPCIkRutZshmPV5iSAc3wfrxCeWbIiUduncsK0qX4OHAuS29XIXiGpCqylZTF0coQOMyxom4rn5jsjXGjwS2eSMfhnAcRdazab8qEAOVrpSeOABFj0Ba17ugulIqUxQDlQ0HJfaLAuIPdXldQ3ZzYWi8z4k053Jju5yV2cg6fO4NKlHuFvmCI7+gaH0Df4KhYtbFNV+6cU+yLKErybSUZaqZntJ7cjHNnLt5hvV4v6ehOtdr4+cBMhYZCB5tmBwQCCJ45O/T8/RebBRx5K+XeL5zfhWENdYoRXkT2lMi4EFahnt7d8m63nPCmBYSgA6ja939wip/SaJQAk5Sx6lZ/quwy//4fcWHyzmdW9GTqtILORIU63+GRrATWMxQr29uDtYx3C/9c01OEL//RtVDgcaCx3gaW+U7nLBd9YIpLSPxLCW28fFrKn5GImCYeWefM0u8Ry4BRGWqWY7afWXSYwdEpgWLzgJk2yQDo/UM3g1Ja5C1HlKUZDhQeHXjqI3u7EyKlLl3oUbxinOztFbjKJBRbCHtBGxP+0Kj/pdZZq2pNkDP7bgL4McCYANEldNemHVTvdQRP9ZeKH5LloNI4wNRVaCJbOXyFbXqMHhNkuk5E9QRnsENe39zmRS3vvjvuwqa0JA8N+BKMcEJ1S54HQSEI1mhlUeey4+7ZNuHXlSrzw6qv4ziPfRCgQgt1pF5RhC9QnSMjvkDl0iiCkNkSytPGFxXsTbqUWFUfDUCv86Ewv2RhdCr+WuQvhtNtQUWwVbiJxfv2vWL9K6C2W6wgh8JOqciY0nAhV5GBIApkEky346VZj1PUlBz97VR1RfyQDHAUSQ5O09gAbrgDpej2p65st1acHnoVm6VSg3h3ifEOjwkUWmxjGps99HhvXrkb34BTolCwejWNgODHI4u7bNqFl7kJ8acfn0NvdA7sz4RIP+xK9ulqUYGm5V3CDFy9vF1xtktEls/1GL3SBPfEmihfcBCCRwLA2LVB0idK1PaoxuV3i1t/xEdz7uR2Jm6kEePSxEo752BjKGpoV3V97TTUGT50RjqNwgwiEYPPWYNg3lHcVWAjwS/n5pgqgGQC9AM4B2nuAiemNUNqVYgpyrq+R0EsHPjpWlGpD5VxbqsRIqhlr9CYwWoyu+Zs1rxXb7/oL4WJNBT+pDQz7cV21G//xzE+weHl74mLlldzrB19VnRyhf4cJDcPlLsG9O+7Dhnu2YtG6W4XnSdyR8/WJMrB87ydmtS4SH9e62bA2LUj7cBXZRa2SriI7rE0LwAQDGN/7C8QvdMHmrRFipF/53nfxw8f/AddVu3FdtRtVHrsIfuRYsmZW9HxjqQfVFV6EucQxGvOPimorT3R0CPArLffiwUceQk1DXWLDpkAI0SP7s5IMkRuFJRdm0buuM3F/dRiBwMWxV3YHJM9lTwFSfraNdjeI+UNR1XvtTkfLNB6ox/RcDEK7G69m7t1xH6o8dgRCMU3woy92p92Ef/nut/C1//d17N/7eyGAf7qzU/XWA8TdZTDVKZJq4jPdo9v77E/AlFdj8qY1imow5YVaNxuzWheBjqC+8z8/xfgru2FjAPDfp6ahDt964vtob5olxERllYNkDbBmFvFoHFWexF4qROVdutQjJJukdZf37rgPLXMXYuEt69D71DNCiKG6gCbE5CLMo6QIU5TCEA4dA4DSLdtNw7t2xrIOQPq6VFZosZwd9OmU0TXyTp7KRfINjQo1f7GJhBu3ce1qBEKZnZd4NA7WzOLv/+6r+BogQJDAauEt6zJuqaNn+5HN04Uhp7wqHHv2J0JBs+OWDwmq8L3jbyW9HlGL5GfvHX8Lk2dPCEmS4ImjgprlJkJYu+F9+NuHH0JlqRsDw/4kyKmxcpcrATy+0HnYN4RQbx/G/KMCFEOBEDbcsxUtcxdiMBjE4vlNoja6bG2jSSeUjLp2MoGeXFxdYzfWGd4t1v1ltHaCEPKSaQbCLMBcgk9PLFBt+1zWoa1ywRDXRFoMnc56Dk8F8Z0VNbj3cztEcSojIPi3Dz+EB/hOC1ImU3vqTNp5gmqsZe5CtDfNwt23bcLhs+/hZ8/+StgzmFaFE0cOIchnj9+jgEeD8J3/+amwORI5dnRSiCmyC1tEPvhPj+Lu2zbBNzamG37EFs9vwl5akfMTqwn8Fi9vx/s3bsJgMCh852WrVuKVX/+3EAvMlwrMdN6fFveXnr6USvHJ1G+SJOzbEs80uwDkx+GLFKArRb1TvuEnNxW6UECo1qRTe1MZ23FUaNmKTQxj7T2fx3XVbkH96XF/lSD411/5Cu772MeErO6Jjg4sc2cevG8snyrHaW+ahfYv3Q/fZz+F5/cfEKlCGoQTRw6haMkKvHP2BAJvviKoHSnsBCXJP09npVcvWyG8bybw842NoWXuwsRm7jxc6Wyw3WlPGuAwGAxixfpVIsWbr83U85UE0aD8SAIkAOBdQF8PsHDN6Aw+2gsNFGqUYLbqEI1aePTASXohqh2M+hZV8zdrXiseuPeTItc3GM38+5NYV3vTLDz4yEMCTEg8MNNuERo+vrExAUp337YJP3z8H/Cjn/8cG+7ZiuoKbyKeWGSH3WnHxJFDGHv2J4hf6BLUHp2NFer6yqvBXtOIoiUrBAiGAiEceP0Qyl0uQ87lddVuLGhrS9qgKRQIYdmqlWiZu1BW+ZKtSInrnE34OTOsfVbaHiKL4JMy6J1Qf08vD8OcAXDKk5vGlk8Q0otEbsEQ11f6XyoMIfu6p9/qSKr5c9qN3buewIk1sxgY9uPu2zZh7Yb3CSDqGxzKqGVODgxSGLY3zcLjX7ofv/j50/jqPz2K6gqvoAjJQ1B95dUoWrICJRvvhOuOT6Ds83+L0o9/FqUf/yya/urRxPaQvB09eVZQuJneHIQ4oMTsTjtWrF8luL5yKpBkiEOBEE6/1ZGVNSjXVaN3LeuZ7ad14LCHjcoCMHLqj5OuNZtzCkCpAiwoX9JmYjIqHM7WCVR7B02CHRmbleY7CYkPJEpJNtyzFRvXrsblgNidMcIFlkLp3s/tENW0yU6Y0eD+qnlP39gYWDOLu2/bhF/8/GlsuGcr6EgBU14twM5xy4dw7V1/iev+7G7R67x3/C3Yq+qmNmziY5esQRl+ab9wKvWnpALjJ49OG5c3m+pPMruQMOiPGYq4jP5YKLCjh5DOmBYJrR6gbmdqwU0nPjh7KRbPb0I8GkeZ02w49ORc4bUfvVNQn5moQK3wISB8/Ev3Cy4nNxGC86Y1onrB946/lZQlntW6SHRjGfOPpix70fq5Ft3QjpqGuiT1l8qUVGC2hyRIwy/ZgJ2BRhZ0pyHrWMcbiwBYSJbr0VWZqkC1EEyeDC12faWz6r7+xYfx5x/bhuf3H8Dg+CScdhMcZgbBKJdRHFDOPfSNjeGBez8putjlVGCot0+UDJD2yLbMXag7BqcXXGqnw+i5MZB6QFLgTNSfnPubTgUGp2FdYJaMQyIDHAW/DzCQWfGhHmIwkGmFK0QzokUqG6YUO1G6C6fqBqGnlsQmhoVuit7uHnz9iw9jx6c/jb//wY/R5RuD026C024yJBlCX+wNFR7cu+M+RRUoVYOcvTTpOTr7m3NJUZQoWDaiXIi8Bh0HZIrsmjaUJ0pRKDbPUiwwl64u/cgQgAAwEOrvuQDob4HTDUDL3BvNhQxAtXd1NW11hWJKLtDptzoSm3LzF1n7+ltR3dIqurD7Boew96ln8KUdn8Pf/+DHeKfPD6fdZFisizWz8I2N4daVK9OrQIWR+C1zFxr2eTTFcZoWiOKXgxlMDZJTyCQOSCbDpFN/xA2WbvqUjVhgIIrpaOSCPRM59ccxZJgB1qsAbVIXuFD20k26s6fY4rBQ3GDdcSY+8cHxHR9rVq/Ev3z3W/i3n/wHvvpPjwrbNNIZ2r1PPYP7PvYxfO3/fR1vvNuX1MeayYVfWepOqQJpBcQU2UVJAjXJj1QmdZ3VnHdpTHDYN4RAKGxYKQwZjEAAO+wbwuXuM6hwyDZRocLhwOXuM/jZY4/h6GuHBfVXSCowX7E/mTxDJwCudMv2jD+Q5hewV9XZMVUGU/AVxekAZYQKzAcE6SnPpOMjEEoMfN24djUe++dv4iuPPoS1G94nAmGYS7SxfeGT9+Br/+/reH7/AbBmFpWl7oxV4OplK1DTUCdAkFaB9DaR1RVTU13LGpoNgbArwyLsMAdVCk2LNZZ6hC1BQ4GQUGojB7/Tp47hySd+JAs/o1WgNI48jdQfC2ASwH8B+kdg6QUggZ0DBVwHKO1MyZWbm00IknY42vWlR12t/eiduK7aPbWHSiiGYJTDxrWr8fd/91V8+z+eEkpFCAiBBAi//sWH8dd/9SX89Dd7EIxyqCx1pwSSUpyMjgUSIypQtIhCw6LNglprKow/Fxo3kSfHxUiTJkKA5J32iBp88vtP4BsPfzOpXe7BRx6C3WkvCBWoVv0ZFOtTAiADoM9cXvMHIPP4nyYAutZsBgXAaZEEyYfa1HrilcZjKZUkcL4+UeKDjLoi6k8EzlAMgVAMS6+txtc++ynZLgqmyI6jrx3G17/4MD659RO4/1uP450+f1oQKrl9ciowVQbYqGJtvcXXdDH05e4zhq4HaSLkdGcnBoNBAXynTx3Dt7/4Bezf+3tRHePaDe/DXQ88gJa5C7GgrU1Qg0aqwFwIgyyB0Bz19RYZ9WJ6fA87iQEaVVGetROgQQkUSlJELjucqneZjLpK9dkJCK+rduNrn/0Unvj3fxe6KIQWMUmc8P5vPS7ECaUwlFOB0owwrQLp+J/NWyNkOVcvW2H48aOTGpmoN72hAKnRiRBBwZ86hp899hi+/sWHRaqPzAe87d5PAUi45Bvu2CSqC2Q7juIqNXpLXlvOAWgur2EoAAotC9IBldPRjARfNmoRyeZItMUmhrF4eTtWL1uBy4GoqgEPBIQVxVZsXLsa//HMT4SECSkiJnHCvU89gy988h7BPQ6EYiIQxqPxJFBIY4HETnR0IMwl3F96NzSjW/VokxuPlc6UYnRqoSk9HvRgBCCRCPnZY4/hO498U4j1kfjj4uXtwnxA2soamgUVSI5lvm/IubYWx6RUgBVLoJg7BRjq77FKfPJpU05yJZmpqBR3PfCArk6PYJQThqNuXLsa//Ldb+Gr//Qo1m54X1KcUOoeS1UhufDJxU+rQKLAybw92oxWf3RWWW2Qf1broqx6MYk4YDFKy70CwMiG6LTqu/XP78RdDzyAsoZm2UQMUYHkb/SowHJviSiOLNlcfDqZFYBTEpbTL1g0uxhVdRZ+kXH2qrqCygJHo/GMW/MyHZelZ2o0PU3XhnjaOy43kRioufTa6qR+XzVGQ5MG4ca1q/FOn192Bl/f4BB6n3oGL/ziV1i0sA0b7tiERTe0Y0F9haB2CARJXeChOz6CVw68OvW57aWomNvMbyqUHfUX5vTLAr2zDFO5zE67CS3z5gnH0k5Nnl740XV4/8ZNqHA4UmagiQok8DzR0YF5bYuvmpt9YPYy2KueJ/9rCfX3FEm80twBENN8EowWl7hQ5gaazWaYy2uEwaiLl7fjgXs/qQt+SjAkF/F11W48/qX70X3vJ3Hg9UPY++wevHWsI0kV0ltkrli/CreuXCmU0gwMJ5Iot937KQGATGgYi9bdisXzmzKu+zP02JbXYFRSoK01+SPdGU6kvFyupATN2g3vw4r1q4TWODXlNxvu2CQqkWE7jiKuE4JqtxottBggEV32qjpH5NQfjTn/Ov6mhHKBZyzXq6C8GhVzm+EwMxgPRWCxaD+FwSin6DqTHeEcZgZ337YJG9euxhvv9uF3z++RV4Xdv8f+vb/Hkw11WHhLQtEsvTZxwf/ssccE19furRFUYz66PtSY3oEIqRSgb2wsaUI0DT+1VtbQjMXL2wUIFpIKpEfbp9nLQ7dHJQm7GTaPVA8APTMY0rYotEvsOPU6UVU7d2Vj0jXZGnPptdXYJFGFJzo6RPt1SF1kl7sEbx3rECYwk2EAVR5jZ+kS+NDbUVqH1CscunWS9ANrAbSajHHL3IWoaahL7A/CF0SnGouVTgUCyFgFBnt74GxLH5pR56Hk7IZGRJcj5wCkNh65agBIJ3f0wEULBJUWG4Gh22mDdL89PeqPdnu1XOQDw4keYqIKSaxw8NQZWReZgJGbSMS7VqxflVXXV6nFLJ25iuwYA5L28tUKwlTHrrHchdraOmFPZL2xRloFEmBX6wRgfyCOchU34nxngJUOhYRJuk1PFthNx09mLDcmGonV25fRRBcyFkvraxAQxqNxIVb42D9/U+g0IS1u0snMC29Zh41rV2fF9aVf06bjcgjXzRbVDho1KUf6GSvmNgs3iTH/qO62O7KfCNmR7/yFwezc/AsTfMQqDTs3Wv/AXlVXLJGjM5YFM3KP1WwYgSFxkcmY+q88OrVPCFF/D9z7SdXuoh7zjY3BaU/OzWmtUR32DaF/ZFz191f7fcpdrqTJMLqlD68CSfjBefI1Ldeu8G9TKP33LBQIUpPeCXO8eQNgqL/HScdPrpa9efPRKaIVgno+nxGKh8CQNbM49NLBqQvOace3nvg+Gio8hrmUqYwMHlBrcsXStDKjaxylD62AlpsMo9vd59vriAr0DY1qfo1Um2tlAj6jW9/CMQ5mMysdc+fhPdDc9QJTb+ak4yczlp0FkWoRphquqReCmYKwstSN5/cfEDZM5yZCWPvRO9HeNCvjfXZ13Tx6zmv7fX6LzMvdZwwbiUWDVG4yjN645fs3bkJNw9SQBXoyUD69j2wOBJGwpjjnCnB4107y7cr4/14d0s8AwBgRh5FOhTb6c2S6d8jAsB9PPvEjoZWupqEOX7nvHqGsJJ7lkWHFdvF8Di3TwMlABC6LE8TTTYbRagtvWZeRCoz6evO2B3AGRhZpKc+knClAMnmVvdoBWCgucCRSOIu3stSNF159Fb3dPUIr3b077kNlqVtwfbOtALO1+ZMRRtS13GQYvaZHBV4BSUtykitdazazSOwHktGJ17QqLXNvtBH6AlfnjnD5inle8Fwr/LszaikYlcqaWZy4OCioPzLLbuPa1Tl1fVkzi9raxBgupdH7+TY6EZJpHFCPCqR3Fwz19xg6Fj/bQ4ElrCkFYMhILK2r0wYDJzFcLZbJ4lCKBQbjXFoIagGh3tKYcpcLO3/2n6IOkbseeED0O/FoYWe06exoJhNhlI4pMXoyTJh/Wm8cUK8KlK4RusheTcF9PuAnowBdMKglV4sLTEpgnLiKLV8xwFx9XrJ9plrVtafjLPb/8ldC0fOa1Suxqa1JNB2G/DdbIJS+rt1p170fTKaxuVSf0eNyorTcK0zHMQK2mcQCyUQYss78oahmVZgr+ElGYjmNEmKqrjDL3BsZXjZXA3AW8p4CWrN/uVSBehaLEfWAWpWgFvvNkz8WFEhNQx3u/dwOoT5QCQRqHlp/F9C3LwjZIJ12m7OxPWcwyqHMaUbLvHlCQfTgqTMZ70OyeH6TJhVIRmLRAxGcZhbhk6/h+GP/H44/9v/hcpiDU0XoIlfwI+9DKXU7gGqaTVkFYPGCm8g/q/gRWHF7VR0zq3XRzCzAK9RSucPBKAfWzOL5/QfwyoFXhbKXhbesky1INkLVqXHFjTAt+/eqUdNJ7jY/GSbTgmhiZQ3NIhU47BtSVIHlXuUbxMXjnQj19yDU34PL//tUwXlbgdnLgMREGJL4qJGwKXsApHruSBvcDPXybA72/2/v3cPbKu900XfpYi1bvsSWHMtWwKEhsRPnOGNMKBBCgE4HOKRlBtrplN05PTADzylDz5RO53To7DO0sztlz7TddDoMuwfaMH3aB1oKdGiTkuy2kATSQBJj4vqaC8SJZcmxZMUX2UvWZZ0/1vctf2tpSVpLWpJtWL/n8RPHtqR1+97vfX9XzvDDZFaidKWDQzqZlufX0rSX7i0bERPiK7bbSzZTz5I2K2lb69p1b9kolwmaEQhRs0AhJuj2BS4EA5rgGDh2BBdjiZXqdqL/WaPCptIBILvhWAC4PH7Ayy+9t6xskP1eJGkvPUePyfW3lIU0rale8UEPtdVUSd2WuSpeGmBe5ID0XKy2rX2bXDNdbEJ0ISyQNfo3yWQS6RvuVgSDJg/8DG6TW1sVa6pyOFPGCdp0fjD90MtUB7PijE2Afb82a9jsKP/uTCVxpYNDmEl7iYvSnN/uLRvR0LqppHM+DPmNdA7EGut/W5FiQQekF3udtNjfQlJE05pqUxOijbJAFuTYcri1bic8revl/18a6ce0kCxnq6ucppF+tl6FTWVhgPTqcR+kOmAzJWWhO+pETPk6p9OBRCJZ9oRom8Mmp72o2V+xTMZsMzoYyVXE46w3hcjN2xUJ0cV0himWBdJqEKoyFB2HJgJwnDqalQUuBzOs9niApajvOnIOpQdA5kMaWNmwGmwlgnSxD09NXa3ivIyAYDHy3c3b8W5oWk57EWICrtrWKSf4rkb5m3F9RGlspVr65zO9lSgpjc4wZs0jpiyQymstFsiqIpoM7XbYcDGWQOjwAcXfXugfQmyZ7qf6OdVgog1A8cPRdQEg8yFr8hzUsrMyNv9L7dx+vzHQ5Xjtnn9/AkJMgIuTGAztT0cBcjmt0OHoQGY9cEoVVVaDISt1jSSQ2zU6w5hllAXSQepaLJCtBmGfBS22HDh2BLF4StHmvkTDzvU9t5Krgi2H48FMpywVAHIARGd7VxWWGhFycf+GFeUgzWaOFRqRNHrt2P5tWgvdqBQ2KuHdvB1vvReS014o+6NGW7yXoqFouY1NUGbBrdBqGdZiQsrUzjCFsECt8ZjZ8mcnD/ysrC4lHc+lDIBYCoSUHAAp+1tVjRBqqvhVAdJ5F00yrdm/TV0OR0HQqCTWA4TpZFoechQXJT8Ty/5Y+avFjkoNjBPFskfVfGB7CZKhl64Vj7bNmyHEpIRoIRgyxQ9IWSB9by0WyKa7iOEQzp25kLHB0t8BQOjwgQwWuFyEQTXHuRZSSVxR84GN0KMqANVsFchKTILWG/0rxlx2Tv4qh7mQNnRehcwKyQaE8ZQIN2+X015o0vO1O2/I8IHlA7lyAKEZVqpyOHo9U8yoTBcHjAwNmfoZOz6yU5bYQkxAZPRcVrCnwKfeYFmWWC4WqNPYzlQtQHHzgfMCIIOuHgC0DQlntN24Zdq7mp5dVV0T3L1lY1bwLTYyrAZCl53DVCyJPU88JS8oOuRILX/1mtns0AxQtV92pZyaMjs9U9Jgjp2MyjQ7IRqQGro2tG7CtTtvkFlgerAna0Q4MnpOEegQwyHwTX7wTX4FC8TgkZK5k/QQKfZvSDUIAGwkpKd0AMigayvZOdJqubBSbbW068oHgkakh9PpkFNkzPDJ8I1r8Nbx3yE4GpBZBU23kP1IvMsUEDP6VQrJSpOhc81OLtqlIaTQ1r5NTruJm0iKG1o35WWBGZHgeCrjfTyt68F5fTII9r/1zrKvE43ZIL5i3zMvADLoSj9sRWsYI40aCpWxdDcq15yQeErMOK9sn0uBr9CRmerrM3p6LIP90TQOaupuzOUyM+U0rQahpnc4UqFMZ02NGx2dnTL4mdmGKx8LrHO7FE0RaCCENa+nViGV5wZOYKTnuOks0Oj6UWV2tBJAL/hBMHI2chncaqqwyHWBz57swdmTPUW/bylB0O2wZTyg7OChXCBY9Gfzdjz70gsIjfTLck3N/goZ8L0SQZCqBdqsdHJhwbSaZvVGGU9JnWFq6mrltJvJ4VOmXZN8LFDdFOHcmQuoc7sUHWK0WODCqy/LAZHlMIfDRvOPKWu5EgCiLz6dKqUEVpfBrdgIsJHM/8kDP0P0uScRfe5JjPW/vewJ09lk7rSQxDv7XlH8jPW/ZWuMWqwv0GXn8NZ7IRx8/gWIfD3EeanTs5r9mdX9xRT2X8LgRSmM3kezOsMYYYEKdheJaGYZeD218F+zQ2aKwkQA7z37PVM3gwI3KjYX0FEMLuUFQGYY0uWy5PF4VkUZXK5ADZv17gqcXVH5gmzSaf/j/6CQv3yTH23t2xTgtpAWSwKEzz7+OOIRKfrMu3m5hGslyN+SqgYyHa6UCiQmpEwdlZkLZLVYIKvismUYTMTS8HpqUdnRrZDC537xk+VeL2wuYFFyVM9Z0DvopR++GoIL2QI1LjuXwRQvjfRjpOf4ijl2+nAN/+h/Zvj+NjsSsFVUZAU8+nOtHEH2K6eEcjtw+M0jUrcXj/R8dXR2ZrA/KrVWYjpUIW4aM6bDGUjoRWNlpZwQHRfN9QM2tG6SWWBHZ6eCBQJKP6AwEUAyHFSkvrC2pm2rQgqHDh8w7A80w1+eTKbRVrkI0pMUkNrzrQOA+rvvt5UCADkAcLZ3ucEMQ1qppqcbdDwlYuHVl2VaTx8A+jOzd/pCZXD/M/+OuYETmed468dR63LmBD89lgsI3w1NKwIf6qRnauvr16yo+29mM1Mj91Uv4KlfQzvD0EBIqST8bXfdoWCBI2/3ZSREsxst/b7JbUM4MoMmtw3+a3YoQDD63JOGUmPY3NlC1WM8JdLGqBAmAtTvV1QkWBcAQko4LLrspNQ2F1mqq7RfdqXm34z1vw1hIpDh8F1JzO/3P/kPGfzEcAhd/rX45rcewze/9RgevO4qzMRzt8PSC4RakeJEIok9//6EIu1FnfTMvn6lsD+at8eZ1KSjZ/B0Rj2wXnDUs8ATiaTcGUacl2qrSwHguVignnQ2r6cW4cgMvJ7ajO7L7+x7ZVmDIsS2EBlvvg+w/u776Zs28E3+KrIzrNhW+KwvI1u3mkTfMU3wW9O2tWi/ZjHXhAW/2IlDMvhVdnTjnocfRuMVTWhY5zX0nrl8g9ns7XeO4c3X35DZgjrpmZVY7PVSSz8jUtAMuxRXBpEKaYSRDxCynZOa3eg5X6fTgZiQUrgVzOwMo4cFsv3/xHBIsS5osGQilkaKr0Y4MoMNlzeisqNboZxOf/fRsoKgy85RckMv8vpS+wDBN/npyluxSdCU2ckPq4afcqz/bcwe2qv9cJvg1ywUQB0OG2LxlCR79/9Ufhh9jR78t799CA3rvLBNCXDOFtYINV+AhErh0xfDOPLb12WmAABtmzdn9V8ZlXylBMJEIml6JLUQn5/RcyxVZxg9LNDrqZX9ftn8f7RUjoJg21WdMgjyTX7DIFjspqiRCtMKALOH9qZLBoDCRICG/1ZNqw+tCHD0uScVhBFYGrlmBqs1+nqHwyY9NINH8Pu//0sFOHNeH770zW+hYZ23YOAzKounRk/pYn+AlMhLgacYwDDLR0e7ONPqCrP7VZYCvOMpUe4MExeXOsOUyhrbNylY4Nnzk3Kai4I953APhSMzWNO2FZUd3RAmApogqPdaFdpQWJUK8yFne1clWcucqQDI6OpWem1WahL04umBnFLmvWe/p76xQSzNO14Wf18snsKF57+Po//ydcWx+Ro9eOTz96LxiibYIzHTPpNKYi0wTCSS2P/SPrlDCZCZ9MyyFsp4m9bwaHA7inJsF8uiaMkay6AKZfS0Hrh7y8aSdoSh17yad2aMyjSL9an//9Hb71CwQPfgUXmzVYOeuoGC2qh8VoMgBo/A7bLnVEkmpdDRN2nkm/x1Ba/DnL9cSoKmqCe3wl9pPsDUhTNLtF0VAJl6+RkaVEgT0D8JYJLz+i4DkHZ4m23lOicqE0Z6jiP63JNInz+ncNz7Gj2476EHcOWO62GbEoCKipIcx0JaRKWNw0JaRK3LibeO/w49R49Ju9y8xP4mh09hz6uvZYBLvdeDlhY/aupqwTf75HkgW5sb4ebtmIpJsrqYcjy996LBLfnSnn3phaKvSeUtd0KYCKAiElIs2FI/F2aPyszLAvv6JAYwGkDtljj4Jj8WwiHNmcFqKcx+779mByKj52TXkzARwJt7vg/fjRew7n//U/k+mp0z3Fa5iHekVBgRUkusKwGE6u++32a0KiTXE8pFX3w6tfZrT9uizz1Jt1POqLSYPPAzxP0bUOruMaz/r2JjB9wuO0Z6jsMVOItLo+foTRXJjndeDIcUid2l9hO57JzM+t579nuy3KXgx3l9uHHLldjxkZ1oaN2EyUWb1OunhMYywSO/fR2cEIXLIw0JD44GEBzVXowhMYLQZEQGy/2QEqU7Ojtx21134Ko/uAZNa3hMxUo3r8Rl5+Dm7Xjl4GHsf2mf3KoLAJy3fqro9/+nv30UR277Q3z+b/7GlHNRbwis66B7y0YcUHWGoSzbDPbH/rx7y0ac9HrkKL978Cgc229CIEdmhLpXoJoJRlTrL3T4AOYiEVxxz/8Ft8ueUeVUbDfz+IZrAbwCYSKQ5pv8dpAijUIiwXm36OhzT1YxDNCQtHj35z+SI5r49IMlA0F1YvO6rVchFk+h6uxJNTjaOa8P1R1Xf4zxt9nMTOxmdzz6vdtlRyyewtivfoLQ4QMZD5qv0YNtt9wgy0vJ7xfHuMuFlni8pCBY63Li9MUw3nz9DYh8vSwBs+6KVbxyeBDTQODtk33oOXoMza1+3PfQA7jx2h2Ip8Si2WCG/9Flw6V4Go8/+QMcfP4FWdIJMQFV23egYmNHcZspeb+D+3+DkaEh+VwKWbz03On5q32mc0JCUdtNE6I/WgQA5mTMpG1+6KcvKFggZXNqiZviq3MCICBlUMx5m+XULb7Jj7mBEzj93UdRecudaOveLvnuTGSDDm8zMBGgN6PgBezIo7FFvsnfJEwEGmgKTKGy1BU4C9e27pLICTYBmvrzxvrfRhXxZbCAU91xdUbpj9lpPWrgO3tSkrtq4KOsj0qg7i0b0bDOi8lFG+AqX43tL/f8QAEi8rV083KlArWWliV/KZVrVB67OAkQQ5MRmUH95cNfRGNVBeaEhCkg2OB24K33QvjW335JZjH0uG2Xr0flLXcW9f6+G2/F1M9/KF8Pei77r7sGf/2Vr+BDvjpDbDDXOTudDnnzoZuKOC+UtKZZZoGNShbove3j8Ho6FX+rnkSYzezCHKo9HtRpSGLhuSfx+9O78KE/+XNNNlgo+ydpThSPthIXRjpblodhAKy/+34u+uLTECYCG/gmPy9MBES+yV9wDmApy+fYBGgapHEFzmI6FsfCQI8CcKo9HoSYCguzAyDUAUyBb+HVlxXHQO2qbZ2K2truLRtRt/0GTKpmcpeSBVLfHzvngwU+Fuyo1dQtVRC0Md/PTs9gfDyAaDgiA+HB/b/B7PQM/vorX0HTmuqiQJAyh69rsD7ezaP29k/A2XlN8ZuXfwPcD/0jbK++jPRgj3wuPUeP4YE/+zP8zVcfKYjZ6o2W01GZpTTKAoPP/FjewGLnJ7Hh8sasoJePCdLfqSUx3+RH7MQhnL5wBpW33Il1W6+SiUExfvSaKh5MeHAdAFx89H7DwJT17jF6mq6ClB7JvBzGlozRRWAX5jJKyao7rpZvFHX40gToQhkg9e1R0MPgEZw7c0FT6lK527Z5c8Zgo4bWTcj2SIwzbNBMMKSRX3FegJAH+PJZTV0t2upqFUDIE+D41298A1/5x6/JjVqNgmCD24F3Q9P41298Q/b1sZK3WNanZZW33InFy65E7MQhpM+fA++WhsCzvsFq3qkL1LOBn8vOYWr0FOLiUvoOOyqzED+gnkRqmQW2+mU/b/3gUeDyj5ty7Tyt6zFNJDEbJRaeexKJjqvh7LwGG7Z1F+UPVKXCXFGza7dn9tDeCJZa5hcHgEwEeCvdnIymwOht4mmm/w+QJl2dVknfyo5uVHs8mI5EIDIRr7h/g+HjoqBH/RpnT5Jgy0h/1jK7bMBH2V9q7Vpdn03BsFggTDfwePvg63j7ZJ8MJvnAj2V/+YBwZGgIocklEPy3b38bj/z93yGR0A/OTqcDDW4HXjl4GHueeEpRngfANNaXzSo2dqBiYwcWVGyQ+ga/9M1v4cNX+DBxSTAM6gtpEdWQ/H3ivKDwpZYqITobC6TDkxyRGTR5ahUskBKGfH5AtdW5XRmSmPoGMXACw31LQEiDg3qNymimKQKdEBep2bWbMzIrOBcDpG8i1+roTYFx2bmMRqOlCoCo/X/rtl6FCy8/kyF9Pa3rkQI0/X96pBcL4GdP9sAVOIu5SATJcFAB9FoBjmzAx0rfcpttSsD+l/bJjnfezecEv/HxAEB8fjQFJpdJFSRDMhM8uP832PGRnbjx2h15WRPNj5sTEvj6kz/E/md+DK5K6evz3Xhr2UYeVN5yJ1xtWxE6fEBmg8HRAP7+3ntzSuJ8sjeeEjX9fTQhulSBEDULjIYjcqssr6cTdmEOKb66JGwwGxBSaUxJRT5bt/UqnH71ZQ5Sapud4NSw0QFJ2Z5CbvbQ3rSzvcuJpT6AXE0VTzK9U4aBqRz+P/tlV8J99k38/tiRDOlLdzF1bz0tsGNvQDaw0wpo0J9xXh+6/GvlPLl8O3Eh3pBimGC6gccIYX8uTlpw9a3+rMAXDUcUMi00Kfn5Ojo7cwJh2+bNGBlaAsE9TzyFhtZN2LjWqymF6c+a1vAZgQ5qVPLGy7xhxP0bUP/pB7Hw6suYP35EIYl77v0MHvzsZ3VLfJp+NBNPYHZ6RrOBQzmau9IRmgf3/2apYWrrenhVLLBYU7NBdg1SIFxo8mNN21Y03vrJDIWltXEwKjPNN/ltANoA/NJoKkxWACQ62oulKhBdw9Ap+4syDUdLWT3CMrqKjR14Z9/LmtIXGhR+TdtWhYx2Bc5idl4AtxCTwU5v1xgxHJITiGlKSz4zIn1zAaFhEAzNyO2uAG32R4GPVoa4uKXhPRQIB/r6UO/1ZK0X5pt9aJmekSVdcDSAX+75gaYUZoGDBjooM5X9u7d+qugUFzPYoMPbjMXDe2VJvP+ZH2Ny+BTuefhhbG1uxJyQyAt+NP2ITXyu93oQDUfAVfEYGRrCx8pwPjs+slNR/siyQLPN07oeaF2PwLEjCjcUAFGYCKRDEwHbpZF+zuFtlllhNjCUByQtgekGleuucACs2bWbJur6ANQZ6QLD9ttjpXMpTN0AQR1xpdIXzOxTCmhiOIRLI/1yZ2ij7bHUWfPivBSNzFY+Zib7K4YNpht4PPvkszKziouSTM8GflR2xqt4XLVNYnx0wVA22NIyo8kEhWAIje2b0AHIvsZDh9/Ajo8ckaWwzNJ5J/qDk3j28cflQAcFWtuW7pIEOgo1Z+c1ECvdSBz4qXyNeo4ew/j4lxT5jzPxBCptnAL41DKUsmnqWpCj6EDRCdF6ZDAgMXl6zesungPQWdLrRytPyPpJcl6fg8hYqc/fRAAYOGFbaPIrwBCAIpWm2uPB3FI5bwdgfD6II0sAhNLIDr7JzzE0Uxf7Uwc/KjZ2lKSkSN0AVQ1+6kJvtf9PKz0lF9hRyUyTRJPHDyJIgE8gD5JeM4P9GQXCRI0TU+9N4OSrr8myy8Vl5vapwa/7umtw2113YHPndtjr7dhxaCf2PPGUvFgH+vqy9gwUgiHU1NXC1+iRmeD+l/bhw9uvl8vwAODwm0c0Ax0VN+4uaaCjUKvY2IGaqs8idPgABOIXZPMf7/urh+TUn2zGBkDU+Za00qYcMrix/TS4k1J5HA2G0D6AehKhizCR8/oWAfw/ALaL4dBuzuurYeRtBhhWezyI+zdgw7ZutQ94Xc2u3fzsob0CDESCHVlkpboJQtrhbbYVAkpaur0U/j+1qZs36pHiaqBzeJtR515KQaGO4RSkNvrzZLHSzilaMzOygV8pAx9aQJheXITdyePXr+xTgAy78LTA7yaSzGyvtyMVTSEVTclVEd/+6mPya2enZ7L6A1kp7OKAnqPH8Nbx3+GPPnYHTvSdxi/3/ED2Qy1XoKNYv6BWlPi+hx7Ah7dfL222Gk1s1X6+mrpaWQaL86UPhCiCIcwGNfnKi5i+cTeqPZ6SSWFSepfmvL4qAHOJ4d573I3NH1oEbgPwxwCuB+BWg+EcYOOb/Nxw3zG6VtmmzVcAGDISCc7mA6SOvi2MTzAvi4unRFwa6c+gu6WKALOMjg1AVHdcrQAu1hmLXbszmGA2oJOufGYROAC5qy7r8Dcqfe0XL5rOArP5B1Met8z+WPBj2Z8W8/vYfX+BRI0TiC4t4Mn5RWzddS06OjvlQMr4eECRGK3FAlkf1/6X9qFn8LQiqXm5Ax3F+AXVOYOUDd502x/iY/f9BbY2Nypk8Uw8gZGhIXBVvOZgdLkzzO13GJa0hQZDWF9g/eBRYOfucl3CzwDYE5sMvovJ4JMAnnS2d20A8IcAdgPYAWYkhzARSGMikIYEhjaCVy4CgkNGIsGaAMg0F6QpMFy1x5MzApxN/pbS7JddKTtBa3btXgK5HFbndiHl2ap8H9Uup2fXq/d6EIwtneubr7+Ba3fekDfqS6VvqcFPzQYbkc5gf2rpqyV7GysrYcvSj7CxfRPEo8cUOWxZ/T4qFjjQ1wdBldS8GlhfbknM49JIPxYGMtngtltuxj13fULuo3juYljh76P3oqXFL8tfI51hiukkPTV6ShEModbktiEslOZ6ET8gVZXb3Y3N62OTwfeILzCZGO49C+AsgP/P3djsX/T4bgZwB4BdkHoT2CgY8k3+JHnddgC/NRIJ1pK1dBDSGoKoMt3PZ2xPPpZdlWqE5of+5M/hu/FWVHdcLdUiuvXVz9qFOcVXIebYfhOqtu9QgMbI0JBu6VsO8JOBqiKNqbGwzP7iogTgNXW1GfW89HyonE95sgewPnr7HYpuxrlKuFgWKC8CFeur//SDqxL82DVSecudqNm1G4sen6KeeP8zP8aXH/orPPnDH6LOV4+p0VOKumvWfeDilga05wO2qdFTRbfRb2jdpGjIAACxLdeV9FqRoesc8ShVxkXcDiDtbO8Sif/O5mzvcgCwxSaDgcRw748Tw72fhlSY8TEA3wNwBoBNmAhUUOAkmCMWDIA1u3az/j8f2wQhVwpMPCUqmh/IvjjCHEvGAoU51LldpXTUZrU1bVsVIBgcDeAk6Z+X7UEDkb7lNsr+6AJr27wZs9MzaGnxK9gfIA1Boj3+slkqmkJTXV2G8z4vC1Sl2yx6fGj4k8+uqChvsebsvAa+G29F1fYd8vVmgfCxf/6OAnDYa8gCITsqUwvkzJofotUJfMPljfJckFIa47q6EwASw71UYqYTw720azvnbO+yA7AlhnunEsO9exPDvZ+DFK6+C8BvhYnAj4SJwB5AMcvcuARm9PM6vslvpxHgXH482ntPS/7qyR0s1CYP/Az2ZXzQ7cIc1rRtlZI7mQqBluFTioDITGs77t6yoazSV/GAq9ifOu1FAVJuXpbxTXV1QI52/OkGHm2bN+PQ4Tfy+gG1fIFUCq1m1peTDfo3wNW2FZdG+hVBErayRcv/xwZCymHqnFDH9pswEUuXfG2pZPAOZ3vXBiJ9qV9PxkkGGDnCDpEY7l0A8HPypcDVghkgo5+3qd8s65T7eCrrXN1STZCbPPCzZWF9WiDov2aHojNJz9FjEIIhdG/ZiO4tG/HHN123bODXWJHOYH9aaS8ySMWkdkx688/4Zp+hhapmgenBHl3znFe7LHbe+il58Dqb46i+Hyz7A5C1Rb4Z7K+hdRN6Bk/LPkchJsC2pRteT23Raysyeg6BY0dyttZXy2BIAQ8427tySUYRQIoAIkekLwVGU2eC0G1ZzOXHc9m5jIRkFuFLYWP9b68I8JPlIF+NihuVETPqD6zbfoMsecsNfmr2R9lFtnQVCuA7PrJTYn86rHvLRkOzeCkLZE2dOfB+M1fgLCo2dsB3462wbenOADn19aCAyFXxso/W7ITohtZNmBo9hYPPvyCXQza3+uFpXW+K9KVVVAsDPXnnizBFCJ9QyeC8CpqAJ837M8y0MgBw9tDeFEFgmtfB5fPjaQU/AClKa3YAZKz/bbnT80ox2hBS7Q/c88RTmD7+hsz+2K/lYH/s4tKSvoCUzN3QugmJGifSi4u5fV1iQmYxgLEuJqzfq5yZA8vFAl2Bs4j7N2BN21aZCaqvgwI0NQIh6n+L9fux0heQAnteT62p5855fVgY6MF0LJ5VBhMcEgF82NnetZV8b0SBFywx1ahGkbQaUlIhkKdlfDwlLrW9Vx0MbZ5gpq008FP7A3OBoOLvywCCudgfG7FVt8GfGj0FeySGlMeNdAMv5QGabCwQV0RC71sZ7AqcVZzb7LygGLqUr+ksvTeNlZWmHtf+l5Y2RtpXkVZ/mOXfY21u4IQmCDIyOA3ACeBuIoPLcn8U6MREgDcA8Obbmd0uOyYP/EyhBsE4L80OgKg+a8WCYHOrPwME//PgUU0QLAUQ2i9eRCXv0M3+WBb49sk+fPurj+HLD/0VfviP/4yRg69jaiws+esaeAUgJjinQsoZMbXsy1XVs5rBL8NdQjIlaHedbO4Ilhn2DJ5GyuOWZasZ4Edrf6n0XdO2tWRRX9opKRsI8k1+iOEQxZ5POtu7XInh3nQ57pFDAxDTADbwTX4HGwFWA5nLziEWT6n9N5dAMrZpBYhZAZCVEvTQA4LYfhOacVBOOg5NRhD95tdRO/oJ3PLZe0vOAFNr12Lx/Hhe3x/1L6nb4QNSLWpw9DdyhJe2vqJT6wCgocaZs55Vjwymsnlu4ATqV2DNr1ngF/dvQKLvmKKCKN/1yhYIKQQI6WvYemu6STu232RKU448ICiK4RA3N3ACUFVqkRJVKoM7IJXBHXS2d9kN+AOLB0AmgbBTLWfVQOZw2DD2q5+w/ptpAOcBeCAFTkxz/q0W8FPc8J27UbW2X+4dB0Bum3TbXXfICdGUBZoVILFfvIiKy1uwj6n6yMXQWlr8ci4gNXauB7W3T/ZBnBfkmt1sCc1GZTAFQCqDV2NKjB757gqcRXTgBERyL2ij3FzXJjQZkQMhU2NhKTBlMvg13n63qdJXBWqsW4zLBoJ1bhfmpDp82tz0vwB4LTHcW3YGCBUASk1GNYaYMOyPDht/A0ATPeFqj4czowPMWP/bqFpl4MfKYUBK9WBTZGj3lI/d9xcy8JkVKdZif/lsfDyg6PI8Oz2DATI8W17AKkBUN0mNizA8S0RLBjtXOAAW4quk7K8iEgI4Y9eKBkIAqZsPpo0D369f2ac5SKpU4MeCGun7lwbwNoDtnNeXJiDIsSDIN/mxMNBjIw1J7nS2d/1dYrg3DIMzPooBQC764tMpZ3tXJaTuqkCWQehM4rNIDjAO4FcAvk5fZ8ZOvhIjvoWAoJ00gaTJ0gAUNaIfvf0OBfCx8tgoINqd9oya32KNtvlS5wyy84F9jR5dM0NyyeBkOAjn+wj4crG/fNeqpq5Wvr5CTJB6A67z5pTAbKoMBb6Tr76m8ANTnx+N+Jah2iNFWN1zBCMe5by+pBgOOVgm6PA2szmBXkgdYb5PZHCyLABIkLYZwBW0BE4NZNT3RxKf06Ra5D8BzBD/X4pv8tuL9f+5z76JqrNDq94XROcr+K/ZgUiTX8EGg6MBBJ/5MU6++hq23XKzXH5WCBjKMjoQxMHnX8gLfpT1qdlfrgXZphFBLgT0spkwEUDl+wj4qM3OCxDDIbmrth72p66r7hk8jSt3XC+nVGkBIf2+Z/C0AvhYH2/V9h3wXdWJiVhaBr9S9/wj/34oMdz7eWd711oAn9MCwTlAFMMhkfP6RAD/B4AflM0HSOcAA7iKb/K7sgVAVL4/jrDAbwP4HB1/Z0YL/Av9qx/8WBAEILPB5PGDS6VgDBAeJL61bGCoRyo/+/jjGVIn3+JSg5geMDTLVqof0Ky0nLh/A1KkSipf5JcanajHMmw2EJJauxYgTRBorbAQDMkjSVnGR1kf7+ZRceNuuca3HCWkbOdnSL39uMRw74PO9q5FAH/NeX0pADYqh6s7rubmBk44CGhe72zvuiox3NtDGGSqpADIGO0kmtEEVRX5pdT2FwAGAHyMgmK1x1PU8OPlrvEtNRvkdu5GRSSC+sGjCiAEIIPhgSoevkapX19j+yZdgDh9/A3FmEu9LDCfNC2lrRQ/YKnyEBdPD8h1wLQLj1GjgZDJRZvc2QcAjvz2dcUcZnU+J31tZUc3PGTYkZbkLVOAMQlAdLZ3ORPDvV9wtnelATxMcISbGzhh45v8AwCqAKwn2PJ/Aughdb+lZYBMBwXaBycDyNTsD1IA5BEAO4luTwOwrb/ysoLz/1Zb0IM2T9X7ENG/q/Z4gJ270SjMyYyQfYBdnJSKEpqMACf7cJCDPICIpqKk1q5VBFH2PPFUxpDzXCCmR/qWw8rpByx3wnXqwhnFYCkjjXNZi4YjsF+8iDOjp7D/pX05QY9uqLYtS8AHoCzdXdQuDUYGTwJy2Zs9Mdz7RWd7l0DwIw1AXBjoWct5fbPMW9zt8Db/v4nh3ksoUTCEAqANUi8uP5aaICgqQCgQkiFCKeL7ez4x3DvobO/6Kt/kF6lsjm24FijQ/7eagh4pvlpO4NXbi1Dtc6GMsFGYw3QsDjdhheyDzebmhSbfwKHDb2Sww/0v7UNopB+8pxlCTEDj7XdLYwhzBENWAvhRIKaST5gIYI0JMnilVJakB3sUPRiLMTomNJfZLl8PvsmvAD4KfiX29WWsCxIBtgHgxHDod2SDSwNI1+zabZs9tPcrzvauGQCPAQDn9TVCGnBOa3ybOa/vjxEO/kepgiEOxv/HAbiBb/LXCRMBOZCRTKblet73nv0eRXNOmAjMA3jE2d7lBfBHwkSAA2Bf07a1YPm7mqRviq+Wu/8CQJLIDKPMkf1/NV8N7NyNBsIUI6PnUHfxnAIQ2QakockIxKPHcKCKl6bSEfBrbvXD66lFZDS77GwzAH752lyZwsyIv6siEpLKxQiI5QPClVxCd2mkX2Z/FOgN+xDFpX+zgZ8W28u16Zba5iIRad4v6eUH4D0AtF42DUAkUyftieHe/+5s7xoD8BSkjjAJQBYBIoDPAviPUgVDWB+gCIB2pZQ7wMRTopz2Qk+KsL8nEsO97zrbuz4PoI76BBtv/WRB8nc1SV81+AHShLlpMrXKjActxVej7apOAJ1wRGYwHYsjGQ7KlQQsQ6QjOanfj9OY5VAOf55ZfsDUhTMAmf/LAhwLhquhdliYCMjgV2iaEPUd0nss+xY9Pk2mx7I91u1iL+D5y+XCoUafS1byiuGQCGniWxJABYDvJMPBOSiDGZTl2RPDvT92tne9B+AZSGM4aIcXQAqGdCaGe/uQ2SfQFACk+X+NfJP/o/Q8lzrApBVpLwDswkTgLIBv1Oza7RAmAn9O36y64+qCx1+uFumrBX6FGA2I5LKJmHSvmzy18HoAXN4IXNWJcGQmgx1SQLRt6UaTW4pdlXIgfSn8gKwMrlxlbE+LBbGzpo2wv2ybVb3XA99tH8/7+gwW6K7N+XxpbdjUtaMeIKbuD0DAjgJaGlLFh50AWAWA30JqX58NvCgIHnG2d10P4DuQKkFA2GAFgKsA9DnbuzizgyGOml277bOH9ib5Jv/tkBogpPkmv63x1k/Kf/Tes9+jSc/0ZL+YGO6dhjSgpJv83O7svCbn4KSsfos3XlxVPj8G/ERmp5IeFo9H93vpNfqgAtKgGq+nFl6PxA65WFqWywDk6hPql2Td3rlGV64UP+BqBDtNAJTUkmH2p05RohsDBUZ25NbI233ai5rZ+NQApsVSNUxkwRvKXnvsM88RHx/Iz+j3iwBOAfilGA79SzIcXETuIAYFwTCAzzjbu/YD+G+QosEBAEcBIDHca34QpPKWO9NEj39GLX8BYOxXz9ObmSINEp5ODPf+gvztX/JNfpswEUjyTX6HVtOEnPTezsFx6igulDk6VQxrYx5s+iAskl3KVPanixm6bRLbc1NANN/iYvmub4YfcGPHqgTCYthfvmt+8pVXZAAinyEyvrZ8Jub5GccCGZ2Tnee9UwAmCFAdF8OhNzmv7y0A7zJBCz0RXCp7OSKJ9wO4CUAvaZPPmS1/AcBx8dH7RWd71xbyYdI0ps5rUMc78PZbbyG6FPV1CBOBQQBfgjSkZD2APybMsKDgRzwlYuzMhVUT+AgcO0IfOlr//D8hTahaB4MNIIoBQSpx9ZhZ5XDL6QdczexPT+KzXmYcFwFIbaNSzAZsJ5LTVBPDoUUxHIoBmIdU5XURQAhAFECY8/rOALgAYArAe0QREiekzDrtZK3o3UYp06Rs8AUDAFqwD1Dkm/z3AnCyTC7W9zqiz30fkIIeNmEiMAvgzxPDvZSu3cs3+atpxNho8IOyv6lVEPigfj8CfjQB/EcA/hHAvaX0AxYCeqWQp8vhB1zzPmB/tI660OuhwZIWOa+vkgGqS2I4NAhpMLibqBEHAxpJ4ktbYL7iBNhmCYCFIeXpyT9zcQgvenwRonCExHCvsj24trS2q4Cs0MhtipAsG5G9JesN6KjZtbsRwKfJATvWtG2NAqh7Z98rNgKOImE79yWGe9+uv/t++9zAiRpm4XPZOsa8H9ifKuhB2/UMAngAUs4kX8zupHZAZwNEVvbqNa+nFpOAIhVjJRvLdtiuyR8k9qc1DN3FAQIgivOCjavi/0YMh+wAfER2/ioZDo4CgLO9ywXAKYZDDiJhRQApMRxKEj+cbiBJAsCkAuToNDZO5Y8TTQA8TTZY6jpgygD/FADd4qNzkcjTl7776MPCRAAE/OzCROALieHeF5ztXa7oi0/Hne1d/4Vv8q8TJgIpAPaKjR0y+1PPAFG3xE8m03A4bIjFUzIDWu5ef1qgQ4+JCXpQyREFcE8yHBQc3uaN5M/TAOx1bheQ41xysT0W2CZiaTS5bYrgR6FAuOjxAbFz8uJqW6FBELUfkF77ao9n9YCfiv0Vm/jMuga4Kl4EYBPnhZHUfPRV1Z/ZIM3RjRN2l42lsZPT5CtNQS0LsLHyNFWOHn3lNAf5SgGw803+xNzAiQcAOPkmfxKAQ5gI/NfEcO+/khq+RWd7Vw2AL1JAqO64Gm3d2+WE6YzGqaeOYGQhM0bgCpzFXCyOOp0AxVZOaDGnQkxuz83kMlFjcprozaeO5vuS4eBJ8r3c/5Dz+nICnF2Y08yhWlo8Sz+vc7sQFkjSFF9dlPxt4hIIFvC65cgbVLOlZDiIeOc1qyYQomZ/hZa95fCPgaviq52XdznS58/ZU/NROoLCSBAkQ62830DNKADuBfB5SHNA1pJhJiIBv0cTw73/VH/3/fZkOCiS3eGv+Cb/hyj7A4Df/+Q/wC3EFCBCACSnNBTDIcySG8dEnAwbHcBiZLoYA2yKByzLz+i1ejQZDv4nmVkQh5SfJO+m6vGOWsfDMISs14YUQ3L0moTIOdL0hjq3SwGMEyQVRhNYReeqkL+r3Q9olu+P3Xiy+F4rmehqMsuzapkBAPwigFZIjlIblrK1v5wY7v0f9XffbyeNEkSS+PwZYSKQpP4EVVoIS7Nt0D+oWKTZ4zpuZsZ7LoRDeXdODRmgHqSc71jfgpSkaWMewCvItRLFcEhcWEoKzQaohq6NGA7Ju/uCFP3jAHBzDDDmAHXF/ZDANGH5AUtgs/MCYiZEfmenZ/SkHd0L4EUo5+FaVgQAXg5lSdybwkTgK4nh3tdY8APAkZnBp/kmfwfxEWa8oYr10AgUpeoiAwB2zutziOGQEwVOdTfJaERsBlI0LAyp8fgUgCAkR/MkgDeS4eCM6jjPYal7DgyeQ4pcmySkSBt1+FZAiujx5DrZNIAxlWNzsGU7lgnRKbf6tvyAxQFeTRUv/5u6cMa0yG8Oo/d1h7ux2RubDIaWcc28rwDwSwDGyAXe6/A2/ypxaG+KgJ96oYl8k/9zwkTg9wA6hYlAFQGQKIBxAhRRLOUMTTOLW1QBoA1S0XMNgDXkqwZSPzAX+V0F+X8l8zMH82XTYFM0GkUBRsBSeD9GvijYXSTHKwCYT4aDszrYJ8usHoGUenA9+VkMwJwKUCfI58ySn0XJz6cgpSQkyRfd0R3kvJsAXAkpx/B/gzSo/jJI3TJyBc8T5P3j5FjrADSI4RB8jfqAhK1GcJV5iVHmRJuHGqmuKSXYsf9XgyBbFllozW+uTYCtBsFSDiosBmgCAM4e2jsC4HPsD9d+7WnbxUfvT2lJydlDe0MA/uF9fE1sGtJYhDKhUwQAkn5wp8Pb7COvmyVF32Y8lOeI7F66Wd7mJuKu6ASwlnFXJMhmM0o2syCABOf1LabPn/skgB9xVXw6Go7YVsMNYBe8MBEAmPK+cgCenp9Ri504lCHhCzU2BYYdY6oqE1wUYkLC8vuZxwBtNbt2g1YxRF98On3x0ftz5Qtx9Xffb4u++LTM6JztXRzf5OeYhSomw0Ha8kaPyaF59UR4EqHKV8Kjx1/IMZ1lxRx+OiNJlxwBwlC289GQ9/mCLZyGzzANIJ0MBycIozym69jCQdFeVR9k33cl1wNn8wOqWdhKsJoqXhH4EOelNmQlvLZUPcW4Kj6OeQu8zALAtAGgAgBRJY3FxHCvaaH0UobkS/De6sBPLmA1+p5GfXzq/C3afWMaQNrFyYOnV4XfiJWA3EIMKAEA5mJ2el7LBj64Kr5kFTPj4wGI83Iy+3QyHLTgz0S5Z5k5QJhGljwrkz+H+jeTqi/6c/Y4RACTvJufB8rb2KAodsX4AYWYkLejSbnBjwY+0ufPyezPDN9fnhQYevei5H5b/j8LAC3LxyS5Kj4aFxEz+mIWLJdDMtMqCq6KN5TfqQf4igU/Wh3E0U7c7uLZn84UGAqA1tq1ANAyvcrfxckeo1XDGCiguLglPyDL3CiQGQG0YoCPfQ+24oMF61LIfw2LWY+0BYCW6TRSBC/ntWgV269Uo0AQF4kfUMXE1Okp+b6KluYa0re51S8PmC/G8r2eqeaZsZ5qCwAt0yeBae+4cCEMcDl9hqwfUJzP7gcsV3Q4m/QtxabCpsAAGXXZNOPASoK2ANAyPfc3LkozWbHKnObZ/IAso6MpMqUGwnJIX83Pnc4gfGPWY20BoGX6jCNScspMOVYu0/IDZqvKMEPi5rLYiUOa0tcskDPQfefiatzMLAC0bNmskChwOVlOLsvlByyX0VrfXNK3WDBk3Q3q9yK/o2t11nqiLQC0zBiIUAbIreT5wGrT6wcsKYVeiMm1viJhmaXcFLJEgKk/V8CSD9BigBYAWpbHRAIgE2rJlfeFJZaURhko7+aRHuzBXCRS1rK4uYETEOcF+Xo0t5pf7aF2OdTU1SruEXMvLlkAaAGgZcaNAqChyOFKAEFWDsZFYPHw3rKBIE15oSko5Ziwp2aXBBwp2E1zXp+VB2gBoGUGZdWlQgBwpchgX6MHQkyAi5NAcPbQXoSkca0lA8LUhTMZKS+lkr5GAiCkGa9VBmeSOaxL8IGwOAHCVZk7Rmdr0A4xLg4Qzp9DIhLC3I27gUq3qZ9XTr+f2h2RJZhCewCeY4hLynqsLQZoWR4VS6TjHCQHOuKiPuaw0uaItG3ejKu2dUrgF5MYGWWD6p58xYIf7Y5USr8fC3wGEs6Dq5XJWwBo2bIBoIvDNKRO1avaaupqce3OG9Dc6pdBw8UB6fPnkDjwU6QunCn6M2iycynBjzU2AKKOANP8QK6Kp/mcYeuRtgDQMuM2DZI/Js4Lq953pGaDXJXEBuePHymKDbLJzoCxoIdZHXPUEWCVvctubJZZAGiZDgYYmwwugEmgzVfpsRpyBVk2yMr29PlzmNtvnA1S8Csk6GFWRQj7eWwOJADOxQH1Xk/QeqQtALTMmHFkIb0vuwizbJDpmiyzQT3VI+oOL6WM+FJpy0pcVnJn2cRscRFxABGLAVoAaFkB5uJkBiiqF6LW4lxNlosNzh7am5UNcgsxxE4cUkx1UzOxUoGfWjJrtdQnrfDp/QqFJiMXLAA016w0mA8GAxQZ9vC+tbbNm9HSMoOBvj7ZN0jZoG0igOqOqyGSlBma56dmXqUOeqjNQAQ4TGaBWDmAFgBaZlQCUwDkqniRZU75rFSDfkrNBkeGhuS8QZkNhkPgvD4AUFR4lAr8jLBpGgFm5THL9lwcwmS4tgWAlgS2rAAAnDRrsa4WNkh9gxQEKfCxwY7lBD867S2bEf+gSGT5OdX9tMwCQMsMWCwfc8pAzhWWDF0IG+zo7FQwLN7NKyK9vJsvGvxo6gr7ZdRy+R3JsY+LAGp27bYA0AJAywowGgXmouHI+47xZWNhA319ACRfG60lZiO9xQY8inURsEw01ybU0uK/ZD3CFgBaZtzkTiIsE2JBQgsMaVrJapbI4+MBuYkCAPn75lb/sjd61dMFmgRI7ORcTgDA7KG9lv/PAkDLCjC5KWq2Bfl+MzXAlDq/zywmyTBB2gg1CSCg2tAsswDQMgMMcKrYe16of2u5GFZchFwm52v0lK2ji16jKTBU5rLvo8oBnNh2y83TFgBaAGhZgRYXcQlLLZR0LyKtsrlcQFhsMMBM+SvOC/mGjK8Iy3GM9D69u+/f/+0SWa8WAJpoVh7gBwgDASwCqDSbybCv19sUQP1ZZjUTYI2yv1KBYEuLX9dxa53ryNCQonQvz30Yz+W+sMwCQMvys4xEPgCkVu/16GqIwC7UmrpaOR2k0GYLrESlPrFCgDGjxrZErezHxwNogb4xovR46r0egPw9BT8taU7aYFG2N2gBoAWAlhVmdBEJABYA1NHF26YBLjV1tcB4wEiJlgL4ouEIhJiQlZHlMlq5Ic4LCE1GQDqgGGJaNXW1GCfH7+JIF1gTjQIZPcfQZERmctmSmtnzDo4qwS/P3BUKeKetx9gCQMuK0b8iFlyc1BRViAkivLnZhN6BSBT82Ppb3s1rgqDe96TgEBclgAmOBtDc6pdb4+c6FtayAXGhwKd+P3qc+YBdfd56EszZWcBxUe4Ebfn/LAC0rBBLhoOCq7HZ0FDtfAuVBb+4CLlNvRATYLt8veZr+KbsicPChMSOKiIhRcJyvIpHcDQgM8Fcvkat/Lpio7+UtWW9TqS+ONeOQs9bmAhADIcU1zhLMjVNgZnH0iwQCwAtALSsAAnMQRqsM1PIQsoVHKHJxpT12S5fjxqm64oRc192pfx9xUIMyXAQ6cEeqYKjilfIdq1jYuWvWSM9tcCPd/NY9PhQ3XG1dDENnGu1t1meOQJoB2hoCgzv5rm4iElYs4AtALSsKKNTxAw1RXVxkvTTYiiUiUXDEbl1vO3y9XBfvQvVVTxmiwQgsdINOwHE+eNHwFXxoCV8edrGmyp7FRfx8vUyk+PzAB/biFX9d2xJXn3+OuRQMhyMW49w6RaGZR8cWzDzzcZVwRLKiGZNHKju8DaDd/MyaGSLuLKAbBb4sT4/FvyoVM8HfmKlOzdI5nYxpMm/pwnzs1sM0AJAy4qzmF5pm8so2NBIrRATYNvSjWqP+ZUWYqUbix6f7r83K++PBT+uis/pu2SBT08LfnbT0GLXKhCnaGulwFgS2LIi7ZIO5qGb/VHj3Tzsl11pKvPTAqR8x60nH0+Pqf1+NMihZqaiSurmksEUzJPhoJw2kwuo6ShMAKPWY2sxQMvMMVoPLBYqFbOxv1Iay76ytfJi5W+8CKGYy++ndTwlNI6cxzC9Z9bjawGgZQUuJvJvGNCWiGxaSUuLPyfb0mJ/y2nsCEnSxivOyn29YJ/L76eH4elisoz/UCs9h/hVRQA2F4cUljp5WwBoSWDLzJDAFBBps9B6rwctOt+AMi3K/qq27yjLgecbUk5SR9Jw8zYAAwQwuiEFE/Ju9Grwy+b3EyYCpjBANk2HVtBQqc+7eZEwwIg4L1y0HlsLAC0zxxRRYMqYouGIolaVApwWyxoZGpJfVy725/A2YzGLFGdBmamd3QfgDwgA5mVOmlUexO9XLOCJlW5wCzH534pICHHCrul1p3mUGkAfSs1HKQNMW4+vBYCWFbgOyb8x1vXha/TIDn+68LTk4kBfnyzXloP9ZWOiLBASUKZM7z8JABqWvVwVD87rA9/kzwl+FNDy+h40/kbLBUGPgdwHuQ8g+d5mAaAFgJaZK4HF+x56gOsZPI2Tr76myYJYNhINRxQpJsvt+2MHEREpT6Xuu6n56Dvuxmaeno8QExCM6Y8Qy8nOWcCPRoCNWjIclNkeW61C65x3fGQn9r+0Dz1Hj4kk9/FMknFZWGYBoGXFMcAopL6ALgoOj3z5C7jwZ/dgYnoaU6On0DN4GpPDpzQ7u1BApCVvzmU8Ibb7DAFmCoCHoNPvp3mh5gUsDPSgsqM7JzjqDYBQppi6cEZilO6lDtXbbrkZ3Vs2oq19G+CTXAx7nniKffm7sADQAkDLTAXAeQAu+ovR2RnYADRe0YSNa71ou2mn9IvQDCYXFhSgyDY9QCQk+7bKbepJb4SV0s4pL5M/S2Rjs9mMgr04LyA92JOR3mPEH8gCX3qwR+HnE+cFtG3ejEe+/AVMh6KYiSeQSKQwNRYG66IgEpi9f5ZZAGhZEbZAvuqx1CRBWnFTAmYA2OISbtTWuLGmxg0QUGytqcX/+uU+fOPRx+Q3Wzy8FxU37i4ZCOYDWKbZKWV85wG8Sn4dZ8Hv2p035P28N19/A6xs5hkQzFf+xgIfAJnxpc+fk+cP0/fmqnjs+MhOGfwAwO60y64G3i0nQZ+1ALC0ZuUBfoAsLiIJJhLcM5i9z+ZMPCF/2aYEXBi9iLabduLWT31CIYsXD+8tKB/OiCXDwQymJsQEdqA5DRC8kgwHZzkA9V6P4QYC1+68QcEUhZgkh/UwPxb4YicOIT3YI4MfPd7u665B93XX4CtfewRtN+2UwY/a1OgpqVejtDEtxEUErKfWYoCWmQckcVdj86WCd8spAfc8eB+EYAgH9/9GBovFw3th29Jd8qAIBb1tfyr5zgDg2199jJW/LzB/vljIZ3R0dsrNXWWWGQ4pOkuzrJSCP5W6AFBBf1fFy8d830MPYHPndiRqnPAsAjNTmWWDZEOiABh1cZhJWgzQAkDLija2JyB1NIlCMFQQCP7lw18EAAUIpgclpuS+epcp0pcCDbcQk4EFkKpUHvzsZ1Hnq8dj//wdCDEhzUvJz2fFeeEIAJsonWeykM+uqauVQTAeCULk6yHOCxDPn5MADVIrLFYWV0RCCh8fBc/mVj+23XIz7rnrE1hT48ZMPAHnbAIz+e8VAIzFJoPT5L5ZAGgBoGUmuDtSAC4W61dK1Djx2X/4MvhmH/Y/82O5sD99/hxikNpiFeIXZIFPzapYi1QAl06P4eSrr1H5awOwLzUfXSAEbLFQAKQgeO3OGzAyNKRojECBMB0JKZgesBRkiYtLwPfR2+/AxrVe2ZWQl+EqN6Rxcm52LI0ztawEi8KyD4ZRx7pMQGanZ5BKGF9bzlmJydzz4H34+29+Db5Gj8yAKiIhLB7ei9SFMwUBn1jplv1o88ePKOQv7+Zx21134EMN9RgZPongaAC8m7eTP/k5IOXoESu6i/K2W27GTbf9oexr5ISo/Dva+p9+sSB530MP4JEvfwFNdXW6gA8AUomUuslDyHpkLQZomfl2iQVE52yi4DeyTQlou2knvtS6Cc8+/jh6jh5TSGKaSpLPN6iOnFZEQhK7YiKn3dddg3sefhgt6xswOjtD/WWU/Z0RYsJbAMB5fSKkoMk5NgBRqPHNPmxr9qEtGFLkHro4oJ4kMPPNPhz46QtyeWBD6ya8OxU1lCfpnE3QJhMUsE+rNi7LLAC0zASTmcX4eAAT09NoqqsrCgQb1nnx0Lf/CT99+oc4+PwLCn8Y9Q3yTX6pgkJDGmcAH5ZaxtMAwoe3Xy/R12gCNqSo/KVg8Ssif+2J4d40AETDkXME+OyU7RYzfJ1v9mHHR3Zic+d2TExPAwAaKyvRunEd/tcv92E/ScmhJYNGNxb6ngzgWX0ALQC0zESTnevEZ2Uas6CL/Z4H78NHb79DZoPkc1ARCSEdCWERwKLHp0gpUQOfOoDwmT+7B7Uupywla11OvHX8d1T+UhfOy+rzFGLCeUjJ0E6och6LsXQDj4YaidvZZhMsG5WO3QvDG0qixglMyzmA9JymipXwllkAaFmm0SgwxzY+SC8uwlZRUdQbs2zwzJHfYc8TT2U0W6iIhDBP8uMAZAW+e+76hFQeNiUo/GiX3Ha1/D0rxISj9DSYw5mG1PxhjVkXrqF1E1KJVE5219LiR6LGaYgB2p12OQeQbExCXMQFCwAtALTMfAY4x4CHODV6imvYcT3skUVTPoQu/LabduKbndsx1Hcc+1/aJ+fW0aoI5AG+VCIFp0aunG1KUEd/ZfkLKVrKEcBdEGLCgpkAmE3aFpJOxG48S4k1skVdHCasHEALAC0z3yKQIsFr1MEBaTGqAKdAVmgj4NV2005cueN6TI2F8etX9uHg80u5yvVeD9p2bpZ9a+kGXnrdlKCZnpBu4DFy8HWEJiNs9PcXWp8vxAS26sUUCdxYWZnxs0Ki6FqmToJe9PgWMBm0ntYSm5UG8wFjgEJMmATjX6L+q8mFhawMhf0qBAidswk0XtGEe+76hBwkEGJSusjXvvPf5QYMtilBF1CI80KaAMV7cRG/05C/SM1HF4kMBlD8wKTuLRuLdhFks1QiRVkkZXvjieHeJKwkaAsALTMXAFPzUYEFhkIkWyGAmEqkMDJ8Um64SmXwu1NRIKRvPKdK/gLA/mQ4OA/lzFzKolIwOZCQqHEauk7Zfpbj+tHjPG+tT0sCW2a+UUZRVDlctoWejSGlFxdhdy6VifEkXaShdZPkU9PBrBI1Tpw58ju1/P15jo3d9IFCav+fdO5Ozb9L5wFB9d+rkqAjzP2yzAJAy0xk/CmGYYiz0zNFJUPrBcNUIpXRfUbLp5YLQGX5K6WKjMZFaEV/WeC4ZPYFLMQNkPOGVFRgYnoa4+MBNjXJqgKxANCyEjFAAHKKBQBg3OWCHZl+QL0ApRcoKNsUYgLadm5GyuMGIrG8vjVbRQXSoRl18vOBZDg4h9y1srNmXbiG1k1Zf8c3+8y+T++ZyVwty80ILPvgWQSQkqHHxwOwX9SevDi5sKD4KsbskRhmp2eWpp/pAA3qJ0vUOGX/IcOSXtbxsfTEOKOD4EsAaprXlxo5ProerfCvxQAtK4FRRhFQMUKk1q7NCoRaC9YIS2RlnhHpbKuokH/XM3iabX01Fhfxehb5y57nWCnl7+TCAhrA9AZkhslPLizI1ybf5jE1eooeMwepemXOYoAWAFpWOgB8j3xvi4YjmBo9hbq1a4tmMbnAcGr0lCICTBua6pHO9kiMlb8igN8mw8FZ5G8VNaEG+kKtsbJSBjU1oGULJBlhzUz9dJRhrpZZAGhZCSwKKUm4CibWyWZb8A0eiSWxYzVpBDjfsFtbRQWG+o6z8peDlPzM6ThuyqRsQkwouCGCnAOYxxXgKvAqqpKgw7HJYNhigOUxywf4wWSAl0D8gEJMEHPNBjHLSAQXAORk6HwR1cmFBSRqnFT+0gHhkwAOk3NJ5TnPaUhT8EoGJpOLmUto3OXS/Xrmb9nJfTTR2wJACwAtMxkAOdJqPVBOlsHKxJYWvywl8wVYnLMJTA6fApZ8fYcJQ7LlOHb68wiAGT0jMfNZLrBmgzuFMExyftSCZsl2yywJbFmmUWYxoQVOpWJJFCSEmICaulopBWZsIad8bqysxMT0NAb6+tgGCr8i52ADcivo1Hz0kr2qfgaAz0ypz1q+wJHe1/NunoL2WYacpK3H1WKAlpkPgABJhubdPGanZ4peyPkWORsB1ptikvK48etX9lH5aydy9lUCZmkdUj/FSOCCraF1U9FpQDllsDI6bqXAWABoWRkAcJiCRbGNAowYjQBr+c60mCNhpxTsemKTwVEsTbjTc54L5TxPo/mDJAWGXYvj5XRNWABo2QfNRBXTsKkWoqmWWrtWkQJjlDmODA2x8vc35PjtBt5mfqXfECYJOg3glAWAFgBaVnoAHCUS0RYNR0q62NgoM22CkE9yq4CTBjwOGQUH3s0vlvqCFsMsmRQYQOrTOGEBoAWAlpUeAM+jiLZYhVpLi98oONCUkIsA3iG/WtHBASP+VFUfwHOLHl/EekQtALSs9DaLpbZLJcsFtF+8WHCUWQUOJ0n6js0gO3IVeuyljo5PjZ7CyNAQe47vJoZ7E1D2N7TMAkDLTGaAXGwyGAfTFquUi53tddfYvkk3cKrA4YTBZ5a+jo5o050CwwYyspXssSDG2kxru+7r8lrMTiW+WO/1iAzDtXIALQC0rJQqjfxblsljah9ZSkfdsUZ09C0Dx8ox51ldiPwu1G52658RUjsqBeLrvR4bOeZ3rEfTAkDLymcRLZZmtsxjI8DdWzbq8pERdkTL3+YBDBgFa3tVfR2A2lKzoTecwQAABWNJREFUqkIi3CqJb4uGI7P1Xs9J8isrAdoCQMvKYLRlPDc+HsCLg2dL+mG0BtgAOxLJa87GJoPnDIADHY25BkAN+b7kF9PI+TGbDqWML48N9Z+HVQFiAaBlJTfKohbIYktFwxHx7W9+Hb/c8wNTP0gdXMnVWVmBzMr635MEKOwGP74SRQRBSmlTo6eoa4Aj4PkGlkr8LCuTWbXAH2y7QBYc7UKaevP1N+yz0zO47a47dIOVDpkHwJgPbnw8wErdEwXKWGcBoClbObpCs6QX+Uv8LLMYoGUmGF1kBwD8G4CDACbqvR57vdeTGujrE/c88RR+/cq+oj+I9S3q7ZQyNXoqFQ1H0gx4nVAxVyPPN2f085dhDYoAHnI3Nq8n98ZalxYAWlZqCRybDM7HJoP/d2wyeHO917MjGo68CsBe7/WI0XAkffD5F4qWxIU0QegZPE1lIRcNRyKLHt+ICrj1WpJ8ZYCxXuaqlwUb8f+9OHgWe554CtFwBPVeT4qA9Lp6r8dtPZqWBLasfCazo7Gh/rMA/gjA1+q9nr8nCzr55utvOEaGhnDfQw8YlsSF5sgJwRAd34l6r+edsaFe2v/PKACmiAxOAeAG+vq4eq8HbZs3L8vFfnHwLOIHfoGBvj4ASJPcPwekOSB/NzbUPwh9jR4sswDQMrOYIKMG0rHJ4H8FcLTe63kKQEu915OMhiP2b3/1Ma6jsxON7ZvQvWWjITCk7EhvjhxJgKbg7HK2d1WQCgm9XZJFAFxcxLsuDq8AuJ0CYjQcsb/5+hvo6Ow0TRLnYn9To6fQM3gak8On1MBH5f1vATwyNtR/HFYXaAsALVs2ozW39thkcF+913MdgCcB3EHZ4EBfnw19fdxJr4dr27wZfLMvJxgylQ55JSIFCjL8CPVeD2VBm5q4RO0YEIb+IIgIgEuGgwuuxuZPAbgXwKMAGsh5igN9fXZ6XC0tfhkMCwl8ECmbwfYq3jyIkaEheg1S5G8o8J0B8I2xof5nyP/zDXiyzAJAy8rACFMA7CQnbbe7sfkL9V7PVwA00kUeDUeSb77+BgfAdtLr4Vpa/HKJGy0da2jdhJvdKbzn9SAajqBt8+Z4Q+smcWr0lB2A7bWYPVk7OiwIwVDN7PSMbXw8QBOf0/VeD8c8m0+NDfVHCpDA1M85C+C77sbm/QD+BcCdzN8ko+GILRqOcAC4eq8HLcRPaIQdMuAn7n9pXxrYZyfnk673etL1Xo+dAb5TAL4H4PtjQ/2zWBruZIHfcvqALLNMZTQ6Ka7bvHUdgHsAfAJAN5TBsxRTscER8AIgpb2QIEgSUvMFG6S8PDsBHfo6kZSDse/bD+C7Y0P9TxcpDTkCPkkAcDc2fxzAFwDcrPq7FPP3MiBSf6EWMxSCIXF2eiY1Ph6w02MkoEclLru+jgL4AYDnCfBZrM8CQMtWgbGLlFu3eetVAG4FcBuAqyElG2ewL6bHoEiiuTYdUngSUsv7H48N9e8noGWWX0wGdAKE1wK4m5xLBzIzIkTmK9sITpGeH7QzKs5CmmHy07Gh/iOqa5qG5e+zANCy1cEGne1dXGK4V8FW3I3NV9R7PTcAuA7AVQBaATRCX/KxAGCMgMRbAI4BODY21D+ZBXzNBHQWfOzuxubN5ByuB/AHAK4EUG20tA2Sn3IIwOuQulcfGxvqj9FfOtu77InhXgv4LAC0bBU/L1zNrt222UN7U+qFvG7z1hYA6yBNYbsCgBeAG0v+uzkAIUgBgBCAd8eG+uc0AAplYEhUoibVYO9ubN4EoK3e69kOYD2ADQTYK8m5UEkfgNRS7F0AxwGMjA31j7JvVn/3/fboi0+X43wsK8D+fzexLgiwvrNNAAAAAElFTkSuQmCC", "myo": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUcAAAHMCAMAAABx4JpCAAACf1BMVEWslqbcoKBcIhZbKW1oWWKZJg8uG3khGiGeZl92TpRdG2RpUpkxIjPabFPfy9mQW5pnLpHRSzViXWJMJHG2tsdRKnGgacXOoNVmMo5fGaFvFghiKow+QEGhSTImJCU5E0wAAP8iIiP8+/uRY6SEOZ7/AP/POSbGkXyhTxqroazXxbaKNR5UQj2GLBSpYlb/AABwIQ6Vhnt1RJJmYg2ZIhQ6GEthKx2mcdR8gojz8LaBM3RJRkjfp+8+QD+DUZvOo6M7HEZDQj6Xl27Mknv//38AampLSEZ3UZObTDewj9C0/7TrbBkzM5l///+AUJe/39/Mf3/Bf5MAAADHlub36NjSpuf028Y2NjgoKS7btecWFhb01bz36+HBjuYHBgZFRERJFnX+9uisa6WZZJWVhYpWF4XtqZroufXHytK1dapoGIzvyPONfINSTWqpdpK+jOU3CmZrJpC5iHe7w85tFgNWUGw0Ckykapc9PUBLE1geIyvTtafsiXC4hdG2lIvPqZdwNpOHd3tEN0c7E2nN0tnlrf2ueMzUsp3Hl4fXt9THltaRV7H21PGRWpNyaGxSJXNbI4fvknmNGQLqyLNGDHL98txKDFZwCwDAfKuJSanDi3cmGxmtJw5/AH/Mp9CZZawAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwwsXeAAAAoHRSTlP///vw//wD8v/+EBQT////6/8Lof9g//9fFQii//5g9gGiAhX/Af//FQj/XP+gEgGh/1IKGqJeCf8F/50G/0MGdUwKCwICSJhXCAMLBQKPCAr/AP///////v/+/////v/9//////7//////////////f3///7//v///f7///////7///3///7///////////v7//7//v/+/f////7/Av//lDACjAAAZRFJREFUeNrtvYlDE9m2718ZIAkg0IgiKs59bG27+/SZz3n3vvvu8Ob3mzInTBUgQhIFgsggJgRRZAYBtRGFf/W31tq7qnZNGSBBbHuf0zInqU++a9xDSf7fRjWG9BuCs8zxU2NDQ33np0+ffuN4gtEoftHZ0PntbxyPMxoA3iUcnZ2Nt9m36hu//Y1jxRgvXUmysb3d2nrl0iXSZ339p984VjA6/Ze2k/qxDTBJmL9elFIN1AgYs761tX2frzWrIt2+cqmTMB/TwL+F8amtsfF2Y2Nj2yf86ttfM8dP/k5A5xsLsNE7tnRxrTXLWbYSyobGSvB9ug2Bv7PB8oc3OmHUNzQ0ANhfGccGP/jG1kBgrHesFwfRHFtaa+XCvELOshz7/vZTQ72A79Y9UOLt2/8Zxu3bt+Gze7duib9e39lw+zPSrDLHRn8nwMoBxt5ArzqQZe7iflYx8L9iAL9h/yg3PjV0cnqNGPmvXLnSmjUPiGE4Ll36Q+Pte5xmfUPbt78Cjp9AjvJaYKzXMMaQ5ZiCsvUKYuq0FuWnBvb9252XEF8ym02nkzYjjYNDvXLpD7f/SUlZTx1mdTl2ohy3xwK9loNQ+ra5fUMAV1SnCbGxHj/8FRCiAEV+2WyhUGht9cFobYVPkZ2eKafJU9b6hlNNWavNEbyjKEeINMxR8rCDBr5W4PbdqC99IGqgJTOGHOF2tnV/7eLFpVwuxx9CHb3wvdzS0sWLkBm0FrICTYR5j7Fs+yI5fvI3kncUIsyYBlD7ZInsO529ckkj+QmVeBsYbnOG2dY14GekZzfGchfX9hWaCFNleTqyrCrHevSOPiZHCNIX4cKyBcQxZkQ5drHAMyFwafU3/Bh1/nrpCtdhtrB/calcgjqaQpZFLG/fokTr+ChvwDh9u/5razK5xOXYKjq3/SWRJH22tI+eMt2K0RtdAlgzQQSGucBJRi+9gVyXrVf+cI/ieKUov22sh6FkAZ9Ok2O9/xJg4BiXmHtTg0Hhov5iyVNmOclbl65sE8TWtaVAVUZuiQszTbKsxMBvfKqvVwLg/4Sk9a/MZZ0exwYhygQuggpHlx8+dDhGNwoUo7MXRUnS52MXGclWpsS1XKCaA1LWgg5lZ2MpG/22k+f+/9TJ0tZt1h3oPFW7vr2tRJmxwFoyOep4iMPheLg8TRdUWDKRDHBHmcxWS4n6wWWJKP9AKItEcJ65/pUSV0OmeuWvn26cEsdOMGuZmzW5R4aRsXw4Srz2x3QgBZLZmmBksvSpKP8F7Pv2DetSXUn+OUJZlpljgj+Gz674206JY4NQywR6oRAROBLJLMdlQ9LgQWuCsvXKbaue06dOZspXtjlCTLsgcV1aGoOxdNEH3+z0f3s6HDHrUaN1bjtZeKgfjocbJMnegDmluajafe1QUqsEXeU9fU36LUblv6IO0UsDwoJvbSlHiS96KGwVBFrl5CV/w6lw/Ml/W6sJMVy3OB4aSToKthbMSLbWkKRSSWVbMegomiQpdjJjlpPbhbWLLPcfYwNBQjFxEQ3706lwbIDaWnOP8MQbJo4wpvH1rgUsJBmg2J3cz9WQJK+kQJScJNbznZeYEtXMtXdMGASyF8wr2VjMsKvJEcLMPnOPFK6nrTgySdoYMJHM1g6kVkmliWQ9SXGbJ11LWjeg18BxrLcgg4PsPA2O1KO4yPQ4FtiXkw4rjgByjUvS6kIxM2+tpSCpkvIxkp3+f7p0haTIkq5eod1H8EiZ9DlezyV//enkj1pR2BvwyUlLjEhSQtm1Wssul92rKUelJmXWzUqe1otjeoisyTKWWxoLIMdedJAyOMjT0OO32OvJKq3HQCG5vfzQDqRjg5c3lh5sKXAKg2lSlaIBIpToaz6owrJrzNDHMG4WDTRV4/gJw0yrgnEM0seH9sORQiHsBz7nID9ZOMoxiQp9e9a2xxwS/m3lE00QaLZv+2/UnqMYZizTR4MkW2paw5RHcv+i0oUSlLivdFa2C0BaKSxAGEUzcamaWbh8UeGI6ePD4iApA7oY+MxDyb8YRbVXX9gYdYBfGoVPcyhIHrA/nQZHMcws2aSPIsnlAqtuPj9E4og+k/WlWkaXH7JkA60GtQGBxlc8YEtVCzNYzeRKpeHmOjGbC5yBgRRZf6IwvSwkbKPkqzDxWTsdjhhmlB4u4zhdiiOQHD0zIBnFLLz5upe9DCVar8LxyilwbMQw41M5wrOOlubIbHvpDGCk2iA7bS4dIO8Yo0S8RAIpVTNcqzOuZXKkrqTvLKgRMbY8tHjF+D4TR0oga88R52bUcN1rXxaaa+3Ws8KxsGzxilmggaoGfqX1Vu3zcLG65mVhqXhNVY1dWXPqqSS+FvNLhuxMZhwxEf+rfSJePbvWmrg4q2BfXisUqT1eOBMUSZJZK5DIcY04QiK+3Vl7jp8q4+hYpnpm7axQhMRnDJzMthEkZBTEERLxLCbiNed4A9PwnMqxUJSj4+E0vvu+XCBwhkD2AsjsspnjPmv6FC9oqlbP/G+XloaX4MjFeDFwpkZvIAdvbsHofvQcG2tu1w1yuRyZZ9wfCwS+BJCny7HTf1nWuo/F/COvBi8Gzt5gi2n09azKkU0Z1pjjJ39DQ7Isjrw7MRYInFmQuoJW84+ttddjk//CLE6dax1lyB9TDruKOnkxcEZHb+AomdRVYkq8Pg2O9YBxdlZoU9C0kCXHjc/fvS0Bck2XRjo0jjWP16jG2SnXtixwhFdj5ujAKuszzyaUHj4x+1Hy8FPgyDEeGTkemWqD5azthOtZGgUhaCt1Ye05NvgbAOPWoMiR+o9rxtLAkT3bNq1N/WpBG3sAIsea1TOfOMbBNW22kM0r+BzGjPas9GyLjzExaOPEwhLjWOO6sME1OzW7YeSI84UOU6AufJ50J5c7RtDmscaX3F6iNWe17VM03TqPGI82kKNP4ziWlXXLHwlj6+ey04rNYD+prN4sgA3RWgDkeLtWHOv95yHjaTnaMHDE9RS65biI8SSN79zqsf80dPEYCasaa2heQVkIUKv+YwOFat/AxiD8T+RoSCAJ40nyndTASTimk2u5VOWVNsaaZYie7JKWtmvWD2cxxgVGPQiWjQVUr2Xic1KMqwMDAyfRcjq5n2upIFHgCUfy/3Ngec3VgfMKNVpH2nDbRaEaxsZgi8iRAva+Q4jUJ8DYARhTJ3GQ2WRhaWAgVxnINRnScdZ+VDheKbKyWTpJAk4xBhhacNQCNmH0nQzjyTi2JrP4GB2VgSzgyuxpZRK0dvOFLAH3oVVbcBxT9is4lrdPEqlDhLESBuaHWEum1wYq8w1MCcnRDWXyjq0QrwnHNhc6x0Fm10d6jmz/jIMXg4WTYjxBmKGAnW6pVNR8R1pBmSxh6wBqsJ6iQbXqDcZRFvMebYE4ZhC9J8V4IrMO5dLpQuUPw3eaZpUF77Xh+Em0aorXcrJV1CNfKdVykmIwtMowDuRCJwG5mk27+ONU3NTlTYOarZNquIVWPbixwUEix4LIkVaS0iLHpRNjHOg4EcdAIe2aHqjYz1LM5s6qVhwxAyerZhzhg4Ejq2iWT9L81jAOnIhiILSfljcGjuFoe7MYrtWVNtXnWK9YNWKEf45SS0fbcla3WB2eGPdm7gd6T4xR82shZdAX+i+LBOy03DJQOUhyTgV2gE6Jaa5jcqQgs8XUuDE4gDvJsDMxZnCQ2HDsPbkaRfcYsh6lKkPZlRo4TsgqqHlPLdY1a1YNFFM5nrfK2vy1eiAALlU5IUYAsFqaYzGsoSWBY2UgL6qLbaj9WOV19jx1RK94lOOL/fEN03EMsNX+J8U4sFEOx6IKDXVkZdfAwLFALjGM2LjYvl1ljk1akEnppqyXhIKmlyaMxk5s1K53rlSFCI0kQ4GsvKVxHKikZRHQ9u8Wa/ccU48YZBCjCM4ncmTTHHvHlKMO46wrFaqYoUGRrfKswLHClkWvWl43VJWjGmQGc2zmQkmwtPW4jKPcmju5GmffuToYlv07HeV5RxPH0L48uyGC7KgUJCsLq8oRK5mp6xhhcgG+s9aSY2DpYhWMenb23T9WCdVSOnnRmthqqpSDXDNwrBTkWOCoeFl4DI4kRwgyR7mAtke5Fxf0Kzlr74n2Fhkwzr5rYRzX0ukla44dA6sl9AgcW1I6kKsVgUSVZC9VVY/YLsMgo8dI+aLW8KkSRrBp9+xsC4N3J521sevcQKq4iwxdlN8ZOKYqEyRUFdk/VJVjvZ8K66MczkaKHJeEidcqYZydXfa+m21hSLLpgk24oQyzWLQJLZk4VgCSZyPbjUXKmYo58hScMCpnDiiNCe10ipPNxWgY87vud7MDZNa5dHrfmtRqKjXQUTRsI0fXwMDxQCrZMXCs4v7reurzKBhFjmpheBKjDqRE35ifew0fUsTxYjo9YOceUwClWAIUysmzs65pgyJzFcgR2/u3q3jOB5djTgWoJj5CYVgtjNLcPHCUcyXCDFAsKkiUbFaeNSuyo3yOuRJpeMV6JDkyjMrJIqaC5iTz1NzmFIzzLiV93LcNM8QxVTwlB44WIFfLBVnyWIUKOTI5Lgl5Y2+vIkzsdF4MVAdjC6Tfo4CROFIMCRTSWWvbXQWMJQybCsMtqIyO5yJLz85UyhHXoUytBcYEv6iApER87SQcQ5KIcRoxvp7feucKMMtM37Fm1IEcU0UiNnJslV2SWZHTqXI5lkofK+NIuaM8JqhQsGw1gTz2dJSCcQOu2EsYX89DoGU5om24TjGOxR3knaQ8bwWyTBeJaU+xLm7FHM/PjrN5cZ1l6xLIE04NKhhfv9ZxXEqn1+zNGjhKRTnup+X8/VEEmTqGi6QYertq/hFnE9Qm45hIUk18eu0aPLlUKlde/j0NodXNKL6eA44FAgFpz8UiZl0q0CDHubnRdyaQZbrIpWT2//57W5U4NvnPy8pxzHpF6hIfK4oD09PFbUhfDb42caS0x96sS3FcS8sQ/i1ATpeZRbZWsy5smxV7jCaOSgfStEInNT1dyqenRIyQ7xg57qfT1h4wpYxAcY5px9zr+blHZkWulmXYELBbb1WnnmnyX5Ch9BvrNQQYfQfSzBHEWOr1hsTEUV6em1f1uMU53klnV4u4RxirJTiudM+DIgeNIMuN2dnigqyAY/1/uPjmeC0HFyWJnTOLgL00WNJ+tBjTwvNvlaNL42gpOEd5HAfS6cMEYHxNIP+RqtSye9m6lGpwbPR3bsvbYzp6OpDWATvFMA6U4xwpVI9qGJFjkqWNhXShuFkX5whhypEI3ldA6ps/ZcVsdsDZtyfn2KkeI2wuZtSOjylgM4wl3vSUokYtcWQYX8/dYfwCNmn4qoqxeCIOaZOUCAZ34bERpK6rW6Zl+zAVr6+CXd/elmUWZcasfSQP2KI5DAyWfqlqAo4xxv36tYgx2MLs2a6c6RioiGMijA/rBZAbqUpjNpWGJ9/PVc9OBx8TMm/jpzxgixFmsPQr1Zyj650Qqglj+G0Liy/A0bKc+aUyPQJIeFQEKeu6aOVYdq7oxo8KOF5Rt9oZQ7UuYFthTJVl1dRxFDEGg2/XGMcOG46aeyxeGCocg4kgPC52NV0Vx+xWNOzGE3Js8zdSlFHbjkaSFJp1HHNHg2V0+pSUR4kx8yLG4Nsj1i7rsC4LVyvmiCAh/3Hps5/pchZYFp0ylCoxa5+W9FiDvHikwwj/w1c5mCrHOcoUY/QYg4lUOp1jbYq1mIV7rIBjinFkILFnoQvaq6EyasMiOz/KtutbrUmZdiyqIM1339K5E8J4VMr9rBqc47wOI3FcsueYEkZRjjmNIwM5aog1qbJScXCQ//VEHMmss+JEawmOhJFxLCZHo3PkHOfm7/NrllSOLWaOhyLH1XI5MpCGWFPaRfayzKfxRBzrefKI99saM8VsM0ZIeHCUWk2rWvU0d45cjvO7yiU7WJ8H7HIgVsw9VsKR0p85Y6wptXa6lznIhpPZ9T1u1oHhsjgyjINYWA8ulWPVkDmqGOdfh9UrPsRpQjuOHcfkCCAh1mzpY03qRA5SKtOsO5MyHigZGH7VqxWFtiBTg9OEcXq6+OJuwaq30DmyHviccMErLFBbc3QclyOBhFgjusjSMbuXMshPJ+ComHXg1avQmFXu2Ks7tHdJxThdTI6KVafIqhHjvGjTdL3NLHG05pg6NsdgYpe7yEqycWpCNp6A441brVgTjoWQo+WtMl8JDYrcILdqAlmeVXsJ47xo0zjehllBCBwvxoq6xwo5BjHW0OJKTZBSKUGuyWm72a6yOOL9HSEJRzm+Cliq8dUrzbQ7uHNEkAPTS6UzcNWq4Z+5sP5qg9SoiNWAIxQ26CLFLLKkg7TPxKUKkvDeV0aOypqUV8PCAgAV46AiR+v9BKtCBj6qYDRcKy8MrTl2nIgjuUhd66ekh8xtJ7P3/D+dgCPV1gHiKBbUfBVRaPiVxnFpQ8DIvONw0SBDXR6yap1r5Fc7gIWhNUdH+Ry1ulAP0quz7JIhm1ZLtR2X47f+21vYEUOMIb01M3zDXI69gnPkckTfDZTt5Yh19ezyaxuMPBGPWcaZVNkcY1YcMdZgoS1Ydqkcct92OYBUfsuMcdT2GoWGh0Pcql+xhf16qwaOVMqEhkPFpmR4kIH/h4MWHA+JoBVHnXv85ZfDijkGE/dfo2WrZU3Josb+EHGpTLPeWyOM4B75gkBMJYepO05yDOABQq8wc9TpsQMxWps1l2MB6urX5kBtSCCtOQrdx5YWW47Dthwx1ugtW3ubLV+0/bKzsvzj3ynr0XHE2D3Mkp1XzG570Q0KVg0cSY7D1hxz08pUwqz02hYjT3xiVvV1h8bxl3+8c9lyzNhzhAJxXszGtUgznLE0cWpVtB2PI2Q9MmQ9oVe6MAOxZRhyScgp0byBIpnvgI4jtsHxxwaLhm8Nc7PmqaMtRhg4sxBj/Z6MIcxoHF2zLlub5hwdVnpM7L4eFAQ5nVJe6yvTux96pUzSNB6PI7rHPR+TIzhIui8dYUSzZs9ITtIox0FFjnqOwxn4VmZVTR2pWzZvizGBndwY9nFj8JfW4fqXlIuWAQ0PW5l1MY6YjrveCaFG6UNavP3DlInbBJoyOLKJwhDnOEwo2WcBcpPDr8YCIYZrQM+RyXHY8HJwvEpN61JHW4wsYA/T/MxwJmM9N/PLgPwOzX54fdiKYywUu2jH8W0QW5HyADcPtetjet3M3mwzcalc9/jqlQpymH9C0Rp0+ArFiE+7pMc4wOSofz34jcwwSx6xeesujpEC9hrjmBE4xsTm4y/T8rv9YeSYsXCPoOIYrQOwfvzwa02QuEzInuMrFmjuHS/OMPcYeGUa4B4pahNEpGmU4xJXnxEjSLdDTR3zr4tihOsEhLEQRptMRjVseAgh7fmlZfbdGvwos24BsgTHYM+uNKu1dFPcsEMmf8TyDrsFfFKZ7jFkwREoQpShT4ctvOP0KscGLlpJxUNMjiEya6U/0f02WGxAoMH1FHdiGU2QGSPHvQHimDFZNsGPtaTTKwm7J7jv1jykYtghK0MKYaDZtmz5SGX2zCw4UtbDkZrlSEnPsDZorwH7NAMMuByxP7FblCJWhumO2B2Aua4KEh2hwNGxMSsvAS3kqI9F6FMBfmytGMdgXhOk0vQJDRsFya7BLtCU4R9vubh7JOuljyxys74u/0HIKEeIMqFhqwFXypJHF80l3A+W4EiBRuGImCBwA0ehS+FoeedagmiCP1dBAsFhosg5Ntty7Al63+HaqRS9u3wLGLOkgLq7jrsuu4qmJMcb/tuYPVKAgcckvxgIMTmyp3vFnzJlSnqGrTmGAmjWkPO8c82XxMgqmuH9dJpx5GNY7FIAx3QuhmFGIJnRfj0U209n7TkGE3MkSLYedZVtAcvoXjOPAQHbDSAlOTay4prwQd6Ino59eBVYKqy9Up7klTK1pZq1nRwxRFCKATmPZG6UWVc0KKhVK46/wEg5/jELpq9wxGijKFHgGC7ihRMb72a9jOM07a41chxWOOa2k61/P068pjCzH2KdR+yIsw/IsbC3HdLcn8GsB1bt5MjMmuU8pTECSICACxg77Dj+8otLzq7GBAWKv5nBRPxOuhAsxnFEFeR0rihHCNiWG+TK4Hg+KV8MsZ4Ea1AEqFUWWpLlwivtGbS+IzdrWzli8ohzMrPSXLgMjrgWoAMKkiUjx1/UYeSY0asROd4p/hxQHbYwjrTxgVVd1hy3Gy0CjVRemAkNh8RpQSivX0EKAEFSSx5TxihjK8dVnoJ7X5eDkbXOoDC8aOD4i8DRdSdkzxEG5KCJos8xImNRoy3Yt+VosxG7FMefWJNClaPCMRAY25bJrKmaAUs4MtQymCvjM5uiDJo1yTHfHSyLI84ZrqbTLevk+9bNHFPEMYY/5IN5STJxDPBQDq0lij/J2h7mkNqCfQby1StdtAF7P8K5rvqKOTb6O5N7BT6Ppc3BsNXgvmEKOwHLFgWlW2wXq87Ead85yXE3WOYA74aFIWdDfGJ6jljyxNZFjspvEkdQ80CiVFYw6xIa62TY1DsLYZ4XUvNJm8RHKrPZozvBgzjuy/JFbOX2Bqw45vRdcIhL+Howp0OzJjkul4sRM/EceDj441iMJzSxmMbRMQ0cQfwix3UgPUx5ORbjOZs2rq5skmc3xAkKfK2BkK4uhGAayFkvTpHKqWaOQq8CRj32ZmW5l6f82AHShxmQo7kPCm9xhps1yjFYNkcHyAmD9jA1KAikjmOLK90yHBLMWqmzh1mdOGzfNhOfRHYJHAP4WnUznQAyNZgas058SseZ8xhmQqblJxCts4FX2ioK3YTC4JJVXx5yCUyRU9Mkx7m3ZXNEBwkcV2NKZ3YdOSrxGspCF1Q8jCODiSU1Dmo+Asei5bUyCulZTH1GOccQyjGk32Y/PT2dy1omPiU5/h2nCkParDV7yDFls0zAiuPg4KrVXEKIogwUM9SgKBsja1Xghi7iiHzW12OxVY1jC3KMUf4dIx8cYxjZCJUqZ5T6Mym7NY40r2OYeE/hzJ31SRVSyXWPEK57A8YDPPC+2rh5y7TCjJu19fwlyjGwxOR4vwTHtwlhSK3ZO9n0EtMjymxY4PiL4x+oVXCPw/RDzlrgSGl4KY5vQfVbpglc/Uwx6BE4QuJzu2KOFGYsVuYVZDlnsVJPbYTbcGwvyBsp97t3g7YYGbm3wZf356T80NBQXpp7uZJNZ7PpAd6BQDY6jq509jCGPaCY1Qhh97KljLppIy1vFOOYowVLPstFPlIZ4ZqfRG5YoiHrj8g8Ko/jGp6kI7+bHXlr27edy//s7o8c9Akj6kqns+rKZobnUOHogLTnDjZ7rDGCeiFpGkiUE86SGGlCodWjJSuUKVr35bOcWpBKV4V7/Ngyw5IhWX8q+JFhQsFyZVQGD9yYbnn3bsMW48/xPosxBYKEHFEch6ocRzF9HM7EYnYctV0fMFSXYRVpXNPIcW1P3BSqmjVbP7dxHI5+/xVlE5cIspefZmbNcWvLRo+h2FISkoutd/KKrVlHGLh41Ol2u38ekoZ+drsfHPSlYdzRCU5NxDF9bIlhbmnHUQnXiTm32xmJRJz97gXpftDIMpFKpluQ437SgmMoJ3DsrJQjVNeGY0aVpYDykTXHAffU3sWQ3Ym/SXlj4927liKtQLd7IS/dDwfFOBOcuwN6hGAiDpXjRjq9ZI8RBu+aJeZ0Go9uSmEdybcr6XRhVAqFCknD5lrNrKenN2at1lRIZYTrMQuO2KQIWMaZ6a0p2WbRI75Cedr1bu/QPlgnlDij/24OOKY7dJHEkXLggDQcyp1iGJUwk5BQ6DgUlPH+vN6wk2ns92SThZAtx8FZOXvPlEBKJQ726JT3ClanvxnDtcZxY3Yqa7uQGWqGjdl3hWClA5OSLCbbAp7VXxxsFECp9hxDw1p1LeVB6MFw+P5cfpM7ELFehBQy3SKFAiaO2CJg7hGGS95uM+0zlEo2w8d9VmclZHEhn35pPZdjy9SUz86swT26QY7S24pBJtbSlPjoAg3DmMoaPKdhDA+oVaHoKxIv826PnuPbEUgLUqHVbHLfzDGncNx6ZzH1KpWT9piP7sCmWcCao2tq6qiIe3TPvsuGg5VzPGyFgK1XHZfjqOkHBo421Qz53fv6H7QkXdMhvIGSxd4xjjHlmtr+z6apV6nEkpTztMnVvFoMzd1wfIISradmc5a+EUYrhOvZvVTlcoSRMgZsCDTEcTqdbinhHu/Ye2NjbZhsieWSSfOm0IDAUTYXNKXitUu2DBqm9FHpm0E4m9oK2HAExyPPziabj4MxmNjHqiVmNmwM10U4DpduPuoMW04tJZNH5kX90wJHc0EjlZ5UyFlz9FlzRPdoJ8eOdHJ2dm/t7fE4powBmwvyTjq9OlzcPR4myu6IJOVkazp5sRTH+ko4fmJz15YLfGXDnctWNfe4YbmOOURhZnZWPjwmR0faELB5xIZIXizM4FKMcLlPmZBasQJNms9cygkcZy9UyrHT5AdVjsYbBw8o2aM5zKinvwDHYyQ94nqAmCnSYLguFmVwRqLsdw4NG0fONsxwjk2VcIRwLY8XrPfGmzjygD07NZsK2HCEcH3cKIPrAQomYCjIaTNeHcelMuYUdIaNHFerzPE8pY9lccwpWbgrZ+MeQz7gmB45ph5pS9JhzCRIqgorz3rsnmQFMWatOI4em+ONey55/GIlHKc3rk9tddjpsZCEKHNcjOyMBYPyDh1YFRYJM2jWLRU9DdSGyazFVu/RY3PsBPdoHWasOAaIo29qyrVqgxFP+5VX3x6bI64HMBJbdeBKNHuOmYHKzJpxNJ9dtarIkXNsq4jjeXnc+pYdVhzRQU67p6bcq9YYkaNcCB9fj2GrwsVRopq5U5FZc477FhxTx+VIC5ptWjdWHJd42tNigzGUS8rHjjLqylyj3nIg0kwRs4YoVNlT+pLZpPlMkZzKcXD23WxDJXl4PcqxECibY05JH23MOoR3mlo5hg6V4o1l4ma7zdlzzLQIM9fwOIlyAnY2uWTiKE2Dg0QXOTo4OztbyTqAb280btnJ0Sp/pAzSzFE4O31JTu4fQ4XzD7sZy7cWDhIX6h4OF6utlSQ8kdg91/WhvMQnV0WOnf4LtnK05phiXYpBG7MODcitlXfMEnfr6j52nVveBRDNJl84fFjUPWbU84+Q4kd4pHCiDP9omfakCOM0bbL4sXyO9fX23jGQW5P3zFV0jnHUlzPCazmSk8fjiONj14dualUMV+Ie77CZGU6x7uPdt2XEGYtwHUqNqhzfzbr+XgHHIt4xN7hhxXG1FhyDQce5rrqPhPLutDHnzqyBy7TlmOlgUSYRJIpdd8Nl+McChGuLI0VGR5ldpzamZl3lr+/BktBWjingKBesvj8ISUHK7i55a3LSYcPx7duicSbs+PANocym10Rqw7Gi2WNmH1s9icR8Hb4Ry8FEGRghubLqmo2qHN1Ts+fLXgdQ74cgM25zF/Xchg1HqWKObEor/PL+/fthPkVox7L7A9DI6g07g2mNvRzhp3eCie5vgOLHD8GyskicCErminF0VcCRYdy2OVN9gDhuB6wM25Zjrj1mtOtE8L7082Z/JErzd/GDyAP3z2xa2XKLbyL8oe4f2bR3RZ/12BfXaPRSIoxe4Vx34q395KTwfNTwWbXlODqd2kKOTeVwBNidW/Ki3Wx+Dlc6bslWP06hf7Tk+KKvL+JKyoIeE+GfI1ZLJzwP3Pn7libYkwiPptP/cAzrs55MkdIa5BgGx+gwPxzCC9+fk6S8JElz2kR2uGBRXWscR0e3rMprC46fGvy3Lsj2GAMpxtGqT56j2ZmQGaNEhNJ7kqqB8ILlAhRljt5tmKNXLr5FnGOl3uJwcTkGE45lk0nDQ0sL/VHtFcTdEv+l5qxVmDFyLGbXN9rqYWDm6JLBqO0wdlB/jDYxmA17mnM0vQ58yZ5k0uPpdy/8PDT086anr8SIu/NmlG8lMc/JQIGTyth6x2y6QMsoEiYHkXeb38QHNHX4diVpURWGcirGaSoLbeL1p/oGpVF+r/M8BOrxgu2dWUmOwHHPanYVvMd1K46hQc6xr5JBKkkYN3dpARp7i6sZHrlt5GihRLeNJfyMNZOUtKgKQ5KCEdNw13/csOZI377X2HjhwvnzW0hx66jIMbHE0S3vrVlwzHGOZpCPieOU5QUcOB/0R+0M/L5+Dc6AJsEMFDN3bDY7UbA2NZdAij9H7d83dyL49qjVoioEjikeZnyWYYY43vA3XmIAcYyPyz5LMWYywrzghs3EDdTXlnrESAMcr5sk54QYPTe3u9s1OVlXN+m0EOyDvCBKjKcFrj40azBym/1O+yY5JhL3N+NFDWAogW2KkLpDxcRx1LqLSxzbMMlhBIGhvO2z9IzNPYl1zaxtEp9AyDc1tWTNMRTtM3F0LszPseHd+fjxG6xZPgJMs33PqSTfHqmCZNHaRo4daePsf+Klu6QnkXqyycJhu/TI9/iF24rjKHBssNjwKimlC3Ap+NYuLuWsTjQNZXoSPT3rmlnbBezQhj3Hdo+cnhVfdH9+Th11OwgRMNLYmfRYiFJbg0OCRMvdH7aRI1bWulnrRHDBkpzHOTkpPJs7nZYVzQ4Om/xjinV7LDmyfm1ru92tjEKxdaTYk8ho09QUsC1WOYaO2LSr5UE6OTkpaxcQAYoOB8c4sVOHcvyojN/97mOdwcajPzOS6CEpZPMk3FqOA/r+bSKR95gJOj/W/Y7GR9UEPOm06sN9FhyhKrTjCIYN+eJ46yHtIdTpMIB7VQgicowpSbh9oEGOa7a3/c4KHN1AUZNj104ds2qO8Ztvzp07983HSf0q8TwWJbSED5Lv4VjB2qxxQxtEoGyzkPPPGXyF09n1O21883FH+cH1dFoBPnMYM7YpyD3O3rbbf81AylLPekxZNIn6aV4HeBwijpDmHgdtKuzQUjGOBVnhGJ/QYZwHsz5Xp4BEhueeP3+OH7ybIsp+bNi8TVFRjS2ztYyVZ7wzgEFGPOd6U6fDSXjT3oSfixzrJvkP5XRaeaNjMWPbDLNH7PbYngcA9TTm3r4VEVtC/KKHu0dtFbhs5SBDS/KUz/aELJ+8zd/svEgRo8zONwrH3wHDc88dwZ5g2PH8HKTikqClOG67CRdwLgFZdZjMmvDeAdItwlqTqAgRngHqbbg4h8axbmfHqXBkb3VcGja3H0ex+QhpT71t3wxAnseAzUgGe4wDi9uY/nTHLSsHGcrJUwVbjmtyUnI7+/viCw6HjiOY9TnGse53QPHc8x7ePngOHBNv6jSS/ShIB4aaw7RV8ogY0/tZkONbpYwXovQkON468hk9GshvvgGOdd6oyNGjx6hyRPd4vtg5SG1+/6UtNG4fFrbIMhhkAIM97KLWA6J7JAdpXncbWi3G8Ujew0bF3P35eR1HMOuPgK8LQH5DGNVGTNABnzrgQhWScaz03kKpMsAScgNFiC/Z9No+/sNnZaS4FleIImg9HH74fBdy8m84xm9+V/feu8A5QmoWHwzh7iVzG5fc4/mi53zcYJIETW4NSiM94gLgnvCK1LISCoju0SaDDAW2xrMB29Ms5b1UEGsM5CiAlHZ2up6fI39I/zq05949t7v7/Bu42DpFkG95dZg1RZlYZphWPy/hDxnHhJbs1BGxb8456NrCb944nn/DMRLHeR6uPX39rMWpbLIT2+FQXMutJc7l6vT7G68AyT3Ixgu+Fkk6PFxpl6QWX2EL6G4HxOxRySBD5qWie9u2J6zmknsb7JC75XnNQTrIPUJYec5jy3NxHTd+h671Gy7JTbJsIGWsZaBOhKQxvXSYTit6fHtfw8ge5dxz5YEffsMY0vjodO96GMc+d0bcmihyJPcob9/y3yg6r3ADSV46r5Q2+lEI6MPM4GDBmPmwmLwn5+xvQ73HSt5d5OgQORJE4vj83BvRGB6eUy+Wg8S+DE9+9Ea9CmyzHRmAuVZgHDU51rGHOHduV33kNxrGb3aAYz/82mxajhr2eIoc0T1a3+5MMvYeCaVLFsdWwSctCT0z28wH14r6inCExCdJy83C88jRYcERh8OSI6STzvgBiAZDNvbP1nRyzGC1nS6sroPv3IfUku2YyVOx5+7b6TLKEV3GN+pD77x37+ajngM5u/d42AKkpLpHOWl5g3tjH/db6kDearyAvR/WvJDC4FFCAUOYgbFtNuxAaG1PXioSsGU2s7C7rLlHx9wHPcfnuzYc67zB8Nwcn43SyzFzuI+BOrYO8Rp+ckfp9bjj7pcJZx2kVUyOD7VHDisO4xxy9MIreS3JUF3HbDmOzk65QArlcGTNSPUWcbK8KCWU3NHI0SePo2GLaTcepCYfhYoEmkHlGFCHYx7CDdWGyxhnxKE5yN03z/m1IsdziSDNs/BUXFFiLJPJgU2Dw8RCBorFDC565PMEEPQhDzhHuHQcd5nnRY+MHO8DyFE5eZSx4BiTeO9xyj24Z3ngns184aeG+vr6hvoL8vhGIshLa324hnGEEVtfvOC5LHu2HEOr2+qCs/D9uXC4mUvy406djqNq2Q+fv3lz7hy/WOIYNMkRKJIYs6sZSs6hyMHyWt0Kmgh/rKMHAI5v3mhad5xTxnPgOIF69MpJ62kzibvHqUfS3valCs/5oKUAh8QxZsFxI1Vgkwv6k+Mx+hSpaGSHca6uJ5jAPNwCZNDx/M1zJYojx7uJoNCqULQYG0AxrsUy1J4o4Ec82EPluAsceQx780Z1GrssN8DvPu+a3FlGju6kzZpUibvHKUf7XrLi83tw10c4oZTWhrQHOB5BAWQspnOYnttyTMl7LW+V2T9tgIPseqMDGWY2rX4TRVNXx5aO4drjbAwPX6H/cgUMMB0ZVnKnVzOsqpHU51E44lBBBuEzVsbDqHtfh43QeVfSZuuDxN3jbPPKXqXnznzrb9wab2U1orDkVtz2D7G83dhllPcK9hwFwxaTxHCdUZDgIh3PNYxvYOAqJ2UdJG+YAcVVsORsdiCG9FbIOeJ3wU0O6DgKj0TvUY9DePBzO+/rUI75rWQhZssxNQhhJthsfQPnoutIG+RxX6JHCzNGjqu+8fEjgyBXt4tw1Bm2CPKcSZCOh8IXcPFvzn2s62JWDUFmP0N+kVNMr62QNmN3wNzpxMJYNr2vzXqLHPEtCTPHi5+yh2ZhZl5KJ21WZ+C8a6plasqbCNJR7N8ei6MSZlaNHEGQ28Z9eNtFChoy7EELjsGPkPo4nluONzQcYNYfaGb0kBkvwMrtp5WxhkEmc7iqHCOnJj7AsQfi9Rvd2H34XPyya2cSwsz8fSmZHCjCEdyjlEj49qzu+VEex5g1RynEIo0+196T24satrbdVQA5v1NnA1K5WDDrXR6r06n1zPDqUZYOW3AcrtEn+znxkD0t8UG11308p+P4XMToeA7pAm7LfptqTdqs7T3kKwAg/rVgwK4/nl3HeDPHwDEVOtqTjVZctKAhw5aCFi4S22YEksztzXPdpb558/DcDjfrFsxsVgfukAxbHMG3b982S/TVHYGklvj04Hqzj9843pgHbfN88/CbnZ0PtMZnI2naoKNwTFEP13U/kWjfq/CcD9wVN+7r0cJ1KGfSY2BbNpYvviIFDUvFN4JWivSCIuFq9SJUrhYw7uxgJoMpT3atQBCzRyv8kNG3QdxGgySV81yFxAcTcfAaD+GR+KNxgny8+bjzka3cKCRtdypKLAuH0m5Elis7nwLnv8YLQrg2ccT5mHGjIKEwtLj1pXYOPfjpZosVXwxkl3iFXJeU9uzs1OFJXhBj8IAFhLjmCAurJoEkOctCioWcVaGTi4IEyT10WA58i7yYxeLSHl/MlqMEWbgXs5fCnkWFXTzvkcddQS1ch0xnE4ZIkC06UljQxIoIck3e0wxbl0Z+QJA0KdMFgy1nBgBsMKtOKRClZuN5t2+Dh2vsZxBs1iEFWgvqOO48f2gxAOPHup1dkuNcMmm7mNIxKlGYgWBxZOUgpaInXm8tboV7+AIAE8dUaD1EgtwOGAuaYhwhxvv0y/HmgJzX20XMJiffWw1IlMM8xqQLR46w5aHBb4MrPPakDlfwSDMF5Hwdfyu6vPg2ffig+Q7HuTryjkG2tMd21dUqhRniKO1ZHOBTqp7ZgnpGSXsMHHOZHgzVBexWlFvQIEiI8XOCIIO7cCV1CrBJHPgJXjeOLj7m2eEK2dRK2H4RNIScFPedWaEynN+p08aOqnD1H1ZuFgnXFLAhzMwhxzA4yH+qpC684ae6MKikPaEOvRwxH0Jusi5AH24VS8TxMEZMIQWO3ZC+TeLqHoDmrUOKXmxP7u6GLfbQhd+WOqcv7GB5UFZYJrW7fI7pnaFEgQM+5b3bqWNHo260pm234oQkrGaoSGYZZGNlfQp5BN4rhaMu71nN9PRksN3j04ealaIc8a3d1kUaYPN6DrB1w1V3e3cm38NVvT3J7rm3wWbpqCWrW25GByt1784tf0AXAoOgdjE/vFPn4Ds+svb7FCUM11QkM8Our4zj4gpxDJk4ghwxIWKhRrTsMMSzQ2uC/FwiQ6QRdnjAxb33hk8CUd3+EF5xNNucKgk/fRuue7/TxbaBhHd3eTMuWbDf0rSqhGuW+dw7Rt8sGLLguBpjiSVGlkXRsnt841ur9hhhtNtte+0CjcyfnKKqy2IDvXKX7lWspJP79luaDnm45oZtjNhS0VO5gKMkcAzogjUrGCn1HtfK7FgCvmoPFQWpq2mE4d3p6q4axlJjFz2lePS2I2lshotjxYVVYY9i2K2GDLKkHgWOYr8nF6O3PMNSHrBsJUY3JwbHZYsVreJrMqU+iqPcDZ7iAJA7XYJ8HUXSHhjA8T7nGCzI24bbxhXneEHPMaT0wzdSgQwJZ13JdeRxXsRkEi3jcipWDGPMlPp8nrHbtXNOXMKfTBY56GJli4drRZC3Oo/JMSRwzIV4Dq0UMeMyN+b1hDRuUdDod7akdEX2Zxth8QYP+vRx3Uh0RebhmgsyqZ+lKZsj050yrxCI8WdXgBUUF9ljzVGP8jB7JgSpH0etyVWFXiaxbtjUdChPedX1dyBIWZ9DluTYwvIe3uzWooyyHU+bCSQXGetJHEJBEytq1rHhI0MujuL43FjXIA1XOPYkegy7SCR56pG2jjGxsSe3iu3cyjgqgWalRzGGda0clMdBhhlMr8aLc8xkDLk4nW352TlutKp77DJAbNjAcU9Je4hjeBtcpKDIkhwHE2pUxnUuaNgbwn6KdWHGAAWZwfpzvBDTQ9SBhN+JYS7ewgQZFsZn5ehLqhx7sKmg55ja25PERbaQjCPI+uNxpE6FtCtsBBDWZPkgGYesMrw1bigMDT4bnc+qjIIMG8fnDDqFJE59K3I0GPb60Z68Iq5PTqwwkG3lcwyua42xwY1BKR/s0Z7ecANL5Lg9risMY6F1/RHp8DIz2IZMmTl+RpLEkUNjk3s6joN78mFCD3JL1m61UJZ/XBcWpg7mJYeAUfwZhWtsGI9vCUv9Q2TIBo49WBxmw+EzBDKclQtcjoyTLmL3QGDZgrggrgKRZALZVnbeE9SmBA+lvDSn226mjyf4Cnwmjon1kIFjBopD7FYUA3m6TJuzsi+jydFg2Big5T250CIdSlJLy9GGr7CNi/GURVPlcVQCdiDUMy9JutMy3maMHLHA1nbUU2CB1xQS4kwC3+wcdivCxSR56hxbMkqUMQqyGTlu42JlbcBXSfnKvRvl19dKoAmEgolwPh/u0U0L6CKKNceennWDHnuoOHQE7UGerp2Hg3NJmc3OZBQH2CO+5I29bXjBW0k2tkGMW61XLjVW1KfgrECNuI1i1PASYhYc22Ni1rNO3HQcE+uQ2e75bDievr9UOA5nuFnrI8164gj1t9V46QqMS5cuNTbevneLGFXQx1UMG3Xom3IFdXrURZp1zjGn0yN+d92gR7AaVhyWN4I1TtXDQUdSPgKOzRpH4c1fT7QQR0Njsb6trPkZWrfXo7DCkhqLFdMBtzF7jswhrutek/JCM1AcPiqXo41Ad49H1vyGKBzRrLUyWhUkVdS4AKCeRmNjY9u35c9f35bHt7gzjLHOBBV9xsMK1vVpT2JD0CN7FbRmLWTg2LNqH2lKgmSfzH/0hu1JhW0pqu+G8kmYOKYysWbVPYqCHGYcLVc+lrcupcBtOJNhQQWKlS2DXYu5OHFUGrlqPWgwEuVFZnz2kaYESP7xXN1Hh4bL8Evn6uaDYhIV1v+W4S+QYwtyXBerP+6NMlS+yJYrcUtybMS0xyg+NNqRhJ1lI6Kg1hBX7o/FsSnuUX2ZLfLeaPBYiuQflj9+PKcYqR5MMPjhY925oAo9qP9LzeOKHMGuMzqOyoum7ouWdFfGUQvXIsdH4+PmU0jWVY74K0aOHNy6waxZh+1YHJVr7677+PGDorXu+Q8P1XDUfe7jx48PK3hwFq8hXPfod/kqLxnnEv67Lcaidg1hZtx4+8SENE4lt7VlMx/KOApxRe9shOZT1rJZUcHFLwPIcw6a2vnQBeS6HobZF7gD+UPQ4AeKPhTVMzD0HJllA0ecJLxtseGjJMd6XCZl8oUUsHvMvjtWhKPeaQt+HF5b+ZmP9dWfQ2Bd5/BoQzZwoRUS/Vi3HDT6geKuIrtXwJVqxi3TGc7Rev1oORx5t8cwWsflZjPIdW7XeAbthp5jRu9rxDcbkjLpRByZIj+ygwTOLXfR5/Sdc7uVPnBhL7uSYcmtEaTdKopyOH7CQ9jNN8oAtVk4SF5mx8KDkpI/msyacVwXOUp7xww0oo/8gFqs6/qwC+a77CWI7IsKH2hjL3loDDPcjnjj9orVzuuS55GCHFstjvqzdpDMsocHMZpTXWg2awo0OrOBZALnDU8IEtyhg5aWsACjfVHh4wzuJdutOIKLZDMJ8tY9f6Uc6TAaK+HZOUgCeQjZZZj1KYRZBJGj/hWGt04WsO3aGsd6EEnGRNxCj4l17sy3Gm0DjQ3Htvpb5y3lyBzkiJUgoWBZRcbI8VCz63WR47qB4/ZeIXxGRtAhYwJpwVF15hXn4Z/wtteLi5b3jE60WDpI7OCFiCOA3jo0Rxn0j4ZgeLY4ziX3fMU4HhYLNJK1bwQ1LlrSSiTCEGh8loYdzIBdt2LpuG0RZYDjsPGlgV2fHY44sRDL9NgNeLHy1m2LIxVsOTb52xBji9V5oCODW+OLi9aGDdW3a9zVQ/PXFnLsGTa9tBG5Kv6xSiB9GLB77EH6ihi2ZLGaGU+XssDYkwhKvsXxRdk6AHHfuRU8BL3SJPoKDDq5JmhrKrSs4qxwxGw2s27PUdqzb/hY6PEWnoi0KJlPQ5Vc40jx/AW7CIRdjMUwJEZHwytE8VBZM2H5wsDV7u1JwbMUaNaKcUTDbrQ448OS46dGtGmXLsRglbIyiCdsAsVOvKnhuMNSkJikrwzCmzC8QkNbetJjyRLrwvCZ4di8DQ5yvYhhb4zbGrZkkX4vQqKdUHREu1FXWlpJiq4LjXjnBYt+mpakS5T2MI56v2DlHgvd4bMD0ifLqz09xQxbdpUZr4njok9aCZPlhUdGpBbf1iKT4oW/+/0NnzBFt4k0iZXx8QLEbEZxxdCQ7tGfnBbEsvBRsNtE8nOhDQKnoyIcIaPbk21akEaON240ukCQ4+NbrT5fwbVFnyNE13lM5etvUDyHHP1RwjJgb0EwhzBjsGqFo0GUBTTrbhx6jt26L7q7TwlscE6WC7b5I/nzcdkm0kjmcH3vgks7UWqRTkJynb8ApaUyO4YbihflsFUO2QNGDdF82Aqj0bixuvYxTgqrbhWdnuNpKRQM+zBRxLBHZLtIY5n33Lt0/jw/S8p1/vyFC1RUdn4Syp3zsnWzAt+xxS1yjx3FKdJaTIjW3aYRDndbj5prEwx77yhRzEOCTKwjjWR5JyQ8AqkBRmMj32lc32a8TbtNubOimnUJNbI3d9eOmQFeMdgm93pcCXcHd2V5e6WYIA/Hoaapv1Fufd1WrzKvb6hvu2G1s8Yy1ACcxcX2YRuMIkiq0weD3dUYBoKWPyurldnlkqfc4WKKtBOkfR/3xqdPN27csOtOYpN3ywwShD9eiJlDtRkkZrVKlKkaSDPL8sUYDs7XTU5OXZ+Vggn7SCOBIBvrKzp3pvidiNtceDKxeRZskZJH+6UM6is6Gh/fqI4cddS6ebxXEZaFEyjueicnJ52uqSmXwx4kecjzlZ4nVRRkA4CEIlyM2qAxqMszhyVuUkiTszivfj/cfWpD4aXLDDSK4bsgRqdzdHT2+pS3CEh63Y2mbezH5gjZaBsmmj5hMWRixEVW3VF6gU1PsDAuuz6Eg92nOMQIpJNosHu5C3fQeyVJ8k5NzQ7ag0Q7kl3mUHNsjhBr7mElviXxGhLKJvzyMNZcxkIlnJuVJye7lrvD3Z9rqLLc9TqdTlAjYByVpC2wbGk+nLBrUgW30LL/T3U4fltf39BGDbbxcR+Gmx7s7wLG9uFyVoBhmrnnnHSeAZK7894up/O6k1Echf/PFgWJta9sjtnH1yMu/0MnuYgH4SfC0hZg9B1mysU4Ls130WEUXRO74fBnorg7N+HF+1Q4wSmiFiVkOXi9BEh49XJnBfuvi4zbFy40sKkzbGtM+XxbWEMeZdbLoNjDMAbvz3m7wLXD8M53nx5K1Tt2zy3jcRgYXoDjLGBENY4ykLOj8/Z5pA+THz3IY3GkhbqyjCXjhQv4KTvRub0cisFEEF4GdtvDjnx+wutkw7vsOA2C3d27OObm5+YnvHVORtE9MQ/pjlu9dxQe6TF13bvcbBdqwi6INXqQx+LYSCqEgRU4fMD2kK99vacsMY60jrN5CXAGQDLvfaCgnJh37NZOgru7jrn5+fnl5Q8TXnCJDOGk88FCHr47igrUQD4CrgD2vjVHSEy2jCCPade3LrgYSYS46MIT8MuhmEiEW/DveP7e00MkJUWUzi6vdxlg7lYTIUrQ8RoBLk9M4EkpzknmTQBilxcgLsNL0AsSiLqmrk+5vHNB/b0mePMPs18C2fntiePMPU7S1XIYDvaUSXGkBd7I8S1t0gJIzuUlQZRwcV7vxPL86yrQRAsmgnfvTtBZM5jdvCclAkmvN49KzNNgghSH+zpKMg9OMqgyFPsxMkXtsvYrFE/D/f/rAhl1K92NoaekPSeChz4ZYvr4IEZC3e0bHMvL83lVlKQT78QECGjeTpxWTYmwSs+B9FCBhM/bRQDVged7ePMj4TmHQhHGMgjSKwkcpUG07Vl3vifBW/mGhgwoQsbedtsJ8x54J9rO4wTtFJuGSCi3CeHiT+hvdXHY4qK+MGSbCZyvmIMcY2gI7wkJw42jPxLFoWOJ4+6yNub5eP36NT8uj7DBeM3RLYP67i5/MOOjA7+YFg88nmfRaKR/cyKvCtKLyc6oWZJTeI81C5Ukwj5scl+4VYX8ESIO9s4BJcSZQclBLXCcGkOKh5KEbcg5APbI7YIICO/f1uBI8H7+501gxqBpw+PRPj84EFje/TBhPz4og764S8jRiLsMALlHdD5wRqLP4uy+vDgim3mHY5lIgvwG9SBRktevo+MMW9y6t6enBSdcXJdoicVJONKNLfwN5wklm4TYcrX6YGy5HvmmlOGhAa9ocXElKPUrACPK0POEL1/Afx7O0knuEjB9EKAp464yPiDAuxiIBRU6nR56lAdu7wKKPi+NvBx58uQJGgK8k1FPnKOUMNTMu82CxLPh6ApcPvVWMtrNosDd+8CvsUVoJ+LIe+e3L/AbW2DwVuFNXZ/SxvVZ/Mo1FCF8M/39Tzd9Q2DX7k3dWKDxaGFhc5PMnJBgRrT8waRAcYAdc350Zh8QPDg4AMN1by4gP4IojQBG+I+PEeC52R8llP355fyydN0Qaci0wUVeB03C1bh8LdLKiLowcGUFbykDlyxfQBd3Uo5UHWJK2XDhz3++jgOE5+HwXrxwuVzwj9vrRacNOoP/PXX7hpTxSBnaZ4/oBwsoGMHEvV6IubYgl6G4ey9aMAeYJ4TwESC+RIi6gTClIUTZF5WWKdK4jYL0wuW0XaDLggF2vMWHYoGgxz9Uh6OKEqP45Ta0BJfXi4HDq3tfUaRRMKIRePELC17vgjAePWL/AsRHC5v9TuTHrNy9GSGSk13eD4oozRgVgqjC/k0EyAgqOjRDVEZzc7s7Gu9zAkeMNCZBgoe8ABd4gWmEmRzxU+cBLzSeNM7oXGVbU1NTvb/tzxjh1HscD07DGBwkjPCOXo9I5KGetEvIUiO4QDIEhG5nNM5vqBWPgqrw2wvU1qLEEjwiDyncXd6lsMIwepTocYB/SWokhiP24+XLdvSW8DcLyxRpvJLJsK//uQFv53qv4QJYHNgXuDD8lyZSGxrvVaHfY17wd49h5KfTTLNBGK//uQ1MZPNl+xNlqCzRmNEhagiBoZMsUxkLDw7QwFkA52EZ8xuq8HhiHYXMKXqgPYJbArGNFBsv2/8GfxFxS+6+eP88cXRZGXaDv6FJKwFvtTU2GvK/KnNs8isYkd60ihEMZurP/8t/7Xr0byMqxiekFID5iEKKgLDf7QaRIGbmK+HfzQj7ucfjRP/X1aWl15ziQV+UAsoCfzCKxG6piBxfjvj4fQ2dm2DYGLCB2SNLw26gW8k0NYmdCbyxTNsnf/X12OT/L9e5Gqe1MYhvKThrv/9mROQ4IrmHhnybdNVxohSPo2+T2tllPnnZPsTCz9AC3ZjrwM1uRO9xOifVyoeXeAsLGCx4doNvgZtHYvTH1ihftuP9uOIgYITeF5lfwJdpjjRo2Bb3aa7a/IxFVt4A+YFrVLFo9oFjbICX8p8i0SGFI2Qd0T5OD/95BgEFEb58qZKWlPjtxks96EdKm+4XkPaBiaux+QHmhtKQhDe2PljIs3cB8xoWibkqLTDi8/dFINNyE8d+SHuuu66bIo1EEdt/ihwZxmnVN7J/6Nht8jDIURpp52Lsjysj6n76N0l6QhrU1No+tKBgRNb9j6QhxczBl26yQ24FD5ofAmrRIUkSYoj0N/4sVzfhTVKEzkY7QnbTn27i+/QCW47gwqe8eo55dsPrhlPj2HDrz1Oe64PTWoiBfwHjCw9h9Os4bqIle6CUAUTPpGaRoCJGDSOS8EDgGbIb6E2fvJQi+J5g1SK4QMk9w98tJwoef5H9qB8c8cIQJVpDm/AU2JNo8J83CHJ6ND+3YT1hXSOOzDl6pwd1HEfzbg/66SY/cYwPAcf2J9JVEADEU4jZf0NZSE/aDRQVMSoYKcgAJJLkIyPGl9xSI2jFaOac1cgThjLCHgEob3LqL33wsAvskeBJ4O28Putq8N9ooJpG6EMehhOHi7Lr3mnZNXOOasbDXaOUx1D9X8hNA8doH3BsZ54RnBYzcNBLRE+xXVpQMZJw41EWjPoiYL6SlDdyVFJqCX+Loo1ow1i1uPmbAXFniLJ9T7zPzdTInqXv4MK/ofGiFqS5lUMaKyuZDK52Hpcb/G2nwvFGfaNrceqF5B1kAYZAIsbrHi3a3Yz3/Q30KD0DM4WAQxpsR0fV5x6xFCPHSBFmgVR1lZSW1yuSM2vfZHGFeT2NJAa1fi2t6kdBQ6iOCKXoI0iAMBGkPZW+zHqC3zSkuWMlHOw5Ksewq8ORjg7YCs+NDoL354oclSakFxAD/6r4aODoe0IYVT+JICWybIHignh9hIVx20TiL1HDeo5PKEuSIqyc6UOlEckn/N0ZGQE/Egf/6O7HnwJIyJLimwaOTfzOHPIWsAt3NMPo6GiGz3GtnuvWqdh1Gy3OX0msrxw6JKoHB6elfH5ucGoRTOKTxtH9Em0vKjrE9hFwgW6zSUONQ86RGyL8C7lNPNqOcHQY8+QIKY2JuhcWXmCRpxo8PuhLeJjoJquLXiBmySjHR/AeXFMXyErrwWAzA4kcg+GtceEqasmxvlFenHqUCDavdGQyHcoSe1wLyZpKbFyL922+xDhpiCuoUCZQiNILj/QycRNGFhCGwLT/ZhIkuccnkT7FoCFp7+fdpHw7IsYUhzvDIbToA3xcnRyHFI7csINckEAyzNbQXChl2NXg2Ok/vzjuwhPhaXTAoDlY3RK3JuToHupjzNrb23WCjLRzk17QSGLmGB1SW2k4/QCJ5MgTA0hU6MunUJkssBbPAuhSacsNYULkg7/SSkxgCOYdFd+uhaEXqh7bcBoO95yiGsGykaMDDNtuX2EVObb5GxbRqoPhlRVhw0dCAqtuU5dctiFHrOx8ELMJI5JkNCNAuJ1T1ECiStxDalMS9RTFd0EH8hF+/VIih8dHBNWmksxjRuBWm52ULKKTVB534RGLO9f463TJi+09KEgczThT0lOOYVeB46dbEKtx1X1Yh3GEWsVNGu0myj36n7S3KyDbKRSwULNpwojZyIJAka43vvmS5UtKCg4PgVbdp6XpbtWwlXIlMsRdrBK7VLN2Y9N9U+NIAbMFjamZOHY08zOLShm2VJUgA7E6qHEMKztAzuu2zxNHTLoJIubH0Rm3YtlgaVpTl8Hr7+OyGdrsx47uIzJsFmmAHX8YDCRDWBJqTTbNsHFoD6M8rPb+9LNcaEHl2EAOEtfXgIdEjsyySmc+J+d4A1NHWiDRLGwqpBXObTpjaPMocsTA/JT6E3397SzU4MUSQhXkwkEfD9ZulvwdgOQg0vheKumMWpHPxDVLHkIXGNcqb9SfGFTQsHm0xnyArDyicqR7km3ReTDNKkfcXSXbbdCsFsdOfAdd7DwADSP5lAv68v4WchxCa26X3FHeu4YcHEtF9FqbPFovqFEmMiSUhnFEvYnVj6EaR7cgChBVtimadVSX4ywcoHuktwwfcgHbFBHNP6KDpFNimjtY/qgadmMtOf50o1HdStOs7eJKPJqC5FXfJbn3DJsSWF8/2uRNq35eXbdjcIgvPNLn4Kx026SZgmiUoKPWNg09jZeb8T5dE0NwkGS67iHdPBo5U3gu/FGUGXpc5agdRoaGrXAkw+6sJUfKuPiJkB3q9iMKMqZuE+gxgl7t0QJScyM1+OQpCnJoAbBFRZAAx6P4swM2z40Z9ibY95ABZES0YyWyCEa+qTY3NL+7QM+ANvDIreeonv6EmU9HWLkcV2Mt/SNu61R3dmlbXBO+KXgDjU27m6wClBbchNEL0DbZt9qH8KpEkKgaDA9D6CajbNr7APmgTCWdHCURG9ESAs2m8vmC2+l0K34Cnwif4cUQvQYwjr6bypLEBmVTdDPPH9FNFcbl4k3IE3Js0rwjheuwvRwxgYz3PX3STsj6QQgLm243Nl6Q4wLG4r7oppLW9bPGFl31gbLwAhMW9KQ6QUIO3mfoTXINcrOmJHyTYhUFbnSLbiZHsolNamLcVBd30s0vlYjNL6hlqkTmc0KO9W1KsCaOyi1+SY4mf9IWpwobrTryCKcI2LwCekjUhZsaW+5NN/CN9MV5SRhBOaogQXn415Iwz9MeNZj1kApPjdbU82YOFj1u9MUCF/wCs2swa7UxBtkw2/FHtSG/oMNSmY904lJmfEs58VPFyORoLAD+KwrymSThhAibstJCNl3QpjoDrWoHk0GRI4gUp7ScGsiX4CScPL44o6xtvsB7FbxBxnB6rt3kCQ/9BMku8KIwrkVrtnVyRHWQ6r7y8eKZz8k44pNOKQerhFfUzTFW3pFlkH3PNp3KBFfcE2UyGcKeI9Yz/UqbsC/uVlO8g0hEEGR/HvWjKpLkSEa8wGdRsW3u5Gw3WemCXsKDBZWWAilyhKeFB7hmaAEeGjjyzKetRhxv+NsWFxeV3ZrKAbQ9Ydmug9zmUedY4zevNV32sDw4qmTfEA1e0BpI9wLv8zgFORLH6BClzwduWjyGEy08yjj7uO1iVkPt3wU3VdJU4SAqgSNk4yzPIvfoMbZSJYVjWNipUtRBSidNeqZMJ36gUz5vE9yopoFLuHntMn6BkyYYPdw8+V5QOv3K5aKFChwj5OL4DJ+EPSJ3H283YuTfjLCUfYHn7n2EneR4E0JiU1xrO0Yp1MFgPzQkcpyjKkeeQTbUiGOT/7waZYRBpUyntT+9dw1Ieqh7QWpE9fWxPI6XG2LtwZJHvSAjzIYxTQKuavsbY0se52GoXBniMwlR1PQjslyF4xDLAvoOJiRMz1GrTTYctaMhcH9+7TjiwSmLIxZ7h1337Nt1965d+xHfAhUjhhx9m183PxONiKtOlfkXd1SYcNGKaozuLGPc7I9EKOiQj/X8B2uAYsd8k4fvqLO/3+3GH94ycmQuP6ztIsfQeb5WeThEazBr81b2qdLtYxCHipEsG1I5QzMcrTpKcozqBdmvRme2Sk+sYSC7PDgQepEKYpBjE05s0AyOc/OgjycFNKFzzX/ZkmNzh3AQjLxYdJJGOql7NJ4/Q0lPY7H2cVsb2ZiGERWJ5TZanNY2G6IFKQY5stRHW4Y6pDVvmU4xwYnr+o/UuSVUl2+yyVf676ZHmRj3mAtdpTAUD9QZl+8VuaqTrbM/bz7tIyFNFfckvBfZJ2BkIOMQpVUwjxbc2HDlGAVBHhgosbkutzI9009Ln6IGOXKQ/svXbrLeEXjof2lqunYNaerkqOMY1nNsrBFH/z0XuEfjngifqWFmNuprz+I6jFG+cJHWjuLacKp1TM5REaRxRUWezXMrYVuU7BAP3Qd/VGbbMM5p1Yu/6bJF48V0yBPtuq4Rx09YzLiClmZdfOC1xA37PqJKHaPED5bxGCgq3Qr9ggqCx0UYJUG6he44hnCwY1V1ly//i/qG2jSwzGc2Bl0149hglT0ys64vFpywPIx7TBtoOEp1HNAeEE5RF2kIpDpBM7TpjAsiZIat65sdkIgv+y+X3QiUTpMjhZkWww6dUtEaMsibpLSZGSuSuMD+QFljr5m0R18cQjkT6adNIpu0uBTXR8GHTYlHbMzW82r8QVkfxHXJdqmlIafMEYprKSG16J7RVXSOsomVhoAxEpm5ak1Svy1J8YkGF9mnTjYwN+qk0hvJATJ1bSP23akeisaN8aRIbWG+q0RN40w9huuRlXGxoqHOcbE8q4kwzjAgV8shGY0aOXKQ6ua2KCPV58zzOhu3avVFcck0S5z4n5Rl1368CdSIJcfbteqbQbj2bbG56zLrUIowkasKkKtlkUQIB3qOfRG3k9E5AC1qLQyWAnkiHnUPoeJZ46zGLj3+J50lb3HeWM3y8Fsu3Ma+KMaaYo3jNjazoGJED8lIRkpYtgVHdx4iTF7sBqkTCCReHrOEaI/pTmmQbdgPN5/XD3ZWu/qaOOLpCtpRkCzMNNi4RsT4LDKjXNkMH1evzhRByThG9akPTxDFZrn6zSh+03kg/k000t+Py57/UhKkzV1OWEO8RhzvEUdZ1/Lx2YcZ5hpFHjPq6O+fsZMlQDjQ/11ULVgAmfpdKAc30UHm+wmujn20HwZ+p60USOtwzf1VUy05ntcZ9tb4Ypt1WLsmRhgjR0IJmrHaRmzFkYUUHccoT3YwKz8w+oL+ckHWW4br2vZxya6viy1xXHNp5Y5V16gfiE+h+aJfGWaWcSXq6olBjqPn2M/pwhMRNdGsywV5W17cMh9ZW3JFxYk5nhenaHqs0x7VNRo5Cqq82i8OU52jb4rHaa2jhLmiTqXwvbzU7lY4Rg0c+3FpelGQjf5L1md6t47LncWW7p0071m8cOOCVmUnVoBjWa7RqMp//ucHDx5oHCOm9FErtFX3iBtVD0S8Edoe0zxEHCMCR6fyuJ4SIG3cI7UfbxdrBp6I43nkiG5SeWrkeN7ONUbsOcK/OowmjgfaCQyCAS8oP3A6H6AAI0/4WvF4lDh6dO4Rx4N4CdPGLHzFJlzXaP66njg2+IV2RWJl3IJj2zOza9RxpA8PdIYdMXIkCk6efG9C9ggWjOsetT+L4j4IGlfjHvhaEKv2uA88xUC2oVlD9mg8IQXD9YXacYRUa/EeOBU10ljb9c2iGJV88p+vXrXnGBVQRJW1pLicWff9uPTyCe4B2aTvq1Fe/GMG8r/ZgORm3TMiBRPmMNNZq7rw3vmtC/42XGbPBUnltRXHSOkhhmy4XIHjgY4j2Gv/S7azWM8RfjDEOOKCSCHQaO4Rx1XcwPOvliCxmJHl5gRkHT6jeyyxkPSE63tu834u95C4BMAcr28WcY46ji+sBRlnc3saLh/fUThk5Oh+qWxmjQqBJtqvH1G7yqaBnS+PN2CUxRK7jIXN1dj3QU/PeyTUXjLOIpTH8cULEaQtRzJfxtFn5LjJt6z3xz0P8OsDk1mrIC1qbbpHnjyinKtoNOtacmQZVQMugmRNEte4YVU4TWppkdPeSc7oMIog42Sm/WoOGFF2YG7qOMJPuB5fsgySu2UzRxuQjSTHcCve2kAnxxG59uvD+UwNVNkueG7sU5gWXLbFSztIVtNQpLlqwTFipbqXT+H90dHpVzb7E3mebFlwtAR5uwHlKOH5b/pUHIvC2u9XYJYNLnJqaySB68LNFlCGg+SNn/6rV5Ww7RQ4HkQszBplF9XDiWi7/ZVAA3//oL88kH7l5hyG+7FiD7ezxM7hKu2/ridFbq1YTXOV5SA5R4R4VW/YESPHqLJN/WW/kWO0Xf2Jx6lwtJAjB/mvApxb/ttXVIzifQV7MMqU3PBarfMACOT4omSR+Fwux0ESx3++elXTo8rRI4YZLSjDiJg4cqk2k4OkN8COI29aCBdwJYkMt3yyePexRGJE2jqlfZoKSAg2476t8UXTfFAZDpIVNajJmav9LOK8UJcICByjmCQqO9RNHNVITg6S94mc/bYgb4q54x+2gOL5/96q9XGhrHH45PHxxa17xaNMdc+daTuP0wxQKjY0HCuDVFtoPHJHLMK1pjnFCxoScX44T1TlaCNHll+2aZb9yf+HK5f+nz+gVXOIIMUCuyPUpVuf/KfFEaP0BZpnuODXv3vlZpAqSp4AWXBUixl2BI+Jo69ZdZDP+vncgh1HgyBpXCCMCTzeMSz5+J0GLzSWvvhqnst1g2wbt7kaV2Y1xcsqDSOGpm7ElPaI7pFnN/qChnNUHaSnCEcU5L+JQmjEgN06gqc7EkTlToOlDgOoMkd0krfxPsWyq/GGbrIYtxZWwpF3dSOmtEfIekYM5TX+ugqZMdZnnqYBlbYYaW74721RpNnakvkd3s5fuoV4b/hPmSO+cQ1YJOpzn6ayHaTKkcYLhaNTU9CMdnTjkJFSVDV65iBLcMQO5d/FF3/rkiyM85foToPflnXhVeZIB71ecG3p75bYVoFh62YRI4xj1MJyFdu1TsQpt6S5WDuOkF5FzP6x8dJ5frjjJWzBNDSUe9lV54iSvG1awYGGXW6k4eU2LQAycBTNeqR5U18WskT8pfrDOM7FFuF4NRp/dk1fpuj8YH059lw7jn6L6fIKDFsnTBTkgcYRuESEg6Lc8aiJo4K5WYqzY6ii/cXzHoMI+I3y6usbv63ommvB0X/jW1ODtBLD1sZVheNVtUehHTGKpuvst07EWVJUhOMLy7Tn+KMmHK3GcQQZifwz2XWkf4aqRZ1Zm8pC4iwpCST+NML+WGfO3Khn+mcgWv/xS+NIqfiz4wlS5Ygzq4JZP4lacPxbsxaFnuGqSIEjuEQMXpQKzFC0vvXl6bHtWIYN4eaAc6T+jVsw63YrjqrdN1OzPCJwvMo4KoOiTNMXx/GYhh15QZJi0ox7BLM2lTO6RJwFGoolejmqKRXI8Z7/i9Nj27EFqXDUt8zsOPYrx/6z6hu+E50xcsQPEPo910qe6ngW9VhqGttuIMcZ/okYZZolU3J4FRNxhSMGmpl+7iB1Ng2fUeldRTmeHsc/+r8/OBZIdd2Y0OrRHCDG35kXrB5/wRJxxpFVNIzjC6NvnInQjpqmL5Bjk/8vk8cCqbpVzlExXKpYkONVpRyf4YkR5+jGcoccJFvzK1BEZ/HsL18ix8uXf8TzvisHqS1jjLJorHJ8CoCv6peiYre8eYT/3Bf3ROlt0P+SwtH5v/0/fXkc/+T//eR75wfnQYVRW1yeHKc+rXIDGSoL9XyuIjVFkJgXxSNYRDPaWLMrGHGJQN13/u++OI6X/d+BHCfwto8HFeTjUXERL4pIlRuMGbadSZe1x6OoWfbzp/gWXCWYM+r0j4pxcueH8jbKnSmOJMeu8MTEhPN9uST5fkN9CoSFHzfsiEnZM/g3bqZGXGwBgZ5xVHgTTgoyXXWTIMgvrS78o/9PIMfXwddekOQkkYyWBdGwv0EEiWWhZbKpqNGD+RKZ+syMNiuJhUy870HY+76qgpROyaxBjt5wd/cygsR7Ph7o9ghZM6TNWmZ3yUFKVhwjlEGOoPN8RmnnTER8L2boNwBjd3C3bqeagjwVjt/5vwc5OvAWoXRjKO+DSSJJm7BtIVr8kIXvJ5hlU903Y/HzKJ5gD7kjz96FgE96xB1z7u5wd9D7vq6KgjwVjpdvOUGOdA97B7vFltfrnHR6lI2WHr5xK4r3FtS2X1sKNuohxRXh+KRZinA1KqY+o8kVxs9BvJe9Y2en7seqgZROxapBjk52f9Hw3IRXRek8EHf/C8NjvMehMJ55sIgeaf6bHUe0+GcejZ1i2IxiX/8cYgSQXZN1339JHH+6/CPIcUK5Ietu3qveDtPrxdNjtJsfqEK0xxjB3AZiMs3OWHL8W1TvEtVlueQrfg4zjOHg/ORO3b0vyK4pyNQJN7Sdn/AKNxYFmgt4n75+J56qY9rDbgXSE99kabhNxhk3nAzyTDlGIO7e5RRx1KEgv/tSOP6Jcp554f7A4d15411a8f5vE4YzVIpm50PNEXuOUXNlSTdSi0gCxXDwQxVTH6n2akSr9oYNt1jenV823PL2rrNMObLsxx21LjCjpsITv0MHBHiXd8Pi2KVc/PKXwfGnH51qkDGgdMyLMBfi5WK0tN4SvwwmnV/OvxYxYuqz88OPP/3xS+B42f8/JiHIBHftbga+uzs3N/f69es5gxxLsfFEo+V33uLxBxPzy8t35/Uc5ycnq5VD1ppjm//HOtCjw/7u89xZTVSCEVPNinpG3vnlPN6GPKwfdVXrVpySf+zqLj7CBjlGqjmQI7+fu1mPVaoNax+vv8N4bQw0Roy7eu8YqTLHPvc849itA1nFxOcU8sc/YTnz/q6li1Q4zuvkGKk6xwec464hzNT9v5d/+lI4UiKOGeSuvRy9ghwjVR+eeJRhnNgVML6e/KLycCwM/wVAOouAXBbkWH2MIMiDCcZxTsWI2SMEmWpNLZxOv8f/HSaR80FbOeow1iDQ9C0wjq9VjOEuKK9/vPwl9XsUkJN3bYLNMh3nFqWUMCqcllLNQEN5z8S8DmMVZ7pOaX7mjwykd9eKJMnRwzFGI9Gqx20MNMTx53nuG3cR4/dVnDA8rXlXeOvBR76vWw6bSVKwPtATrC5MKK7FBDL4uo4wfnnzhajIWz/grb+75o0kd71Wx7za0jwOWCivJ9TEJxj27lQb4ymuk4JX/T3Y9vvJruXdYFCXO5bF8ST6pEADhn33591g9wcoVHeq1ug5dY6YkP/ISNZ57+6CLDhHL015Rcsdxw40qMj8vJco/vBjdTGeKkd86d/9gPHm/Xtnl3e+Owgsw6+d7w+iFXA8Dkte0Ux4odQHimDT1VyTcuocGUnUJKJEWTrCwS6cOayQo2mytnSnwumFJ8InBYq3/Jd/8n/RHKG2weD9/Q8Kyy4vJOjf3ayUo55oaYHigh54Nhg/fOevuhg/A0dOEjzlD05nHaHc+d5/Ao4UgcppneE79/u//FgTip+DI1o3K8dQls6dnbpbJ+NovHGAlZlH49H/9JfLCPFP39Xkkj4LR1Tld4Ty3//0/Q//44+0z/2EI6Id9iicZKowjeKqenwDf6rR9XwujoIs+XkB1RkRtdcRUbXKzly5eflyDa/lc3JEWf7x8p9+ZJu9ojUckaruJTyDHPlc2L9qS3pqxtHzFXD8Y405Rr8KjuwckN84VkGR0d84VmP82ylwjP63Km4nPKMcb3lqzzF+rZr7t84mxxMXNOUE7N84VkWQnt84VofjX74Ojs9qr8dfe5ypfWEYfcZvcvwbx5MND5559MevgaOn9hx/7Xbd5r9ca44WZ3D9GuNMzQvsr6MupFur/Max+o2KZ8+eVZvjza+B4z1jgV19jrqjR3+tHP0eY+LzrAZxpu3Xz1EraJ5xu35WTVmyG8X5vxKOz7hnfCaOL6JtdqY4GgmqJE/IFJcFHji/q2U5c8b0WHoUMV2rVZT0TaSIZyj89KvnyAvDZ8cF+eyZdjSI8Xt9fXEnntZT2ys4axyjJTGaWXLRCRxVhvF4xP3zfLdjcucr41jB0EKx/nwQjrUvHu135++Hg8Hg2/lqbjk6wxzbkGNc0JXu8BQctur06H6NU0WGC9IuuysUnaBQ94P/8q+fI2tUcHcmDBNRUyQXIKqPEHe6BYbwL5559P1XwhFPkPAcoC0Ko185X0qEKsLkEAXWUffPc5yhep8y5Pinr8GuwbKdzsmu+fn5+/ob/eJpHPfnpPyQe9Pdz46OEVnqMfb1RcEh6hkyTXZV93C9M8vxMp6+UBfml60bItTdOWmhP8pZAkYEqEEEc543QqSHC+JJPT9+DfH6J/+/OyfrdsPFByPTTSyJZDwuQPROLC/vBsMavrB6ctRuzdPHM2PXt5yTzlIcNZr38+54nwjRTZuMJohj2Cjq4OsqHz56djle9iPHYLjMgSg3ozz+RBlEHFyPxt9e/oo41k1OzpXNkVA6nM6DiNO9kOcQYXSTczT9qvf9zvdfC8cfJifnK+EYDs6/f1+3vKxBhBG2fASWPn73G0drjl7ne68IMZ9ftuHY9b66h1yfbY7vlyuy67Dz/XtnvhyOkPY4v6tp1+wMcfzLzvu7wcrMetLAUVq2/k1Ie5y3vo6857L/+533ExVx9CLHCR1Ha8cQnJuc/MH/1XCse++tyD/WAcfJsjjO1z7t+WI5osjwTgMixwkbjhPvvxqO3/m/d1bG0fu+bI6175qdIT1enqzMrrveTzrBrpfL4NhV+/Tx7HD80+T7rvI5Bh07k07g6F2W2JiYkOw4srTna9Hjd873XRWY9cT7yd//fhI4qufr2nLsBo4/1jh9PDscf3RO1lXAsWty8jJyzGsHFf9szTHomKx9+nhWOP5EHHfLxri7szP5f/1+0ilynLDhOD85+ftam/WZ6T9W0IDkR6j/3o8cl0tzvPt+8oevh6O/Io4UgsviiMe3Tn7/VXGcfB0sN1pP4oSLmWPYmqPz6+FYUeOMVSj+v5TDkTLNP9U6fTxDHH+PjbPuMpNwPCG4XI51k8Dxp6+J493yODKzvowcu+w4Kufkd4d3wfH++1fE8Xu69VQZGLuVxgNyzFtx7BaO6gyfSvp4ljjulMkRPR41HoCjc6Ikx1NJH88Qx8tOJ94KzVKB3fyDprAfIXJcNnPsDptugoEV5NfDkVacRfO7opgEduLgZk3kTRwN97iZy/teHBxc8/u/Ko7PHj+VdkV2lueNM7P+rhTHcPdu3vf08eNIrbcqnDGO9fG4By7bne8OF7/FCjNriMB/nHRO6ji+1pTcfT//CB7t6dOndMLHV6RH3NIF1/348aZUlGRYvT3Zj07npFfHUTBnBvHpY+TY9LVx7H9amiSYNavzfvKDXYscvXgXiu5dx9Dm48cKxcePn31tHG9yjozkrh1JbtaUuus4fphwIMOnnCF7oKeP4/F429fGcebpYwWAe2iOH3evP/wezJq3wS5To4LuKUl3k/S63W6B4VMuyFrvvD5jHGnrh8oRST7ezM/tGlnudncpbTCmRyKIt+N8MTOjZ8g49td65/WZ0yMe7vpURIEoH+UduzpFOpzabMu1eF8/IHzx4sXMCxxWHGe+Oo5NxNFgl2iom4+G8vNzc7s4uiecWnkCHKMcoZnjYxrI8drXx/Gx0cEJRJ7iTpBNMR0kji8sOT7m4+nppOFniSMm4o+fWpIU2HiENKYp3ucpxTH61emRJeKK+GyGLmyUybHpK+PIEsjHRUhyMxU4xkWOWrKjDc9XyXFGQGBJUicvK46PDaPWB1OcQY7X9BzNKFlW3WbP0Qjx1NLHs8YxakJRLBssg+PMV8hRSXxsQRrco5Fjv5kjusfTSHvOGkfPY6uhcdRH39IcwaxPJcycKY5tdhxVlI/jRo6e4hxffI0c8RRxCx/HKKpR45boUHUcHz+1co9fH0dMxOMzNnK0ihqGutDi76Kn0zU7Yxxv0sEIj5/aGrehyCvJ8enXybHpJpL0vLAFaSjyDP0eM0b8g3j9V8eR5ZBo29ZeErPwej3HeNRWj08fz9DBCw1fI0c6OAXgPH5qkVS/MCTV1/AsgOiMDccZOn3hZpP/q+Tor7/JToZ68VislvHzmWcGPTZdo1MVolEjx6eP++mUPXaXuK+TI7dtRDnTryWCTF3xm20Gj0pnK+CBXNfVds/jFxH2y55r9f6vmCPozKM7sSyqfnnTBObaTX4GFfxqZGZmhh2aecoUzyhHQnnTdNDZTWswTTc97NQU3RFep+QXzzpHhvKmR8Vy7VpT0V/1iAyvNbWd8os9wxxZ1GmiUQ72pms0mprqP8PrPOscv5Txq+JYrnR/4/ibHn/l4/8HGweJNCTjtWYAAAAASUVORK5CYII=", "suiko": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAAGiCAYAAACWHB8jAADTyUlEQVR42uy9eXwcd33//5pjZy9pV1qtbseWZVu27Mh3Yss5wAacgzgXEBMTf0vrpLSFpkCgHL9SylFovpDSptDjC/lSviYJpi0JJE1CKAkkxEewHR/xJce2fOhe7WpXe8zOzmfm98fMZzS72lu7kmzv5/HYh+XVanZ2duY5r/fNoLIqa2IxALB1ezN7pifAAMD+faIKgOT4E4ABHrzres9ZctEp+ggPwAbADYAF4ALQ6IsEHQCqAbQBqAfgAGABwOvPu/V/bQAEAJz+94zpDen+JACEAQwD8AEQAVwEcMLrdIcAHAcwtH5j69Dff+MtUfuzyTu/dp2NA4AFHbXqrp0DCjK8sLKu4BO+sq7e75/CLjPoGIABNt3R7BV9pBWAF8BSXyRYDWCuDjMHACeARh1gFlkinA43BgB4gQMAyBLJukOSSAr6AILGr6TFCxxkiai8wEUBXAIwAOAEgLNep/sogEudc+eee+Kn+6NQJ/GOa19iYa67zlsBYgWAlXWFLXbr9mbm97/3MWdPJsiki5thsGF9gxdAJ4D5vkhwFYD5AJbois1DX5oOZDngZcDEBC2GgtF8PrrsyeemwLon3kMJGj+HYlDpNvX9UfV9YHTlmATIlPfq0+F4xOt0HwJwYIF3ztGdzx2Iph6ztets7P59It3/ChArAKysy+X77VhuY112MPv3iSnAY7BpS3Oz6CNLfZHgtQCup+ADUJMKORPcFAAKBQsvcPQcYlx2MBRWNi+H0LCfEVg3bF4OVhaw2BlYbRbt73gGvIWFYGH0vZmAE8dpu8mw2u84dmKvZQCMotvCigpCGKggkBIqxBiBlFAghWXEFUD0EVVSgmooBlWWCIUjmwpHExgvAfg9gNMA9nud7td37xkeNB+29iUWvqIOKwCsrMvDrJXNX/WG7oaFANb5IsFuAOt0ZVdlhp0OCVWHnKqrNMZlB+Nq8DAAIDhYVNv5JIgx4MBxKhiWgaoDi4KKYyfApbIp/ypTYwiFZCoozcAkcSCekBEKJSCFZQSHJ4GRKkYmBYpBAPsA/NLrdP/69d/tOsJx7zbvMLd1ezMqMKwAsLJmgXnbvsTCnj2ZMKA3Mvqf/F13fPx6XyR4G4D3AVgBwJYCO0PR8QLHUtBZWaCqVoDNzkGwMOA5Nglu5kXixe0wVXr5As68KDjNv1cVNe3rVVaLsqSueByIRCVEwhLCERWhYb/iDxJVEomqXxucflzonxwD8IrX6X5hgXfO7p3PHQhVYFgBYGXN4Pe3dp2N0/1TCgA8+YN7+e898Ua3LxK8G8DtAJakAI8INk7VVR3ravAwVNHZ7BysFl4DE88kgU0FAQPO+LdcwMsHfqVaqWAkChCJyggGRApE1R8kig5EPkUd9gH4H6/T/bMF3jmv7nzuwDjdztp1Nn6yy6GyKgCsrDKpPQYbuhuW+SLBDwH4IIBlJuipAIjDJRjqrtrFw+WyGMoOAGSiZDhBuKJ3slDgTTf80q1UpRgKa0D0nZfhiwSVaEhSdHOZNanDSwBe9Drdu17/3a5XOe7d9GBy1J1QOWUrAKysKX5XW7c3s7t2DhgX1PYta2rP+C7d5YsE7wewUZaIJRV6Xqebdc21oLbaAoeDA8+xSbCTEhOQogGJqcBvKtCbLgBmgp/x3iZcmf2K8TgQDMUxOirh0nm/KktEkUTCCDbtVToM3/I63TsB/MfuPUOX6A1r05YWvPJcfwWEFQBWVpHgIya1t9IXCT4AYCuAObJEqHkrm6FX77HCauENEzYb7DKfIIVBsBQAnEn4pYNgOpOZKMDoqAFDqgw5wcbR1J4AgJ94ne4f7N4zfFC3hum7V0BYAWBl5VpbtzdzFHyE/Ia96catd/giwYcA3KYnGkMSCRFsHDxujq1v8jA19VY4HcIk6OULvFKYwFOF4GwF4KTPqW9LllX4AxL6TsUwGPArkkgUwcbxuiokAJ71Ot3/sHvP8O90EFZM4woAKyvT6lhu43qOaJJOj+Ru9UWCnwSwNkXtcXPmeZi6OgEuF28EKcxKbyrwmykVeLkAMJ0yDIVl9F2K4dJ5vxoNSQR68ERXhc94ne5Hd+8Z2gdoOYVpE9IrqwLAq3QZJhIhv2FuunHrNl8k+FkAK3TwKQDUpkYhSe2lg14FgNMHwEyqcGAggv5zo+rgkBY40c1jBcBOr9P9d7v3DJ2sgLACwMqaKN0iuo9vsy8S/BsA3Tr4iGDjGI+bY1vm18Fda4NgYbJCr5QQnE4Aljv6mw8EGaU078FD8xUODMbQ984wBockAoBzuAQAiAD4vtfpfowGS8wuj8qqAPCqM3c3dDde64sEvwLg3lTwtS5sgLdO8+0VAr5yqUAKOUKYyw6A2SDIlMErx7EaCPv7wjh5fBTRkEQEG8fpZrEPwN+vm7fsn3Y+dyCsX5MMKv7BCgCvFnN3+5Y1NfvOH/s8gIdlidh1UxdNjcKUwVcOAKYDHAXhbDZ/s4GQmQbccKxmGl84G8aZc5qPULBxvA7CHq/T/Te79ww/Dag0mVquXCYVAF5xx7x9iYU7ezIh691Xtvkiwa/JEmmnlRoOl8C1d3pR77GW7E3LDcCSHJgSwy9dbTCZBbqKY7WcwrPnxtF7ekTVlT4F4Utep/uzu/cMvV1RgxUAXmmLg95zb0N341JfJPh3ALbo5q4s2DiubVE90zrHnhViM20ClwOAU4Efxxb2+lJC0PzehWyX/l0oLOPMoTBNn1F10zjmdbr/evfe4W9DrajBcl+QlTU9NxoOAPn0F1dbGVn5vC8S/JEskS4xIhMiq5jbXM8tXulhPLq5mwovogAXLsRwoWcIvoFxCDYBLpcl74uO46YKwIkrnWVLfHCmqPwK/XOWQZo+qEWa0OrE+9Ntcqz2XLb3UVXtYbeyaJ5rg9vjYORYjA0GZcIwEERF2lzXyN+4uL1u7769QV/lWq0owMtymSN7G7obN/oiwW8BWEODHA6XwC1ZqkV2AUBOKOAtyYTx9cdw5pwf0ZBkPNfUKGDFujl5q8FyBUFmg9nLFQnkUinBQt4/03vSQMn5d8Zx6lSSWTzmdbo/sXvP8JOmapKKSVxRgJeH6jt2JEy2b1njFm2Bb4Ui0X9WiNoiRmSZ41lmQWcj23mtBzY7DzmhgOUYsBxj/CzGCE4fHcDZM0Ek4lp2hGDjYHVY0LrIC1cVPyMKsBgVyLAMGEZ7QJ34f6lV2HQpQbPKK/Q9Ux9UDQJAndeKugYnI0UMNegQFeneuka+6e53r3r1rWP90tp1Nr6/T65AsKIAZ/WNhaq+9/siwX+QJbJQb1Kg0uiuy2WZpProzyP+OHoODxmdmAUbh6ZaD1oX22GzF3bfmqr6S1WBxaq/ckZ4uSmY5fk61/gynzRESVaDPT3j6Dk6qAo2TuEFjgNw0Ot0/9HuPUOH9eTpil+wogBn19LvzuTBu9dVhYXRx0KR6D8oRPVIIpEdLoGb31HPtC/2wGrlklSfGX59l2I4cXAAHM+CyCqaGgUsvLYJ8xY6CoKIYGGmrPzSqUBVZaCqTOEqkCndvqh0VhwD8FPcbC6bkgdQDF+JMqHu8nmYFS0ANNRbUVXrYPyjMTYakmSGQauoSNsWt9ddOHIodLjI3aqsigIs27FkAZAN3Y3X+yLB78sSWW7O6Zvf2QSbXQNf0gVmYZPg13N0EIKNgyQSdHQ1IVNUuBzKz+zrU01D4tJVg0xHg9N8S9dKoc7kEm0vVZZNJceQYwExTnB43yUMDiUlUH+152j8y1DVSqpMRQHO+GKhebbUDd2NH/NFgrtkibTS1JalyxqZeR0eA3SpS1HUSfADgAWdjZg/31G0s7449acaSo8BazzSfugC9Eeh8FPZwm7PSgnkEGt6lNScZpIfTAH3DYWoEAQWc+bVQOUEdrh/XGUYKCzHbqxr5Dvv6V7zi4Mn+2RMdJiprAK/88qawtq6vZkDoDz5g3uFjuXW7/kiwX+VJWKTRKI0NQr8mvWt8LbYISeUtPCjCjAVfh0rGtE+v3pK1R/lXunK4Eomp5USwWcaV77vr7ITj3xuHETRzOnOJdVYvb6ZAcBFQ1ICwNbXzh5+adOWlgYApGO5rSJoKibw9C2aoLqhu7HVFwk+KUvkXZJIZABcR1eTkdCcCXzZ4NfaaCsJ/KZqBudWmfntYznN33KYw9MJX6bABOrhkTgOHxxENCTJeqrMKa/TvWX3nqHTlaTpCgCnZdEo3IbuxrW+SPC/ZInMlUSSEGycZfHiekP1Zb1Qywi/6er+UogfMN1UuVwXvzoFG2U6QDhV0hgzjvM8LqqigucZhMIy9r3RZ4Zgv9fpvnX3nqGjFQgWcEOpHIIpwe9OXyT4c1kiDXpSM79sZRNqvda84Dfij+PM8WFwPAtJJFi6rBGtrfaSKL+pRX/VjH6/Sa/MMxqcaaRmLp8Yo06+TfPQfH7035ny75SEMEx6GZLpmDAMA4WosNs4tF5TjchYhOYLukVF+tDi9rrX9u0NXqzkClYAWBbFvHV7M/e7V4JkQ3fjx32R4E5ZIlbd38ctWd4Eq5WFkmPYN29hEQolcOKtQQAwor1NrXbE44qRFjOVRZSpQZApAB/ZAGhOeDbDjFG0/2e60GmisapN6JwUoDD/m+lRTvCVnSxMbghyPIvmOW6MB8IUglU6BH+3b2+wtwLBiglc6mPFAIzSsdz6JVkiXwWgSCLB3OZ6dt4yR35mmR4JPvDmAGh7+7nN9ViwsiptGdxMmcFTNYWz+fxUNrOJl62DCzeDIbuZsCezuQdSB8Mf2T2GCwMjNE1m3Ot037Z7z9AbFXO4ogBLBz+GUTqWW/8ZwF/qTQzYjq4mdl6HM6fqM9QSx+DU4X4E/JKR5Nyxymv8rqRf7pS3V5wpnDPgwWR+pEtnYRlAYUqT6lLsMitLZRrPumwqkGEYqIoKhmHQeI0N4hjH+sfChGFgExXpg4vb616tmMO5v9fKykMlE/IbtaPL+mNZIn+qO56NSG8uf59Z/fVdimFwSGtq4HAJWNTVXLYdnw0pNOaUD/rIFfiQ0yguPsvvpnvxaR7TrQDNSpuqweUbajC3uZ6TRKLIEnH5IsEXNnQ3rty/T5TXrrPxlUu5ogCLUn4jo//JrO6+90lZItvMkd6m1sLgFwyI6Dk+Ao5nwfEslq1sgt0x0QihLF9wCZsgcJwKloVefDDxHMczYMxSRQXAMRkdLIbvL8euKUhWfWYFpqT5/UwrCbYESjGXbzSTGqRKsGGeDfEAx/jHworeSOEDi9vrXty3NzjYsdzGjQ7JlWTpVHVTWRmPDQuGIbry+wiFX8eKRtR7rHnDj64Dbw4YLa1oiVup/X7pVrmaoVL14Q9IcLl48Fb9dbKaOeqbomwKSXPhU1Ript/NxjWV8rh8VDOg+QUz+AQHvE73pt17hk6aZ9BUVsUEznjNr11n43T4fT8d/MRY/ucQb2Fx/ljUgF9To4BCTOdSmMJTMYfNNcGaO4ABwzKQE8DRvUHs+c0FHN53CaDiQu9OkJcJp+QPAzmLGTpdKxSWse+183jrd2NFm82Fwi/vk9ZkDnfdWIOmRoGTREJkiTT7IsEXN21pmdNzRKxUjFQAmH21L7Fw+/eJckeX9VFZIg+mgx+fZwsSmu83GPAD0Px+8zubki9svUxuuoBYLAQ5TgUhDHgLEInKOLTvvPG5Jj6MOgFCE+DMj0L9XZlANxO+wGBAxOCQhAsDI7jUHytoP6j/MtUnWgr4UQVo/CurWLNhLoWgLEuk7dJ5/8+33d7l7DkiKpVrX7doKocgea1dZ+OPHZbkjuW2v5Ql8jd6QwPL4sX1qK0VIElK3vADtEYHxw8PQ4xol8mSJfVweYSMsCuXL1AzX6e2bUVVYbGwGB2N48CbA4hENWVodViwcl0rBIGbKMdXC29/RX1fTEruX7a7N83Jm64rmuFYDA9HwTCAHI1hzryavN83o48wQ6ME8/HIF36pirC+2UiWlhkGrYORwKq7373qpxHOj9GhSnZM5S6QAj+9tvePATwKgA4qQk29FXKB/mPewmJoKJ5k+uYqkZvNKpC3chgYjOHA3j4jh9Hj5nDTu+fA6eAnXYSqUn5/O5/yb7mXq4qH1+mGJBL4gwShsFy0Gk0XTebY4pVfuuctFg6dq1vhcAm8Xqd+2+snjj7ec0Qka9dVTOGKAtTX1u3N3K9eGCMbuhvf54sEfyJLRJFEwi3obGQaG5Phpyjag82Q7ybLKliWQTgio+ftIRBZhWDjsHRVS353pTKpwKlUh1gsHC6cHsfxo0PGc631XqzsbgTLMiByhpI4Nf0jlzqkTULz6aEw3XdxwqsYHYlAEgkEuw31XmvJFCgFKc+oppb5TMHwMx9/i41DXZ0DPl+MlSWSYDl23eL2Ov++vcG9V3uOYAWA+nE4diRMNnQ3LvdFgi/q7awwt7mebZ1vz6j8MkFQUQDByuHssUEEg9opvaCzEZ46Ia+EaUVRZ1VaDM+xOH06jDM9I8ZzbYvqsXSlG1C1oEg+TREYljFM5HzN42LnfZRzOZ0WnD8fQiJOEBMlzGtzgy/RTrJQMySCM0mmsKqoeXf/IwkG9ioOdocVwwNhViGqIirSrYvb636zb2/w3NWcHlMBoN7MdNOWFs/gyNj/yBJplkSizG2u5+Ytc+Q0e1MBKMtat47RoIRL58dBZFVLeF5ck3e1yGxRgYzeY/PYmyGcPaM1bQC0jjUdC6qQkLQ64FzNEJLqgZnChyGlax8/k1BkGYBROAwPhcEwgKNKgNstlGDLavaTVFeChboWWFaDoKfWAo7hmYG+cTAMOFGRbrtlTeeTv/ldfxhGU9+r7+K/mhcDgHnyB/eyl877/1OWyAJJJHJTo8C1LrYX7PMzL1+vzxhotGC+p+y5foWsfFJiGHBQobVivzAwYrTr6lrTjLY5TohxkncrrHL4AskMG20t8xxwuARIIkH/udESgE9N8xmZpEfSDaXAOwDHqYjHgbkd1ZjbXM/q6TFN+y+dfpqQ3xjXQkUBXkVL838Q8nbvucdliWzVBxfx7Z0NeaskswKk6i8wnsDZU2MA9Jy/+YWpv3IqwHxMYZ5jIUoEb+/vgz9IwPEseIHDquta0NBgQyJBwBfamUD3+6lsYVUOGfefzexDm45KEZ5nIckcRofDkAjg9jjgdPJFwk+DHR02RR+lvqmweui5rlkwIsMWK9e+68fP2S5eivzqavQHslcz/LSIb8ODAD6hp7vw7Z1eOAoYO5lOJfp6fQC0UZbeNu+s/PzpVKCUUMFzLELjCex7Q4MfAPAChzXXN6OuzopEQntOLkCCmRULoxTf5DSf3Dk+AxTNj1KtxkarMbyq71SsYPBpre6T1V0xxzQvxUwY42GxcFjU1QzBxvGyRGRfJPi5Dd2NW/bvE+WrLUn6qgTg1u3NnJ7ucr0vEvyuLBECgGtbVI/aaktRpi9Vf2MjcQMcHjdX9PZmAogOGwd/QDJaddHPsO6GVriqLQb8jM+cJwRVRU1SLOYuyPnCsNiSOZQJiEQBPLUCPG6NF4MBP/wBKYd5riaZuxyrgmOndm5QEGaCIYVe0udPAK5aAdeubIAkElaWiOKLBP9905aWuXqZ3FXDhasRgOyunQPq9i1ranyR4I/1hqbM3Ob6SekuxajAkUG/lh4xBfU33f5CKaHCauExOCzi8MHBJPitWDcHDhuXEXaFKMFUs62QMjjz6/IxNPkCHlNZ8zubDBU4NBTPAb5M5vzUQZgJfhl/FwdaWqvQ0dXESiJRZYl4Lp33Pzky+p+micsVAF5pi1m7zsYCjLLv/LF/kSWySA96sFMNelDfXzr1x/Oz61wSLIzRIIEqv+HhMI4emFB+TbUerFw3Dwy4giBXqBos6MvTgUmUmW+JRX2QDfVWQwVeOu/XgkPsZLWX3zbVomGY7phynJo1UCUngPb51Ua5HIAbb9j4wN8BuGqSpK8qAK5dZ9NN34Y/liXyYRr0aF3YUJLt08jvVH1/01UbTOE3MBDB24eGtedEgrZF9eha74YKMqkRwiTwF9mm2ahbZYvzCfKY+UgwXS3z6yDYOMgSwblzUciiRJFdtI8vXwjmc0PJBkGOU83+QALgs9QfeDX0ELyaHJ5sf59MNnQ3dg4G/M8AYImsckuW1DN259S+Z55nEAlLOH8+DCKrqK+zoPUat/amRSas8Ra2LJHgVOV34WwYJ45NJDgv6GzEooVVeak+fgo96o2giIq8h4bTOSH0kM58grS281Ybh0sXw1CIinA4Do4VQBJxsBYegoUFW0TYOxM0jQTowsSlka+ZGl1WVQYOBwfOIWDgfAgMA4iK9L7F7XVP79sbDOIKzw+8WhQgA4B58O51gi8S/H8A7HqlB1NVK5TkDXznZSPvz9Xg0ZTcFEzqcqo/M/xOnUqu7sgXfoDm/yvUPM4VvcykCItlbelM5XQ1fdrzNitn1AdTF0IoxKD/fNQIjOQLulyKkZki9dOpQTkBtM1x0vxARZZIvS8S/BEhv9FdRleuP/CqUIB6fhMJC6NfNef7LeqqLcn2FQU4d2EUiTjR2l0tcINlmaLVn3F3KoMCJArSwm/x4nq0L6gqyt+nqCoUVc36eRmWMbpEpwoic9eTdN1PpjIMydwxhs0LcsXdX2l9MABYFBsamhnE4wzEKAFJxCHYrFrNtDI51y/f3D/j3Wg1TZG7m+59FAWob7UhPBam+YELdv34OWXf3uCrV3J+4BWvADuWU79f43pZIp+TREIEG8e1d5YmP4/nGYyOSkbHF6/TDZ5nSpL6Ug4VaLXwaeE3t71qSsGObOZwanfoQnx+pZgEl3+0N3VKU/6rqcEGXtD0hC8SRCzBwmJnYLEzCIUYDAxEjABJ3qk/Ofx7DFvqIVoqjWpzen7g32zobrxp/z5R3rq9+YoUS1c6AJmeIyJ2bL3O6osEv68rXqZtUT1TbechlQgwoWGtKahg41Dfbp21B8Nq4dF3fnxa4Wf4rdKYuvkq1hn2nOQBQy3SbzaDEzHtM5v/7T8fNdpn5esuMINwUrsxtviyuLTHmjCoq7Ni8eJ6Rs8PZHyR4P/bvmWNe9fOAfVK5MUVDcD2JRYOAHn9xNEvyhK5lqa81NUJkBIKhBLk26WmvjjsnKH+ZlMCtNXC49JQJC38okWOiOA5Nu9ASLqcPzME00U9OXZmZwEXCkPvPN6omQ4Opz+mvv4YQgEpY1VLKuzMic7pQKfmO4o0DQQz+QPntlcZ9cIA2vadP/Y9gFF0f2AFgJfD2rq9mTt7MiFv6G7skiXyeWr6pktPkRJKUWqQ5xmELiQmBT/Mvy+FGTzVtBgKv57DQ2nhV+zQpKKCICYQmoGY6vjXgFhgqHNGYDix3/UNdsMMlpRgxr8eG4kjlCE4kquyI92xLDa3MjVRmqY9EcJgwcoqOFwCJ0tEBvCRDd0NH7kSTeErFoBvHQ6AkN8wvkjwewAEADCbvoKFnQS+QiEoyyp8Ee1Ed7gEVLv4JNVXDgVYKAStFh7Dw+Ek+LUtqkfrvOopwa8UIEynZtInAqeLvs42IAI2KweXXXeLxDSz12JnskKwFIl2xfgCzfBLzfdUQeCwcejsagAATi+V+6dNW1qu2bVz4IqaJ3JFAnDr9mau54hIOlfd+oeyRG6SREIcLoGjpm8m2BVqEocDkpH24HW6C2qiMB0QpPCjSc4Ufu3zqxFPlLaWIh8/YLpHqikng4Gch88tc1rKVFdx26H8dzV4DD9gPMvXZLHrdeMByTDz0w2Rzzk4qUj1x3Fq1kR3mShobrKjbVE9I4lEBVB76bz/B2AYdev25ismLeZKjOwwx46Ese32Lk9/yP+MQlQ7kVV2yZJ6RrBzIPrJIlhYcByT9CjU/B3qleAfC0OwcWhZ7ILdykFRSmsCZ7xz5dhfwcLANxrH228NZYXfVAcl8RxbdLqPWbmkpsGktoaa+aTn7DtA909VgeHBsKYIVRscNSyUNPca+pwYJVBZBlYHp6niLMPkzdArlPmETBxLRVWgqLn/WFVY1NTyGBiIsNGQJFus3KLF7XXDL/334Jtbtzdzx46EL/sE6StOAXYst7EAlP2XTn9FlkiD3t2ZqaoVcpq71CTOxxSOxohh/vICh2o7Py1BD97C5myWoMFPwomjuZXfVOYFF2v+5jLbzDWx5WoUUJwyzK04XS4+Lz9gqjkcDcvg2DxHiBZxN6ABj1yljak+QZ5jsWK1kRqj+CLBRzd0N7ZdKabwFQXATVta2J4jItEDH38siUQRbByXKTXFbA4X6v8bD8lJ5m86tVdqIObbJSYUknHi6HBSY4NymL3FgDCTg392wa54KFI/oCQSww+Yz/L1xxDSIZh0vJSJHopmU7jQ9BeZKAXBz/x3dXVWwxSWJVLtiwT/GWDUjuW2y94UvqIAeOm8nwEY+CLBRwFYAKhti+oZGvDIBsF81SD9v+gjRuMD11xL5hNomlNh5IRitLSSRIKmWg86r8sMv1IEQagpnE9KjMqa/IGs2YfGZH1cDovuZ32TXgqZww+YDoLxePqUoKmAMFtbrHxWIkEwf74DDpfRNea2Dd0NH+k5IpLLPSp8xQCQBj42dDe8T5bIbekCH6VYNFAyE+ZvPvAzNzNtahSwYGXVlM3c0klYxviX5wEeaob8v8vbtVRVKxj5gKKPZIwEp1vDw+HstcApzWSzBUHSNUOdyg2us6uBmsKqLxJ8bNvtXXV6gvRlqwSvFAAyu3YOqHray9/SJ+fM85Rk46kAHY9NmL8ue+5gR6ngmCv6e/pocifnztWts+tbklUwCiDHCU6cDGPfaxcQCpMk4NGfzf9eLkCkuYvF+AENtRVTERgOgWPVKQ+TKsbvl80UbmqwoanWw0giUQA07r90+usAlK3bmy9bjlwRANQrPpTOVbfeJ0vkOkkkpKmx9OoP0GAnRZWMyc8zBcETB/uSKlLygV+pzN/CIAGMDMfQc3QQg0MSzhwKJwkIs8l7uSrBQvIB061QiEEoTACeSQvBXEGSVPXHlCjZw5Qgzeq9A/94Q3fjdbt2Dly2pvCVAEDm7MmEsn3LGiuAr0Bv0kb9MKVaZpCKPg00go2D4GDzhlupIUj/PXMonDTAaFFX8/Qd/CIurnBE1Y6djYOkBJOOy+UXCEmBhA5voyWaRHDq1IgxOjNfEAYDoqaY09QDZ6oNTqf+pvI9pS4VBFYLjwXzPYye68j6IsHvPPmDe9m3DgcqCnAmlt66Wznju/QRWSKLJZEoTY0Cm5r2MtVFfX/m6g/q/ytEPZbMmkwo4C0s+i7FMBjwG/uzYnXTtM0UoRcVA64ofxMvcAjFgKhIZlHNb3FHIrUsrtrFG58RAPxBgjPn/PCdzy8Sn4ipGPONG/Ar1gTOd3ZzviuekNEyz0Hb6BMAN3zviTfuu1wDIpc7AJn9+0Rlx9brbL5I8AsAVMHGMfVNnpKbvumUIDVz8oaWrE5ZBVK48RYWvv4Yek9PNDfo7GqArYBqFCmhFh0gMSuKQi8yqqCpQpLC0SvAEEnODXS5LOAFrU0+haAsEQwG/BgZ9OelBkMhBokEKUsT1Kne+FoXNkCwcYweEPnajq3X2S7HgMhlDUCq/l4/cfQBWSILJZEoHjfHlqrLczrwSeGJAIjAuqd94BFVfsGAOKmzi8tlKbhWuFg/IC2johdXvmpDltVJgYFQiJmS0pkd8Jsw4QGt4zbNB1ww34O77+0CL2jT46gazMc3GA5ECuqfmJqLWQ5fYDwho77OjqZaD6sHRBaeuHDhT3AZBkQuawDu3yeSB+9eJwD4zHSoPwCIKzACIDYvN+3pL7yFhRgjOHl81HiubVE9WuY5khRiOeGXesFNdWoczZVj2Cun87r5xhgcJljT3oYvP3w7OrqajFrhM+f8CEeyQzAUYiDHScFJz/SRz2CrfC2FVGuhdbHdrAK/sO32Lo9eIXLZfJGXLQD1iVXqa2cP30t9f+VSf0knpKn5aZVz+r9nOaHg3InBpCqP1jn2okzZTCd2uUDIsAxkoiAUS3dM1ctYASav1EAI9Rl3LAR23LUe3e+ea0Cw9/QIfOflrBAMByL5gzeDMzVfEFKVSM+JTOdGPCHD7bKibZHRN7ChNzD8SQCqnpVRAWCZ1Z/y4N3rOKr+6AknlXmUJL14eYGD1WYpDhZFqkbewuL8sWhSusuClVUlMvFLB8KMvih24j2oX8wMDYa9fKtA0i0rC2Ncpnn95UdX49Y7FxmWxGDAnxWChfoCpzKtTwWBu8oFq4WHlFCzWgkqCBobrbRvoOKLBB/e0N3YcvZkglwubLksAahHm5TjQ72bZYmskUSiNjUKHI28lWOlltMVGgAphembGvGd39lkqMKpfTYmaVh6+RYDMUYmASEU08qtUpOf6f8vVygKVdr5KIkEB872Gs/3vAN87N5luG/bSuO5wYDfSJWZqgqc6o0wGo9g4/JlOSEoJVQ4HQLmzDOSo92+SPDzAC6bllmXJQB37RxQwTDwRYKfoTejfBOSp3RypARApqSUClCBvIXFiD+eFPFdsrQONjtnBEWmAr8pw1mvA85dD6xmDBpRZWg2g4nCpO0Mw7EqGIWAUcisPk8ddm6S0jVD8P7NbUZwBNBSZWiEOJMKzGh268GOqZa/CRYGkaiMA2d784KgCoLWOXZDBQJ4cEN344JdOweUTVta2AoAS7w6lts4AOqG9Q1rZYm8WxKJ4nBNqD+VlO+iSA2ATNlczBOCYozg7Amf8f+2RfVw19qSEqKLVYHFmr6FzAMxK0AlLiZvh6aIpNl/jlUzqj+V5aCys9vVlOvGRCH45YdvT4Jgpnki0WhmMzjVvzeViK9gYTAwHMgLglJChdXCm1Wg3RcJ/n8A1Fee62cqACzxWrWiFgCj+iLBv9D3XzHX/DJc+S6K1AqQ6Vrpgh6lHplZMATlBCAnwKtE+znPRVNegIlabVkiOhi1JgmpEJx9vQGzL7qPNBUGAKLxCOav7kbHwskQ7FiIJAgOBvxpIRgJS5MCRebgUykh6HBwGAkE84JgPCGnqsCPbOhuXIJ8xzFXAJj//u7aOUA2dDe0yRL5gCQSlaq/uKxgwTwvHHaubCrQnL9m5ct/6NIFPeYtc5RlXnChprDMcJAZLu2FmM0Ephe2yw60z682fhNL5H88LwfzF1CT1FowqA1Bmr+6Gys31qaF4B13LE3yCaa20krE1JwT/Gi0l8Jwqrl/IwHtnDdDMNP5o6tAFYDgiwS/CGDW9wy8rABIHau+SPAhAHYAxGUHE5cVzGl0AtDGVJZDBUoJJSkCXKqVqTqEVnqkBj2mq8ytGBDmMollMWHcRATWDVeV01C2WuNQzeTNBbfLwfxNXWMjcePnxvoluGnL3CQ1aPYJUjfLpfOT/YFSOJoEVp5jM0JuqjmA9Kb46pFjBgQdNi6jBZGiArdu6G7s7DkiKp94ZAFbAeDUF7Nr54Cy7fYutyyRP6L772rwoNrOY+PyZdO2Iy47SjJTOJs/MBRK4My5iQtgwXyPEfTIbJXO6BTxrCqQ57Vobyim+VHdDRzWtLdNmFFKsvl4eai8XKbwRLAsVc057K1o7VqSFoK3rFtj5AmmBkXSBUM4Ti1ZlUcq1AQLg3hCNqLYNy+7Fk4Hn/Zc01UgdF+goJWnMurIcHTWqsDLBoB62Zu6/9LpDwJo0huesoKDxTUtniS5Xo4Vl5VJ6RulzDlMjY72vTPR0r5tUT28LfayAa7U6S+ZIBgJT8zCbZ1XnaSmRR9Jgl4ulVdeQDJ5vkZ7MAqBLEPfn+S/pcEy0UcgJQIpx712kl+w5x1g0/uuQdeKJqNsLtUfmC4YUkoImgNjFILUHwgAN3UuQ3NDbdq/a59fTVWgqqnAhiW7dg4os7VRwmUDwP37RDIy+p+sLJGPQ0989jrdmNPoxJr2Nhw42wsxRsoECBaMOHFRTzUFJhP8ZFlN6/drbLTmDb+ZVoGZFa7WBstQ0VVOQ00DE/7VfM3bfF9XPCQnd3hJB0hZViFY3bh52bVQWR6ymH7gebbGqKkQ7FgIPLBlPZoahbT+QCUupg2GlKLxKYWo+aZIYRgKT+Qirmlvw61rVsBh44wsBMHCYOPyZbRdFtFV4GcBqLt2DlQUYLFLT33BDRsfeBeAVTT4Ud9uNS4kqsjKFZwodQpMOj8gzzMZk53zhqllln6lcgKiTzPrBFuy+UtXQlJMyo4picorzleYOvXNDEJz81bt5kU/y4bFy3DzilUAGMimrle0Pb4sR/OCIA2K3PyepcZ5YPYHhkKMobJLUYudCrpMwY5IVEpK6KYmcXNDLRwODu4qFwCgc1mTWQVu27SlpR2zNCJ8WQBwzjyPCjCqLJFH6BnqdbqxYJ432Y8kF3YiqITkHTE2p8BYy3DUeJ5BJCwlJTu3d3oLam81G8zfdPmBDMtovj9dBXncXFY1rbI8NixeZsCLgtD8mJq6mwoITb9VVGxYPNn3bLU4Jz0XigHj4XHwrCtvCN6/uQ0bV6xENCRN8gdGo6Qs54IKAleVM+15wVtYRGLhSc+vaW/DpuXLjWtxTXubWQXaLp33/zkAde06WwWARSzulef6lQ3dDasA3JZp1KVZnmcDXlxWDFC6a21oaKiCo0DIqCX+HnmegSyrkzq81HusBZm0xai/ohOhVWL8S3/OtiJhyYii1zd5jAvd3cAZyhq8BQmFMwBitVQhoaQ3dVMhmEktpkIzf9PYbAJPjL0kiqb8xDiB0567DrvQm6U5TYb6A+c21xsQpaYwTSg3+/1K4QOMRglC4Qhs1vTbCo0nJqnAdGvewiRf4B9su72rYf8+kWCWdYq5THyADPS8IhaA6nFzhvpL92VQyJkfAOCsEjCn0YmlCxqwYJ4Xt65ZgY3Ll+UFDqpeeIEri5nddyqWNNCoEL/fTKlAnmMB3pIMwjRJ0YkEMebjSiIxAiAdC/NoEZ8lydqsEDP5BOnzqb/LZBrTgAZ1S8iipP9fe3As4LA64a5ypTXjS7Ea65cYEOxYCKzfqM13kSVidCMKhSZK3txVLlgsHOIJGQy4gkBo7ggkJVS43QJcVU7jJlTsueGwOuF1uqkKrO0NDP+RrgJnVTCEn+Xk4wAoG7obVg4G/PdQ9edt8056oavKCQxFEJc1P6BgYWGzc3A6eDisTkOap64DZ3sx4o+nhRrdRiiUmNTCif6+FOpvaCg+Jb9fqXw/+Z7sPMciKqo4sz8IdwOHuXOt6XMB5QTAWxCNTkQyBRuX5Led1FHHBLw17W3YfSqi+0e5JEglFE7zKoGDhSVJPrfUZWH1XEOFSw9Y3gKG1eqOVZaH0+qcZOIVsuKJydaILBFELwaAxvwheMNt5/DGi4NY096Gd1YO4eDeAYQEDsKwlkYUT8gQLBM+yANne41MiGwNDJLNdd74PlI/50sHDk96PW9h8862qG+3whcRWFkiqg/Bhx68e913fvDsPskkqysAzMfi1GsLOQCEFzgsXdBgqD+z3yGdbyLXGhgOQGDSfxdulxWRqJQWfOYUmGJBmMnvR03iQrpN8xZ2yo0RcrU/MkPjzKEoLgyMwBER4G1phUN3C1CHvNksVuKiNvxIbw9v/l6ojzMU0/6W5y1Jv9+weBl2n3obsqiBCnICvE2YBKl8ukCme025VFwpVlX1fGy8pwZ9R09iK9bh5PEXIEsEPgThhkePvHJJn4VaRJFYGDJRkgAmWJicgiDVMkjnHpETStK1lyoo6PMulwVep5u9EBohvMC1Hx/qvRPAf6xdZ+P37xPlCgCzrE1bWljN99e4iqo/AJy57jf1C0j9f6Yvyfz7wHgCVp5LCzlXlRPBUDxZaZawDVY6v19ttaVg+NGT0uHgyjIEXUqocFXxIIpmzg6MSPBFgpqa048H9YcFwyFdBbIGLEMhxlDQC+Zr/j8a6bRa+KT3sVsm++Y2LL7WuLBnM7DM32upulvTXEFgD27q7MIv9x0AL3AYGfTD5aoFHM6cQiDbSnUhmdVktnMpGo+k3dbAcACvmvzx9e1WDAY46CrwTwDmP/bvE2dNrtasBeCl834GYBST+pMFG8e2z6+epP7MX6T5OfOXme7EyCTlaV2xdlEqaZOgS6H+zh+LTvL70d8VvD0LC3eVCwPDgSmrQLMC4DkW7qoJuEkJFb7zE23B6ps8cFVxGf2xoRgM81cSCTqXNU12XZggrrLptdzlAL4k3w1b2vlA81d340/+FDjcexT+IEEIHEIhBlW1hW+Lfk/0+0w1e/M51yJROcnsrq91YyQQBG9hEU/IhjXiclngcXPc4JCk8gL3rg3dDdfu3jP0NhU4FQCmWR3LbVzPEVHZ0N3YNRjw3wXN28N73Mn+IzPczLBLvXAK9f1ZeTbjBV2Sg57F70dL4nKVvaUqjuaGwpOz6fYpMM3+oFTo7D6l1YNK4WjSWNCaeiuslqoUgCqGP9Bs/jY1CllBpsRFWC21uJxXuc4ZAFi09hZ86iHgc19/1lCBNfVW2KyRvPctEgsnNVRIdXnka0FQMzieiEBOKJNuvGaXTH2TB4NDgwQA74sE/wDAZ3tPj7DGiVIBYPLqOSJS399fAOAlkciCjWPTNT01g2okEEQolJik8upr3ZMuvIHhQEb1RxsrpFV8JagCSfX7LZjvMfx+bpeW3E339/UTx4xOIvksJS5Chi3r3dtq4cFbYPiCcimsA2d7EQprDveL70ycs3PmeeCyI8n8MgMgMh4wzF9JJJi/vtUwf5OOqY27LGCWrwqViQKG5Uo+61hWQrjlvm78+Lm9OHp4EICAsZE4XNWWgsBHoVeKMQjxOJJuoqnnGgDU1FvhcAms7gP+8PYta/5m53MHIpgFwZDZCEAGANnQ3dgyGPDfpx8gjheSe/CZL7aL/X6Mx9L7VEf8cYz4h5NAOOH7YxGXFTCiYrQvt/KsoYJC4YieKF3a1KVUv19NvdWAn7mpw4GzvXnBz+2y5nVxFmtGBsMhrR50OJak/uprVDirazP6kMbGRIwMBgzI3X3j6rT79CyOQpZIQS2xioVYaoSWpntoz6sTEeY067XDbwG8BTzPwGpxZjye6bri8AIHxzVTV7c868JXP7Ue93z0We381lVgps8ejUcQicqTRh5MFXzmaHA2lwtVgaZgyJwzvkubATy7dXszu2vnAKkA0LTWrrNx+/eJsi8S/AiAagAyAN7rdMPKszhz3mfAaWQ0ZuT45crNG/HHIcb8BjDp8vX6MDgkYW5zPerbraivsyed2AzHAVkqTKSEUpAfMDXfr65OMIIeqfCj+5nNJyjLakaztVQAkRIqHLyS5PtrqvWgpiaz0ozEwob6kyWCptqJ5GeqAh3X1KIDAQMQNFdwKqCLJyJglImbYULhjDQYpNzKVJaDFA8az9N8wYynkp7zyCgyIuMBvHYsDKe9KrkaSQesqqhAGcZ8ykoIi9bego23HcarL54DIGBoKJ7k584GvpLtR0KB0yHAagX8ASmn39k7j8dggFP1YMj/AvDMmZ7AjPNm1gFw/z6RPPmDe7mvPP7CAwAgiYQVbBxccy2GiXr8zHCSv86c7JzOn0f/HY/Jxt9aeRbjIRmDQ5rC0hKdGyb5GPNZNCUmFwhHR6Ukv1/rwgbtM4kJXNPemBV+sqwiHJAQV4BqF29Ur5hrUcuhnkYCQQgWBmMBEb5IELygTTnzzuPB24SM/tWoSJKCHzSZF5iIADfWL8G5i3uMbRa6b5HxACwCi4SkHX+LwBogm1BMgJolMTg1IZomVU8yS1IqR3g9fzEyHsCeE0F0d64wvieeR9a8xFKsh7euwBuvXgCg9Q1snWPH7lPHEI9rHZrT+feS3A4ZUlwKUYDxhIx4IncFkpxQ4K61wePmOH+QMADet2lLS+srz/X3Qe/qPlO8mVWVIPoQFfV7T7yxWpZIl95dlqXVF2a1R8GWq/7X/Hvz3wHJM35dDR447Mk5aulyADOfUNkPZVxMJBW0L5jvMSBmTgZOB79IWMLoqAY/0TdRvyzL2lSuYuFGH7ngx6sEF9+ZiITzAgdnlZC2DpaqICkcTRv8oPBr7VoCnnVNMgvTpTKl7qMZfhRGFEilaJSarvY4tZqEPk/f97Vjb2P3qbcnwZKWrrnsQHVVdUlV4Ob3tyMa0s5RX38MYpwYydHZ4FeqEaiFLleDUR/sFH3kHt3im1EGzSoFSCNDvkjwHt0qMczfTFDLd1FoMBxnqD9zy6kqJzMJJvkOLcrHBO4/N5psPup+PymhGGZ3OviNjcQRHCZGBxqbl0vqeF2IYqVRu1B4Ik1BTih4NRxJCryY4QfAyPujSs3j5uDJMoBeFqWk3L9FXc1JuX+tXUsgpIn2pjYN3X3qmNFe6sBZWhmiPcfbLECapgjmn4uBYSrkMinA1OctLEFC5gyzW9+aoYDh5sDzjpKawn/+ZzfilV+dNxoltMxz5DR3ZwJ8dNXVCcacZB+C2wDmuzOdEzibAMicPZkgI6P/ya674f73U4Uq2Di4G6Z2Vzd3fKGlcqFhPySRGOpPUpmsznPjBFKC0Lrx57/6TsWSYNu62J4EV1eVMy/4FQJcuv/UF2ROqeEtrGG2UFNmJBA0Ul1oxJdeMBTetHmpq8EDWVbx2rG3jQRoMzxDMSR1Lrlj/SrD95cJfqmLgo6qPCkexGuH34JFYLXn8ugEk63hQSYzV2W5vLvMmF+bKXBifGcl7iEJAK2N1+OOO97CT586BD+AkeEYmpudJWuPVRLA6DdZOaHAZufMOYHXb+huWLZ7z9CxmTSDZ40JvGlLCwNAveuOj3cCWKabvwwvcBCq+KJU3yR4qYxhSlMg8QIHOlJzZDSWBL6pdHymfxsOJPv9WubXTYLZxX4/+i4mN4xMBz/RR2BlMwdFDpztxesnjuGlA4cxMBzAwHDAiCJT6GXz14TCchL8eE6bS+IPkqQ5KPU1GrxlomAkEMRIIIjXTxwz0i1o5xdZIli8uN4IfrR2LYHDOi8veJvhR1fq/0tt5maDptkEpj8ThYEMHiqbHGgxL9pGzebl8gJ/oSpwx45VcLiECStjBuGXz3hWPZWNAOB8keAHZ9oMnjUADA37WQDwRYK3Qa/7BcCkmr/Fgs+s8EIXEkYLJvP2VULwztkhvH7i2CTlWOgSLCziYvJcjznzPLDaLGnBqnATVSAUfuYLyICAqXsKzzMIhSM4cLYXLx04jIv9fgSDkmHe5gJeJue4cZzGtf03w0+7ITmMC02wMHDYOCQSBMFwSPNHnZ+IANDKDwo/WQllfG8rO2Gml3Nl6hCTDzBTfwZggJBhGeNBn6ddhGhbrGyfv3gVuBSSSDTlPRxLm4YzHX4/eq5REKYCUU4oqKsTjJxAAB988gf38nqbrKsbgNpBYCBL5D56zgk2ruTdl+OyYuSyOVyCEV228iwYTvOv9V6K4J2zQ3lPl5MSShLU6M+pfr+6OiFn2kwkLGUcjG3zcpO6p0SiEi72+w0TI/VuXGhLLfNFYi7VAzRF53W6J/mZjAYIHIvQeAK+SNDwFa5pbzPM3nQXf/RicipEPBHW3AN6b8BywC+XKZy//0gGDxmqohoPA5gsk/T/qlohazPUUqhAWSKTVGAx4JMTCnz9Mfj6YyVvyWazc3DZweq1/cu+98QbawGoMzUzZLYAkAOgbuhuWA5gjW7+GsnPpTB/KeSkqGJEzlx2JEWXza8rdrQmBZzZ78cLmt8vH/+deW5GqimVyfw1UmVKdLLyHIuRYa01f+oIUHcDl3H8Jc9PjH+URIKb37MUt9zXndP0o/7FnL0BS2z6lmqZzd9UEBrHzWUt22dKpwIZFN8YQ5ZVxBUtKDU2Es94XhV7vtU3eSDYOAUA44sEPwwAZ3oCzFULwPYlFjrv98P6PhFqnpa6+ShNRaHBDwq8Yvx7meBn9vsBwJKldXn5FMMBaZLJm2SeVhUesyrGBA6NJ3Dy+Ogk+PECB5cr80UliwmMDPqN1JcdO1YVrXosLMnoVys1DEsFQfP+cqyapMSKyS+digqcyoAklsQNs51CMJtazNf/R19XVSuAFzhqBt+7fcsap94ei7kaAcicPZkg227vspnMX5aapyVVf2E5KZet2pV/cCXfYehSQkny+7Utqjf8ftnUX1xMZDR9RZ/WANNhnx4rwWz6Uh+pLBFtHrLJ/5eqGsfGRKPu9+b3LEVr4/Ul93nN9kUhyCgEUkJN20i3XCrw5nfPM1Sgb1QqugJEVCbcLBSCqTX2U1GCKWbwNWd8l64DgK3bm9mrDoD6h1Z7A8M3AVigd31m58zzlFz9BYeJEfww9xVM8gnpg5KKCYAIFjZpni8tdcunXC6T6WtcWEWah4X4AQULg/7zUUO9Lpjv0VJ2dBO1vsmT9aKijRIcLgH3b24reF/tFpPD3PCw8ZcVAKnfUmWTu/lMRzuvj927zMizGzkbL8k2aW6mFJYnBTSmsnTrS9Etv5sAMDNhBs84AN86rDnBfZHgNv0ppanWU5A6y+uLNAU/BNtEYwWBUZNmh6TmA9LX0JXpji5YWIyOSsl+P73ULSf8cpi+6YIfpTaDBQuDcCBiqFePm8MDW9bj3IlB7YS1I6P5aw5+REMS1lzfjEVrb8lL/aV2hjG2aULg5agAgYnBRdOxZCWE+au70bWmGZJItO8iSkpWBxxXkgfbT2lfJ6LBjC4W3gsw6kxEg2cagEzPEZFs37KmRpbIHZJI4HAJXClNX8P8jSpJyowGP1KBl649fj4BkfGYPKnFVWrr/Fx32Yz7zxbXJLWQJSVU0OJ0asIeONuLwSFJS31h3VmbHwwNxY2bC018zvu9RYLLbSUULu3DvGh3G8HGJQ0+L9fiWRfu27jWcFkMDcWLmhRnY9Obu4mYWlRmQdp95Rm47AZ/rt12+7UeaKUzzFUDwPYlFg4As+/8sdsBeAEQr9PNlGPqmuibMH/T9RXMBL98l6/XZ/zcVOtBVa1gwC8bBLOpP5oCVO7oqGDRBrL7g9rg8jU3zMH9m9uw99U+o1ffNQtZY/BR0omsEoTGtTpnWSK4dmUDbrmv+4r3/WUK0pghmIiphvugFK2w8lGBG+9Zgo6uJs0XOOw3aoOLFg9s8o1altUpdRw3WyUC62b0jA9Pb2B4yUwwaUYBePZkQgEYFcD9Ov1Vm5crqfpLNX8dLgGCg83Lx5fPawQLi5Gz8UmlbqnQSwdBKaFkVH82L2cEP6w2S951ycXAb2Q4ZkTHPW4O921ci553YKTBeJ1uVNU6J4GPVwnAWwz1BwBb37tuSvlujFL+6G+5TN5Myt7rdKO2pnFa9sdhnYcdd6033DW+/sKjMDQpP9MNu1RmsM3LQbBx9ACuAoC162xXjQJkoI28nCNLZJMkEsbhEjhz09NymL809y8f0zcfMI7H5KSUl3QjOzNBUArLadWfOfnbYmembP5mM1uiUZLUoPVTD92OjoXAj5/bazx3zcLJ3wlVg2b1t3hx/ZTUH2u1TVJRl5MaTOo7qBDD6nA3cBkTwcuhAldurDVSYsw12YWYp5kGuscVTHn6IF1VTsYw132R4FoA2L9PVK8KANIByb5IcAsABwB5pszfbPCjsDNPgzPDM9X0rbbzWU1e8+9y+f5sXi4pMjoVcyPTCXv66IBxEm7a3G50baHBkHTqjypAs/qTRIIHtqwvWv2VctrebABiQlKMMrjWedVlqQLJtFJTYkIhuaRNUUsVDLHaLOAFI6t++cjof057U4QZA6DWBoeBbv5CsHFMuc1fGv2dSo2vLBEwegcfc0stXuBQ327Nu4FCNt+f6CNG5QdrtRU1JjNVAab+P9Xvt3hxvdGR+tnfHTR8V955mdNQzOqva0VT3uovJwzkxGUFvKQgiL7vodhExkA5k6AzrY/du8w4X0dHpdJ+Xj0YMiWlqp/TLrsR9Fi09aMP12GaAyEzBUBWN387ZImsl0Si8gLHltv8pY1VzQouVf2lS4MBktsZUeVmbnCaKa8wl38oq5IwBT+m4gM0qz9qvqT6/R7Yst5Qf4cPTqS+1DfYM20U549Fjf8Wq/7M3XfM+5mQFKPT82wEXabIL6DlAJpTYKZ7pCdNiTEHQ6JRUvD5Qsvh0prBJQqGmAIh1aKPdALTmxA9IwBsX2KhnV8+CMCCMkV/pbBsdH2m5tyk1+idYugjkzmsO2wnfH8hOSmthrbUyvmF611isuX90fczBz+KVYCpJyntz9Z/bsLvd/N7lhppGs/vfctQfy3z68CrWkUDr07sL8+xGPONG00P1qxvLcj3V4gvbLZBMN8VCmnfl8MlYOXG6R/1ybOupGDI2Ei8pGawVKK6c93fTQBAUoJLgOmtC54RANLGpwC26k1Jy2L+BoeJUZpVqs4y1JdoBmumtJpsJkSuVeWcevAj0x36/LEoQjEgGpJww8a5RtVGzzvAgTcHtJpfO+CutUFmuMkXjpyAeaDNX350dd7qj2ddGV/r4BVDXZofmZTXdAdLzMGOXJHq4DAxuudMVwQ49SZjDoZkKrPM5S7JJi6KNYPN1ozgYI3qlVAMqwEYbqUrEoAdy20ctMan62SJdAFQeYErefRXiiZ/Ofl0lsknEizYOISG/UlpL/mqP3rnzMf8NVd+lCIJmvr9fP1alxdZIpjbXI9b16wwXkPVHwC0zK8zBufQriJUCQ6MSAZAN21uz7vqo1DYpIJntq0kGMoJ7cFbIIsJSEoQkkjQutiesw9iuVZj/RKsWN2UVBlSCvhN1fdn/tnKs+AFjp7gC8EwenrcFQrAVSs0c0CfEM8AIIX6z3ItRlQMEzM1/aVof6LpT813KKr+8g2sqITkNH/pCIBS5f5Rv59vVDIanPICh4/vuMEwfdOpPwo+qswcvIKozBrmc1OjgE/9xY1lAUs+Cmw2QZF2q7awJKlc8poWz4ztE8+6jFnMskQKMoNzJd9TP2Cx8DO7hDAR9Oj49BdWCdAiwcyVCEBm184Bsu32rlpZIh/UTdOSqz9jHKOehgDknsmQKxVGtbFp20NR9ZdPuZxgYeE7r+UNmvdt0utS2l7JsjrlIIicUND3zrBxMdxxx1Ij6AFMRH6p+jNDz7z6LsUM9VeKji+hcCSnwrrcFh0JINi4aQ+ApDODmxq1lvkjg/4ZHYqU9txMjgR7977a10JZccUBkOb+7b90+kMA6gAQj5srafDDbPpS/x+gOVun4mNMB0iqXPNVf1JiIiUnU1MFLWmWzfsOmq9Px+z3W3ejVupGp7TRyC9Vf/UNdkRlvb05wxk/j42JRtpLR1cTvvj5+/OGX6rvj/5MZ9iaFw18zJYASKER6XBENTpiz0QAJNUM7lzdauQEijEyydxNlyY1nUuPBCvQpo21AcDW7c1XHgD37xOVB+9exwH4mNmELGXwI515Kdi4jJntRd+5BM7IZM9X/Zn7EWZK/M1lehQCQcP07Y8ZEdu5zfWTprS9dOCw0SWbRn4noK3CwSuQGS4p8LHjrvUlSe6VE0pSdN2An8KVrS1+MeateSATBWIqFOmQdhoga5lfh8b6JTNaF82zLsPPK0skqZTNXCGUCr1iO6IXc77qwUn6wnnA9EWCpw2AevBDOT7Uu1GWyGpJJEqpS99SAx/m/D81x+CpTPl/9HcMp6kjSdSqSrxONxiOKyipOp/Kj6m0vUpn+krhqFHVker3m7+6G31HT+KNVy/A4RLgdbrRXC8Ypq+DVwyfUf/5qDHp7e57u7D1D7elVXbZzLF0K6orkmwuipmK+ppBZ4ZdNhhSZS+JBAvbG6e1AiRfMzgvVTbFHD+z2yaXC8fKAoKNUwHAFwkundYbxHS9Uc8REQADXyT4af0pZc48T8noZw58pC6XXTNhs0GOgi6bL9DV4EEo5ofLDnjn8Qb8zBDMduekyoC2l0p3IpT05E8ohmqj4DLDDwD++jvJNb+hmObDSsRUA9ihYb9xYfMChzPnffjEX/5/cFi1YeodC7XtmS/2VOClA4GshJKOHVVQ+s6nfT6B0o7HNIOMbjeTuZuPGZzL/1coEEuhHhvrl2B+ZxMGf3MBIYGDGCOw2bmSmbqplUoFWSmyalg9ev5po24tqlcMADuW27ieI6Kyobth1WDAv1lXf3wp1V9qnlNqAIThOKBIU1tgVKiEoNrFY8nSuoKVXz7L5uWKmvmRTf2dORQ2VNt113lx/+Y2NHbOhcPeihrnfOz64VM4enhQm45nR5KJmwTuWLKiPnpgAEf13z0vHNf8hk170bmsCWva23DTlrlwOTvzuoDzyYlMBY8ZVqU0c1N/LsYHafb/bbxnSRL0ZCWEaPw8AmNDiF4MJDWDpRUxZmh2LITxfWW7ueRjBt9942rs+c0FbR8DEmz24ouvRd/EvGqzyis2XYvhOPOMkE4wDKCqyhUDwFUratFzZFD1RYJfgDYBTvY63SU7g1NNX+P5AgMgufIA0ym+vPcxoWSdD2Fl8zc7cp1sqX6/ploP/vpvbkdj/RLjNbt++BS+8/0XjKHaOd9TImhbVI/WOXaIMYK4mIDvvAxJCSIUA/ynRnDq1IgGxO9rXWVuua876aI1g8AIgihJfqCCQDUdvr98IZjq/1vU1WwMgT+9/5d4+uVeDAwHMDQUT1LU5rGjAPCsfmuhASmBdcM7j8fC9kZDbdMxo+bjmY8Z7Hh8Iina25IDDDlgRpv0liJVK+W8r6GX25UCQG7XzgFlQ3fjysGA/17q+6PzeEux0pm+9AQzO9jLvaj5qxIyyRTOBc1SNT3lLSyCATHJ7/f9H9+RlK7yy5/uwee+/mxa+LkaPKhyMnBWCYiEJZw8PmpA9Mf//tGkpN5orA9DJy6g5x3g1SPHcPz3Y5CUIPxBgq88/gJWbqwt+WCkfIA0nZA0L/NQKBpo+uo3/g3PP398Euwo4JBh0FUoRvNN/RgMAG8fGsazOAqPm4OrYS9a59hRX+vG/ZvbDHdGLjN4zjwPeo4OQlKCkBOOnH9DByJNx3LZwfi1+EzjttuubX7qhaMD0HsGXO4AVAFG9UWCX9HVH5kO9VfUtjL4AHP5BvOFXDbzt9DgRyYVKMaIkagcDUl49K/uToIQVQ30xuCya9FKu0WBUOWAYGHAqyQp4RkA/vGbN0yqaHA5O+Fa24lFa4H3f/gWROPn8eozJ7H71DFsWLzMUJzZ/F65ksJLBclsUMwU4ChUBY6MJdf/ykoIr/36uGEStyxtMJQcNXFpp+jqqmoAwHh43BgW3/OOZhpf7Pej71TMuLn4gyPoPa27IJ4/jicfR04I8qwLK7ua0HN0UEuHihG4XJai/YDpbtjFmsE8z+ipMCPgBc7dGxiuAzBwJShADgDZ0N2wYTDgv3O61F/SBxQmBiAVC8VilWCm7aSmwNB0mlKscycGjXy/+7atnNSkQFZCePXIMeP/9U0eNNcLkBnOKHuTwOLEwb6k7aQrd0v9v8M6D+//8Dy8H7fk6RYIFOWnywakTK/J5jc0/0261+UDQWr+0tZijfVLwLMufOqh23HgbC927FhlPJdVCTkB6KXDi9YC79ePs5QIoO/oSUNt950fL7jZ6Zr2NvwUhyBLBOMhGS6XJa/rK9U9kdqoIxWCxYoADBitsKropXS5A1AFw8AXCX6d/j9dR5ZyqL9U30qhKrAY8GWFoqik3Sebl5tyzpUsq7DZOaNKg/bn+8wjt05SAf/9k1/ipV+cNgIf3hY7ovKEy8XBKzjdGze2c9N75+Wd8JxP5Nf8vCxHISlBrU1ZHveoTBBKB71CzOB0sEzdRjYIWgQWI8NRw/ztXNYEnnVBVkJ4/4dvwftNx6dYd4BgqcWitbckqe3A2JBh3ubz3Zj9gKKPAHOKExzuBq5k/r+UpeiiaQmAvWvX2Zj9+8o7Wa9szhKa97dhfcPtskQ2SiIhpVZ/efoWpkX1ZVN/ufws+U6PSwc+anYEAxNVGrzA4dt/fxsES3IVQjR+Hk/8fK9h/i7oqE25yBhcuBA3ttNU68Fjj95fVC5bPn8zHh4v+jjT5GQKJnP1SLbKjUwJzOmAmSkPMJf5a56JTKFXCj+oeVuCRfOv5gM/sx9wwXyPlsuqBEtq/k71Bq67ZWguYP108aFsAJwzz6Pu2HqdxRcJflOXF0ypmx6Uw380Zcmbxg8oWNiMzuSpnkz0Tkz9dZJI8OWHb0dr4/VJJibPuvDtx15Cz1Gt5G3OPE9Sq3s6HCk1eFKOTial2F4qmMxAzKbsMsEuX9WYCZTU/F0w35NXUGK6jyM9FzqXNQGA4QcsxlQtZbK+cf450kaCL08Abt3ezL3yXL/y+omjD8oSWa77/thyVn0k/S5Lo4Hp8AWmQjCTuqMnU7HNJanDOZ3fLxo/n6QAT+//JZ5//rhh+jY2WiElJlqbhwMRYziSLE1AtFhY5ft3NFpfClWRTqnlMouzVXmYnxsbEzEwIqVVj7Q9mHkuymwdC2rOM5TCckFdnemYhjKZvwBAB6UvAZhpSYYuBwCZXTsH1E1bWryyRL6sFzmXXP3lfWdh3dP+nqlmcKb8vlJUfgwNxQ34rV7fjC9+/n7DZ2ReX/vXfUndXmiHGKNcTk+CjoYkfO0zW/D+D0+9x1+mv6fmMY12FmP+pjNf06nAdKZsOrM2m6mbkBSEQgwSMRVjY5N9Ur7zWkOHpkYBN22ZOyvBR8+HjoUwGpDGZ1Gzbb0vIP1vHdUSlyMAOQDKpfP+r0GLZ6lNjZr6o8OErlTzN50CVAlJq/Bo5cdU1N/YiMlf1yjgm397a5K5Q2Hzy5/uwcG9A8aMX3etzYAfLZczK8hSwC/Vb1VKEzgTuPL11xW6zNALhRijOw4NftCE85vfsxQuZ+esHgrf2rUETbUeY1ZIIX5Am5dDVa1Qlv1KEQnVhLzKXHYA3Lq9mQMgb+huvFGWyMckkRDBxnFG01Bbad6ulCAtxhSmjynd8VIqPwopPud5BpGwZPjrAK3yorF+CaREAIKl1oDg6f2/xFcef8EwfVsX25Pgd/roQBL8CmlxVRJASrO7319UZo35HnSZeyTS4AcvcEnBj9m6BEstWhdPRAbzNWWp+VvI3+R1PSUUswhg9eqtlo/e/Ygb0zAhrpQAZHbtHMCDd6+z+iLBf9V3nGmq9aDU6q8Q6V6KOSCl8ANOMuOm4PMyBz2iIQl339uFW+7rNuBHT3QpEcDnHttrQKa+yQObnQNvYSHGSBL8br1zkWE+l3qliwhX2euSamFLMf+4HMvXn7l+cTQ4EfxYc31zWUYDlPTmrd8UaZfqUKyw4UYWO1OS8Qxm+JmXKWPDfcZ3iUboLg8A6s1OyWtnD/+tLJFletoLS9NeSqX+8j64YvmVRTYgZkuHoc0ZijV/zUEPM7hS/X7mqK/X6Ya3RTvDxBhJ2sbG2+bj777+YFnAl086zGwdip7O30dvXBaBNfyvAIzSt8thpQZC6E01tYUVFRo0GTpT8nPJ1Knur5clIgCwTsexKBWVuP37RHlDd+P7ZIk8IolEFmwcO1OBj8thpZq81BRIMQmywq9rRRO++uUPJN3dpUTA8Pv99KlDhuk7b5lDP+Gjk+D3nUf/pDzm7SxWQ/msVNOXKlWLwCapv2tXNhQ0FnSmVyGBEGpBTSVgl+58znCOM9CHpAG4RnerzXoFyAJQNm1p8Q4G/P9XH3LMNtV6GMHBlrRW1+yPmBUQY6ZQ9lMAHAGAJfEkcHV0NRnJzma/n2CpTfL7AfqMDwenNUkwBTxuvXNR2eB3ua906s+8zOpv63vXzXjj0/xuupqF0Ng5F021nknXktm8lRJaf036+2JdNhR05n+zpYVhovlBA1D+ztBTBSCzdp2NBRj10nn/v0MrrlHMpm+23L9C/IKMqBiPnHfu2MyfbKXsF8iSeBK4Orqa8E//cNukoIdgqcXQyEn86edeMPx+C+Z7UN9gR//5KE4eHzW2cccHFpXF7C3U/DU+o9U2a2aAhGLJ6s/ca7KmxoZgFEl1v5eT+gMAh70V3nn8REVImiYG5vO3VMnPebp8aDWIYzqOxZQA2L7Ewu3fJ8ody61flSXyfkkkssMlcNT0zQarQuE36+6mZewOUwj8qNkrWGoRHj+Hhx54Hv4gMao9vC12nDs30RafRnu//uXywq+YNVNtrCapv5G48fPIoB++SDCp8QCtuQZgJD5fLoueMwvbGw3YUzCZ/XvmRrXWafpaUiy7aeljV/RHW7vOxp89mZA3dDfeI0vkS5JIZADcnHla1DeT6ZuviksHP9XGzqrkzVKlxKSDHr1jpsLv//7r3Unwo6ZNNNaHP/qTZzEY8BtBj8ZGK84cCuPSee3ilSWCR//q7rJFewuFH+2CDGh9DGeDAhwYkZKUn9macLlUTR1epr4/8zIHQlJv1GYQljP3bzasorrBtC+x8HrQo3Mw4P9/erUHO7e53vD7pbtrpIIvrgCIKhnN5Nmo/Mzwm9Kdri7z7xXOCkmf42sOePzb/7kPDntrWvh97I9/ip6jg8Zwo9bFdiPNhTZIKFWFR7aV77bDsdFZ6fdLxEx+ML2kUmv57wGgpvX9Xe7BnnBEhbMKk6/NaVR/6S7/2QpA7uzJhLxpS0tL7+mR56H17lKaGjW/HyMqeR008wFWSww+lx2IzrJz0spqybK5En8FC4u4mED/udGkErfv/uOH0sIvPH4Of/Qnzxrwc9m12cKHDw4aJu/c5nr84zdvwPzVk2uEp8O0LRaS0w0/s99vZHCibb3AumGxM4glGISGtQ7ZN2ycW/abSbnMXwBJrbHS+epo6stU1J80taFL/KwDoD7ciGzfsqZ23/ljzwNop22uvG3etOBKq/ryNHmn5KOzcZBELYolzC3vbSwvf2AeeZAUfrQpQTr4meE1NHISDz3wPC4MjBjwE1h3UoXIHR9YhK9/+UFDqdA5FYXCSUoEIEGfMCdHJ7WyMtf1mhOck84fvQNyY/0SVNmTJbC5umI6l9HLLyXoQeFHbyiJmGpAkRc4fP4z774swUdXdVU1XHbAL+kWid6ElecZxPUc2mLVX7Hg05uiUijPLgVogl/NvvPH/luWyCo96MHnm++XCX6MqEC1sbPa5C0lJDXTyp4VfrJEcOudE5FaKRHQG2BqTTAPvRrAd77/AvxBkjTbwxeZ6ISzYL4HN3Uuwy9/uiej742uUDiCeEKGGJsYnm2OftLhR3Tfik00d7gELJjvwQNb1iMUjsz495IKv7iiHUOXXQsQ0DJOeizoeNFSzzqZLvDR53negfomDwaHBvXzUQu6Dg1NBIBm0vfHC1wNkNDnoswwANeus1GfX/O+88eekyWyRk925s1Bj6n4C8oNPwrZmVB/+Si/cGCittcYq7h8Al4vHTiMEwf7NFjpprFg48wdNCal/5w558fnvv7szII/ZSiVLBEcPTyIL516Dh538v7PtNkLaAEOWpnisk+oIHoDaFtUn7bT9mww8wsZMSBYalFTn1xsMToqoff0CHiBw4L5niLeXyl6oHoa1bgEAM6eTMwsAE3wW+SLBJ+XJdJB4de2qD4v+BUauY0rU3O+mkGg3d28RcG4VMBMlw5Dv/B08KNQ+NK3n0u9KyYpqXwV16SLM4Mfshzlg3SbZhDSfZqpfM10Zq/Z72eoP/vE8/S47bhrvdEkNmneb6wP4+FxVFdVg+cdWf2sqaCS5Sh43pE3uIr5Xbr399ROfA/RGDFGegLIOKM6E+RSE56Lulk6WAg2jn4p86ZjPnA2ADIdy20sLXEbDPh/DKBB9/kZyi9X0CMb/NL9HX19sRCUlGDGCzyXCiwGfPlOjGM4zvC5hGJACyGw2iwG/Og+e9wc/EGCEDh43JnVXbpFL9hsr51O+GXbBzoWcrohmA1+5mMIaOYvNX39QYJNm9uTAh///ZNfYtf/7EM4oibBA9CixuZa2nSuBPP3kUsJU/+u2V9Grw+hiodgYWGzc7BaePAWwGF1TtrGmvY2rNxYa7TRt1omXiOF5SS/ZzYlZ755l3LpPQHpgPRrt9+xunrncwfGdX+gOp0AZAEoPUfipGO57c8GA/5/lETCAyA00bnUHV6KUYrp4JfqMwjFkvVfLghOV9MGhuOSlJ8kEty3bSXu39yGv/7OXgSHiXGxmFVhJpDxAmckQGd6zXRCLpMJnM/FPp0+PzP8UtWf6Jv4Djxuzqi7psOlPvf1Z9N+PkkkGBwaLEopZ1paVsPIxBNFDI38KQ5h7hP1+MdvBtDYOdeYEpd67bkaPHl1faZqcIrR3lTQM4MhovICV3fGd2kZgL1btzezu3YOkGkBYPsSC3/2ZELesfU66+snjv6DLJE/0et7FYdL4No7vXn77AoBWj6vzfWe5jsrL3AZTyozBM0/T2fHmvGQbCQo0+oM6lv6t/8z14iyRi8G8PTLvXj2Z0eNC8XhErB4cT1abK1GwjkhWuCC1PkQCjEYGfSjfn7m2TJCFQ+vrIX+pKhi/P0gN2ooFtroM91xvHR+4uKYM4/J68KmsKDbdNk1E6zcXbvp4KRUn19cgaHcQjFgydK6pFnINA9Qlgg+9fCWJNO3Y6HWATr13JMlkgTFct90UgGc7uZiVrW+SBAfefgFuOwa6Ojf0+Ruapnl2/WlVPBTCdGspAYPBocGiSwR3ofgDQD2lbMe2AxABnqO34buxvbXTxzdKUtkA63wmNtcz5onuuWK2pYafmY/gYjJJxWNfkoiwV0fWgR/QMLr/3PeuMBTFetMRJy1C1274Kiz2dyIlPpmeN6B2hrNJ9RYvwSf1O/WgBbBXdPeho6FQFvXNmPbvUefQlvXNrz8zFP4xW/3wOWqxZ3vWo+269PbmB2tO+Cpyewb9Y/50j7/8jNPTXrutcNvTeqanFZ96T62OfM8WNnVhNd+fdww58q5EpKCCxfiMGdWUIVNzdu77+2CFA/i7UMkyfVAf5ea89fzjvY782tnYkliMnDTWQtmf6bLru33YIgA8BuvpQDnBS5j44NSKr10FhGFr8kPuBFgHtu/r3wXKwUgB4BA6+Z872DA/28AvKnBjnIArVizV1KChnIw36mbGgV89pPvwePf2wvg/KzqOGzzckDAbNZMhl86h7UiSwbwNuuw63kH6HknGUZtXelTXNKtbPDL9vsP/+HDk567YfCn6Bs9lx3+fjv++jt7gUE/dty1Hpvv2YbXfv3AJJVW6pUu0psOfvdvbsOffu6FJHj4g1rCc7ou2Ss31qLt5/XoPT1SMn8qVdXZFHU2CGZ7X7808bobNs7FrWtWAAA+9/VnkwJlLjvKMvUtb5FQxYMXODYaksAL3PrtW1bX7HzuwFi5/IA8hd+Dd6+zv3b28DcGA/5P6gcyKdghZSlZKyf8zBUjcQUQdJBIw5NNX0kk+NRntkCw1ST5N3IlQ5crRSbXovCLxvqyRgFZXkgLvFwrk/oT/KXtQBoR4zlf8/TLvUkNBcxKslzlVungZ/b3AcDd93Zhx45VePwfXklSdP6g1unl0a9vnVTuJishtDZej0cf0dwTa9rb8MqvLuJwr+amWHCdFzU1tknvX5uoQ29gOOP+zm3O78afyfXTVOuBu4EzAoi1CS3ZnOME1HephhWx8Z4lcFjn4b9/8kvMpmWYwXYw0RAUWSJ1Z3yXNgB4sVx+QB4A2dDd2P3a2cP/SkdYAmCaGrXqDrMJWS41l8/2Mm2bnhC0uedNW+ZClqPoWDgBxWJSYQq6A+cZCablcGblF431Tb/Z5Jn+/BMprn1PWk1t8oVb6kHb+cDPZdfmqKzcWItDrwbw6m8HDPjRoMe3//62jHORZSUExzW1+MIj1A3xFPqf68PIoB93vqt70s1ncdsm1DqvS+tqyKXG6TrZuxNjkf6k53rftOM7338BAPDxHTdg8z3bkm4uHQs1c33zPdvAWM4ZVkWmPMV0AZBymr6Z9mFwaFABwPgiwTsBvLBr50BZ3ovd0N34scGA/zc6/GTBxrEdXU1MofCbGX8ajCipwyXg4a2arFdkCXwLN635ZrmaI6iEJF3ooXAkyeeX9S7FOwyg51rmLh+9b9oL9vEVs/IZb0nNW5dLxeZ7tpXtewjFgAsX4pOCHRR+/iDBnHkefOqh29GxUNv3Hz+3d5K/7F8ezW8ucu/Rpwzf7MigPwnwSd9/Yn5Rrgjzqq1pnPRcLpcHLUscHntRK2fMkSxdSACk1OrPuLYdLBwugdXN3tu2b1nj0F10Jb9Tsr5I8GuSSARJJKJmbXEG+OjO0P9n6+48XW2qzPtA1Z8kEmx63zw0ds5FND6mnSzO+qRs9nw7UxfSeLWou5vOpLPnxvNOgA2MDeHpl3tLuh8JHCzJdvxjvrwU5diYiPomD1qvaTYuXFkicNm1NvNT8f/RPoJjY2JSLz+q+mik1x8kWHfjHDz6yHrjhvL0y704dWokKf3lXx69Pe8BR+ZAVH2TBy6XOkn9CX57QaDL+DmxOqeyThekymfR4Ek51Hgu8JnhF5cVWHkWLjtYSSSKLJG5Z3yXbgSAjuWl91OxXqf7a4KNGxNsnE2wcWw0JKk9Rwfl3tMjqq/XZ4BPcLBJSpACIq5g2nv0UZ8RVX+CjcOOLcuM34skCpYX0LmsyfhygcxpLuaUmHIu86Ck0LDfSHWR5ShkOZrx75544i2cODaYd4CDrj0nDmf8Xd/RkyX5TDH5dzlfQ5WoyzXhhwqemTgWQpVjSuAbGY5OUn3BYZLW3/fpB1YlqaPXfn0cHjdXFPyutJUuAFKs+Zs6G7vQ5sB6DbYCAL5I8D4A6Dkilt4E3r1n6J+aaj3LeYH7NC9w+wUbxwg2jpdEwgwOSYoOQ8XX60PoQsIAompjodpYA4zmx3QsmjohiZqzun5RExRZgo1zpDUHs80RKYXioz7AXKawwLoh2LSkZbPpmE4JUiiuaW9DVa2QBI106+VnnsLme7ahviE3UCRPDENjL09Z/V0cOlUUiH38kPFzoZ1g8gEfTWAOxYBVK2rxqYduT5rb2/MODN9ZKAZ4nW786KmPFAS/hprbDBPYfK6V7QZqOZfVtVDoSr2hGlkVJcztK+T/ZhWom8GcJBLIEtmy7fYudznMYF6H4EUA3wHDfGfD+oZ3+SLBBwDcDqAF+rDiQZEAGJExoOXp8ALHAGBcdjD0wJnzuaxsZsVV6kFJncuawPICovGxJAB2LNTqTqMhaVoCIfmCm49ogZCed4DWrmTYpVsdCwH8DgjZRwBcM8nRnbq6O1fgF8N7MDIcRe+b9ozR4HN9b8GC1UWbZ71HnwIKqJmvqbFh8z3bMDz2IsZDslYO11B40f1ENUdy/z6zHw/Q8g133LV+kv+Uwo9aEIsX1+Nf/vlu1LhX5A0/nnUhgeldQyMns7gWmjJC7tDRQezAemy8J9mHmNqNx93AlUT95YIew3Hp6+NN15BuBjPREAiAhv2XTt8O4Cdr19m4/ftEuZQAVACwa9dpdb+79wz9FsBvt93e5d5/6fS7AGwB8G4AC/XXa5FVPecoGoICjKgAVApHADABEkD+kMwHjqqNhXghYZi25ruvosQgMAxkKYj6RU2YM8+DnqPaNLX6Epm4U0mbMad8HDjbi41a04v0X46uChs75+Kall5c7PfjlV9dBPDUpIua+qI8NV5svmcbfvHbPYb6aru+I+N79PQ9gQ7sKBiCB19/PC/fX++bdowMa3B3VmvF+tGLAaMKxsrmlwMYigFKXEwCn7mSwwy+BfM96FzWlKT4JqlXvWRy0+Z2fPXLH8gY7c20Tu//pZECs/omb1YVJnliBUV7M/pR00SAzeo33Y0xeIZDtYufdK5JiQBGRie+P7P/r9TlbdmgmE04uBo88AeNPMs/BJinS50UTROhFdOGOQB46oWjQQC/APCLHVuvs524cGGZLxJcC+A6XuC6ZIk0AWiClpqX/IUnAxIAVGBEAcBgAKy5jVO6Iu98AEQDIE2NApbezEGRpZS7iQoHL2BlVxN6jg4aM1CnWsM8lb9NjQSfOZ89EktVIc87sKa9DYOHEgg1jGDlxuVY0rY94995arxovaYZfRcHMDIcheC3Z4VVT98TqBlrQUPNbTkv0kDk9zjV+0reys9s/n7hkS/CU+PFN1/uNVp+uVxqTvhZBBbKmKb64spEja4ZeoBWyrb1veuyRszrFzWhtasGX9P/f8t93dqxLtDn9/TLvcb392Gq0n87AaZU1a0FnTYXfe5cHPxpRhOW+lYLCYDIchQjZ+PGfGCPW5v8Nt0pL5kWNYP1pGgVwMYN3Q1Ldu8ZOgW9V0EpAWheFM+MnnyIJ3b9XgRwQH/8GxgGD951vXB8qHeeLxL0AGgHsADaZdGp/+vRTWiHfsvmzHBMBuRENn2TIsDb5s0ZcQ7FtG3VL65HrbPeUH6piyZES6LW7oem90wn+JK2o3eFiYaAkbNxBMaGUFvTmNUEBrTKg1d+ZUMC4zj0agBL/jD7+3zhkS/iE5/8cwDAj547jPv/oCOnuhiLPAFhSEBj3XzY+RuTfE/h8XM5qz0mQeJHPYb6u/Nd3fDUeHGydyde+/Vx4wZYU2Ob5Nsz+7ZCMUAZi2JkjJmk9uiFu+b6Zty8YlVa8Dmu0VRnbU1jUruo93/4lqLAl7RtO5eiwPdkfO25vrfQWFMcAP1jvrTHnkaAqfpL9QenXgfmNR4ehy8SNMY0lKoeu5BgRy63kZVn4XW6mQuhERkA74sEPwbgU5RL5QKg8VlMmdcM9BnA/iDB2ZMJ+QfP7pMAnNZ/v890iQMAHrz7evvxoV6PLxJUvE53M4ClAO7wRYJboyFJEWwca1aMhZiQ5qhz67xqsLwAMR6dBEBFlrByYy2avi9gcEiashlcqq7VWiDEj8GAH9GLgbT5XWYzWJajqK1phHsBQexQNZ7f+xY235PdpPLUeHHnu7rxi99qvsCnf9STE4IAIMmSHtg4NaXPaDZ96xscRgndE0+8NdF2qcGT1KggltBOiURMTWvemluGdXY14L6Na5PaO9Ect3z64k01yrumvQ3PDwcm+TjHxsSMboeDp76D1Ys/VTD8evqeyOgLdbmA1muaJ50LH/7Dh/GTHz6OkH0EzmG3cVyisT447K049OpJREOSkSub6v8rBHg0u6GU8KMq0DXXAiHAcToj/mDTlpa/3bWzf7RUKjDflvgqADXF/qbOGGbr9mac6QkwOhwVAMoPnt0XA5i+Dd0Ny3yR4I2yRN4LYB39WzP06DwL6hAvJEjiqnKmhwzDQCRRVFfVYOW6eXjpF6cLMoPNsKMR73zgl09FSKZASK51/+Y2/OuZiwjJ4/jmY9/At77291lfv/mebdhz4jBGhqM5AyKlXL1v2vGL3+4x1N2Xv/goAOAnP3wch44OGjl3VU4GCUnB6d44Lp0PTOpnaK7j9rg5zF/dirtvXI2OhcD81d1JDUnzBV8pl2PcCzQQw7/nrK7F2NhARpNekiUcPPUdtDVuz8sfmA1+//WToYzqLgkiYgKuahtWbqxNSoJOGklaZP5faqpLKeFnVoEeN8cMioQAqL103v8nAL6uB0OmDYAZoQgAuhxltOPwG/amG7du9EWCW2SJ3DIY8C9No/SYVOhlmyWcbwAk09q4fBle+sXpgszgVNhl+n8xwRBzIGT3qWNZAyHUNJblKFq7lmDT+4CXfq7gIkbxkx8+nrY5gVkFfvmLjxqm8C9+uwd3orusEHz6Rz1ISIoBv6//zbfgqfHCP+bD6yeOQfQRo+Z2bqsNgtWNjo4IQsP+5IacrBv1XVYsmOdNauRpht5syNUzR1Lv39yGbz8xgLExMePNRpIl9PQ9gVZxPpy2TWlB6B/zYXjsxUlBD/OKjAcM1ZmpsubA2V4wHAf3PJJkZUiJgOG/LIX/Lxf8zKWihY6TjcsKDYYwelu+P9+0peWfX3mufwwlaJBQytFzzIN3r+M6V936pCyR+1KAJws2jnG4BNbrdDM00JFvlcmkA6o7wAUbl7NErBRmcCkTpGkghPoBz/aM5/T/pfoCXz1yDMJQPV751cW8TOHv/sM/JUGw/oQjL3O4ILPeb8ePnjtsqB+LwOLLX3zU2LeXn3kKo6NxSEoQX/vMFqzcWJvklzt3cE+S3666qhoOe+sklTdbEpQ7FgKvHknel9U3PYz65zTF/drht9B2feYbm+bTewLoA2qcLXDarIiIcUTjPkgpAb10NxnafuzmFasyQvRivx/OgBtrNrYZN1GedyAwNoS+d4aNNlrFpCIVmthMISgwasEQrHIy8Lg5dlBrzddw6bz/kwD+mo7rmMr3WKqsZUa3x60AbtODHDEARLBxaGoU+LZF9Vx7p5cx9xQsFHypMOIFDpInZkSAJVVNegDQzeBqrL1xnnHHiyula35aDBypz0SwcRgZ1CpC8imJo77Aj927DCH7CKLVPnzzsW/krOulEKSqjPoEs9UKF6r6fvBfbxnwc1bXJsHvJz98HK8dexvhgISb37MU7//wLWisX5Jkss5f3Y1Fa2/BorW3oLXxejjsrbNK6U0yf/XgSjwhJwUc/mCLVo8+Nibi6R/15LWtsUg/+kbPYSzSnxN+mXyrqevlZ56ClFBg181f8zr0agCDQxJ4QcvGqHIyeUOvmKoO83kfjqgFX/OSytDmrZwkElWWyF9s6G5s3b9PJFNlWKkAqAJgf/DsvgiAPxFsXFCwcXYAnCQS2R8kSmjYb1SSWNnStEBy2QGBz2840E2dywwzPHV+w5Q+eGoeY553N3rXHRyScOjV/Kd5UVP47htXQ5ZVDAwH8M3HvpHz7zw1Xnz9b75l1OKODEfxi9/uwdM/6sn7Qk31QT39ox78v++fTPJ53bxiFb71tb834Ocf8+HA2V4QwsDlUvHJv7g5I9Ao7C6HMrTamka4qpyQU8zG1Tc9jDvf1Z10oymlyqb5nWbfajr1p+WLAu4FZFKQzez/o+Vv5Up/MV8PcVkbuJ6tKivjZ3ewaKr1UKHl8kWCfwtAXbtuakqmlO1sVQDM6JB8tHNR/S5RkWSGwUKOZ6slkTDhCFGC4agyHooxqhxn5KgAXjeBBQcLksjPlOcZIBqOIRZXkVBZfOCDC+G0uSCrmfPyE0REywIr9u4fwuhwGBIBql0O8CUoqmFkFYyswrwxLsd2GZYFk1AQHI8jESfwzLFhw4aFkKUIGDb3V6IoCcxb7MaJ48MYC8YQjYnY8+ZrWLt6Dey2zErSbnNg86ZbkAj0YyjogyjKiEYSiEYSOHV8DMff9uPtw6OoluZgrM+S9Hjxf47j7cOjePvwKN76/QgSkgj/aAyiKMNm43HzilV46E8fwXXdG5Pe8+dP/wCnLmotvx7+yGo0zF2Ky33RAfXR/jAunZDhZwJJx75l/gL8/uBvjWN79p0QulbWTek9e9+044fPTMDvznd1TzrW5mP++wun4Qy48a4NCzC/02u4WVjWgpd+dRjvnPLDYuVQ3+qBw8GBKHlcf6paNPysPItYmECOattgLAw4S2EXoM3KYCwYYySRKAyDVZ2L6vfs2xs83b7Ewgd8ijLTADRU5cVLkcDokPxy56L6naIi+RgGrRzPNnA8y5pgSMZDMYTDcXAxCyNHVQOINFBA1OwAZDkWH7h5MZx1VVkBCAAOaw16z43i2NFBcDwLm2qDtY7X4GVawWGC8fEx8A57YYA0vZiAyQ5BVQVnYeAbiSERJ3DVCbjtli6oBUT1ed6B669vwYnjw1AGqxCQ/fjtM2/hhveszgpBALh21Tp0r78RfGwMYYWAY2WMjYkTMDx/adKD/i4aSRjQq6uvx8ZVXQb4Ut/3Jz98HK8eOQZAC0StfW83roRFFBEcZwcXv4QDFy8hFImBCY7g2lXrjBvNuutuMCAoWDgcf9uPamkOaloLd1k9/aMevHX8XBL8sgW/fvSzXQgEo6iZw+KBjy4Hx9ugKAkDgD/92UEMXAzBYuXQ0uoAz+cGYDE+v+RjpiIyMPHZ5agKawHjBGj1lUWyMsFwFBzPIizG3r2qu+nJg7uD4U1bWthzPePqbACgCoDtWG5jDx0Ijo8OyW989+/u/v6JE77fi4qkMgwaOJ6tpjBMxAkTDEeJrg7VcDjOQIolKUSzSuTsLKJjUcTiKhSi4kN35AdADizaa3k885IWDU6wMjzVtqTXnDnnRygSRTAoIyZK8NTaiwJgXiqQ4yCNRyARID4exa3vb4dVsOb9doqSMCDIycClE9rJ9YvXfg7JdwEt8xfkVIPXrlqHzZtuSYKhzaZAsHCw2XjjUe0S4HRaUOvxYuOqLmx57zW4d+sjuOv2e3DtqnVp38cMP1eVEx/5o/XgOPtlBzspETCAZ3y3+s9ObxUOHLgAQgj8kSg2b7ol6fiuu+4GHD52CCPDY8aN5ew7obxA2PumHS/+z3G89fsR+E0la7ng95MfPo7fHXoHzoAbm9+9BAu75iRVFPUdPYl/+9EhMAxQU8XC2+zOz/wtUP2RlJ4FUlQx1J9xDRSiAnlGG8Fbx4OV40wwKCscz9aEw/FrR4fJkxZrgh0dkguOCpe7+RfTvsTCnT2ZML7tbbd3eXoDwzf4IsH3yhK5GcAyABbqn6PXt/6AYONYXuAYr9PNAFoOnegjGAz4IYkEj/7V3bjhtiaIJHck1cY58IUvv4jX/+c8BBuHtkX1hi8yriBpvoMkEsxtrodrriWvnMFJPosc+YAMx2HkbByDAc0f+bXPbMHGe5ZAEsfA5unXNKvBV585afh9otU+OB0CNi5fhs33bCu4BjVdUCXfbfjHtMAMTQ9xVTnx8MfXo6p6/mUFvbz8UpZa/PKne/DKry5C8vhx65oVaeH0kx8+PmlwVE2NDRaBRXfnCuM5WjZIE8PNq/WaZqOUMNv67Jc+jYv9frhi9fj0N5YnVRnxvAPffuwl/PSpQ3C4BMyZ50FdnZATgMUEPagCFBgViZhqzFee5AufW/j8ESmq4NJ5P6IhSRZsHM8L3BM9R+IPAiqncyNvCJZ9pJVumzMdy23c6JDMHj09HL14KdIzOiS/FBhV/61zkfcpUZF+x3Jsv8XKSQyDao5nHRzPsplUoqhIrEJUEFnF+25egrZODxIkd68wnrXALlbjf147CSKrSSqPqMCYfwKiHM9CVKRJKjEf9ZevH1DhgHA4DjEiG35AIot5+QFT1eCCZc1YdUMVjvf2QxmsAiJWHB44gyNv74f//KmcijBVHaY+8gHfz5/+AX74X09DjCcM+H3yL26G0zkXUiIw6xUgVXuFmMLzO704ePI05H4neiOXcMP67knHy+xy8Mf8hhsh1d1gdjFQSNbV1+ObX/0m7rr9npzfA1V/tlEXbrljPjpXtSWlWMlSBP/2f/djdDgMi5VD69zqkvr+JJUx3D9UAXIMEJMwSf0ZgZGgUrApzNlZOJ02jIdirCQSmWGwtr7F0jg6TJ4HgK3bm7ljR8LqrAAgXaNDMk2cNmAIQNX9hcdHh+SXRofIv6/qbnwiHI4/z3LscZZjAwwDK8eztRzPcjoQ2UScqBzPgsgqY6snuOmGRXkBUFYTaFtow/6DQxgeCoNhgGqPEzwzGYAAIEZk2Fh7Wl/hVAEIVYUgTPgBEwDuuLWtYPVnhqDTUYsNGxZi8dwETgcCwLDmG+y5NIjXdv8WkYFzePvQvoJgmC/4fvrCczh1sQ+qfuffuHwZPvJH62GzNhiKiiii8ZgtMKTQKwR8qSqwY7EFe9/WqkJ//dtX0kKQuhzWXXcDlraOweu6xoChWRVWuwS8d+1aLG67Bg/96SN5gY9+D9//pxcgW2OobmbwwEeXJ/mUed6B157rxa7/3A/BxqHBVYvaBqGkAKTQo/9S9RcZya4gC4IgzxgNmqtdDowOh1kiqzLDYF19i6Xj9utXvPTUf/RIa9fZ+P6+3L39mRk+/1JrjEmqfH3yB/dy33vijUW+SHANgLUA1ssSWa+bqWpHVxPzz9/Lv8jcYa3B689dwOe+/iwEGwePmzPaiZ8550c0JKGpUUAoBqNW0txaP18TuFAzmJrzxZrBqSaxLEfx+nMXcOBsr9FINVqtmbZOhwBXldOoojFXEuQysah5/PIzT+HA2V6EwhHEEzKsFt5QfTt2rEJj/ZK8TcliwVNuE7eQfTl3cA/+7WfHjOe++eW/zftYFuNqyGT6Woar8am/XITWriVJ6o/nHfjcX+3Cqy+eM87pqtrs5u9UAx8AELqQf9fETOZwuvZzFIKhCwlcGBgBtGILnhe4I16n+6Hde4beBICO5Tau50jmZgMzDcC0+9Sx3Ma67GD27xNVIGUKOsOgo8t6myyRHwOoAcDs+tctTN0Ct5H8nM/6s4+/jJ6jg4YvUHCw8PX6MDikAXB+ZxP2/OaCAUlvmzejL3AqAJTCsgHe7nfPxWOP3g1FlqYEwFQQDp24gJ53kARDrbkqwPMMnA7BgFc+i0IPAAS/B0xjCBuXL0PHQqC1S0twLif88oXjdO5DOghuXL4sa8CiVMsMv/ffuwgb75kMv76jJ/GRh18wSt/mdzaVFH7pAChFlYJz/twNXNL1lK3klEJQiiroPT0CSSREsHEcgAQvcI+um7fs0Z3PHQgDgF41QgUW7XSlcLMQgBgdktX+Ppk6MxloDVu5/j6ZXbvOxh49KPbUtwhRlmPfL0Zkojps7IYbFudlBlMVWMdovkCOZxEOx1Fb74AcsiAmxxEMytiwYT7GfQT+sTzyBjP8Ip90GN7GG9HggUvjuG19E2pb5+SdE5jLLAaAmuZmzO/0Yu1qL5a2c3DVuhGR43BX26GqCtQhFxCxIiD7EY6ICEdEKINViAfYtM8hYoWnRYDTbsMNa+fhng8vRueqNnjnLJqSOVmqNRP7QBQR3jmLsKAmjgMntJvLqUsDEIfOG+kx5Vg/+eHjePPYWdhG69C4gsXW/7Xc+N4BrRSU4234Pz/ej0P7+2B1WPLL/ZtCzh8FVy7TN605HFGN6LBZcKTm2gIwXsPZNXM4JkqsGJEVIqs8w+Dmi/6he+tbhODd71514r9/eYEGYlkAKvURzkYFmHV94pEF7HcfO4MN3Y1zfZHgyWhIsq5e34x/+NbmghSgjXPg4Ud+joN7ByDYODTVemDzcvROgpveOw93rF9lmMq8wKG9szwqcDwk06gWbr1zEb765Q9AEseM15RCDVIlYF6BsSFjLgkdn0iXuVogteFEx0KtFIzW8s6k2pttiyrBp1/W1Lbk8aO+1o0dO1ZlbWJbjO/1m499Axf7/bCN1qG+S8WOHatQXVWdBD+WFzAeHsdDDzyPwYAfvMBhydK6pAFdpTJ9BUZFOKIa3b69zuJ7DNq8nNErwHzNma8zWlVGOzxRk3sw4Ff1+eacXu98mBe4J7xO97O79wxf3NDdUA9g3QLvnNeYy/Q8YwFG6VhufQXAu2WJKLv+dQtXiBls4xwYOT2Iez76rFEU3rao3gCRYOOw61+34Gv/ui8JktnSYopJh6EQ7HtnGP6gNprwycdvR2Pn3EldrksJxHxqj2eLeXk5rsDYEJ544i3D5UBBuKa9rajUpFTV98qvLiJkH4FluBpNKy3YsWPVpMa6iixBsNXg1WdOGjfyploPWhfbM5q/U/X7nT3hM64fj5ubcqNVCsJ0pjCtKTaX1ao21pwmQ61ICsJxXuDekCWylBe4uV6n+1fc5Xhy6eawsri9To0m4veIEVkVLYS9sbsjZ0K0IbUlBTWNNQiLMo68NQCOZ8GSOKqtbsTkOCSRQHXY8PE/78Qz/3UGABAWY7BIVlR7OShyfqYwl8cthmFZMLwV4XAc0ZAE1WHDjTd2gsjpzThVIVMyjyn8ZDkKRUkkPVjWMuvMy8tx2W1V2LBhIRgpAT8TgNzvnFJEnkbbf/SzXXjz2FlYZSeYkB2339OOD21bApvNMcn0ZXkBwZAfX/rSrxGT4+AFDnMXVUHJVq9eZMKzwKgIXJDhGx03LKZq69S7TMtRzSTmmQm4cRYmqaGC+bKTJBWCg0VtvQM1HidjYSRWIlAkkShEVm0Mg4WSSNwMA4iKdOFyVYAMAGzfssax7/yxk7JEWnmBU3/4441sc21TQaYwSXD480++aARE6IxYGgH+xfMfxoGXQ8YdFEBGJTgVBagSgv5zo9OqAkupDCsruxo89Gogr4h8ukX/jgauqMl7/+Y2I9qbGjij6o8mPuej/gpRgLS9Ff03HFGTCglKof6ymcXpOsqkDlmTogpCw374g4SaxAztRM8L3BNz5nk+z12uJ9XadTb+pVcuxue38UJCZd8XDUlKQmYLUoEAYOOBG5bUGyVyEgFYjgXDaHmAx3pG8cd/tjpJKWZUgvqtiBEV4+d8FCBUFQzHJanAMCPj5hsXQVVIRhVIH1MNlphXvkqwsvJUMHIUTkftpCDUuBQ3EtZHxFGcvDCQ9nHkTB8CwShkawyuWD0a5tlwc3cbPrRtCWpb50ASx6AqBCwvQJEl45xgeQEjgV5897E3IBHkp/7yVIDU7CWYPvhRNRgPKmAsTFIDFcHBaiV1eo5gZEBGX39AHbwYVMIRohJZZQUbx3I8y/AC91KDq/ahQweCj5/rGY9etgDUkxyZ96xe8XZfcOSjDIPq3t6Qeuu6ZqbaY0O+ngwpwaGmsQYLG1qNqLCid2HgeBaXzgXR7wvic599L8aj8SQIsnFrUpI0jVSZI1ZcvhpbT4yWwjFIBDj7zhgWeJvQ1unJCMF0MCwVECsQLA52qcfN7F6wCNVwNXozRuQZRoF1zAOr7IRVdsJWR+B0WNDcUINNKzpxyy1ubLpVq+9VoUCWIknnQLJbhcPf/t1v8fahUVgdFsyZ50G1S4CckMGwbLLiU1UwLJuX+kv1+cWiWtCDXjOlMn0zvr8ShBoTDAhSc5hCzz8SVvxjYTURJxR6LMezo7zAPdngqv3EoQOhRy9eCvdCLwJhLucTjnaE3dDd+GlfJPhYNCSRW+9cxP3V596TV21wkhLkHHj8e3sNcyHpoIsEz/z73WjsnIt/+MfXkl5DE6lTZ4aYpXg+ZjA1hWlEWJYImmo9+P6P74DTZi3os5TSPK6YxPnDbyrHVhLHEBHjaV9XXVWd7LfN0TTVHPigoydaFzYUZe6a29mbAWiO+NLxFLzATSnyWygIASAUgypLRNHb5fOmazfKC9xvAPx0zjzPi6881z9ML7OO5TaWJkdzl/NJp6tA9t2rlhzuC47czzCoPXcmoC5saGXaFtogJTiwXH7wkdUE1qxtxOlzAZx/ZwwcPwEwIqt468wY3rNpLt51cwc6mprx6u4ew2QOjsfhdNrA2dlJCrBQFWi1a3mBCZWFb3Qc5/sD2Py+ZTlVYDpFWColWDGLsys+c/Ch2GPLsBysghVORy3stirYbVWw8KzRIUiWIkadeLZzgeUFDBw7g4f/5gUwjObOmXONB3Ynn6T+Sg0/QHsvh2ArG/CIGkcgGkcoElWDQVkJR4iaiBOq8liOZxO8wP2O5djvNLhqP33oQOi7o0Py4XM94xGddQwAVS/LxWUPQADYur2Zfeo/euKL2+t8oiJ9QIzIZCg4xr7vtgV5w8+83nXjArz51iCG+8cNCHI8i+F+DUY33NiE9o5a3L6hFXv2jcI/ptUUj/mjUEURvGCD3aEVhVNfIFeIzlZVVNc6IIVjUDgOZ074MR6No3tDe0EQpCAsh3+wAsTiFF/O4ytLILJoPMxujUymbir8xsPj+LOP/xqhiLZ/c9u9qPFoJW+FwI/6+DhmosmBwKjgGMB3XsalvtEks5flWERDEhKsjGgijmgiDp6Pg6jag2NsBYNO344aikTVWFxVgkFZScQJTD49luNZEcDrvMA9rkPvsdEhed/FS5EAJgooVGToEsNcIecjR8hvlM5Vt74C4N3RkETu27aSe/jj6xER4+AseX7hCQ52QcFAYBCf/dhBXBgYSTKHab1u9y2azA/Gwvjed4/gpV+c1k0PzjAD3A3aqMHUaFm+pjAtkQO0iPR921bik39xc07zZzrM4qvFXKZDhMzAo+WF5V6Ffs8UfjSjgZq+6UreCon0mt04iZiKkUE//MGJv6fnO23rpl8nScDRryEmD96oAFTz9Egq0lLcUqMAdvMC9wKAX/UciZ8xsY224DNa6mW91q6Qc5UFoGzoblzsiwQPyhKxSSJhHv2ru5kbbmtCIDICu81ZEASDsTC+8Y3fY89vLhi/61rRhG986wbYbU6QBAfOQmDjHHjjxUF874k3aFF2WhBmMy2KgaCixMCy9lkDwSsJfhR80wG6qYIvIsZRXVWN0WAfHnnkjST4Fev3SzV3AU31+SLBSbOaabQ39XcZtyuSHP7LSRaLDGAQwNu8wL0JYI/X6T64e8/QsPlyKQR6VyIAsXV7M7dr5wDZ0N34oC8S/L4skQQvcJYnH78ddQvciElsQUqQsxAIDIM9vwzix8/thcXO4HNfXI50eYY2zoGIGMcTT7yF1359HINDUhII6fxjK4uCBlCbgyIUgje9dx7+6gubUF1VDVkKFgzBihq8MsBn/i6HTlzAX3xBuwGb4SdY2KLUn/kGnc7Xlwo/aroODklEsHEcL3A7AewCMBdAhyyRKgANAK4BUAVtHC+TZG0DEoBhAOcBRHiB6wFwxut097TVNlx66oWjkdSPvnadjdWHoxc90emKASBAo8JxuWO59XEAfx4NSYmmRsHyL49qEAzGwnkrwQnpz+RMrDarwZFgH57+8cVJIKTmgkvnFQUiMAHFdPWZgoVFOCAlKcG5zfX4x2/egMbOuVO+mKYDhjMJW7MZO90+vXLBTyRROKw1AIDXn7uArzyudXmh51cm+GUDYOrwclpOlgq+TJFeSQnCHyREN1lfP3sycfNk2jAY8f0H+4Ud32KiUtRgj0NwqP/2X48qHLdRzdLMmWtfYmF4gVN7jogFdX2+agCofx72yR/ci688/sLPANxJIfiph25H9y3FQbBQYLKsHYHICI6/RrDrf/bh5PFRREPSJJnPC/pgah2K9I5KB8ebaxzjCgwlSE/Ku+/twv2b25Lenw4Vz/eiogm0VxIQZ+sqVuVlUn3/+98PGi3bKPwWdNRCVCxFmb65wOeyI2uCsy8SRDQkKfoYixtdduzzBwnncXMkT6XGtC+xcKb3VHuOiLSRslouYOAKhCB2bL1OeP3E0WcA3BYNSQmHS7B8+WENgpKqGqqt3CBUlBhGzwTx9Mu9GBgO4PyxqNEANZv/g8Ix26LlehSgoZgG0089dDtu2jK3qAuuAsDZC0CWFzAa7MPOfz+D558/bnz/ALLO90iFn9nSiMuK0bcvnR8vH/BlMIOf7jkibtMVIcmTOeqMwOIKXCwA5ckf3Ct85fEXngLwAVkisiQS7r5tK5k//pPlEBim7GrQ7EukMAzGwpD7idGgdGA4gLGROEYG/QjFNHWXy1Gcaz36V3cXDcAKBEsLPHosS6H+3nhxEN/5/gsYHJoAn8sOtMyvg7NKgJzSAT4TDBMxFXEFCA1PnHOT3AoFgM+89Ju7Itg4mRe4VT1HxBObtrQwrzzXr8zG74i5gs8/FoCid5D+ewCf0uFCulY0cV/91HrQ9lkxMVJWEJphaFaHxoViAiOQvTdfkgKMRxCJyqivnThJ17S3YeXG2oKrR64WCJrTWlJTXGajyUv9fUMnLuCejz5rgI8uGmCjy5rSjyOuY0f0EUhKECF9wiaFniSSSZbHVKo5dDOYdmb+2dmT8gc6lluztqWvALC8n4+BliLzMV8k+BgAZzQkyQ6XwN1xx1Lm/geuQV21xwAhXfkAcapmdCoUARhgzBdA6drnF5smkwrAUrXmny3gSx0PQG8WtNQsXVeVmfLz0RujpKoGAD/y8Atpfcm53CZm2JkXHY1JfX6lKmXTVSA1hTf1HBFfbV9i4c3jcSsAnMbPSGv/NnQ3rvRFgt8FcIOuBuWmRoG7+T1LmQ98uBHNtU3aiZJHRwwKLMPcUEvrvsgXrqlRavN+TQWAV4pKNIPv6Zd7jXnFhoLSW1F1LATqFzVBsNUk1duW0oTNF3ppjzVrx8jpQTz9smYNXOz3Y3RUSjJjs7lOqK+4ZX4drrmmChsWazNcJE8Mf/HQq0Zycyk6uei+QEWwcQyAk021nrW79wxFDausAsDpX7RxAiG/YW+6cetf+CLBLwLwmkDIdq5uZW9dswIdCwE0EPC8kKQEqUKkPjwAeO3Y23Daq/DHf7K8JKqwkJUK4XQXzbT6HGYRELOBjw5/os+pQy4wjSEDhjfc1jTt4MsFQPp9mvdLJFHExEjS+ZjOZUIBjwaC6qrapJvm6NiQGYAqAIUXOK4Y/18mU5gXuGdvbl/xoR88u0/G5KBIBYDT7hcEsGlLyzWhYf+nQzH8IQC36Q4q641RGd23wtC5AwBU0x1XlUTC6tvExtvm4//7wk0GKMvtU8wXgvTCMV9YV7IyzAW+iZb0DgQix/DLn+4xxnuqQy4AgHsBSQLhTKs/s5WReoPNpPhTt0WBZ3bzAEBUDCcpQH3RaYwsL3BsMTDU8wIhiYSOq/yV1+n+0O49Q8FcoyorACzzolUjOgjnij7yv3yR4IcALM/kN8mUomJ+3Q03NeLzX7oRbntV2SPMxYBwulThTAIwN/gmz+Lwj/mMOccjgSCsFh7qkAvuBQT3b24zEs7LDcJ0AKTgypaQTxIp7dtIKO/31AGohmJgAJwAMABgkykyTGHI8ALHAmBS81bzhSCAg021ng/s3jPUO1vM4asSgKm+QQDQTeMVANZLSvDaUAwdAKoBeKCV7sQBjAGIuewIAdgbiqFLlsg23WxgaZXGx3fcYOQbTqcazAeG020WTxccFVnCGy8O4tUjx3KAL13E12GAsPfoU2kBuv2jC1Dnbi15kCMT8EqxUtVeFgCSUAycy46f7t8X39qx3LoZwIdlibwHWjnbxP5preUVc4MDXjD6HTHARGK/cYNJhmA/L3Af7Dki7tm0pYWd6fSYqxmAxjWp1xTK6Q7Nkz+4Rzhwtpf7wiNfTNTXfUieGFWsomO57UuyRL4KQOYFjqeKkBc43PTuOfijBxcZtcOzyTc4W2BYCijSqO3rz13AK7+6CKYxBN4C3NS5LA/wIS0MqSJ89cgxxBMyyHkH3n/voinlVuZr7pYCgPmAz7Bg+gk+8vALMgDeZcdT+/eJD+iqDxu6G6t8keAaADcDuFmWyGpdECAFima1mFSmRkFJ3UsArIKN8zfVepbt3jM0pF9MSgWAs0ARbtrSwoSG/WwohkwlODSthu9YbiMAnpclcisA4nFzXMh0TkdDEpoaBdz8nqWYrsTrQgFYMKhmCTDTAZSavgDwxc/fj1rndQWCLzMIAWDpzRxqnfVT8uHl9JtNI/xkWQLPCzj+GsGXvv2czAsc77Ljf+/fJ35u7TqbVRcExHzqb+huqPNFgtcCuF6WSBsvcEtliTQA8EJrdpDX4gVO9DrdS3bvGTo/06ZwBYCFHSMq//Dg3essr5w8eADAtQCUploPS/0eqSC84aZGPPzZlSh0Yt1sAuBshp8iS6iqng81MR8AdNVXiuRmzTQej52CP7A36zGYKvyKBaDZsihI+aUBIIBP9hwR/5FmTOjnOrt2nY1JX8urnWcbuhs8vkiwST9gCwE0yRIRALh5gasH4JIlYucFTgbwptfp/tXuPUMHDVNqBhdf4VvOle4LUo8P9boBtOl3NIM4AuuG1zkBQodLwBuvD+FMz6ugDRnK7RuUVLWkEJyt8KMmMADUOOeDAQVfqSo7tO2EIidmrfIrFn6Alux/4OwRSCKh+X+hHoip5z7Zv894julYbmNddo18+/eJBIC6e8+QHwDtiLo/+d0Sk342vYc60+dPBYDFKUIVQDsAhyQS1QxAMwhd9gkIhmLA577+LDYemI+H//xa1FV7ymoSlxKCqRd4KhCnWnVSChXIwFFC8JkJEM3ad3Gmzd5CTN50fxtPhAGAC8UArxPHAW3QUKbDkSF9hbqGmLXrbMZJ5w8SnD2ZSNpWZjVZAeBlsWgTRl8k2Kb7L+RMxzGdGnz1xXM4cbBvWtRgpgqRkiowHQDTmWeY+v5V9vm69VV6AI5FzpXUzC3lKkT1ZYLi2Z6wqldsjC7wzunZjSHo/fYKtZJUXRVmfWGu30/7zbOCtMKWKWH0WkCLcrlyXO+aGtS9Si4B/iDBl779HB57fDdiYgRuexViYmTKJ3Q5lUYqdLLBgP5+uoBR45xftm1HY32zDn6lOFd4XkDPbg6nTo0ovMCpLjt273zuYEBngnq1XM8VABZ795TIwkJer6lBDYQet9bA8uf/cRqPPPIG9vwyCLe9Cnabs6wQTAdF82OqpnE5TMRc27Y5mstm/o7HLkKWgrPqplTM+SFnSN157fBbkEQClx2MwLqfAlSsXWe7qphQAWBhizl7MiGPjP4nC2BxMceQZs/LElEdLoH0nh4hX/r2c+p3/+Vw2dXgVIE3VcWY76OQ5bDOA43Wllz9xc9fUSavWf3J/QSv/nZAcbgEFsDFBd45vwDA6IGNq2ZxqKyCAAgAb7z+W2dYjP0VACcvcKi2unM62Oi805ExbcYpAFYhKssLHMtyLHNofx85cCjA1vP1WLjEBZa3ICZGYJnGsjKOmR1ZUQyTe94wDbx4a5eVJZdLRRSj/oNTvuEQIONjOuCXTv2xLIf//Q+7cfZ0iNTVcJzAur/0378+/cbW7c3csSNh5Wq6oCsKsAgAAlgAwKtntzPZoOeLBOGLBFV/kCj60BiGFziOF7goL3D/2+t0P+SyY7CpUeB6T48oX/r2c8qXv/Eaxs+G4LZXlfTOXw6TbCZXVTVNfSn1ciQFPy5bN00a+PG8gJ3/fgZvvD5EHC6BB3C8c+7c7wNgd+0cUK62C7qiAAtYHctt7OiQrNo9ZLVC1AeIrBKLlWMdgm0S+ALROCJRoihEJQpROR2ULC9wEoAnvE739kMHgj+9eCly8N0rOn8yHidewSqtTKgsc/rYKPntnrPM0KjCLL22Cm57FYgOwnIrQjILlKCqysYjnRqkZnJj3fVlyuRPwOd/E6pafP/OUt1MYmIEspwoKfye/dlR1eqwqADUaqv73l+81HMOs7BXXwWAs2zNb+O5/j5ZqWvkP6gQ9b1EVpW6Go7lGJth4urgIwpRVf34sgDivMD1sBz7S6/T/UeHDgR/cPFSxN+x3MbNb+O5X/6mP3jxUvTZtrl1v+f5eFdVFdccioE5tL+PvPE/PqbZ1cDUtsrTAkKBmV3FQWYY0gcA2BzNqLItKMt7jscuIhrrnRXwK3YpCskIP17giMsOvtrq/sTuPUPPdCy3caNDMrkar+kKAAtYLXN4tr9PVty1zH0A1nE8q9htLKtDTw0GZcIwmtLT1V4vy7Hfa3DV/tmahR3f/J9XLvznxUuRQf24M6NDstLfJyu6OuQuXor03Hbjqn8PhOLjPB9fVVXFVY2MRZlXd/eQwwdHWQ9Xj5YFVjgt1rKBcDYowHyWq+paWC3usmx7LHIUspYgXNxFxTBT7vg5FZ+fGX48L0CUYvjO3x/Biz8/pVgdFsZlByew7s/u3jP8+Np1Nv7oQZFcrdd0pRa4sMUCjNK+hH8RwC06Lxh9sIx5nulvAPzftXMW/fypF46Gkv9eu0Gn27i5T+G227taewPDX5CU4EMABD3/kCxeXM89sGU9lt7MwW2vmpaWW7NNFbKsHXOaNunpL6VXf/7A3ilvZyoqcCrKj5q+vH5jPP4awfeeeAMXBkZk3eeX8DrdH9u9Z+iHmGXdmSsAvCyOF6N2LLce0FsDmdcwL3A/8zrdP9q9Z3gvzSXVh8HQFkH5XBXM2nU2jrbn2rSlZUVo2P95AFsBMBSEbYvq2R13rWemC4SzCYIu91LUOpeVZdtDY79DKNJf8OelpYfT3c4qHfjsNidGx4bwr//SgzdevaAAgMfNsQDOCqz7j3bvGfqtqeHB1X5BV1aBLgPSsdz2xwC+JUskygvcEQD/5XW6n929Z2iYHtet25tpVK3YK4JugwAMNm1pvk70kc9ISvCDAFgdhHJTrYdbv7F10lCncsBwtkDQU7se1fZrSr5dFVFcGnyl4FzEUkfPCwUg7exCwfdfPxnCa78+rg4OScThEni9CulHrgbPZ155rt9XgV8FgFNeG7obWwDEdu8ZDpgYx2GiKWRJlt41VzebGWza0rxG9JG/kJTghwDY9PkkssfNsetvbGX/YMsKVLe7DDVSahDONAR5wY1W7+aybHs8dhGD/j0FfcZypA4V2tPPba/CQGAQT+08i32vncfgkCSbwHdMYN2f371n+HlATXKzVFYFgEW7oUyQox2lCcpYQ/mJRxaw333sDOj7bru9q7M3MPwxSQl+BIBXByHhBQ6rVtSyd76r2zCPS3mhzjQAy6X+CjF/p7ttfbpFb2qjY0PofdOOJ36+Fz1HB4nDJdB2VSMC6/779Rtb//Hvv3Ewpt+cFVxFdb4VAJYfgup0n1A6CBnozuvtW9Y0n/Fd+gNJCf4BgCWA0bBBbltUz63samLu39yGugXukpnHMwXBcqo/av6KJDqtACwEgnab0+gsfvw1gj0nDmPv7/oUfQYv73FzAKAKrPvv2mobvvvUC0f7AVRUXwWAVyaAzbNMPv3F1ba9r/bdLSnBjwLYDIChqtDj5rCgI70qLAaGMwFASVXR5Okum/rL1/ydTvhR4AFAMBaG3E/w9Mu9OHFsUD11akSRRMLoig/6DfE1V4PnW6881/+iCXwV1VcB4JX9HZqjxrqfcK3oI/9LUoL3Amg1q8KmWg+76sYa9qPvX2b4Cmc7DCVVhcNaUzb1l6/5W64Irxl09H3GwwFgmEPPO8CeE4dx5p2YcuacX42GJAg2jtPVHgCcEVj3MzYv99Qrzw28pXd04cvtkqkAsLJm3XepR42NIMyOrdfVnrhw4V5JCW4HcBMAVleFCi9w6pKldezC9sYkE7nQC3261GA5fX8qorjQ/99lUX7mm0q6YxWMhREVw+h9U5Nxu0+9rfoGx3HxHUXxRYKqPp+XA8CYoBcE8LLAup9cv7H1Zd3HZz4HKuZuBYBX7/rEIwvYvb/rY82q8La7mlcEh8k2PXo8HwDMJvKirmb2jvWrmI4NBHXVnoIu/HJCUFJVeGuWlSXvT0UUDBw51V+h8MsGOsFvR887oEPYVV9/TB0Z9Cv6dwHo3cV5YVKj3YsAfi+w7v9uq214+akX3r5EBd7adTbe1eBRZnrGbgWAlTVbVaHhB/r0F1c7Dx0dfK/oIx+WlOCtAGrMJrLHzbFrrm9mbl6ximm7PmbkFuYDBLM5XQooSqoKl7MFjTU3lg1+2Xx/2cCX6fOlA11kPKBeuBBXRwb9aigGVZYInaHBpgEdAIwCOCWw7rcBHLR5uf3zHa2nnti1P2yyatmt25uZio+vAsDKylMVjgxHmQnziMH2Lavn9GHgTtFHtkpKcANVHyYYMgs6atnWa5qZNe1t6FgI8C0TQZR8AFYsCCVVhY1zlKXkjcKPmr65gJ5u32JiBHI/MSAHQO27OIBQiFFGBv0wgY6F1gItHeiCAAah5er1ADhs83InW9F8YedzB/1puDYtKVcVAFbW1aAKAaMOlMFtdzUvDQ6TLQDulpTgdbrfiZrJtIMIXA0epr5GZesbHBCsbgOMaCCorqrV5MvYEOpqGo1k7GIhOLfl/SWFn2pqm8/AgT7fy4jGx4z9o8OcaCVIqn+OqrmxMVEdGWPU0LBf1Y8PwwtaLXiG+TDjAC4KrPsMgFMA3rZ5uTNNpO70P+788mh93QflTN/TmZ4As/7GVuW7j51RK9CrALCySvz96xHkCUXBMLjtzuZrg8PkFgCbJSW4BkCd+Y9M/iqFFzhFv+iZ+iYPY7Ez6D83igUdtexndnSjboG7IAiWWvlR6GnbmtheIPJ7+MaOGUoOgKHmpHhQHRmOqqEQo44M+lX9MxtqLgPkiMC6xyQleEZg3X0ADtm83AUAR1rRPLTz+YN92hFOyzCOjpOswK4CwMqaIRNZD5yYzCsGO7au9Z6L9i0VfWQpgHUAFkhKcCEAL4Ccves/9dDtuOG2przqa2m6S4v3RsNELY0CdMA/5sPw2Is49GoAANQ9Jw4jFXLQcieNwd+TTGLWDUkJjgms2w/guM3LDYo+8pa7gesHcLzF1jr6xK79oxS9aRZLhw4t6KhVTR2YK7CrALCyZiEM0wywZrBj61pHbFycM8iNzgWwRPSRhQDmAZgvKUGLLrXaAKC+yYOvfmo9+BYthSNTSkixAQ81ZRpcYGziZ4t1FNH4eXz7sZdw4tggRgb9hoLNNMpUH1oVAdBn83LDoo+87W7gBuIKDjWRuhGOE07fete80EcefEbKwC1GB51Z0QFXYbflCgAr64o4R6gvCgAyO+AnTqUH777edmjg8D4AywXWrXx8xw1Js2c6MgwUbe1aklslimNgeQHj4fFJv4teDEx67q+/sxdnzvlTgacKrFuSlOBZgXUPATgN4IzNy523sjjZYmv1/5+nvnWR4zaqWcSZYbYu6KhV6xscasV0rQCwsq6S8+YTjyxgRoajjAmMpgufIWvXWd8GsKy+yaM8sGV91uFbHQtLv4OOa2rxxBNv4bVfH6emqwKArW/y/Hdtou5zDsFx/t/+69FIDsgxa9fZOAo5AKiYrRUAVlZlpQUFTbzednvXvJ7R0/sBeBd01Kqf2dHN9LxTOPwc19RmfdN0io/+XfRiAH/9nb2G2WtSfjGbl3vLyuLfW2ytTz+x6/cRANxtd7XwI4N+sv7GVgUAKmquAsDKqqyCwHfbXS1zgsPk0wD+l6QEPaEYmDXXN+PTD6zKS7GVatXWNOLVZ07iO99/AQDQMr8OiZiaBENXgweij5x1N3CPPbBl/f/5yIM/k/XmASXt51hZs3tVhiJVVrHg4/v7tKFOt93VMrfB4/ir8fGx7xM1vpGocQcAptrqxgN3Xo86T+4NWtz2ku2c3VaF3pM+7D14GgDw4Ic24oPvn4OO+YuQ4MMYHeCUaHhMIWq8zlllf//vT166fUln9YVnfzpwGoCqDwivfMsVAFZWZSUvHQ5Kf5+sbLu9y1PtZT43Pj72BFHj7wVgD8VArBYwN79nKfPZjy3PC36lBqAoRtA03475nmsg1Frw7utq0Nq1BILsw+qlzVjQNpeBI8peujCuRMMxxeq0z+EZPLBoSXXHoiXVh5796YAf0KLhb+4JVMzgiglcWVf7MnekfvDuddbjQ70PSUrwswDm6i+RXQ0ebmVX00R1SAGrlCaw2RQOjA0hejFg+AXNq+cd4LXDb+HAm1pgo77JwwIYA/DNVuaa7/7g2X1RXKUDwysArKzK0s8R83CmDd0Nd0pK8CsAVgJAKAbZ63Rz6ze2FgW+cgIw3UoXOOl5B/jFb/fgTE+AAODqmzwA0ANg64s/7z+kw78CwQoAK+sqPD9UANi0paVL9JGvSkrwbv13BACz/sZWtrtzxZRTWaYLgJkgCMDotjwy6JfrmzwWAOdqE3WrPJ3R8Uoy85W5Kj7Aykq7qK/vwbvXcax79GvxSOxHRI0v0yGgLupq5v7grpuZ93Q3oc6jqah8/X3pVil9gLlWIiSmfb5rQQ1a6+cwI2Efd+l8IOGssteJXGz+Uz+8+B9r19m4/j65AsAKACvraoDfrp0DZMfW62pP9J//OVHjH9XPFVLf5OE+dv9G5o53NyeBbyrwm24AWtz2jBCs8wBe1zXQISg7q+zLl65yXXj1l4GDNPJdOUOunMVWDkFlmdcnHlnA7to5QDZtaXnviQsX9khK8L3+IEkAUG9+z1LugS3r0bFQA1/PO6Wr4shkls7E6lgI3PmubioQlERM/ccdW69r379PlD/xyILKNVMBYGVdqcrvu4+dUW67q+U60UdekpTg4pb5deRrn9li+ZdHb2fu39wGYAJ85Shhm66Vy+fYsRD41EO3M3qnmOp+se8JQn5DfeYV33nFBK6sK2wxx46EmR1br7Ne6h97UVKCjf4gkf/8gU38+z98C9xNDXB6q1DTTODiRfS8A4z6p276zpQZDGT2Bfa8A1yzohYrrl+FE6dOsu+cGiHOKnv7U7v+q/2pH178me4freQHVgBYWVfK0v1bxO4ifycpwbv8QSK/77b5/B9/4i6I0iCIosHCXX0NnN4qCLIPo/7SQnA6AUhzA1Mh2PMOsHJjLRrrtc401y6vxhtv9LEAZACr1lxftWfXzoF3KhCsmMCVdQWZvvv3ifKmLS3vlZTgIwBIU62Hf/gTN016rZTQfHXzV3fjpi1zDTOY+gQvJxM4XWK0GX5SIoDG+iV4YMt6jAz6GQBqKMR8c2T0P9mKKVxRgJV15Zi+2L5lTe2IL/giUeOuUAz47J++h1lx/SoDeKmLKCJY1gLvnEVpTeNilOFMm8BLb5iLWnd7EuiJImJ+pxc9p3vZd06NKM0tttYXXnpxZNfOgX0VFVgBYGVd5vDT8tsIqar7/9s7+/g2rjLf/0YzHuvFkSxHfovz4titm6RN8+IkfkmbkhQCLXVbmru4tM2lex0+C9uFQmFhYdkFdrks+1Jgu7Bw77b3lmta1nuXtpBSlu2lhUDtODht0zRJ68SJ48S2ZMuSR7ak8fGcmfvHzMhjxS+SLdtycn6fjz6JZckazeh89XvO85zn0B8RVaoNSVS9+56b+D/8ozumhV8yCK2h8ZrrnSgos8EtyAlXlSoQFwOAsUthjEfkBPzWb69Dvm8PvKvzkJPjBhkPJ96TKTHHiwqvgmNvD3FjY5w2NsbdctvWDf/W/Oy7YbZeeHlLYKfg2pXZyqq+rvgzRJXui8Sh3HBDofDpR/ekBL+pQmOnowxOB4BC/b7C64cRlcemLXMxw+aq62bu75cK2FIJe8s2b0AOtgMACvInNkoaievt88Uc7xXvnYyHsX57HSqvO8Ed/V0vrazyekZx+V4A3zr6u14ebIUIAyDT8pJR7Kzsa1i1MzIQ+lsA1O0A/1efqYXTUZY2AJNBaDonMceLvBU6EK2/V5QYRkZHsHWNfr83vxg52I5xvI7wcCDt17VC0ptfDDHHC218/aTHWIGXrBWONVDUyIzv+6MNW9B1Ls4BmgagARz3rdpbytSO9i72gVquIRA7BdfmdW88WGrLI6tzT3Sf/D2ATZE46Fc+dSf//g/XIRbvhSA4M/6iYs70Ts7r2jmTv5v0U2g4ZgFaAoHzPr6R+LuIjV2c8fi/+rUfoOtcXHW7NRuA21ua+18xV86wj9XyE8sCX5vuz9bS3E/P9PR8A8CmkESVPe9Zx+/90AaQ8XDG4Gc6QPOW7BTNWwr+btKtIN+Hgnxf0v3zV55j5ayP+WjDFmCiVf6XAQ6FRU42B8gAyLSMQl+6r2HVrUSVPgW95IX/zKO3LOpxTAXFpQ+HfDMeExkPo2zzBlRe5+AjEU4FsPcjh8rf893Hu9TGg6UsocgAyJTtoW9Lcz+aGnfaIwOh/wF9I3DukabdXHHhBihKLKMvZnV5c51TXGwJNves4La6QHVM/hLA4dI5lblABkCmbJaxxSM909PzFQAbjdDXtvdDGxZs3i8T0FlMzRYGT+EC3/eRQ+W7W9sCzAUyADJlc+hrrPbYTlTpcwBogYefFPpm2gEuS4s8Sxic5AJVwwWyuUAGQKZs16F7a/jIQOj7AISQRPGZj93JefOLFw18V0sYbHGBguEC9zceLKn57uNdGnOBDIBMWej+Wpr76elA9yMAdoUkqtTcsprf+6ENi+76lsN8YCrZYABWF2gD8CWAYw6QAZApm7SvYZWtpblf3dewai1Rpb8GoBZ4eH66zcqXIgxOFTiLFwanNhea5ALvamrcsb2luZ8yF8gAyJQligyEbACnyUH69wDcIYlqe27fxJVtnt79LQYErU6QgzPLzppz0jzgVHOC5jmyusBR8fKXAA5dnWH2wWMAZMqG0Fdf61v0fqJKH47EQW+4oZD/1CO1s0KOJUR0hYcDuPB6W+J8mP+aGfPijWuxdm2umRG+t6lxx80d7bLKWuczADItcSQ3OMxpTY077USVvgO9bo17qKEWoj0fqkKy4iB1d+XMupOX71oPRYnh+//8a/zlt4/it4d7pvySEAQn9mzZZm4fyo+Kl78IQBsciLFlpgyATEulHTV2/pXDfeqZnp7HAGwISVTde/ta294PbQCRh2ETxFn/xrXsAjn4IAhOjBMVbreG4+e7pz1HtzYkXKAG4EBT484bW5r7mQtkAGRaquva0S7TfQ2ryokqfRF64sP28U9sgaLEUoIfgyDgzF2HHFEfImRMSji+5PNiuEBA3yw+Z1S8/AWAYy6QAZBpKdR4sJQDOC0yEHocQJ6Z+Cheef2cQt+FhGA2rQJJ1grHDRBzPQCAcaImzl3y+VCUGHbfUWJ1gR9uatxRxVwgAyDT4sOPb2nup/V1Re8HcF9IolckPuYKwWvLDervtbqiHAAwPCxj8Kx/2keL9nzs2bKNG/SHKIDcPrn382BzgQyATIsqrqW5Xzt0b00uUaVvY4bEx1yTIJmGYLbVACZr696JEpiZNn0yXWBlldd0gQ80Ne5cz1wgAyDT4rk/GwD1dKD7UejNDtS9+9fZbm1YCyIPX/H4bIFgNqso/46UHqcqBKI9H3ffVscN+kPU7dYcfXLvY8wFMgAyLdK1bGnuV+vrilcTVfrzSNxIfNx386wDdykhyGVhCYy1A3VBvhOFRU5EIhzazpyY8X0rSgxb93qtLvDhpsada4zrwsYaAyDTAro/DuA0okrfBOCORYie+Ni4FiOjIwsCwavfDcYAOFG3cQsAPREy1bk0z5+qEHjzixMuEEBen9z7KACNqBIbawyATAsEPzPxcQuAB0MSpVWbS/impm1QFQKXPTelEC5dECavjkhX2VoEPZ2Gh2XELulbBkx3rqwucNAf0gAcamrcWdLRLlM2F8gAyJR5cS3N/Rgc+nebseIDANB0Ty1W5K2ATNODE5sXvFJ7P7QBbreGSIS7IhGSfL5UhWBF3grcfVsdB70u0NMn934KbC6QAZAp8zK7PN9z1yNNAKpDEqXVtWX87jtKEBsbhsilP+bmC0Hz3/BwAL0n35kSjooSy9IawCuPNQfbkZ9vB4BpV4Qkn7+te70oLCkwXeDHDzZUF7U096uH7q1hEGQAZMrU9etol9UH7ty8MhiVvh6JQxNEnvv8w9snPUimMahqHKoaXxQICoIT4eEAnvjOK/iHp9oS62iz2yXGpoQfEENBvhOuFXo5THQknFhKONM5WpG3Ag811Jou0Bu09T8CQBtZ0cPGHAMgUyakJz6gdg6d/YrbgaJYhNC77tpkK964NhH6Ek2b5AIXA4IA8NRTb2B4WAYAVF135e8FwbnENYCxpNtMck4qiA5HB2c+b2ocqkKwaQ+fcIFjKv64qXHnypbmfhVsP24GQKb56U8+W2nTEx/FmyNxfCIkUbWkWOQPPlyJ2NjwpMcSTZt0SxeC6SRIBMGJ3pPvoPdSPwCgsMiJss0bEr+zaulKYNJ3oibEIxEOp4/QGeFHNA1ReQwrPWXYeGMJB0DNtcHXJ/f+EQDNmLZgYgBkmqO47z7exYHjQFTpWwAEIlPtMx+7k1vpKQMdn3l8mRBMB4SpOkJFieGHh08kfjYahk4Kf5djwmT99jq43doVUwuTXJ8BPwDgcyhUheAjD61BYUkBN+gPadIA/eTBhur8jnaZMhfIAMg0R5mJj/raovsAvFchlG7eUsJX73cjNjYMPofO+jdMN5iupnODqkIgCE789nAPBgd0MNx9Wx3MztPJ7m/pSmBic3pOvms98vPtGPSH0HZGB7ydn/n4o/IYCnUXaAOg2n18SS/6mwBoxqodJgZApnTdX0e7rB5sqHYGo9LfReKW9b5zyPjKNJa4zccN2gQR4eEAjpx4AwCQn2+ftI42uZnCRAZ4ebhBDr5EImRwIDapIHomJ62qcRy4vxiizcNFBkKaHKSfPthQncfmAhkAmeYgc73vmYFTnwFQGYsQde/+dba693sQJ/O7nOlCMNn9WRMfe7Zsw2JuuZma25vfsZiJkEiEQ+xSGDZBnHTOkh01n0MRJzaUrVyP2r1lNgAqUaXVveh/GGwukAGQKf3rZawrXRuJ4wsKoarTLSbW+6YS+mYSgmY4LNrzr0h83Nqwdtr6P2AxusDELP+mkumdXaajHfSHriiInmk6QaYxfGR/OQzHp8lB+tjBhmonmwtkAGRKz/1xALRgVPo6gBVEptpdd23iVlZ6IMVHp33ebEmR6cLiVDVV4mOm5WKC4LRkgDM1DxhLgl7mgVpWvAuVVToErQXRM8GPz6Gg4zxWVnqw5/ZNtkgcKlGl9V3Byw8wF8gAyJQ6/Iz1vsV1AB5SCKVrSwv5gw9X6rV+vHta0M3VGaYCQdGePynxUbamFMUb16aw74gzRZilAr1YxsLcmZTnWJlYERIdCUMhUsrPJZqGj+wvh9uhu0CiSn/62Je2ix3tMpsLZABkmk0tzf2g9NdcMCr9AwCOyBSPNO2Gx5GHuBxNy+3RcT5lVzgbBIk8nEh8AMDBhytnh2Zin93YNLfpQJhO8fLCyEyE9PSMYWgklFLiic+hiMtRrKz0oPaWMlskDhVA1dFXe+8HoLKMMAMg0yzuDwC99ZbGBwDUxyKEbq8t5av3uxOhL6GRxM0KxAX98AgiXvuFP5H4uPu2Opj7jkzn/lSFzGEN8NIBL1lmImTQH0JnKw+bzZHylwnRNHy0YYvVBX7h0L01OS3N/Rr7lDMAMk0trqW5XzvYUO0KRqWvK4Rqop3nGt9bM+OTZoIgn0PTCounmxMcknrxs9+0JX7eutc7KfEx3RxgtrfBn06j8aEpl/Wl4rjNa7Kiwo3qXaW2kERVAJtOB7r/i+EC2VwgAyDTFO7PBkBtv3jqMQDlRKZ09961tur97lmdXlyOZtQNmhCUqb61ZvPTXYhEOEQiHO6+rQ4r8lZMag46FQTT2ZIzW6RhInMtrOJRWFIAAGg7c2LGGkDz/BMamXT/ni3bIIg8TBf4zJP3CYYLZHOBDIBM1utjlL2UAficUfbCf/wTVWn9kUxD0M47ETjTkyh7Wbs2F7vvKJl1qZxZL6hngJfPcjjrmuWVnjKsXas3mB0ciCFObFe4aTrOT3vO43IU1fvdqNldxhsucMv3nnrtbgAqywgzADJNdn9m2ctXAbiJTNW77trErcwvThtqsz0+ncQIAPzw8AlEIrphOXRg24zOzgrG5dYF2uoCOTjhdJQlEiFdnWHELoUhctykc5fs+KbSB6q3JLtAm5ERZmIAZAJglr1sBfCHsQhRS4pF/sD9xXN2dFOFxMngmwmCdJyHnXfitV/40XVOD/0qr3Og8PrU3N/VIMHmTiRCgImtMgmNzOj8kq/Dpj08tm3xmi5w1/eeeu0DhgsU2EefAZDJCL6CUekbAHgA2p7bdfenzBMm1kE6VTJkpnpCmcYmlb2Y3V7MpqupAGQ5hb/JynOsnJQImVQQnYLzM+Wwu3D3bXUTz1WlL4LjUHtLGXOBDIDXfOird3upK9oH4I5YhNCqzSX8wYcrEZejEDKQSDDdYKpu0nR/x/8zguPH9Lm/jTeWwGy+OpdGDMsh7DVv5s8A4FzjRWFJASJxoPdS/5y66oyMhrFpD4+dO32mC7ylvrZo33cf72IZYQbAa1stzf3a4NC/24JR6RsK0R1a0z21cNhd83Z/U2kq55LsAvkcinB0ED/7TRsKSwrgdms4+HBlIrSdCwSyHX7TyZtfPJEIGeYwMhqGw+5K+zUsLlCLxAGiSl8COLC6QAbAa1bGHJB6z12P3AughsiUbq8t5Tft4TEyGs6I+0sVglbZeSean+5CV2cYg/4Q7r6tDis9ZYjKYxN/I4Vu08u1BnBiUsIJMccL1wov3A4gMqAXRM9Fpgu8aWsRrxCqArjd2NpUYy6QAfCaVEe7rDY17hSCUekvFUI1ALAWPSsLmEywriaxOkGR4zB41o8zp/wAgMoqL7bu9U7ZfDXdlvvLzf1piE1KhETi+jxgOlMAydew8b01IDK1ukBtcJhjLpAB8NqS8a2vnunpaQCwhchUNd2fddAoCrnilmklg+2Hh09g0B8CoC95c9lzp02WEE27YvXIcodisos1W2MphIKMSSlNAUx1rRSFoKqeYvOWEj4WIWokjg/U1xXteuVwH5sLZAC8ttTS3K8ZDQ/+bCr3l+7gmo/MBIlDVDHUJeHo73oBANW7SlG93w2ZxlJaTmeCj2ha1q8CsSY8ZguDiws3YNV6PZzvOhefNZk007URBBEPNdTqhwBwRJW+CHBgLpAB8Jpzf7fe0ngngF3Tub90w6t5h8Wahid/MlH2smfLtisKf1PV5D6AyyfsnS4MXlumt8Ya9IcQk0enTYTMdk1MF1i1OeECG+rrira+crhP+5PPVrIxygB4Tbm/L5uZ31Td33RucL6u0OPIm1T2UntLGczW+6k2U1gO2WFtDnWJeY6VqNuo10BG4kD3Mcecv5CIQiAIIrZuLgEAFQBPVOnzALTBgRhbH8wAeM24v7sA1BKZqjfVrErb/WVaUnx0UreXjzZsmdtOclfR/J9VVdcBBR4eCqGJgujkudpUJAoiFIXgwP3FWFtaKCiEapE4DtTXFd9gbJ7E5gIZAK9u93fo3ho+GJW+arg/7eD7diXcwXw1F4h6HHmJshcA2HP7Jqys9CAuR+fcYdpshKpl0UqQ+RyLc83Erne9l/rn1XSCKAROex5q95aByJQCEIkqfQ76vCATA+DV7f5OB7oPANhurftTFAIxw4mDVGDosLswNBJKlL0UlhTgwP3Fidb7TLq8+cWJPUIGhznE5FEIhpuby5dOTB41XSBvuMAH6uuK1wNQ2VwgA+DVKM5wf2IwKn0lOfNLMhj+WgdlKoPzxz+6lCh72XhjCUq9JXN2OGbYnH4n6IV1fvN1omKOF76SFQD0gmgx5Jiz+0u4St0FcoYLdBJVegxsLpAB8GqU0f9NPXL+xEEAm4hM1d23FvOb9vCIyaOT3B9RSOK2kE7QYXdh5HwER351OuH+zI2XgPQW/F/tEmxu1N9wEwAgJFF0nkNaS+Kmup6mCywpFk0X+NF9DavKjLlANl4ZAK8e99fRLqsP3Lk5D8BfmK3uJ3UIMdfZzgC9+UBxOghat7h8qEFfg5y88dJc3GA2LIPLhPOzvh8zEQLoHaLn4vqucJaCiD23bzJd4IrIQOhR6MvjmAtkALw6ZLa677h89k8ArCMyVXfvXWsz3d9MA2UqN5gJZ+iwu3D8PyOJoufKKi827bkSdqYLTKcW0LpUjFuGDVGndYGreLiLCkBkip5eOaUvhtmuFTEywhYXeOiBOzcXMRfIAHjVnPeW5n51X8OqIgB/arS6t338E1XzKnshGegT+LPftCFiVK3cfVvdjCFdOuGwzeZY0hOeSednlddViOJivTNM34WhRCIklS+tGb8wBBE1e9aaLtDbOXT249A3UmdjlgFw2bs/DoB2+WLoSwAKiEy1971/Lee0580bYuk+30yOOOwunD5C8caJcML9pbrx0lxAtFBAmna+YYFcp00QUVrkhWjnZyyInst1fOBgJZzuhAv8xL6GVfkd7TIF2zyJAXC5al/DKnOjow0APm60urc9cLBySYue43IULf+vHQDgdmBSt+JMgWIqCC0kCBcDtoLgRHVFOQRxckF0JiQKIva/r4wjMlUBlMhB+lHDBbLCaAbA5anLF0McwGlGq/tcAOqe2zdlxP3N1QWuyPPi9BGKd04PQSE00fAgVXeXiksUBGdasEoXWvN57nxVvisOtwMgMsVgWMrY1ARRCOo2boHTLXIKoVowKn2yqXGnnblABsDlGvrynW/JtL6u6HYAH4pFCF1bWigcuL94UuJjsTUyGsZTPz0KQM9oHjqwbU67zmVy+00r2FKB3lJKFMTEXsG9l+MZdfJV9RTVu0pthgusNFqlMRfIALjsxL1xIoxnnryPD0alb5sNDx5p2g2nPS/jL2addJ/JgazI8+LHP7qE7rODUAhF7S1lWFHhnvMgng6C5jK4TAIxG7LJYo4XgiAmWuRHBkIZLWAnCsFdtdsg6rzTglHpkwAHtoUmA+Cy0o4aO9/5lky/9sRLnwew2VzyVlVPl9T9DQ0HcPTV3oT7+8hHqxbEyS2WK1xsmatbXCv0REhIoug+5oAgiBkDYfmuOG64oZCPRQgA3FJfV1QNfY0wc4EMgNmvqpvtfEe7rNTXFe8E8FWFUCraedtc211lbPAKIn7yrwH4w/qStz23b0Imt9207jk8n2VwU4W62RD6WmUmQohM0fruqYyH2BtvLAEACoALRqX/BkCr2JDD5gEZALP/HOvzfsXrglHpeYVQkciUu/e+zdymPXxGw6XZQqlkxeTRxJK3Ag+P+Wy6Ph0E+RyaqCXUlvF+wKm4NLdRARP0RzI6D5hcGA3gDx64c/P68++MK2DJEAbALJfZ7OAZhdAyIlO6+9Zi20ceWrNkoa/ZgPPZ5vMISXRa9zffQUxoJAHC5b4b3HQy35coiInOMF2dYRCjk0+mvuBEQUTtLWUckSkAFHaHB9oeuHNzORvHDIDZLA76XI0dwE3mnYPD3KI5v6ngJwoiYvIo2o9cBACUePV2VyOjYXbF5gIn3g1BECc6w2SwINp63SwlMTQYlYq7wwNrwNYIMwBms/sDYHvyhfbI6nUFDYLId4l2nu886Ve/860zGe/1l6oEQcSPf9gJf0CHcO3esgXJRJuy885r4mLX33ATRPtEQfRC7OGsEEqNcXt649q1v4feUo1lhBkAs1YqANsrh/t+63N53iOIfK9o57m2X/eoP/7RpUWFoNX9Hf1dL0Q7n3B/04W7mZjLyvbd4OYrlz1X39joOiQSIWRMyvjrPPXToyAyhSDynM/l+fJTLb+XjaYarGs0A2B2Q3BHjT2ntS1w2efyHBREnhPtvPrCcye1zlZ+USFodX9Epgvu/vTXvPodIFEISEEcPpcHgL5VppLB+b+f/GsAnSf91OkWeQC/bG0beL7qZjvf0txP2fBiAMx6dbTL4ztq7EJrW+BVAF8SRF4gMqVfe+IlLBYEk93f2tLCGd1fJl3gVT2IjGvntOdhzXX6kBr0hxKOe77qbOXx4ounNaMYWva5PJ8GNK7zLZk5PwbAZQVBWrEhR+g8OfY3AFqcblGIRYjy7X95KWODZS7ub6ETMplaBZKtsjrcsjWlADKbCHnqp0cRixBFEHne5/L8VWtb4B2znyQbVQyAy0na+XfGKTTNtqdiy38F0Op0i4I/QMYf/dirC+oERUGE0kcTzU6t7i+V15yPC8ymvUAWWtGRMEQ7j1iEZCQR8sTfv4nOk37F6RZzALz2SNPuv2s8WMqzxAcD4LKFIAA8+UI7Wb2u4F4AbzndYo4/QJSFDIcFQcQPD5+AP0Ag2vlFc39Xuzg44cxdBwBofroLL798GYLIJ2A4X/i99tsAdbpFAUBg9bqCBx489Bxtae7XwBIfGRFbS7h0ELRd6ByJbtlV9FxEitfn5PLlsQhRjhw7y0VjCrd5SwFEQQRV5z/HLQoiZBLHt/7hLZid6R/8YA0K19mQI4hQVQqiEPC2mT8Oqkphs6X3kXHYXSgp2HrVQQ8Yx2h8CKeO/l987+lf4cc/7sLR1y4k4MdxQE5OLm7bV5LWNTSv+d9+4y0ca00kPSI+l+eDR37lP22MWeb+MnYtmZbagasP3LnZ3nH57FMAHlAIBZEprdpcwjfdU4vyXfF5v4jTnocffP8Efv78OTjdIhRCIYg8qneV4q7abaiqp4n9bFNxkunI6yrE6pJ9yxZ05vK90fgQYmMX8erz7wAAXjz6Bi6eisEfDoHI1OzWkgCgQigKPDz+8V/2prwiRBREdLby+N5Tr6Gnf1AxnN+wz+X5YGtboLXqZr2hBhs2DIBXHQQBDlU35z4K4G8AOGIRQgFw22tLbY3vrUH5rvicllaZz/nDh16F2YLLlDlwy68vxNbNJThwf3GiJGY6GKYLwOKV16Mof3sWOzmrLddhNxy9gMDgO3jz1TCOn+/GYFhC7+U4Ll8MwejIop9bO58AntsBiDYPKn2r0RW8nGgw8defa0BVPZ11FziiEDzb3IVfHL6gEZmaYe8Fn8tzoLUt8MaOGrvQ0S4rbLgwAF6t14EDoNbXFW8ORqVvArjTdIOincdNW4v46yqKceD+4sSgAWbvNiwKIp74p7fx6i8uTHJ/boeeqTReAwBQUiyielcp9mzZhvJd8Un1gclATBWEa0p2Id+1fsnhlgw509H1nnwHneeA4+e7ERmNovfiCAb9IYSkifNiws7q8Ezg2X08SuhKOMWJ14uRGDoun0UsQvDhB7bi4MOVV6z7tl6/Z5u70H6kR/MHCBXtvGC8xi99Ls/DrW0Bv5H0YM5vASSwU5AV0qCv6eRbmvtPAtwH6+uKDgQh/bkg8tsUQvH60X68frRfefFFkatcX2DbeGMJV11RjvJd08PQDKlee7UHop3XFEITX3hVK68HAHSHBxCMSlAIRUii+Pnhi3j55cso8RZge30e6jZuScDQ7Opi7RhjgnEqICoKmXcGONWmpxpiGI0P6a+rRhAY1EPVN1/VExHmXh2X+kIYDRNIAzTxvqcDnflFAeiwA4Byb5E+rWAB3kwz6dZEiPU6dbbyePHoGzh+rF+NRYgm2nnecH1hn8vz9dajA9/q1AJg8GMO8FoMiQFAfebJ+/ivPfHS/QA+DmA3AM4yYKlo57USb4GtcmuerdDrmdId/sWfn0DnSb/mdIucz+VR/eGQDQBqKzYkBnGMxNAdHgBRpYQrtIbIBR4elVVelK0phQ7deOJ1TPA57K5Je/+aWrvqg2lBzJQVZgAQGHwHsUthdJ6beLwJtchoFINDcYxEFMhBOul9kKQpM9HSSd50c6ajs4LOU8TDO74SPC8il0/PJ4xRBWcGTsEfINheW4ovfOlm/cvmmANHTujQ8weICsAm2nmbcRxhtwM/Em2ex1vbAhetUQEbEgyA15wmTXhzHOpri7YFo9JdAO4AsB1ArmWAawCo0627w4qqPK7+hptw5MQb+Pnhi2Ym8Rmfy3MuGJW+ohCq1FZsEJyiE2NUSQzwMaqAUjItDK3zXm4H4C4qQJ6LgytPxEqPDWKuZ9J7qK4on/V9WndRk7p4RByDGJPHMRrVJsEMmBpoU4EtGW5WwE0FOQBzAt1MOh3ohj8cQoGHx6r1K9V3Tg+pxvyhFXoAcMrtwI+qVl7/f5596WQfAOb6GACZzOvTeLDUZhS9auYlq68rqgSwJxiV3mc4w7VJgFABqJZwbnj1uoIbLl8MHQDwP5MBaNVUMASAYHRicb81mUIWICmZDsySoQYAdh+PXBsWDG7pANDcLjPpPVxwO/AL0eb5ySNNu488eOg5xfKlpzHXxwDINEVovKPGbjO2REwUwR66t8ZxOtC9LRiVbgewD8A2AB4TVILIw+fyfKa1LfCd+rriTwaj0hMKoUr59YVCBb/mCgAmg9Aa1lFKEM4ZgjRgAaA6AcZImhU7s4HMCjNgaYGWrs7TS+g+O6gZnVteD0alN9wO9Is2z6ubisvbnnyhPXG2LCs7WHEzAyBTGjDUoO8Tkbic+xpKy+QgrQlGpfcAqPe5POFK3+qHmw8f76uvK743GJWeUwhVS7wFtk3F5VMC0OoCUwWN+Xconb1Mh+fFKSE7k7RcFdyYDVruhDnixrJ3IVOMxHD0/DuKIPKCz+X5dGtb4B+tv6/YkCPs3OnTGPgYAJnmeQ2rbrbb3A5wye4QHGf8pN+1o8a+LRLH6wqhWom3gJsOgOnCiWlmAAJ43O3AnwEQKqu84wx62SP2KV/+0pJWB9gaD5Zyv/99kLNsmmMDQEWbRwYk9sW3WINrYt6vtKN9TAE0raOdJTcYAJkWUmpLc/8kQJpuw+7jxxAFASAa9zEQLpCMMJ8DALdDT1KBJTeyTqwbzDXiEgGgDKUhACFAT16w8HdhZJ5Xt0Ov24zEkcfOCgMg0xIDsPnw68MmADHDHNR0YGRKXUlfItxs55yJAZBpkQwKMHvJCoPg/NxfkvIO3btLTIIhEwMg0xJca7NwT5utZIVBMCPnnAKoPB3oPgAAO2rsrAcnAyDTEsisiek2spMsHFtgGUXdGgAEo9JqdkYYAJmWSDtq7GboNQjgit6ATJkPf+2+Sc0WxtgZYgBkyoJxav2BZXwXBn4AEkv4DDcos7PEAMi0xPK5PAPm//380JwGNlNq58hYM2067yAAVFZ52dQDAyDTYssceMGodN64i5ODNOUBzkA4vzFGVOkyAAwOcwyADIBMS+gAR0wAsrOxMM4vSZwRAo8AwCuH+9iJYwBkWkIR68Bkzm5BZbo9iklde5gYAJkWVcZm2oA+F0UMAKYVjjFYzvmcSJW+1cNJUGRiAGRaAjcSADDMTsfCgm+MKiCqZJ7zgQ/csy7IAMgAyLTE2rh2LYFRCmMZoEwLIMtyw/iDh55XweZdGQCZllbf/OcvKADkpAHKlGEZywytrhsMgAyATEsbAnOFvj+gAMxaQC2VFvbphH5ME8XlCqGaseywE9Cwo8bOxhsDINNSqWJDDg9NA4BeCxTT1rUOwXTfv9uBCPv0MQAyLbEKPIm1qbK5XeN8IMDc4PQyVtmYNYAX2BlhAGTKHmVs9u9agmA60DdW2Zhzfl0AWwbHAMiUNQaFnYJFG18agFF2KhgAmbJHPUmhGnOBmZfp9sIALgCAsR0mEwMg0xKLrQde4FDZUmMZeaRpN0uCMAAyLbXMOSifyzNu3pdqR5jlDKMYiSVui+VyI/GEA+x58GPPm/szsznALBPrhnltavhq/gIco4pZiIzucKL9Icq9RYsCP7MI2qgBvAhNw44aO9/RLrO5AgZApqWSpSGCH/om3eYk/bxDYRMSS9lh2nR4U0HPet9CKpcXEKMECqEQRB5uR2IVCBMDINMSyzoxLwNwLoT7WkwQxkgM3eEBlHuLEpBLdnrm/TwvLsoxJSWW3mIfOwZApuySCmDZh2MxEkPH5bOJgu6pQlwrFBcLysa8qg0ARJsnBMiorPJqHe397JOXZWJJkGtQlb7V44YDBFGlBXmNxSiN6Q4PJELNZOAt8fvQjLE1DuBs0vQDEwMg01LqA/esi8JIhFiylcvO/QWjkjnPlnB/Vhc4HxjOdalf0nNidh/P+gAyADJliTQA3IOHnh+HsT/wQg7MhXSBfn4oEfoaG5BPAt5c4ZeJNc7BaKIG8FIFv2YErN6SAZApm665BgCJorh0W2Jlg6aqX5xrmUsmldQHsPfJF9rHMZFtZ2IAZMoSLUoSZCFc4BhVEIzqc5fW8Hcm97dYGWBgUh/Ai+xjxgDIlJ2KGoN1USCYSRAGbf2J5Edy+LtY9X4p6jQA7KixsxCYAZApyxQy/l200CxTIJQGpob2dPBbzNDYOAYOAHwuzwDA2mAxADJljSxupN9aPrJcZIa/6TZ0nakG0ARzBl2qeWJPAawEhgGQKRs1vBwPmhrLzEzNtY5xATPUJuxku48fZh8zBkCm7FSCAJnoCbjIIWbWytIGq2e9s6x/sacZmBgAmVKQz+WRzf8vl5ZY1vA3W92ppbA89FRLxzhYGywGQKbskWVCfhgAiEwXPUM51zk3S/irpQOVJSqBedc4RDbGGACZskVvnAgDAIJRqS/5M7AUBdFWGM4GREv4y8GyumIpV33MoB6AlcAwADJllTrfkq0tsYBlskwrqfg55nboGw3NtpbZWgKzANneqQBtlsCwImgGQKZslc/loZYwUlvsUHEqTVWqYsLKCH8VQeQRieN/R+LoMELNbJtfM79Q3k0F0EwMgExLZKoAyKI9e2sBrU7NcFc2A97/nuVjisKYY129roABkAGQKYukGaFhBEAEAIJRKasbIlh2WbMB8G8qLm8FYLe+n3Sd5UKIqJK57WWw0re6GwBeOdzHAMgAyJRtAGw+/E/DAIYAPXPZcfks2i+eQlfwMnrRv6QJkWR4UUoQkigVRF4D8PKTLxwjWRj6IhJP/DfQfPh1thk6AyBTlorj+b2aEQYDAGIRgliEwB8OofvsIDoun8WZAR2Iiw3DZBBakgucz+V53mDfpCUg5d6iGdf8LnSHass50gDYD927qxysD2DWi+0Jcm0rDgCCyGvVtWXofTcOfzgEIlMQmSIWAUR7CP5wCILIw+fywO7jUUJXLlrCxMj+qtDX1/oBvGr8atB0r0FIIKqU6AxjAnGxV40ohJrzf1WnA93fB7g7AI037mNiAGTKFgdoOJXElo2ffmwjnPY8nD5Ccfx8N7ouBtF7bgD+gO5siEzhJyEgDFwWQ3A79E7MputaCCDm8gJiJAaFUFUQec7twIutbYFh49cDFvAgRAAgNO0qkeR5wLk6wlxemJSZNiFrluhY1M0WgDAAMmWhdtTYbR3tsgqjWFchVBNDDjgqXKjeD9RxW0A0DUPDAXQfc+DIqbdx8qg0pTu0NiYVbVc6xLkkIEzAmFteGlM1nGjz/MTYywnW8L3AwyMS10EYixCIdh5+osMwGJXgc+nO0Dy2ZGDPBEdr+O/nhyAH6CTgKUQ/H0Y2nRpO9ZlNxeWPtSJgg74DHxMDIFMWKiqIPGIRgs5zQHUFMDIahiDocHDa81C934Xq/fWIy9Ep3SGRdSCYQDQdohWKZkhqlZ8fmnYNMlGlRELBWFpmA9BX6Vt9BHWwtbYFVOg7rgEA9ty+CdUV5Th+vhu9l/rR1RlGSNJhCAA9kUEdUJZjM4/PlHmc1u4ylqRGAnamG7aqpFg/XyGJcsZUwXeffKE93niwlG9p7mcAZABkykb5XJ6R5NDNhJ+puBxN/L96vxvVuBkAEu7QCsSQRBMOcRIUgcQ8ohUkU8LPAhfRzkMQeWp8Tn/RfPh4bHW5zQ5AdjswagKKjOnvobqiHNUV5cBtSMAwEuEgDVAEoxJiETLp78ci1lceTOmciXYeJcUiCksKUFG1AvU33Iiqeoof/OCU9sufnbcJIi9Dn6vkGPwYAJmyWMGodMH4L3f8fDeqcTMUhVwBwalgaLpDM1weGQ2js1UHXOu7p3C5L47B82MIRqVEmJjsnKxF2Ob2lqK3AJ4iHr5VDvRejqP77KDpqn7SCZkT7bwGqIjE9TlAIlNunFzJGROGVdcBwioeSh9F5zkdjGPjUYTCBMODehQ9NgWmcm1AjoODK09EgVdEbo5LhyuA8l1xOO15cNhdE/gcSNjFmNEHUAPLAjMAMmWfLMuzzIYIcxqocTmKuMU5Vu93GU6xLgFLK3iSAWWq6jrDyRXoYDH12c++phGZ8oLI91X6Vh9pRUAr8PD0vB799s527PprlqO6wgVU6CF+HbdFfy1NuwLqVlnhJnITL0E0DXGZv+K5wYuKCbzepntqR185/Bz7oDEAMmV5CDxmhMBcND5RtzuTC5xJI6PhK0JpYRWP6gpXInSeGah8Aj7H/zOCzpN+6nSLAoD/aD58PNp4sJQHoHW098PtQNwMgZPn6qyQNeFqwiqeBtwT/5/lsTF5FESVNMPR9j546DkFejKElb8wADJlmywdYfzQd4dzhcJEi8tRzgrBtD9MKYTOqar13VPAxNrf5zoho6szzJnuVbR5FKMWmlPH5CU7lw67C0oftUJ4mH3Clo/YSpBrUxoAVPpWB2C0xRqTx+ddtKYoZE7gnMpJvvG7YVW08zYA/nJv0W8BoKNdphZ4D0PPBHORCLekBXed54BYhJiNUNlWmAyATMtBT7/w+DiAGAAELyqIyZlZvjofEDrsLnS28vCHQ6og8prbgV8++9LJiBFSWjtBBwCEZ+pmkzzvuEgaYJ8sBkCm7HeANp7fqwLoFu18YjOfucz9TRUKT/d3ZoKjeX/ru6dAZGoWPz83laPatDM/BmN6ThqgMzrAuYTg6cgArdkINcw+XgyATFmuHTV2m2Gm+oDMNu40ITfVbarHmD8LgmiGv5oR/g5W+lb/xgx/ra/xN1/57xTGspDptsa0ZpoXQkkgN8dSp3G8rAaQAZBpGWjYXA3SfUxfGkGUxe3+YgWJEf4mWl81Hz4uWcJf071yhSv/QIWexAEAbbZwV1nA9zQYlswSGAqjxyITAyDT8tCpbDkQh92F4+e7zZ3qOJ/L8wIArvFgabJ75Q0eXjJa5GszhKYpOdPpnOpsistRBPsSKeBwpW91xAJqJgZApmyW25FYA8ZZgUEUsuhOcGQ0jDdP+jXD8YXLvUW/AqDNsKQsBkxeWpcMPVIQn9OxzAZF689j6kRh+dMvPD4EthcwAyBTloOvqEAFANHm8RuD1WYthk4G4ULCkBjzf52tPLrPDlKnWwSA3zz70tshs/h5uugz8TfGrpwHNOcAMxX+JsNQEETE5FFEBkJmEfSo0WiWiQGQKZtl2aviguGkuFCYaDPBwgrDZDBOdd9Mf2e6kNVcL+xzeQ4DGtfVGZ6pnu5cKqHvQssSgl9g44oBkGkZaVNxeQzG6oWhobk5vameMx0spwKm6a7OnQ9o0FcnyQB+BUCbJZsqAVM3RFgsCHYfc0Ah1Ox00w1orAiaAZBpGUgDYHvyhWOjALpEO4/IQGhJSjdEQQRRCN45PWSGksdbjw5cND6fVxxTZZXXdFzU4sKWREmulRVBMwAyLSNxxvTaoAmR7mMOiMLib5DefcyBWISoRlusl6FpRq3i9PK5PGZX6CVdD2yOo2BUOpkUEjMxADJlqyyh2ttGLeCSDdy2MycAPfsL0eb5dZLTm04pd1tJDr9nC9dTVf9A2BxH4z6Xxw+wzdAZAJmWm/qsId1iiygEXefiZjFxuNxb9DYApNBRWZjLayVDbyZgTvd7QRD1LQKO9atG2B6o3VvWBbDN0BkAmZaFTIflc3lM6tnGxpdmP+9Bf8gEyalnX3p7xlo6MzMcjEq5xl2aLdc+K/TmA+ipHOLx893WLjCd3/rGGwSsBpABkGl5qKW5XzNAkijfUOTxRT0GURDRfcyBkERNkBwzMql8Ck9fYQLQusHRIsuE3VtpHDcTAyBTtmj1uoIxGJ1VenrGFt29WJa/wefy/D6Np1YA+t4iOaJtyr+7kOq91G+OIc3n8rxoddVMDIBM2S8NAEroShlATLTzyrvvDqp//VcdCXe20CIKQe+lfnP5mwLgTWBipcosWrmYwLMqJo9icJhTjTF08acvfu/XhqtmXWAYAJmWkTin6BwBQASRFwDwrx/tp49+7FV0tvKLAsFL51Sz/q/nkabd54CUEwkzHtxCt8PCxHxfzheb/n6l5T4mBkCmZeIAuSdfaI/7XJ7P+lyeHwki/7bTLfL+AKFf+PoL2g+fentBD6D7mAPBqJSYR3vw0PPKLOt/r3CwACDmehbtpDnteeg+5kBkIMSJdn4cQNnpQPcfA5i1dpGJAZApu6QCQGtb4MetbYGDNeturAfwv5xukRftPPfCTy7Qr//FiQUtkDYzqW4HXgM0zLL+N/nzSwGoZ075F/QkiYKYeP/NT3fha0+8pIUkqlhc6LsAmwNcbmK7wjEBAPY1rLIV5mtcc/PxEYBrqq8ragtC+rYg8nknT/iVr114iX/fu2u5+htuQvmueMagYhRAcwA00eYZAGRUVnm1jvb+WZ/vduBsJA4eAH/yhF8Z9IeE6l2lcK3wZhR8AIABHk///G20H+nR/AFCRTsvGFMG7/hcni+0tg38DADX0tzPtsJcRmIpeyYAwIXOEe3UW6MaAK7qZjv/5nHp+A0VK1+KjY9V5+TyaxRCudNvDSmtb57X3n4jwg0OcJwzVoj8MmXOoe/zL57Ar17p0zgOxMbbcpyifeDS5eiLDofC9/Uq0yYTjN9xt2/fcnyEDAbGNdu2nFzeE41R7fz5iDrQN8SNQ+XGoGDTTXkJkFF1djaJggjexoO38aAqxb8924df/vxdfO/pk+rbbwxSQsHnOnNsNt4mAfjmrRs3P/yz/+h8G6z+b1mKTdgyTakdNXaho11Wmhp32k90n/xyJI5HAOQrhJqL/6lo51HiLeDW3ejkSou8nDXpYLpEs83+8fPdIGMSenplre/CkBaSqEpkyol2njfq/3p9Lk9Da1vgTeNzmXI2tb6uuCwYlf4WwIOA3iCVyJSKdl4r8PC2yiovV7amlKuuKJ/VvXYfc+D4+W70XurXujrDmj9AVAC8aOc54ziDAJpXryv47iuH+84DQOPBUp45PwZApqtPiW4s9XXFa4JR6T4A9wCoBeCwwBDG4zTRzkMQ+UmfK4VQzXicvtOb/hjz1xfdDjwr2jzfbW0L9KXrpExQG8dYH4xKjwC4E0C+BYaJ43O6Rc7tAOcuKuDyXPphjkY1RAZCGgAtJFHNqEm0JR3nm24HnhFtnmda2wL9FvCpzPkxADJd3Z8RM9kAgEN9XVE5gPcEo9L7AVQDKAeQYwInWRaIAMAogLNuB46KNs/L5d6iXxn7/k4C7hyOkbPAuoSo0m2ROG4HUAOgCoDdenxk8iZzMPcXthyrDH2T85d9Ls/Pfvu7ljaef48GAFU323ljg3ZW88cAyHStuMEdNXabsT2lZn58mhp3OM/09FQA2BaMSsUANgEoxESCbRxAL4AzxprjE61HBy5C05JdHM2AkzLplaAbpb+23XpLYyWAXUSVtkfiuBnAOgCrTGgDIAD6AVxyO/COaPP8HkB769GBM1Mcp8rAd/Xo/wPe73BuLjjOkQAAAABJRU5ErkJggg=="};   // { borg:dataURI, myo:dataURI, suiko:dataURI }

  /* ---------- helper registry ---------- */
  var HELPERS = {
    myo:{ name:'Myo', kanji:'猫', tagline:'A purple cat-spirit — sly, theatrical, half in love with her own masks and mirrors.',
      img:IMG.myo, accent:'#9945ff',
      lids:[[25,30,26,14],[59,32,24,12]], skin:['#fbeede','#f0ddc7'], lash:'#3a2f3a',
      egg:{shell:'#efe9f5', dot:'#b98cff'},
      moods:['serious','teasing','ominous','confident'],
      hello:'Nyaa~ I\'m <b>Myo</b>. 🐾 Every building you raise is a little stage, and the SOL it earns is just standing there for the lights. Keep it fed, keep it whole — a torn set ruins the show. Build first. I\'ll teach you the rest as we go, darling.' },
    borg:{ name:'Borg', kanji:'機', tagline:'A quiet construct of clean lines and colder logic — emotion noted, then set aside as irrelevant.',
      img:IMG.borg, accent:'#5ad1ff',
      lids:[[25,27,23,15],[59,27,23,15]], skin:['#dfe7ea','#c7d2d6'], lash:'#3a4448',
      egg:{shell:'#e3eef2', dot:'#5ad1ff'},
      moods:['precise','formal','curious','fond'],
      hello:'Systems online. I am <b>Borg</b>. 🥚 Lesson one, logically: a standing structure generates SOL without further input. This is illogical to ignore. Build, and income follows. I will cover the remaining mechanisms as they become relevant — emotion is not required for this part.' },
    suiko:{ name:'Suiko-bun', kanji:'河童', tagline:'A small kappa, damp and unimpressed — minds the silence between things as much as the things themselves.',
      img:IMG.suiko, accent:'#7a9c3f',
      lids:[[24,29,23,15],[57,28,24,15]], skin:['#cdd98a','#b7c46f'], lash:'#4a5a2c',
      egg:{shell:'#e4e9cf', dot:'#7a9c3f'},
      moods:['grumpy','dry','reluctant','wary'],
      hello:'…Fine. I\'m <b>Suiko-bun</b>. 🥚 Here is the thing, said once: buildings earn SOL just by standing. Put one up, it pays you. The silence after that — what you do with it — matters more than I\'ll bother explaining twice.' }
  };
  var ORDER = ['myo','borg','suiko'];

  /* ---------- persistence (webview-safe) ---------- */
  function lget(k,d){ try{ var v=localStorage.getItem(k); return v==null?d:v; }catch(e){ return d; } }
  function lset(k,v){ try{ localStorage.setItem(k,v); }catch(e){} }
  function jget(k,d){ try{ return JSON.parse(lget(k,JSON.stringify(d))); }catch(e){ return d; } }
  var seen    = jget('yk_seen',[]);
  var hatched = jget('yk_hatched',[]).filter(function(id){ return !!HELPERS[id]; });
  var enabled = lget('yk_on','1') === '1';
  var cur     = lget('yk_helper','');           // '' until first choice
  if(cur && !HELPERS[cur]){ cur=''; lset('yk_helper',''); }   // stale id from a prior build (e.g. removed helper) — reset to unset
  function isSeen(k){ return seen.indexOf(k)>=0; }
  function mark(k){ if(!isSeen(k)){ seen.push(k); lset('yk_seen',JSON.stringify(seen)); } }
  function didHatch(id){ return hatched.indexOf(id)>=0; }
  function setHatched(id){ if(!didHatch(id)){ hatched.push(id); lset('yk_hatched',JSON.stringify(hatched)); } }

  /* ---------- styles ---------- */
  var css=document.createElement('style'); css.id='ykCSS';
  css.textContent =
   '#ykWrap{--yk-accent:#14f195;position:fixed;left:14px;bottom:104px;width:104px;z-index:12;pointer-events:none;'
  +'filter:drop-shadow(0 6px 10px rgba(0,0,0,.45));will-change:transform}#ykWrap.off{display:none}'
  +'#ykFloat{animation:ykFloat 4s ease-in-out infinite}'
  +'#ykStack{position:relative;width:100%;aspect-ratio:1/1.32;cursor:pointer;pointer-events:auto;transform-origin:50% 92%}'
  +'#ykStack.perk{animation:ykPerk .6s ease}#ykStack:active{transform:scale(.95)}'
  +'#ykImg{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;-webkit-user-drag:none;user-select:none;transform-origin:50% 88%}'
  +'#ykLids{position:absolute;inset:0;pointer-events:none}'
  +'.ykLid{position:absolute;transform-origin:50% 0;transform:scaleY(0);border-radius:0 0 45% 45% / 0 0 72% 72%;display:none}'
  +'#ykGear{position:absolute;right:-2px;bottom:8%;width:22px;height:22px;border-radius:50%;pointer-events:auto;cursor:pointer;'
  +'background:linear-gradient(#262b31,#171b20);border:1px solid var(--yk-accent);color:#e6edf3;font-size:12px;line-height:20px;text-align:center;'
  +'box-shadow:0 2px 6px rgba(0,0,0,.5);opacity:.55;transition:opacity .2s}#ykStack:hover #ykGear,#ykGear:hover{opacity:1}'
  +'#ykMin{position:absolute;left:-2px;bottom:8%;width:22px;height:22px;border-radius:50%;pointer-events:auto;cursor:pointer;touch-action:none;'
  +'background:linear-gradient(#262b31,#171b20);border:1px solid var(--yk-accent);color:#e6edf3;font-size:13px;line-height:20px;text-align:center;'
  +'box-shadow:0 2px 6px rgba(0,0,0,.5);opacity:.55;transition:opacity .2s;z-index:2}#ykStack:hover #ykMin,#ykMin:hover{opacity:1}'
  +'#ykWrap.dragging{transition:none!important}#ykWrap.dragging #ykStack{cursor:grabbing}'
  +'#ykStack{transition:transform .35s cubic-bezier(.34,1.56,.64,1)}'
  +'#ykStack.x-serious{transform:rotate(0deg) scale(1.03)}'
  +'#ykStack.x-teasing{transform:rotate(-6deg)}'
  +'#ykStack.x-ominous{filter:brightness(.85) saturate(1.3)}'
  +'#ykStack.x-confident{transform:scale(1.06)}'
  +'#ykStack.x-precise{transform:rotate(0deg) scale(1.02)}'
  +'#ykStack.x-formal{transform:translateY(-2px) scale(1.01)}'
  +'#ykStack.x-curious{animation:ykTilt .5s ease 1}'
  +'#ykStack.x-fond{filter:brightness(1.06);transform:scale(1.04)}'
  +'#ykStack.x-grumpy{transform:rotate(2deg) scale(.99)}'
  +'#ykStack.x-dry{transform:rotate(-2deg)}'
  +'#ykStack.x-reluctant{animation:ykShrink .5s ease 1}'
  +'#ykStack.x-wary{filter:saturate(1.25) brightness(.92)}'
  +'@keyframes ykJitter{0%,100%{transform:translateX(0)}25%{transform:translateX(-3px) rotate(-2deg)}75%{transform:translateX(3px) rotate(2deg)}}'
  +'@keyframes ykBounce{0%,100%{transform:translateY(0) scale(1)}40%{transform:translateY(-9px) scale(1.07)}}'
  +'@keyframes ykTilt{0%,100%{transform:rotate(0)}50%{transform:rotate(-8deg) translateY(-2px)}}'
  +'@keyframes ykShrink{0%,100%{transform:scale(1)}50%{transform:scale(.93) translateY(3px)}}'
  +'#ykBubble.x-ominous{border-color:#7a5fff;box-shadow:0 8px 26px rgba(0,0,0,.55),0 0 18px rgba(122,95,255,.35)}'
  +'#ykBubble.x-fond{box-shadow:0 8px 26px rgba(0,0,0,.55),0 0 16px rgba(90,209,255,.3)}'
  +'#ykBubble.x-wary{border-color:#5a6a3a}'
  +'#ykWrap.min #ykBubble,#ykWrap.min #ykGear,#ykWrap.min #ykEgg,#ykWrap.min #ykFx{display:none}'
  +'#ykWrap.min #ykStack{aspect-ratio:1/1;cursor:grab}'
  +'#ykWrap.min #ykImg,#ykWrap.min #ykLids{clip-path:circle(34% at 50% 32%);transform:scale(1.9) translateY(6%)}'
  +'#ykWrap.min{width:46px;filter:drop-shadow(0 4px 8px rgba(0,0,0,.5))}'
  +'#ykWrap.min #ykMin{position:absolute;left:auto;right:-2px;top:-2px;bottom:auto;opacity:.85}'
  +'#ykEgg{--es:#ece6d7;--ed:#e3b24a;position:absolute;left:19%;bottom:3%;width:62%;aspect-ratio:1/1.3;opacity:0;'
  +'background:radial-gradient(58% 52% at 38% 30%,#fff,var(--es) 58%,#d8cdba 100%);'
  +'border:3px solid #4a3b2e;border-radius:50% 50% 48% 48%/62% 62% 42% 42%;'
  +'box-shadow:inset -5px -8px 12px rgba(0,0,0,.14)}'
  +'#ykEgg.show{opacity:1}#ykEgg.wob{animation:ykWob .7s ease}#ykEgg b{position:absolute;border-radius:50%;background:var(--ed);opacity:.9}'
  +'#ykEgg b:nth-child(1){width:26%;height:20%;left:14%;top:24%}#ykEgg b:nth-child(2){width:17%;height:13%;right:16%;top:14%}'
  +'#ykEgg b:nth-child(3){width:20%;height:15%;right:20%;bottom:20%}#ykEgg b:nth-child(4){width:12%;height:9%;left:24%;bottom:16%}'
  +'#ykFx{position:absolute;inset:-14% -20%;pointer-events:none;opacity:0}#ykFx.on{opacity:1}'
  +'#ykFx i{position:absolute;color:#ffe9a8;font-size:18px;text-shadow:0 0 7px #fff4cf;animation:ykTwinkle 1.1s ease infinite}'
  +'#ykFx i:nth-child(1){left:6%;top:10%}#ykFx i:nth-child(2){right:8%;top:4%;animation-delay:.2s}'
  +'#ykFx i:nth-child(3){right:12%;top:40%;font-size:13px;animation-delay:.4s}#ykFx i:nth-child(4){left:12%;top:46%;font-size:12px;animation-delay:.6s}'
  +'#ykFx s{position:absolute;left:48%;top:52%;width:10px;height:13px;background:#fff;border:2px solid #5a4a3a;border-radius:30%;text-decoration:none}'
  +'#ykBubble{position:absolute;left:calc(100% - 4px);bottom:34%;width:206px;max-width:46vw;pointer-events:auto;'
  +'background:linear-gradient(rgba(23,27,32,.96),rgba(12,14,18,.96));color:#e6edf3;border:1px solid var(--yk-accent);'
  +'border-radius:12px;padding:9px 11px 10px;font:500 11.5px/1.42 "Trebuchet MS","Segoe UI",system-ui,sans-serif;'
  +'box-shadow:0 8px 26px rgba(0,0,0,.55);opacity:0;transform:translateY(6px) scale(.9);transform-origin:0% 80%;'
  +'transition:opacity .22s,transform .22s;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}'
  +'#ykBubble.show{opacity:1;transform:translateY(0) scale(1)}'
  +'#ykBubble:before{content:"";position:absolute;left:-7px;bottom:18%;border:7px solid transparent;border-right-color:var(--yk-accent);border-left:0}'
  +'#ykBubble:after{content:"";position:absolute;left:-5px;bottom:calc(18% + 1px);border:6px solid transparent;border-right-color:#181c21;border-left:0}'
  +'#ykBubble b{color:var(--yk-accent)}#ykBubble .ko{color:#b98cff;font-weight:700}'
  +'#ykName{font:700 9px/1 "Trebuchet MS",sans-serif;letter-spacing:1.4px;color:var(--yk-accent);text-transform:uppercase;margin-bottom:3px;opacity:.9}'
  +'#ykToggle{position:relative}#ykToggle.off{filter:grayscale(1) brightness(.7);opacity:.6}'
  +'#ykToggle b{position:absolute;right:-2px;top:-3px;width:8px;height:8px;border-radius:50%;background:var(--sol);box-shadow:0 0 5px var(--sol)}#ykToggle.off b{display:none}'
  +'.yk-hi{animation:ykHi 1.3s ease 2;border-radius:8px}'
  +'#ykModal{position:fixed;inset:0;z-index:31;background:rgba(0,0,0,.74);display:none;align-items:center;justify-content:center;backdrop-filter:blur(3px)}'
  +'#ykModal.show{display:flex}'
  +'#ykBox{width:min(560px,94vw);background:linear-gradient(#1b1f24,#0f1216);border:1px solid #9945ff;border-radius:14px;padding:18px;color:#c9d1d9;box-shadow:0 14px 50px rgba(0,0,0,.65),0 0 26px rgba(153,69,255,.2)}'
  +'#ykBox h3{margin:0 0 2px;color:#e6edf3;font-family:"Yu Mincho",serif;font-size:18px;text-align:center}'
  +'#ykBox .sub{margin:0 0 13px;text-align:center;font-size:11px;color:#9aa3ad}'
  +'#ykCards{display:flex;gap:9px}'
  +'.ykCard{flex:1;background:rgba(8,10,13,.6);border:2px solid #2a2f37;border-radius:12px;padding:10px 8px 12px;cursor:pointer;text-align:center;transition:transform .15s,border-color .15s,box-shadow .15s}'
  +'.ykCard:hover{transform:translateY(-3px)}'
  +'.ykCard.sel{border-color:var(--c);box-shadow:0 0 16px -2px var(--c)}'
  +'.ykCard .pic{height:128px;display:flex;align-items:flex-end;justify-content:center}'
  +'.ykCard .pic img{max-height:128px;max-width:100%;filter:drop-shadow(0 5px 7px rgba(0,0,0,.4));animation:ykFloat 4.4s ease-in-out infinite}'
  +'.ykCard h4{margin:7px 0 2px;font-family:"Yu Mincho",serif;font-size:15px;color:#e6edf3}'
  +'.ykCard h4 span{font-size:11px;color:var(--c);margin-left:5px}'
  +'.ykCard p{margin:0;font-size:10.5px;line-height:1.35;color:#aab2bb;min-height:42px}'
  +'.ykCard .pick{margin-top:8px;font-weight:700;font-size:11px;color:#0a0c0e;background:var(--c);border-radius:6px;padding:5px 0}'
  +'.ykCard.active .pick{background:#2a2f37;color:var(--c)}'
  +'#ykFoot{display:none;margin-top:14px;align-items:center;justify-content:space-between;gap:10px}'
  +'#ykModal.settings #ykFoot{display:flex}'
  +'#ykFoot .pwr{font-size:11px;color:#9aa3ad}'
  +'#ykFoot button{font:inherit;font-weight:700;cursor:pointer;font-size:11px;padding:6px 12px;border-radius:6px;border:1px solid #05070a;color:#c9d1d9;background:linear-gradient(#262b31,#171b20);margin-left:5px}'
  +'#ykFoot .act{color:#0a0c0e;background:var(--sol);border-color:var(--sol)}'
  +'#ykHint{margin-top:12px;text-align:center;font-size:10.5px;color:#7d8590}#ykModal.settings #ykHint{display:none}'
  +'@keyframes ykFloat{0%,100%{transform:translateY(0) rotate(-1.4deg)}50%{transform:translateY(-9px) rotate(1.4deg)}}'
  +'@keyframes ykPerk{0%,100%{transform:translateY(0) scale(1)}30%{transform:translateY(-14px) scale(1.05,.95)}55%{transform:translateY(0) scale(.97,1.03)}}'
  +'@keyframes ykWob{0%,100%{transform:rotate(0)}20%{transform:rotate(-6deg)}50%{transform:rotate(5deg)}80%{transform:rotate(-3deg)}}'
  +'@keyframes ykTwinkle{0%,100%{transform:scale(.6);opacity:.4}50%{transform:scale(1.15);opacity:1}}'
  +'@keyframes ykHi{0%,100%{box-shadow:0 0 0 0 rgba(20,241,149,0)}50%{box-shadow:0 0 0 3px rgba(20,241,149,.85),0 0 16px rgba(20,241,149,.5)}}'
  +'@keyframes ykRise{0%{transform:translateY(14%) scale(.3);opacity:0}55%{opacity:1}70%{transform:translateY(-4%) scale(1.06)}100%{transform:translateY(0) scale(1)}}'
  +'@media(max-width:760px){#ykWrap{left:8px;bottom:auto;top:44%;width:76px}#ykBubble{width:158px;font-size:11px}.ykCard .pic{height:84px}.ykCard .pic img{max-height:84px}#ykCards{flex-wrap:wrap}.ykCard{flex:1 1 28%;min-width:84px}}';
  document.head.appendChild(css);

  /* ---------- DOM ---------- */
  var wrap=document.createElement('div'); wrap.id='ykWrap';
  wrap.innerHTML =
    '<div id="ykFloat"><div id="ykStack">'
    + '<div id="ykEgg"><b></b><b></b><b></b><b></b></div>'
    + '<img id="ykImg" alt="guide" draggable="false">'
    + '<div id="ykLids"></div>'
    + '<div id="ykFx"><i>✦</i><i>✦</i><i>✧</i><i>✧</i></div>'
    + '<div id="ykGear" title="Guide settings">⚙</div>'
    + '<div id="ykMin" title="Minimize">▁</div>'
    + '</div></div>'
    + '<div id="ykBubble"><div id="ykName">·</div><div id="ykMsg"></div></div>';
  (document.getElementById('gameRoot')||document.body).appendChild(wrap);
  var img=wrap.querySelector('#ykImg'), stack=wrap.querySelector('#ykStack'),
      lidsEl=wrap.querySelector('#ykLids'), egg=wrap.querySelector('#ykEgg'),
      fx=wrap.querySelector('#ykFx'), gear=wrap.querySelector('#ykGear'), minBtn=wrap.querySelector('#ykMin'),
      bubble=wrap.querySelector('#ykBubble'), nameEl=wrap.querySelector('#ykName'), msg=wrap.querySelector('#ykMsg');

  var modal=document.createElement('div'); modal.id='ykModal';
  modal.innerHTML =
    '<div id="ykBox"><h3 id="ykTitle">Choose your guide ✦</h3>'
    + '<p class="sub" id="ykSub">A little yokai will watch over your island and teach you its ways.</p>'
    + '<div id="ykCards"></div>'
    + '<div id="ykHint">Tap a guide — it will hatch from its egg. 🥚</div>'
    + '<div id="ykFoot"><span class="pwr">Guide overlay</span><span><button class="on" id="ykOn">On</button><button id="ykOff">Off</button><button id="ykDone">Done</button></span></div>'
    + '</div>';
  (document.getElementById('gameRoot')||document.body).appendChild(modal);
  var cardsEl=modal.querySelector('#ykCards'), titleEl=modal.querySelector('#ykTitle'), subEl=modal.querySelector('#ykSub');
  ORDER.forEach(function(id){
    var h=HELPERS[id], c=document.createElement('div'); c.className='ykCard'; c.dataset.id=id; c.style.setProperty('--c',h.accent);
    c.innerHTML='<div class="pic"><img src="'+h.img+'" alt="'+h.name+'"></div>'
      +'<h4>'+h.name+'<span>'+h.kanji+'</span></h4><p>'+h.tagline+'</p><div class="pick">Choose</div>';
    c.addEventListener('click',function(){ pickCard(id); });
    cardsEl.appendChild(c);
  });

  var tog=document.createElement('button'); tog.id='ykToggle'; tog.className='zb';
  tog.title='Guide — on/off'; tog.innerHTML='👁<b></b>';
  (document.getElementById('zoom')||document.body).appendChild(tog);

  /* ---------- bubble / tips ---------- */
  var hideT=null;
  function clean(t){ return t.replace(/\$SORU/g,'<b>$SORU</b>').replace(/\bSOL\b/g,'<b>SOL</b>').replace(/Kami ⛩/g,'<span class="ko">Kami ⛩</span>'); }
  var curMoodCls=null;
  function applyMood(mood){
    if(curMoodCls){ stack.classList.remove(curMoodCls); bubble.classList.remove(curMoodCls); curMoodCls=null; }
    if(!mood || !cur) return;
    if(HELPERS[cur].moods.indexOf(mood)<0) return;   // never let a guide show the other guide's mood
    curMoodCls='x-'+mood; stack.classList.add(curMoodCls); bubble.classList.add(curMoodCls);
  }
  function say(text,opts){ if(!enabled||!cur) return; opts=opts||{};
    nameEl.textContent=HELPERS[cur].name; msg.innerHTML=clean(text); bubble.classList.add('show');
    applyMood(opts.mood);
    if(opts.point) point(opts.point);
    clearTimeout(hideT); var dur=opts.dur||Math.min(8000,Math.max(3200,text.length*58));
    hideT=setTimeout(function(){ bubble.classList.remove('show'); applyMood(null); },dur); }
  function point(sel){ var el=document.querySelector(sel); if(!el) return;
    el.classList.remove('yk-hi'); void el.offsetWidth; el.classList.add('yk-hi');
    setTimeout(function(){ el.classList.remove('yk-hi'); },2700); }
  function once(key,text,opts){ if(!enabled||!cur||isSeen(key)) return false; mark(key); say(text,opts); return true; }

  /* ---------- per-helper visuals ---------- */
  function buildLids(h){ lidsEl.innerHTML='';
    h.lids.forEach(function(r){ var d=document.createElement('div'); d.className='ykLid';
      d.style.cssText='left:'+r[0]+'%;top:'+r[1]+'%;width:'+r[2]+'%;height:'+r[3]+'%;'
        +'background:linear-gradient('+h.skin[0]+','+h.skin[1]+');border-bottom:2.5px solid '+h.lash+';';
      lidsEl.appendChild(d); }); }
  function applyHelper(id){ var h=HELPERS[id]; if(!h) return; cur=id; lset('yk_helper',id);
    wrap.style.setProperty('--yk-accent',h.accent); img.src=h.img; buildLids(h); nameEl.textContent=h.name; applyVis(); }

  /* ---------- idle life ---------- */
  function perk(){ if(enabled&&cur&&!egg.classList.contains('show')){ stack.classList.remove('perk'); void stack.offsetWidth; stack.classList.add('perk'); }
    setTimeout(perk,9000+Math.random()*8000); }
  setTimeout(perk,7000);

  /* ---------- egg hatch ---------- */
  function hatch(id){ var h=HELPERS[id]; applyHelper(id);
    if(!enabled){ setHatched(id); return; }
    egg.style.setProperty('--es',h.egg.shell); egg.style.setProperty('--ed',h.egg.dot);
    img.style.opacity='0'; bubble.classList.remove('show');
    egg.classList.add('show'); void egg.offsetWidth;
    setTimeout(function(){ egg.classList.add('wob'); },180);
    setTimeout(function(){
      egg.classList.remove('wob'); fx.classList.add('on'); spawnShards();
      egg.style.transition='opacity .22s,transform .22s'; egg.style.transform='scale(1.15)'; egg.style.opacity='0';
    },1000);
    setTimeout(function(){
      egg.classList.remove('show'); egg.style.transform=''; egg.style.transition='';
      img.style.opacity='1'; img.style.animation='ykRise .55s ease';
      setTimeout(function(){ img.style.animation=''; },560);
    },1230);
    setTimeout(function(){ fx.classList.remove('on'); setHatched(id); welcome(id); },1900);
  }
  function spawnShards(){ for(var i=0;i<7;i++){ (function(i){ var s=document.createElement('s');
      s.style.cssText='left:50%;top:55%;background:'+HELPERS[cur].egg.shell+';';
      fx.appendChild(s); var ang=(-90+(i-3)*32)*Math.PI/180, dist=42+Math.random()*26;
      var tx=Math.cos(ang)*dist, ty=Math.sin(ang)*dist - 6;
      s.animate([{transform:'translate(-50%,-50%) rotate(0) scale(1)',opacity:1},
                 {transform:'translate(calc(-50% + '+tx+'px),calc(-50% + '+ty+'px)) rotate('+(tx*4)+'deg) scale(.5)',opacity:0}],
                {duration:620,easing:'cubic-bezier(.2,.7,.3,1)'});
      setTimeout(function(){ s.remove(); },640);
    })(i); } }
  function welcome(id){ say(HELPERS[id].hello,{dur:9200}); }

  /* ---------- chooser / settings modal ---------- */
  var modeFirst=false;
  function openModal(first){ modeFirst=first; modal.classList.toggle('settings',!first);
    titleEl.textContent=first?'Choose your guide ✦':'Guides';
    subEl.textContent=first?'A little yokai will watch over your island and teach you its ways.':'Switch your guide, or turn the overlay off.';
    refreshCards(); refreshFoot(); modal.classList.add('show'); }
  function closeModal(){ modal.classList.remove('show'); }
  function refreshCards(){ cardsEl.querySelectorAll('.ykCard').forEach(function(c){
      var active=(c.dataset.id===cur);
      c.classList.toggle('active',active); c.classList.toggle('sel',active);
      c.querySelector('.pick').textContent = active?'Active ✓' : (didHatch(c.dataset.id)?'Switch':'Choose'); }); }
  function refreshFoot(){ var on=modal.querySelector('#ykOn'), off=modal.querySelector('#ykOff');
      on.classList.toggle('act',enabled); off.classList.toggle('act',!enabled); }
  function pickCard(id){
    if(modeFirst){ closeModal(); hatch(id); return; }
    if(id===cur){ closeModal(); return; }
    if(didHatch(id)){ closeModal(); quickSwap(id); }
    else { closeModal(); hatch(id); }
  }
  var SWITCH_GREET = {
    myo: 'Nyaa~ ', borg: 'Acknowledged. ', suiko: 'Ugh, fine. '
  };
  function quickSwap(id){ img.style.transition='opacity .2s,transform .2s'; img.style.opacity='0'; img.style.transform='scale(.85)';
    setTimeout(function(){ applyHelper(id); img.style.opacity='1'; img.style.transform='';
      setTimeout(function(){ img.style.transition=''; },220);
      fx.classList.add('on'); spawnShards(); setTimeout(function(){ fx.classList.remove('on'); },700);
      say('Switched to <b>'+HELPERS[id].name+'</b>. '+(SWITCH_GREET[id]||'')+'Tap me whenever you need help.');
    },200); }
  modal.querySelector('#ykDone').addEventListener('click',closeModal);
  modal.querySelector('#ykOn').addEventListener('click',function(){ setEnabled(true); refreshFoot(); });
  modal.querySelector('#ykOff').addEventListener('click',function(){ setEnabled(false); refreshFoot(); });
  modal.addEventListener('click',function(e){ if(e.target===modal && !modeFirst) closeModal(); });
  gear.addEventListener('click',function(e){ e.stopPropagation(); openModal(false); });

  /* ---------- minimize (separate hit target from drag handle — never put pointer
     capture on a parent that contains this button, or its clicks get swallowed) ---------- */
  var minimized = lget('yk_min','0')==='1';
  function applyMin(){ wrap.classList.toggle('min',minimized); minBtn.textContent = minimized?'▢':'▁';
    minBtn.title = minimized?'Restore':'Minimize'; }
  function setMinimized(on){ minimized=on; lset('yk_min',on?'1':'0'); applyMin(); }
  minBtn.addEventListener('click',function(e){ e.stopPropagation(); setMinimized(!minimized); });
  applyMin();

  /* ---------- drag to reposition (pointer events on #ykStack only — #ykGear and #ykMin
     are separate elements layered above it, so capturing the pointer on #ykStack never
     swallows their clicks; a movement threshold tells a tap from a drag). ---------- */
  (function(){
    var DRAG_PX = 6;                      // movement past this = drag, not tap
    var dragging=false, moved=false, sx=0, sy=0, startLeft=0, startTop=0, pid=null;
    var suppressClickUntil = 0;
    function clampPos(left,top){
      var w=wrap.offsetWidth||104, h=wrap.offsetHeight||140;
      var maxL=Math.max(0,window.innerWidth-w), maxT=Math.max(0,window.innerHeight-h);
      return [Math.min(Math.max(0,left),maxL), Math.min(Math.max(0,top),maxT)];
    }
    function currentLeftTop(){
      var r=wrap.getBoundingClientRect();
      return [r.left, r.top];
    }
    function applyPos(left,top){
      var c=clampPos(left,top);
      wrap.style.left=c[0]+'px'; wrap.style.top=c[1]+'px';
      wrap.style.right='auto'; wrap.style.bottom='auto';
    }
    function savePos(){ var lt=currentLeftTop(); lset('yk_pos',JSON.stringify({l:lt[0],t:lt[1]})); }
    function restorePos(){
      var saved=jget('yk_pos',null);
      if(saved && typeof saved.l==='number' && typeof saved.t==='number'){ applyPos(saved.l,saved.t); }
      // else: leave the CSS default (left:14px;bottom:104px) — first run, no saved spot yet.
    }
    restorePos();
    window.addEventListener('resize',function(){ var lt=currentLeftTop(); applyPos(lt[0],lt[1]); });

    stack.addEventListener('pointerdown',function(e){
      if(e.target===gear||e.target===minBtn) return;     // let those buttons handle their own taps
      dragging=true; moved=false; pid=e.pointerId;
      sx=e.clientX; sy=e.clientY;
      var lt=currentLeftTop(); startLeft=lt[0]; startTop=lt[1];
      try{ stack.setPointerCapture(pid); }catch(_){}
    });
    stack.addEventListener('pointermove',function(e){
      if(!dragging||e.pointerId!==pid) return;
      var dx=e.clientX-sx, dy=e.clientY-sy;
      if(!moved && Math.hypot(dx,dy)>DRAG_PX){ moved=true; wrap.classList.add('dragging'); }
      if(moved){ applyPos(startLeft+dx,startTop+dy); }
    });
    function endDrag(e){
      if(!dragging||e.pointerId!==pid) return;
      dragging=false; try{ stack.releasePointerCapture(pid); }catch(_){}
      wrap.classList.remove('dragging');
      if(moved){ savePos(); suppressClickUntil=Date.now()+50; }   // was a drag: swallow the trailing click
      moved=false; pid=null;
    }
    stack.addEventListener('pointerup',endDrag);
    stack.addEventListener('pointercancel',endDrag);
    stack.addEventListener('click',function(e){
      if(Date.now()<suppressClickUntil){ e.stopImmediatePropagation(); e.preventDefault(); }
    },true);   // capture phase, runs before summon()
  })();

  /* ---------- summon (tap guide) ---------- */
  // each entry: { text, myo: mood-for-Myo, borg: mood-for-Borg, suiko: mood-for-Suiko-bun }
  var lore=[
    { myo:{ text:'Keep <b>FIRE</b> & <b>POLICE</b> up, darling — a safe ward is simply a more flattering frame. Richer wards photograph beautifully.', mood:'confident' },
      borg:{ text:'Maintain <b>FIRE</b> and <b>POLICE</b> coverage. Safety correlates with prosperity. Prosperity correlates with beauty. The chain is not optional.', mood:'precise' },
      suiko:{ text:'Fire and police. Keep them up. Skip it, the ward rots. I won\'t say it twice.', mood:'dry' } },
    { myo:{ text:'Every <i>$SORU</i> you spend is burned into Kami ⛩ — nothing wasted, my dear. Even ash can be composed into something gorgeous.', mood:'confident' },
      borg:{ text:'Each <i>$SORU</i> spent is burned into Kami ⛩. Energy is not destroyed, only converted. The whole island ages on what you feed it. Logical.', mood:'precise' },
      suiko:{ text:'Spend $SORU, it burns to Kami. The island ages on it. Nothing comes free. Sit with that.', mood:'grumpy' } },
    { myo:{ text:'The brighter the Heian gold shines… the more theatrical the fall to Sengoku will be. I do so love a third act. ✨', mood:'ominous' },
      borg:{ text:'Note the pattern: Heian\'s peak and Sengoku\'s collapse are correlated, not coincidental. Enjoy the gold. It is, statistically, temporary.', mood:'curious' },
      suiko:{ text:'Gold now. Ash later. That\'s the deal. Don\'t act surprised when it comes.', mood:'wary' } },
    { myo:{ text:'Yokai like us drift through your streets at dusk, posing for nobody and everybody. Mostly harmless. <i>Mostly.</i> 👁', mood:'teasing' },
      borg:{ text:'Yokai entities are present in your streets at dusk. Threat classification: mostly harmless. The qualifier is doing some work there. 👁', mood:'curious' },
      suiko:{ text:'We\'re around at dusk. Watching. Mostly we don\'t do anything. Mostly.', mood:'reluctant' } },
    { myo:{ text:'Tap <b>⛶</b> to reframe the view, or <b>✋ MOVE</b> to rearrange a piece that\'s simply standing wrong.', mood:'serious' },
      borg:{ text:'<b>⛶</b> resets the viewport. <b>✋ MOVE</b> relocates a placed structure without demolition. Use either as needed.', mood:'formal' },
      suiko:{ text:'⛶ resets the view. ✋ MOVE picks a building up, sets it down elsewhere. That\'s all those do.', mood:'dry' } },
    { myo:{ text:'Watch the <span class="ko">land value</span> overlay, love — green is a portrait, red is a confession. Poverty always shows in the streets.', mood:'serious' },
      borg:{ text:'The <span class="ko">land value</span> overlay quantifies ward health. Green: thriving. Red: suffering. Poverty manifests visibly. This is by design, not accident.', mood:'precise' },
      suiko:{ text:'Land value. Green good, red bad. Poverty shows up in the streets whether you look or not. Look anyway.', mood:'grumpy' } }
  ];
  var mythLore=[
    { myo:{ text:'The <b>kitsune</b> slip through quiet streets at night, leaving little sparks wherever land value flatters them. A fox\'s tail glows brighter the more lies it\'s told — I find that terribly relatable.', mood:'teasing' },
      borg:{ text:'<b>Kitsune</b> are observed near streets with adequate land value at night. Folklore claims their tails glow proportionally to lies told. Unverifiable. Noted anyway.', mood:'curious' },
      suiko:{ text:'Kitsune. Night streets, decent land value, little sparks. Foxes lie a lot, apparently. Not my problem.', mood:'dry' } },
    { myo:{ text:'A <b>tanuki</b> stumbles drunk between the trees, shapeshifting badly — half raccoon-dog, half whatever pose he was attempting. Charming failure of composition.', mood:'teasing' },
      borg:{ text:'<b>Tanuki</b> exhibit poor shapeshifting fidelity — half raccoon-dog, half intended form. Classification: harmless. Generosity observed as a secondary trait.', mood:'fond' },
      suiko:{ text:'Tanuki. Drunk, bad at shapeshifting, gives you stuff sometimes. Annoying. Harmless annoying.', mood:'grumpy' } },
    { myo:{ text:'When the island prospers, a <b>ryū</b> coils above the rooftops like a signature on a finished canvas. Dragons don\'t bless prosperity — they\'re simply drawn to anything that glows.', mood:'confident' },
      borg:{ text:'A <b>ryū</b> appears above prospering islands. Causality is misattributed: dragons do not cause prosperity, they are attracted to it. Correlation, not blessing.', mood:'precise' },
      suiko:{ text:'Island does well, a dragon shows up to look at it. Doesn\'t help. Doesn\'t hurt. Just watches.', mood:'wary' } },
    { myo:{ text:'A <b>tennyo</b>, a celestial dancer, appears only over the most beautiful wards — catch her robe mid-performance and she\'s yours forever. So the old stories claim. I\'ve never reached for it. Some masks should stay on the wall. 👀', mood:'ominous' },
      borg:{ text:'<b>Tennyo</b> sightings correlate with high-beauty wards. Folklore states capturing her robe binds her permanently. I have not tested this. The ethics seem questionable.', mood:'curious' },
      suiko:{ text:'Tennyo shows up over pretty wards. Grab her robe, she\'s stuck with you forever, they say. Don\'t. Just don\'t.', mood:'reluctant' } },
    { myo:{ text:'<b>Kappa</b> linger where shoreline meets ward, small and scaled and fiercely protective of the water-dish atop their heads. Spill it and they lose everything — even I find that a touch too on the nose.', mood:'teasing' },
      borg:{ text:'<b>Kappa</b> occupy shoreline-adjacent tiles. Their power source is a water-filled cranial dish. Spillage results in total power loss. A single point of failure. Inelegant design.', mood:'formal' },
      suiko:{ text:'Kappa keep to the water. Don\'t spill what\'s on their heads. We take that one seriously. I take that one seriously.', mood:'grumpy' } },
    { myo:{ text:'Where despair and fire gather, <b>oni</b> begin to circle. They don\'t cause the suffering — they simply attend, the way an audience gathers for tragedy.', mood:'ominous' },
      borg:{ text:'<b>Oni</b> are observed circling sites of concentrated suffering and fire. They are not causative agents. They are, functionally, spectators.', mood:'precise' },
      suiko:{ text:'Oni show up where things are already bad. They don\'t make it worse. They just watch it happen. That\'s its own kind of bad.', mood:'wary' } },
    { myo:{ text:'In snowfall, a <b>yuki-onna</b> drifts pale between the rooftops — beautiful exactly as far as the distance allows, and not one step closer.', mood:'ominous' },
      borg:{ text:'<b>Yuki-onna</b> manifest during snowfall. Recommended viewing distance: nonzero. Aesthetic value decreases sharply at close range. I have not tested this either.', mood:'curious' },
      suiko:{ text:'Yuki-onna, in the snow. Pretty from far away. Stay far away. That\'s the whole lesson.', mood:'reluctant' } },
    { myo:{ text:'When Sengoku\'s ashes pile high enough, a <b>gashadokuro</b> rises — a skeleton composed of a thousand unburied dead, taller than any wonder you\'ll ever build. A monument no one asked for.', mood:'ominous' },
      borg:{ text:'Sufficient unburied dead during Sengoku produces a <b>gashadokuro</b> — a composite skeletal entity exceeding the scale of any constructed wonder. The threshold is the input. The monster is the output.', mood:'formal' },
      suiko:{ text:'Enough dead pile up, you get a gashadokuro. Bigger than anything you built on purpose. That should tell you something.', mood:'wary' } }
  ];
  var skyLore=[
    { myo:{ text:'Look up long enough and the void isn\'t empty — it remembers shapes. The old stargazers traced a <b>heron in flight</b> across the dark, wings spread the width of the whole island. A composition worth stealing.', mood:'serious' },
      borg:{ text:'The void background contains fixed point-star patterns. One configuration resembles a <b>heron in flight</b>, spanning the visible sky. Pattern recognition, not coincidence.', mood:'curious' },
      suiko:{ text:'There\'s a heron shape in the stars, if you look. Old stargazers named it that. Fine, I suppose.', mood:'dry' } },
    { myo:{ text:'A faint cluster sailors named the <b>Boat of Ages</b> — seven dim stars in a line, said to carry every era\'s souls forward to the next. A ferry that never stops running.', mood:'serious' },
      borg:{ text:'The <b>Boat of Ages</b> is a seven-star linear formation. Maritime folklore assigns it the function of transporting souls between eras. A persistent and specific claim.', mood:'formal' },
      suiko:{ text:'Seven stars in a line, sailors call it the Boat of Ages. Supposedly carries souls between eras. Supposedly.', mood:'reluctant' } },
    { myo:{ text:'The brightest point above the void never moves all year. Fishermen call it the <b>Still Lantern</b> and steer by it when everything else drifts. Constancy, the rarest pigment.', mood:'confident' },
      borg:{ text:'One star, the <b>Still Lantern</b>, exhibits zero positional drift across the observed year. Used reliably for navigation. The only fixed reference point in an otherwise dynamic sky.', mood:'precise' },
      suiko:{ text:'One star doesn\'t move all year. Fishermen call it the Still Lantern, steer by it. Makes sense. Most things move too much.', mood:'dry' } },
    { myo:{ text:'During Heian\'s golden nights, a faint band crosses the sky they called the <b>River of Quiet Names</b> — every soul who lived peacefully here, they say, written in light. A gallery with no walls.', mood:'confident' },
      borg:{ text:'During the Heian era specifically, a band of light appears, named the <b>River of Quiet Names</b>. Folklore attributes it to peaceful souls. The era-specificity is the interesting part.', mood:'fond' },
      suiko:{ text:'In Heian, a band of light shows up — River of Quiet Names, they call it. Supposed to be peaceful souls. Nice while it lasts.', mood:'reluctant' } },
    { myo:{ text:'In Sengoku, the same stars look colder somehow. War doesn\'t change the sky — it changes what you\'re finally able to see in it.', mood:'ominous' },
      borg:{ text:'Identical stars are perceived as colder during Sengoku. The sky is unchanged; the observer\'s state is not. A perception shift, not an astronomical one.', mood:'curious' },
      suiko:{ text:'Same stars in Sengoku. Look colder. Sky didn\'t change. You did. That\'s usually how it goes.', mood:'wary' } }
  ];
  var loreI=0, mythI=0, skyI=0;
  function entryFor(entry){ return entry[cur] || null; }
  function anyFire(){ try{ for(var y=0;y<grid.length;y++)for(var x=0;x<grid[y].length;x++) if(grid[y][x].burn) return true; }catch(e){} return false; }
  var FIRE_ALERT = {
    myo:{ text:'Fire on the island! 🔥 Not the dramatic kind I enjoy — tap <b>💧 DOUSE</b>, then strike the flames before they ruin the whole composition.', mood:'ominous' },
    borg:{ text:'Active fire detected. 🔥 Tap <b>💧 DOUSE</b>, then target the flames directly. Spread is exponential. Act now, not after assessing the aesthetics.', mood:'precise' },
    suiko:{ text:'Fire. Right now. Tap DOUSE, hit the flames. Talk later.', mood:'wary' }
  };
  var REACTIVATE = {
    myo:{ text:'I\'m back, darling. 👋 Tap me whenever the stage needs setting.' },
    borg:{ text:'Systems re-engaged. 👋 I am available when required.' },
    suiko:{ text:'…Back. Tap me if you need something. Try not to need much.' }
  };
  var BEGIN_HINT = {
    myo:{ text:'Let\'s begin, shall we? Choose a structure from the bar below and place it like the first brushstroke.' },
    borg:{ text:'Initial action required: select a structure from the bar below, then place it on the island.' },
    suiko:{ text:'Start with that bar down there. Pick something, put it down. Not complicated.' }
  };
  function summon(){ if(!enabled||!cur||egg.classList.contains('show')) return;
    if(anyFire()){ var fa=FIRE_ALERT[cur]; say(fa.text,{point:'#douseBtn',mood:fa.mood}); return; }
    if(!isSeen('placed')){ var bh=BEGIN_HINT[cur]; say(bh.text,{point:'#builds'}); return; }
    var pool=loreI%3, entry, v;
    if(pool===0){ entry=lore[Math.floor(loreI/3)%lore.length]; }
    else if(pool===1){ entry=mythLore[mythI%mythLore.length]; mythI++; }
    else{ entry=skyLore[skyI%skyLore.length]; skyI++; }
    v=entryFor(entry); say(v.text,{mood:v.mood}); loreI++; }
  stack.addEventListener('click',summon);

  /* ---------- on/off ---------- */
  function applyVis(){ wrap.classList.toggle('off',!enabled||!cur); tog.classList.toggle('off',!enabled); }
  function setEnabled(on){ enabled=on; lset('yk_on',on?'1':'0'); applyVis();
    if(on){ if(!cur) openModal(true); else say(REACTIVATE[cur].text); }
    else { bubble.classList.remove('show'); clearTimeout(hideT); } }
  tog.addEventListener('click',function(){ setEnabled(!enabled); });

  /* ---------- boot ---------- */
  if(cur) applyHelper(cur);
  applyVis();
  if(enabled && !cur) setTimeout(function(){ openModal(true); },700);

  /* ============================================================
     TUTORIAL HOOKS — voiced per-guide
     ============================================================ */
  var SELBUILD_TXT = {
    myo:'Good eye. 🎨 Now tap the island to set it down. Every build burns $SORU into Kami ⛩ — the whole island ages on what you spend, like paint drying into something permanent.',
    borg:'Selection registered. Tap the island to place it. Each build burns $SORU into Kami ⛩, advancing the island\'s age. This is the core mechanism.',
    suiko:'Picked one. Now tap the island. Burns $SORU into Kami, ages the island. That\'s the whole loop.'
  };
  var PLACED_TXT = {
    myo:'Lovely. 🌸 Buildings you keep standing pay you SOL over time — trade it at the DEX for more $SORU to burn into something even better.',
    borg:'Placement successful. Standing buildings generate SOL passively. Convert at the DEX into $SORU for further construction. Cycle is self-sustaining.',
    suiko:'Built. It\'ll pay you SOL while it stands. Swap that for $SORU at the DEX. Keep going.'
  };
  var builds=document.getElementById('builds');
  if(builds) builds.addEventListener('click',function(e){ var b=e.target.closest('.bbtn'); if(!b||b.classList.contains('lock'))return;
    once('selbuild',SELBUILD_TXT[cur]); },true);

  if(typeof window.place==='function'){ var _place=window.place;
    window.place=function(){ var built=(typeof S!=='undefined'&&S.tool&&!S.hand&&!S.douse&&!S.demo&&!S.pillage&&!S.arson&&!S.guard);
      var r=_place.apply(this,arguments);
      if(built) once('placed',PLACED_TXT[cur]);
      return r; }; }

  function tipBtn(id,key,texts,pt){ var el=document.getElementById(id); if(!el)return;
    el.addEventListener('click',function(){ once(key,texts[cur],pt?{point:pt}:undefined); },true); }
  tipBtn('valBtn','value',{
    myo:'This is <span class="ko">land value</span> — the soul of a ward, darling. Green is a flattering light, red is an unflinching one. Poverty breeds litter, beggars… and worse, painted plainly.',
    borg:'<span class="ko">Land value</span> quantifies ward condition. Green: thriving. Red: suffering. Low values correlate with litter, displaced persons, and further decline. This is measurable, not metaphorical.',
    suiko:'Land value. Green good, red bad. Low value means litter, beggars, worse. Don\'t look away from it.'
  },'#valBtn');
  tipBtn('dexBtn','dex',{
    myo:'The DEX swaps the SOL you\'ve earned into $SORU. Burning $SORU feeds Kami ⛩ and turns the Ages forward — alchemy, basically, with extra steps.',
    borg:'The DEX exchanges SOL for $SORU. Burning $SORU fuels Kami ⛩, which advances the Age counter. A two-step conversion pipeline.',
    suiko:'DEX trades SOL for $SORU. Burn that, it feeds Kami, moves the Ages along. Use it.'
  },'#dexBtn');
  tipBtn('advanceBtn','advance',{
    myo:'Ages turn on <i>collective</i> Kami ⛩ — every $SORU burned across the whole island, never one player alone. Push toward the next age together, like an ensemble piece.',
    borg:'Age progression depends on aggregate Kami ⛩ across all players, not individual contribution. A shared threshold. Collaborate accordingly.',
    suiko:'Ages move on everyone\'s Kami together. Not just yours. Push toward the next one anyway.'
  },'#advanceBtn');
  tipBtn('arsonBtn','raid',{
    myo:'Ah… the cruel part. 🔥 Torch and sack rival wards. Soru Shiti was never gentle — beauty and ash, always sharing the same canvas.',
    borg:'ARSON destroys rival ward structures. 🔥 This is the conflict subsystem. It is by design, not malfunction. Beauty and destruction coexist in this system.',
    suiko:'Arson. Burns rival wards. Yeah, it\'s ugly. That\'s the point of it.'
  },'#arsonBtn');
  tipBtn('pillageBtn','raid',{
    myo:'Ah… the cruel part again. 🏴 Sack a rival\'s holding for their $SORU. Beauty and brutality, two halves of the same brushstroke.',
    borg:'PILLAGE extracts $SORU from a rival holding. 🏴 Resource transfer via conflict. Functionally identical in consequence to ARSON, different mechanism.',
    suiko:'Pillage. Takes a rival\'s $SORU by force. Same ugliness as arson, different method.'
  },'#pillageBtn');
  tipBtn('guardBtn','guard',{
    myo:'Hire a ronin retainer to shield one building from the next raid. Even the loveliest stage needs a blade at the wings. 🛡',
    borg:'GUARD assigns a ronin retainer to protect one building from a single future raid. Mitigation, not immunity. 🛡',
    suiko:'Guard. One ronin, one building, one raid blocked. Doesn\'t last forever. 🛡'
  });
  tipBtn('handBtn','move',{
    myo:'✋ MOVE lets you lift a piece and set it down elsewhere — rework the composition without tearing the canvas.',
    borg:'✋ MOVE relocates a structure without demolition. Non-destructive repositioning.',
    suiko:'✋ MOVE picks a building up, puts it somewhere else. No demolition needed.'
  });
  tipBtn('demoBtn','raze',{
    myo:'⛏ RAZE clears your own works to make room for the next idea. Rivals\' plots you must take by force — PILLAGE or ARSON, no other brush for that.',
    borg:'⛏ RAZE removes your own structures. Rival-owned plots require PILLAGE or ARSON; RAZE has no effect on them. Ownership-gated function.',
    suiko:'⛏ RAZE clears your own stuff. Rivals\' plots, you need PILLAGE or ARSON. RAZE won\'t touch those.'
  });
})();


/* ==================================================================== */
/* === ykGibberish === */
/* ==================================================================== */
/* ============================================================
   SORU SHITI — Townsperson Gibberish Voice Layer (Simlish-style)
   Web Audio API, sample-based. Plays short, sparse, randomized
   vocal-texture clips from real .ogg files placed beside index.html.
   Zoom-gated (audible only when zoomed in, fades out by mid-zoom,
   silent when fully zoomed out). Reads cam.zoom / S.era / residents /
   encounters. Writes nothing back to sim state — pure
   presentation layer.
   ============================================================ */
(function(){
  "use strict";
  if (window.__gib) return; window.__gib = true;

  /* ---------------- sample manifest ----------------
     Files expected in the same folder as index.html. */
  var FEMALE_FILES = ['f-chat1.ogg','f-happy1.ogg','f-laugh1.ogg','f-laugh2.ogg','f-sad.ogg'];
  var MALE_FILES   = ['m-angry.ogg','m-chat1.ogg','m-chat2.ogg','m-chat3.ogg','m-chat4.ogg',
                       'm-happy.ogg','m-sad.ogg','m-weird1.ogg','m-weird2.ogg'];

  /* emotion -> which files are appropriate, per gender bank.
     calm/chatty default pool is the *-chatN / *-happy / *-sad files;
     raids pull from the more aggressive/scared-sounding set. */
  var FEMALE_BANK = {
    idle:    ['f-chat1.ogg','f-happy1.ogg','f-sad.ogg'],
    social:  ['f-chat1.ogg','f-happy1.ogg','f-laugh1.ogg'],
    happy:   ['f-happy1.ogg','f-laugh1.ogg','f-laugh2.ogg'],
    laugh:   ['f-laugh1.ogg','f-laugh2.ogg','f-happy1.ogg'],
    worried: ['f-sad.ogg','f-chat1.ogg'],
    sad:     ['f-sad.ogg'],
    scared:  ['f-sad.ogg','f-chat1.ogg'],
    curious: ['f-chat1.ogg','f-happy1.ogg']
  };
  var MALE_BANK = {
    idle:      ['m-chat1.ogg','m-chat2.ogg','m-chat3.ogg','m-chat4.ogg','m-weird1.ogg'],
    social:    ['m-chat1.ogg','m-chat2.ogg','m-chat3.ogg','m-chat4.ogg','m-happy.ogg'],
    happy:     ['m-happy.ogg','m-chat2.ogg'],
    laugh:     ['m-happy.ogg','m-chat4.ogg'],
    worried:   ['m-weird1.ogg','m-weird2.ogg','m-sad.ogg'],
    aggressive:['m-angry.ogg','m-weird2.ogg'],
    scared:    ['m-weird1.ogg','m-weird2.ogg','m-sad.ogg'],
    curious:   ['m-chat1.ogg','m-weird1.ogg','m-chat3.ogg']
  };

  // Picks from arr while avoiding `avoid` (the voice's last-played file) when
  // the pool is large enough to do so — keeps a single voice from repeating
  // the same clip twice in a row without forcing artificial pool shrinkage.
  function pick(arr, avoid){
    if (!avoid || arr.length<2) return arr[(Math.random()*arr.length)|0];
    var f;
    for (var tries=0; tries<4; tries++){
      f = arr[(Math.random()*arr.length)|0];
      if (f!==avoid) return f;
    }
    return f;
  }

  /* ---------------- zoom gate ----------------
     Below GIB_Z_LOW: silent. Above GIB_Z_HIGH: full volume.
     Fades through the middle so it dies out by mid-map zoom and is
     fully gone at max zoom-out, per spec. */
  var GIB_Z_LOW  = 0.45;
  var GIB_Z_HIGH = 1.6;
  function zoomAudibility(){
    var z = (typeof cam !== 'undefined' && cam.zoom) ? cam.zoom : 0;
    if (z <= GIB_Z_LOW) return 0;
    if (z >= GIB_Z_HIGH) return 1;
    var t = (z - GIB_Z_LOW) / (GIB_Z_HIGH - GIB_Z_LOW);
    return t*t*(3-2*t); // smoothstep
  }

  /* ---------------- audio graph ---------------- */
  var ctx = null, master = null, voicesBus = null;
  function ensureCtx(){
    if (ctx) { if (ctx.state==='suspended') ctx.resume(); return ctx; }
    try {
      ctx = (typeof sfxCtx === 'function') ? sfxCtx() : new (window.AudioContext||window.webkitAudioContext)();
    } catch(e){ ctx = null; }
    if (!ctx) return null;
    master = ctx.createGain(); master.gain.value = 0;
    voicesBus = ctx.createGain(); voicesBus.gain.value = 0.9;
    var comp = null;
    try {
      comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -26; comp.knee.value = 16; comp.ratio.value = 3.0;
      comp.attack.value = 0.006; comp.release.value = 0.18;
    } catch(e){}
    voicesBus.connect(comp || master);
    if (comp) comp.connect(master);
    master.connect((typeof sfxDest==='function')?sfxDest(ctx):ctx.destination);
    return ctx;
  }

  /* ---------------- sample loading ----------------
     Decoded buffers are cached by filename. Loading is lazy and
     fire-once per file; failures are remembered so we don't retry
     every frame (e.g. a missing/renamed asset). */
  var bufferCache = {};   // filename -> AudioBuffer
  var loadFailed = {};    // filename -> true
  var loadingNow = {};    // filename -> true (in-flight)

  function loadSample(filename){
    if (bufferCache[filename] || loadFailed[filename] || loadingNow[filename]) return;
    var c = ensureCtx();
    if (!c) return;
    loadingNow[filename] = true;
    // resolves filename against index.html's own URL so the printed path is
    // exactly where the browser looked — makes "file is missing" vs "file is
    // at the wrong path" unambiguous instead of guessing from a bare name.
    var resolvedURL = new URL(filename, document.baseURI).href;
    fetch(filename).then(function(res){
      if (!res.ok) throw new Error('HTTP '+res.status+' at '+resolvedURL);
      return res.arrayBuffer();
    }).then(function(ab){
      return c.decodeAudioData(ab);
    }).then(function(buf){
      bufferCache[filename] = buf;
      loadingNow[filename] = false;
    }).catch(function(e){
      loadFailed[filename] = true;
      loadingNow[filename] = false;
      var msg = 'gibberish sample missing/unreadable: '+filename+' — looked for it at '+resolvedURL+' ('+(e.message||e)+')';
      if (window.__err) window.__err(msg);
      else console.warn(msg);
    });
  }

  function preloadAll(){
    for (var i=0;i<FEMALE_FILES.length;i++) loadSample(FEMALE_FILES[i]);
    for (var j=0;j<MALE_FILES.length;j++) loadSample(MALE_FILES[j]);
  }

  /* One consolidated readiness report, a couple seconds after the first
     preload pass, so missing assets show up as a single list instead of
     N separate console lines arriving one fetch-failure at a time. */
  var manifestReported = false;
  function reportManifestOnce(){
    if (manifestReported) return;
    manifestReported = true;
    setTimeout(function(){
      var all = FEMALE_FILES.concat(MALE_FILES);
      var missing = all.filter(function(f){ return loadFailed[f]; });
      var loaded = all.filter(function(f){ return !!bufferCache[f]; });
      var pending = all.filter(function(f){ return !bufferCache[f] && !loadFailed[f]; });
      var summary = '[SoruGibberish] audio manifest — loaded:'+loaded.length+'/'+all.length+
        (missing.length ? '  MISSING: '+missing.join(', ') : '') +
        (pending.length ? '  still loading: '+pending.join(', ') : '');
      if (missing.length) console.warn(summary); else console.log(summary);
    }, 2500);
  }

  /* ---------------- one sample playback ----------------
     Randomizes pitch (playbackRate doubles as a pitch shift, which is
     the simplest way to keep repeated clips from sounding identical),
     volume, and a tiny start offset so back-to-back plays of the same
     file don't phase-lock against each other. */
  function playSample(filename, t0, gainScale){
    var buf = bufferCache[filename];
    if (!buf || !ctx) return 0;
    var src = ctx.createBufferSource();
    src.buffer = buf;
    // Two independent layers of pitch variance: coarse playbackRate jitter
    // (covers both sped-up/chipmunk and slowed-down/deepened readings) plus
    // a separate fine detune jitter, so two plays at a similar rate still
    // land at audibly different pitches.
    var rate = 0.7 + Math.random()*0.75;        // 0.70 - 1.45
    src.playbackRate.value = rate;
    try { src.detune.value = (Math.random()*2-1) * 350; } catch(e){} // +/-350 cents fine pitch jitter

    var amp = ctx.createGain();
    var peak = (0.32 + Math.random()*0.68) * gainScale; // wider volume variation
    var dur = buf.duration / rate;
    var attack = Math.min(0.04, dur*0.15), release = Math.min(0.25, dur*0.35);
    amp.gain.setValueAtTime(0.0001, t0);
    amp.gain.exponentialRampToValueAtTime(peak, t0+attack);
    amp.gain.setValueAtTime(peak, Math.max(t0+attack, t0+dur-release));
    amp.gain.exponentialRampToValueAtTime(0.0001, t0+dur);

    var node = src;
    try {
      var filt = ctx.createBiquadFilter();
      var ftypes = ['lowpass','allpass','highpass','peaking'];
      filt.type = ftypes[(Math.random()*ftypes.length)|0];
      filt.frequency.value = 700 + Math.random()*3200; // 700-3900Hz — broader muffling/brightness variance
      filt.Q.value = 0.5 + Math.random()*1.4;
      if (filt.type==='peaking') filt.gain.value = (Math.random()*2-1)*8;
      src.connect(filt); filt.connect(amp);
      node = filt;
    } catch(e){ src.connect(amp); }

    var outNode = amp;
    try {
      var pan = ctx.createStereoPanner();
      pan.pan.value = (Math.random()*2-1) * 0.5; // subtle left/right drift per play
      amp.connect(pan); outNode = pan;
    } catch(e){}
    outNode.connect(voicesBus);
    src.start(t0);
    src.stop(t0+dur+0.05);
    return dur;
  }

  /* ---------------- per-voice phrase scheduler ----------------
     A "phrase" here is exactly one sample clip (the source files are
     already short, self-contained utterances), followed by a pause
     whose length depends on the emotion's chattiness. */
  var EMO_RATE = { // phrases per ~second equivalent, used to derive rest length
    idle:0.09, social:0.11, happy:0.12, laugh:0.14, worried:0.10,
    sad:0.08, aggressive:0.16, scared:0.17, curious:0.09
  };

  function bankForVoice(voice){ return voice.gender==='f' ? FEMALE_BANK : MALE_BANK; }

  var GLOBAL_MIN_GAP = 13.0; // seconds — absolute floor between any two phrases from the same voice, regardless of emotion rate

  function schedulePhrase(voice, t0){
    var bank = bankForVoice(voice);
    var pool_ = bank[voice.emotion] || bank.idle;
    var filename = pick(pool_, voice.lastFile);
    voice.lastFile = filename;
    loadSample(filename); // ensure it's loading/loaded for next time even if this attempt misses
    var dur = 0;
    if (bufferCache[filename]) {
      dur = playSample(filename, t0, voice.gain);
      voiceActiveUntil = Math.max(voiceActiveUntil, t0 + dur);
    }
    var rate = EMO_RATE[voice.emotion] || EMO_RATE.idle;
    var restMin = Math.max(GLOBAL_MIN_GAP, 2.6/rate);
    var restMax = Math.max(restMin+3.0, 6.2/rate);
    voice.nextAt = t0 + Math.max(dur,0.2) + restMin + Math.random()*(restMax-restMin);
    return dur;
  }

  /* social ping-pong: two nearby voices alternate within ~0.3-0.7s of each other.
     Disabled — even brief deliberate overlap reads as "unison/overlapping voices",
     which is exactly the artifact we're removing. Kept as a no-op so call sites
     don't need to change. */
  function maybeChainReply(voice, t0){ return; }

  /* ---------------- voice pool ----------------
     One lightweight "voice" record per audible agent. Pool is rebuilt
     from residents/traffic each gather pass rather than persisted per
     -agent, keeping this decoupled from sim object lifecycles. */
  var pool = []; // {key, x, y, emotion, gender, gain, nextAt, agentRef}
  var poolIndex = {};
  var MAX_CONCURRENT = 1;      // hard cap on truly-simultaneous voices — strictly enforced via activeUntil
  var GATHER_INTERVAL = 0.6;   // seconds between full re-gather passes
  var gatherT = 0;
  var voiceActiveUntil = 0;    // ctx.currentTime until which a sample is actually sounding — real concurrency gate
  var GLOBAL_TRIGGER_CHANCE = 0.10; // even when a voice is "due", only fire this often — keeps it rare/atmospheric

  function genderForAgent(a, seed){
    // stable per-agent gender so the same townsperson sounds consistent
    return ((seed*977+13) % 2 === 0) ? 'f' : 'm';
  }

  function emotionForAgent(a){
    if (a.flee > 0) return 'scared';
    var rg = (typeof inRaidRadius==='function') ? inRaidRadius(a) : nearAnyEncounter(a, 5);
    if (rg) {
      // raid/combat proximity always wins — never let happy/laugh/social roll through here
      if (a.nerve !== undefined) return a.respectful ? 'worried' : 'worried';
      if (a.watch > 0) return 'worried';
      return Math.random()<0.55 ? 'worried' : 'scared';
    }
    if (a.nerve !== undefined) return a.respectful ? 'curious' : 'worried';
    if (a.watch > 0) return 'curious';
    if (a.act==='temple' || a.act==='water') return Math.random()<0.5 ? 'idle' : 'curious';
    if (a.pause>0 && Math.random()<0.4) return 'social';
    if (Math.random()<0.06) return 'happy';
    if (Math.random()<0.04) return 'sad';
    return 'idle';
  }

  function nearAnyEncounter(a, radius){
    if (typeof encounters === 'undefined') return false;
    for (var i=0;i<encounters.length;i++){
      var e = encounters[i]; if (!e.mob) continue;
      for (var j=0;j<e.mob.length;j++){
        var m = e.mob[j];
        var dx = m.x-a.x, dy = m.y-a.y;
        if (dx*dx+dy*dy < radius*radius) return true;
      }
    }
    return false;
  }

  // raid combat states bump aggression/fear sharply for involved defenders
  function defenderEmotion(d){
    if (!d) return null;
    if (d.state==='down') return null; // fallen, silent
    return Math.random()<0.6 ? 'aggressive' : 'scared';
  }

  function findNearestVoice(voice, maxDist){
    var best=null, bd=maxDist*maxDist;
    for (var i=0;i<pool.length;i++){
      var v = pool[i]; if (v===voice) continue;
      var dx=v.x-voice.x, dy=v.y-voice.y, d2=dx*dx+dy*dy;
      if (d2<bd){bd=d2;best=v;}
    }
    return best;
  }

  function gatherVoices(){
    var list = [];
    if (typeof residents !== 'undefined') {
      for (var i=0;i<residents.length;i++){
        var r = residents[i]; if (r.claimed) continue;
        list.push({ ref:r, kind:'res', idx:i });
      }
    }
    // include active raid defenders directly (combat barks)
    if (typeof encounters !== 'undefined') {
      for (var k=0;k<encounters.length;k++){
        var e = encounters[k];
        if (e.defenders) for (var d=0;d<e.defenders.length;d++){
          var def = e.defenders[d]; if (def.state==='down') continue;
          list.push({ ref:def, kind:'def', idx:'e'+k+'d'+d, forceEmotion:defenderEmotion(def) });
        }
      }
    }
    return list;
  }

  function rebuildPool(){
    var raw = gatherVoices();
    var n = Math.min(raw.length, MAX_CONCURRENT*3); // keep a slightly larger pool than concurrent cap
    for (var i=raw.length-1;i>0;i--){ var j=(Math.random()*(i+1))|0; var tmp=raw[i]; raw[i]=raw[j]; raw[j]=tmp; }
    raw = raw.slice(0, n);

    var seen = {};
    for (var k=0;k<raw.length;k++){
      var item = raw[k], a = item.ref;
      var key = item.kind+item.idx;
      seen[key] = true;
      var v = poolIndex[key];
      if (!v) {
        v = { key:key, x:a.x, y:a.y, gender:genderForAgent(a, (k*977+13)%1000),
              gain:0.55+Math.random()*0.3, nextAt:0 };
        poolIndex[key] = v;
        pool.push(v);
      }
      v.x = a.x; v.y = a.y; v.agentRef = a;
      v.emotion = item.forceEmotion || emotionForAgent(a);
    }
    // prune voices whose agents vanished
    for (var p=pool.length-1;p>=0;p--){
      if (!seen[pool[p].key]) { delete poolIndex[pool[p].key]; pool.splice(p,1); }
    }
  }

  /* ---------------- master gain follows zoom ---------------- */
  var curVol = 0;
  function updateMasterGain(dt){
    if (!ctx || !master) return;
    var raidDuck = 1;
    try {
      if (typeof encounters !== 'undefined') {
        for (var i=0;i<encounters.length;i++){
          if (encounters[i].state==='duel' || encounters[i].state==='assault'){ raidDuck = 0.45; break; }
        }
      }
    } catch(e){}
    var target = zoomAudibility() * 0.38 * raidDuck; // overall ceiling — kept subtle/atmospheric
    var rate = 2.0; // smoothing speed
    curVol += (target-curVol) * Math.min(1, dt*rate);
    if (Math.abs(curVol - master.gain.value) > 0.001) {
      var now = ctx.currentTime;
      master.gain.cancelScheduledValues(now);
      master.gain.setTargetAtTime(curVol, now, 0.12);
    }
  }

  /* ---------------- main tick ----------------
     Call updateGibberish(dt) once per frame from the existing sim loop.
     Internally throttles: agent gathering is periodic, scheduling is
     per-voice and respects nextAt timestamps. */
  var activeCount = 0;
  var preloaded = false;
  function updateGibberish(dt){
    var audibility = zoomAudibility();
    if (audibility <= 0.001) {
      if (ctx && master) updateMasterGain(dt);
      return; // fully silent at this zoom — skip scheduling entirely, cheapest path
    }
    if (!ensureCtx()) return;
    if (!preloaded) { preloaded = true; preloadAll(); reportManifestOnce(); }
    updateMasterGain(dt);

    gatherT += dt;
    if (gatherT >= GATHER_INTERVAL || pool.length===0) { gatherT = 0; rebuildPool(); }

    var now = ctx.currentTime;
    if (now < voiceActiveUntil) return; // a sample is already sounding — never overlap, full stop
    activeCount = 0;
    for (var i=0;i<pool.length && activeCount < MAX_CONCURRENT;i++){
      var v = pool[i];
      if (v.nextAt <= now + 0.02) {
        if (Math.random() > GLOBAL_TRIGGER_CHANCE) {
          // skip this cycle but don't let it go silent forever — push a short retry window
          v.nextAt = now + 1.4 + Math.random()*1.6;
          continue;
        }
        var startAt = now + Math.random()*0.08;
        var len = schedulePhrase(v, startAt);
        maybeChainReply(v, startAt+len);
        activeCount++;
        break; // one voice per tick, period
      }
    }
  }

  /* ---------------- event hooks ----------------
     Raid/disaster triggers an immediate localized panic/aggression
     burst rather than waiting for the next natural gather/schedule
     cycle. Call directly from existing raid trigger sites. */
  function onRaidEvent(tx, ty, radius){
    if (zoomAudibility() <= 0.001 || !ctx) return;
    radius = radius || 6.5;
    var now = ctx.currentTime;
    var burst = 0;
    for (var i=0;i<pool.length && burst<2;i++){
      var v = pool[i];
      var dx=v.x-tx, dy=v.y-ty;
      if (dx*dx+dy*dy < radius*radius) {
        v.emotion = (v.gender==='m' && Math.random()<0.5) ? 'aggressive' : 'scared';
        // stagger so the raid bark still passes through the single-voice gate naturally
        // instead of stacking everyone onto the same instant
        v.nextAt = now + burst*GLOBAL_MIN_GAP*0.7 + Math.random()*0.6;
        burst++;
      }
    }
  }

  /* ---------------- public API ---------------- */
  window.SoruGibberish = {
    update: updateGibberish,   // call once per frame, e.g. inside loop(): updateGibberish(dt)
    onRaidEvent: onRaidEvent,  // optional direct hook from raid-trigger code
    setEnabled: function(on){ enabledOverride = !!on; },
    _debug: { pool: pool, zoomAudibility: zoomAudibility, bufferCache: bufferCache }
  };
  var enabledOverride = true;

  // Hook into the existing first-gesture unlock so AudioContext resumes
  // alongside BGM/SFX rather than needing a second user gesture.
  function tryResume(){ if (ctx && ctx.state==='suspended') ctx.resume(); }
  window.addEventListener('pointerdown', tryResume, {passive:true});

})();


/* ==================================================================== */
/* === ykBattleSFX === */
/* ==================================================================== */
/* ============================================================
   SORU SHITI — Battle Sound System (Katana Clashes & Combat)
   Synthesized Web Audio API. No external assets, no network fetch.
   Weapon/impact sounds only — no vocal layer (handled by SoruGibberish).
   ============================================================ */
(function(){
  "use strict";
  if (window.__battleSFX) return; window.__battleSFX = true;

  var ctx = null, master = null, bus = null;
  function ensureCtx(){
    if (ctx) { if (ctx.state==='suspended') ctx.resume(); return ctx; }
    try {
      ctx = (typeof sfxCtx === 'function') ? sfxCtx() : new (window.AudioContext||window.webkitAudioContext)();
    } catch(e){ ctx = null; }
    if (!ctx) return null;
    // Bus gain lowered (was 0.85) — combat was overpowering ambient/UI audio.
    // Compressor backed off (-22/3.2 -> -30/2.2, slower attack) so transients
    // breathe instead of slamming into a hard ceiling, which read as "loud
    // and synthetic" rather than weighty.
    bus = ctx.createGain(); bus.gain.value = 0.46;
    var comp = null;
    try {
      comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -30; comp.knee.value = 18; comp.ratio.value = 2.2;
      comp.attack.value = 0.008; comp.release.value = 0.22;
    } catch(e){}
    bus.connect(comp || master || ((typeof sfxDest==='function')?sfxDest(ctx):ctx.destination));
    if (comp) comp.connect((typeof sfxDest==='function')?sfxDest(ctx):ctx.destination);
    return ctx;
  }

  function rand(a,b){ return a+Math.random()*(b-a); }
  function db2g(db){ return Math.pow(10, db/20); }

  /* short noise buffer, reused & sliced — avoids reallocating per-hit */
  var noiseBuf = null;
  function getNoise(c){
    if (noiseBuf && noiseBuf._ctx===c) return noiseBuf;
    var len = c.sampleRate * 0.6;
    var buf = c.createBuffer(1, len, c.sampleRate);
    var d = buf.getChannelData(0);
    for (var i=0;i<len;i++) d[i] = Math.random()*2-1;
    buf._ctx = c; noiseBuf = buf;
    return buf;
  }

  function noiseSrc(c, dest, t0, dur, filt){
    var src = c.createBufferSource();
    src.buffer = getNoise(c);
    src.loopStart = 0; src.loopEnd = 0.6; src.loop = true;
    var off = Math.random()*0.5;
    var g = c.createGain();
    var node = src;
    if (filt){
      var f = c.createBiquadFilter();
      f.type = filt.type; f.frequency.value = filt.freq; f.Q.value = filt.q||1;
      src.connect(f); f.connect(g); node = f;
    } else { src.connect(g); }
    g.connect(dest);
    src.start(t0, off);
    src.stop(t0+dur+0.02);
    return g;
  }

  function ring(c, dest, t0, freq, dur, gain, decayCurve){
    var o = c.createOscillator(), g = c.createGain();
    o.type = 'triangle';
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0+0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t0+dur*(decayCurve||1));
    o.connect(g); g.connect(dest);
    o.start(t0); o.stop(t0+dur+0.05);
    return g;
  }

  /* ---------------- Katana Clash (4-6 variations) ----------------
     Metal-on-metal: bright noise burst shaped by a sharp bandpass,
     layered with 2-3 inharmonic ring partials for "shimmer". */
  var CLASH_VARIANTS = [
    { freq: 2600, q: 7,  partials:[1, 2.41, 3.88], ringG: 0.30, noiseG: 0.50, dur: 0.16, tone:'sharp' },
    { freq: 2100, q: 5,  partials:[1, 2.0, 3.2],   ringG: 0.33, noiseG: 0.46, dur: 0.20, tone:'resonant' },
    { freq: 3100, q: 9,  partials:[1, 2.76],       ringG: 0.25, noiseG: 0.54, dur: 0.13, tone:'sharp' },
    { freq: 1750, q: 4,  partials:[1, 1.78, 2.9],  ringG: 0.35, noiseG: 0.42, dur: 0.26, tone:'resonant' },
    { freq: 2850, q: 8,  partials:[1, 2.55, 4.1],  ringG: 0.26, noiseG: 0.53, dur: 0.15, tone:'sharp' },
    { freq: 2300, q: 6,  partials:[1, 2.2, 3.5],   ringG: 0.31, noiseG: 0.48, dur: 0.19, tone:'resonant' },
    { freq: 1950, q: 3.5,partials:[1, 1.6, 2.6],   ringG: 0.34, noiseG: 0.44, dur: 0.23, tone:'low'    },
    { freq: 3350, q: 11, partials:[1, 2.9, 4.6],   ringG: 0.22, noiseG: 0.57, dur: 0.11, tone:'bright' },
    { freq: 2450, q: 6.5,partials:[1, 1.9, 3.05, 4.4], ringG: 0.28, noiseG: 0.47, dur: 0.18, tone:'complex' },
    { freq: 2750, q: 7.5,partials:[1, 2.33],       ringG: 0.27, noiseG: 0.51, dur: 0.14, tone:'sharp' },
    { freq: 1600, q: 3,  partials:[1, 1.7, 2.4, 3.3], ringG: 0.37, noiseG: 0.38, dur: 0.29, tone:'low'    },
    { freq: 3600, q: 13, partials:[1, 2.95],       ringG: 0.19, noiseG: 0.58, dur: 0.10, tone:'bright' }
  ];
  function playClash(opts){
    var c = ensureCtx(); if (!c) return;
    opts = opts || {};
    var v = CLASH_VARIANTS[(Math.random()*CLASH_VARIANTS.length)|0];
    var t0 = c.currentTime + (opts.delay||0);
    var gainScale = (opts.gain!=null?opts.gain:1);
    var jitter = rand(0.90,1.10);
    var freq = v.freq*jitter;

    var ng = noiseSrc(c, bus, t0, v.dur, {type:'bandpass', freq:freq, q:v.q});
    ng.gain.setValueAtTime(0.0001, t0);
    ng.gain.exponentialRampToValueAtTime(v.noiseG*gainScale, t0+0.003);
    ng.gain.exponentialRampToValueAtTime(0.0001, t0+v.dur);

    for (var i=0;i<v.partials.length;i++){
      ring(c, bus, t0, freq*v.partials[i]*rand(0.99,1.01), v.dur*(1.4+i*0.5),
           v.ringG*gainScale/(i*0.8+1), 1);
    }
    // tiny high-frequency "tick" transient for attack definition
    ring(c, bus, t0, freq*1.6, 0.025, 0.11*gainScale, 1);
  }

  /* ---------------- Katana Swing (3-4 variations) ----------------
     Whoosh: filtered noise with a fast frequency sweep (bandpass
     center moves), no metallic ring — just air being cut. */
  var SWING_VARIANTS = [
    { startF: 1800, endF: 600,  dur: 0.16, q: 1.4, gain: 0.30, label:'fast-light'  },
    { startF: 1200, endF: 350,  dur: 0.24, q: 1.1, gain: 0.32, label:'heavy'       },
    { startF: 2200, endF: 800,  dur: 0.12, q: 1.6, gain: 0.27, label:'fast-light'  },
    { startF: 1500, endF: 450,  dur: 0.20, q: 1.2, gain: 0.31, label:'medium'      },
    { startF: 1950, endF: 700,  dur: 0.14, q: 1.5, gain: 0.28, label:'fast-light'  },
    { startF: 1350, endF: 300,  dur: 0.27, q: 1.0, gain: 0.33, label:'heavy'       },
    { startF: 1650, endF: 500,  dur: 0.22, q: 1.3, gain: 0.29, label:'medium'      }
  ];
  function pickWeighted(variants, label){
    if(!label) return variants[(Math.random()*variants.length)|0];
    var pool = variants.filter(function(v){ return v.label===label; });
    return pool.length ? pool[(Math.random()*pool.length)|0] : variants[(Math.random()*variants.length)|0];
  }
  // swingType -> preferred sound weight: thrusts are quick and narrow, sweeps/chops carry more mass through the arc
  var SWING_TYPE_LABEL = { thrust:'fast-light', diag:'medium', chop:'heavy', sweep:'heavy' };
  function playSwing(opts){
    var c = ensureCtx(); if (!c) return;
    opts = opts || {};
    var label = SWING_TYPE_LABEL[opts.weight] || null;
    var v = pickWeighted(SWING_VARIANTS, label);
    var t0 = c.currentTime + (opts.delay||0);
    var gainScale = (opts.gain!=null?opts.gain:1);
    var speedJ = rand(0.82,1.18);
    var dur = v.dur*speedJ;

    var src = c.createBufferSource();
    src.buffer = getNoise(c);
    src.loop = true; src.loopStart=0; src.loopEnd=0.6;
    var off = Math.random()*0.5;
    var filt = c.createBiquadFilter();
    filt.type='bandpass'; filt.Q.value=v.q;
    filt.frequency.setValueAtTime(v.startF*rand(0.9,1.1), t0);
    filt.frequency.exponentialRampToValueAtTime(Math.max(80,v.endF*rand(0.9,1.1)), t0+dur);
    var g = c.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(v.gain*gainScale, t0+dur*0.18);
    g.gain.exponentialRampToValueAtTime(0.0001, t0+dur);
    src.connect(filt); filt.connect(g); g.connect(bus);
    src.start(t0, off); src.stop(t0+dur+0.02);
  }

  /* ---------------- Blade Impact (3-4 variations) ----------------
     Blade hitting something solid (armor/body) — duller thud than
     a clash: low-passed noise thump + a short low ring partial. */
  var IMPACT_VARIANTS = [
    { thumpF: 220, thumpQ: 1.2, ringF: 140, dur: 0.18, gain: 0.40, label:'soft'   },
    { thumpF: 340, thumpQ: 1.6, ringF: 210, dur: 0.14, gain: 0.43, label:'sharp'  },
    { thumpF: 180, thumpQ: 1.0, ringF: 110, dur: 0.22, gain: 0.37, label:'heavy'  },
    { thumpF: 280, thumpQ: 1.4, ringF: 170, dur: 0.16, gain: 0.41, label:'medium' },
    { thumpF: 250, thumpQ: 1.3, ringF: 155, dur: 0.20, gain: 0.39, label:'dull'   },
    { thumpF: 310, thumpQ: 1.8, ringF: 195, dur: 0.12, gain: 0.44, label:'crisp'  },
    { thumpF: 200, thumpQ: 1.1, ringF: 125, dur: 0.24, gain: 0.36, label:'thudding'},
    { thumpF: 300, thumpQ: 1.5, ringF: 185, dur: 0.15, gain: 0.42, label:'snappy' },
    { thumpF: 230, thumpQ: 1.25,ringF: 145, dur: 0.19, gain: 0.38, label:'soft'   }
  ];
  // group the granular impact flavors into the same three weight buckets used for swing selection
  var IMPACT_WEIGHT_GROUP = { 'fast-light':['sharp','crisp','snappy'], medium:['medium','soft'], heavy:['heavy','dull','thudding'] };
  function playImpact(opts){
    var c = ensureCtx(); if (!c) return;
    opts = opts || {};
    var label = SWING_TYPE_LABEL[opts.weight] || null;
    var v;
    if(label){ var group = IMPACT_WEIGHT_GROUP[label];
      var pool = IMPACT_VARIANTS.filter(function(iv){ return group.indexOf(iv.label)>=0; });
      v = pool.length ? pool[(Math.random()*pool.length)|0] : IMPACT_VARIANTS[(Math.random()*IMPACT_VARIANTS.length)|0];
    } else v = IMPACT_VARIANTS[(Math.random()*IMPACT_VARIANTS.length)|0];
    var t0 = c.currentTime + (opts.delay||0);
    var gainScale = (opts.gain!=null?opts.gain:1);
    var jitter = rand(0.93,1.07);

    var ng = noiseSrc(c, bus, t0, v.dur, {type:'lowpass', freq:v.thumpF*jitter, q:v.thumpQ});
    ng.gain.setValueAtTime(0.0001, t0);
    ng.gain.exponentialRampToValueAtTime(v.gain*gainScale, t0+0.006);
    ng.gain.exponentialRampToValueAtTime(0.0001, t0+v.dur);

    // low body-thud ring, gives weight without sounding metallic
    var o = c.createOscillator(), og = c.createGain();
    o.type='sine'; o.frequency.value = v.ringF*jitter;
    og.gain.setValueAtTime(0.0001, t0);
    og.gain.exponentialRampToValueAtTime(0.20*gainScale, t0+0.004);
    og.gain.exponentialRampToValueAtTime(0.0001, t0+v.dur*1.6);
    o.connect(og); og.connect(bus);
    o.start(t0); o.stop(t0+v.dur*1.6+0.05);

    // faint grit transient (cloth/leather/armor texture)
    var gg = noiseSrc(c, bus, t0, 0.03, {type:'highpass', freq:2400, q:0.7});
    gg.gain.setValueAtTime(0.0001,t0);
    gg.gain.exponentialRampToValueAtTime(0.07*gainScale, t0+0.002);
    gg.gain.exponentialRampToValueAtTime(0.0001, t0+0.03);
  }

  /* ---------------- Structural Collapse (3 variations) ----------------
     A building actually giving way: a creak (slow downward bandpass
     sweep on noise, like straining wood/joinery) resolving into a
     cluster of deep thuds (lowpass noise + low sine rings, an octave
     under playImpact's lowest) as the structure hits the ground.
     One-shot, fired once at the give-way instant — not a loop. */
  var COLLAPSE_VARIANTS = [
    { creakStart: 900, creakEnd: 140, creakDur: 0.42, thumpF: 95,  ringF: 58, thumps: 3, gain: 0.52 },
    { creakStart: 760, creakEnd: 110, creakDur: 0.50, thumpF: 80,  ringF: 48, thumps: 4, gain: 0.55 },
    { creakStart: 1050,creakEnd: 170, creakDur: 0.36, thumpF: 105, ringF: 64, thumps: 3, gain: 0.49 }
  ];
  function playCollapse(opts){
    var c = ensureCtx(); if (!c) return;
    opts = opts || {};
    var v = COLLAPSE_VARIANTS[(Math.random()*COLLAPSE_VARIANTS.length)|0];
    var t0 = c.currentTime + (opts.delay||0);
    var gainScale = (opts.gain!=null?opts.gain:1);
    var jitter = rand(0.92,1.08);

    // the groan: noise swept from a tense high creak down to a strained low one
    var src = c.createBufferSource();
    src.buffer = getNoise(c);
    src.loop = true; src.loopStart=0; src.loopEnd=0.6;
    var off = Math.random()*0.5;
    var filt = c.createBiquadFilter();
    filt.type='bandpass'; filt.Q.value=2.2;
    filt.frequency.setValueAtTime(v.creakStart*jitter, t0);
    filt.frequency.exponentialRampToValueAtTime(v.creakEnd*jitter, t0+v.creakDur);
    var g = c.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(0.30*gainScale, t0+v.creakDur*0.3);
    g.gain.exponentialRampToValueAtTime(0.0001, t0+v.creakDur);
    src.connect(filt); filt.connect(g); g.connect(bus);
    src.start(t0, off); src.stop(t0+v.creakDur+0.02);

    // the fall: a ragged cluster of deep thuds landing right as the creak resolves
    var baseT = t0 + v.creakDur*0.85;
    for (var i=0;i<v.thumps;i++){
      var dt2 = baseT + i*rand(0.05,0.11);
      var thumpDur = 0.22+Math.random()*0.10;
      var ng = noiseSrc(c, bus, dt2, thumpDur, {type:'lowpass', freq:v.thumpF*rand(0.9,1.1), q:1.0});
      ng.gain.setValueAtTime(0.0001, dt2);
      ng.gain.exponentialRampToValueAtTime(v.gain*gainScale*(1-i*0.12), dt2+0.008);
      ng.gain.exponentialRampToValueAtTime(0.0001, dt2+thumpDur);

      var o = c.createOscillator(), og = c.createGain();
      o.type='sine'; o.frequency.value = v.ringF*rand(0.94,1.06);
      og.gain.setValueAtTime(0.0001, dt2);
      og.gain.exponentialRampToValueAtTime(0.26*gainScale*(1-i*0.1), dt2+0.006);
      og.gain.exponentialRampToValueAtTime(0.0001, dt2+thumpDur*1.8);
      o.connect(og); og.connect(bus);
      o.start(dt2); o.stop(dt2+thumpDur*1.8+0.05);
    }
  }

  /* ---------------- Parry / Deflect (2-3 variations) ----------------
     Glancing metal contact — shorter, higher, thinner than a full
     clash; reads as a deflection rather than a clean strike. */
  var PARRY_VARIANTS = [
    { freq: 3400, q: 10, dur: 0.10, ringG: 0.15, noiseG: 0.26 },
    { freq: 2900, q: 8,  dur: 0.13, ringG: 0.17, noiseG: 0.24 },
    { freq: 3800, q: 12, dur: 0.08, ringG: 0.12, noiseG: 0.29 },
    { freq: 3150, q: 9,  dur: 0.11, ringG: 0.16, noiseG: 0.25 },
    { freq: 2650, q: 7,  dur: 0.14, ringG: 0.18, noiseG: 0.22 }
  ];
  function playParry(opts){
    var c = ensureCtx(); if (!c) return;
    opts = opts || {};
    var sorted = PARRY_VARIANTS; // ascending dur order as authored: index 0 shortest/highest, last longest/lowest
    var v;
    if(opts.weight==='thrust') v = sorted[(Math.random()*2)|0];                              // shortest, highest two
    else if(opts.weight==='sweep'||opts.weight==='chop') v = sorted[sorted.length-1-((Math.random()*2)|0)]; // longest, lowest two
    else v = sorted[(Math.random()*sorted.length)|0];
    var t0 = c.currentTime + (opts.delay||0);
    var gainScale = (opts.gain!=null?opts.gain:1);
    var freq = v.freq*rand(0.95,1.05);

    var ng = noiseSrc(c, bus, t0, v.dur, {type:'bandpass', freq:freq, q:v.q});
    ng.gain.setValueAtTime(0.0001, t0);
    ng.gain.exponentialRampToValueAtTime(v.noiseG*gainScale, t0+0.002);
    ng.gain.exponentialRampToValueAtTime(0.0001, t0+v.dur);

    ring(c, bus, t0, freq*1.5, v.dur*1.2, v.ringG*gainScale, 1);
    ring(c, bus, t0, freq*2.9, v.dur*0.7, v.ringG*0.5*gainScale, 1);
  }

  /* ---------------- polyphony / scheduling guard ----------------
     Caps simultaneous voices so a big multi-duel raid doesn't spike
     CPU or clip the bus; oldest-active accounting via a simple counter
     with timed release rather than tracking node references. */
  var MAX_VOICES = 40;
  var activeVoices = 0;
  function withVoiceBudget(durEstimate, fn){
    if (activeVoices >= MAX_VOICES) return false;
    activeVoices++;
    fn();
    setTimeout(function(){ activeVoices = Math.max(0, activeVoices-1); }, Math.max(50, durEstimate*1000));
    return true;
  }

  /* ---------------- public trigger API ----------------
     gain: optional 0-1 scale (e.g. distance/zoom attenuation).
     delay: optional seconds to offset playback (for staggering a burst). */
  function clash(opts){ withVoiceBudget(0.3, function(){ playClash(opts); }); }
  function swing(opts){ withVoiceBudget(0.3, function(){ playSwing(opts); }); }
  function impact(opts){ withVoiceBudget(0.3, function(){ playImpact(opts); }); }
  function parry(opts){ withVoiceBudget(0.2, function(){ playParry(opts); }); }
  function collapse(opts){ withVoiceBudget(0.7, function(){ playCollapse(opts); }); }

  /* Convenience: fire 2-3 clashes in a quick ragged cluster, useful for
     group-duel ambience without each call site hand-rolling timing. */
  function clashCluster(n, opts){
    n = n || (2+((Math.random()*2)|0));
    for (var i=0;i<n;i++){
      var o = Object.assign({}, opts||{});
      o.delay = (opts&&opts.delay||0) + i*rand(0.03,0.09);
      o.gain = (opts&&opts.gain!=null?opts.gain:1) * rand(0.7,1);
      clash(o);
    }
  }

  window.SoruBattleSFX = {
    clash: clash,
    swing: swing,
    impact: impact,
    parry: parry,
    collapse: collapse,
    clashCluster: clashCluster,
    setBusGain: function(v){ if (bus) bus.gain.value = Math.max(0,Math.min(1,v)); },
    _debug: { ensureCtx: ensureCtx }
  };

  function tryResume(){ if (ctx && ctx.state==='suspended') ctx.resume(); }
  window.addEventListener('pointerdown', tryResume, {passive:true});

})();


/* ==================================================================== */
/* === audio-block === */
/* ==================================================================== */
/* ============================ YOKAI & MYTHOLOGY SOUND SYSTEM ============================
   Pure synthesized Web Audio (no external assets). Reuses sfxCtx()/_sfxGain/optGet from the
   existing fire-bell SFX module — call sfxCtx() once elsewhere before this runs, or this
   module's own ykCtx() fallback will lazily create the shared context. ========================= */
(function(){
'use strict';

function ykCtx(){
  if(typeof sfxCtx==='function'){ const c=sfxCtx(); if(c) return c; }
  try{
    if(!window._ykActx) window._ykActx=new (window.AudioContext||window.webkitAudioContext)();
    if(window._ykActx.state==='suspended') window._ykActx.resume();
    return window._ykActx;
  }catch(e){ return null; }
}
function ykDest(ctx){
  if(typeof sfxDest==='function'){ try{ return sfxDest(ctx); }catch(e){} }
  return ctx.destination;
}
function ykVol(){
  const base=(typeof optGet==='function') ? optGet('opt_yokaiVol',0.32) : 0.32;
  try{
    if(typeof encounters!=='undefined'){
      for(let i=0;i<encounters.length;i++){
        const st=encounters[i].state;
        if(st==='duel'||st==='assault') return base*0.4;
      }
    }
  }catch(e){}
  return base;
}

/* ---- shared low-level synth helpers (self-contained) ---- */
function mkNoise(ctx,dur){
  const sr=ctx.sampleRate, n=Math.max(1,Math.floor(sr*dur));
  const buf=ctx.createBuffer(1,n,sr), d=buf.getChannelData(0);
  for(let i=0;i<n;i++) d[i]=Math.random()*2-1;
  const src=ctx.createBufferSource(); src.buffer=buf; return src;
}
function envGain(ctx,t0,peak,attack,hold,release){
  const g=ctx.createGain();
  g.gain.setValueAtTime(0.0001,t0);
  g.gain.exponentialRampToValueAtTime(Math.max(peak,0.0002),t0+attack);
  g.gain.setValueAtTime(Math.max(peak,0.0002),t0+attack+hold);
  g.gain.exponentialRampToValueAtTime(0.0001,t0+attack+hold+release);
  return g;
}
function mkFilter(ctx,type,freq,q){
  const f=ctx.createBiquadFilter(); f.type=type; f.frequency.value=freq; if(q!=null)f.Q.value=q; return f;
}
function glide(osc,t0,f0,f1,t1){
  osc.frequency.setValueAtTime(f0,t0);
  osc.frequency.exponentialRampToValueAtTime(Math.max(f1,1),t1);
}
function shimmerPan(ctx){ try{ const p=ctx.createStereoPanner(); p.pan.value=(Math.random()*2-1)*0.5; return p; }catch(e){ return null; } }

/* ===================== CATEGORY 1 — AMBIENT YOKAI PRESENCE ===================== */
function sfxAmbientPresence(opts){
  const ctx=ykCtx(); if(!ctx) return; const dest=ykDest(ctx); const t0=ctx.currentTime;
  const vol=ykVol()*0.25*((opts&&opts.intensity)||1);
  const dur=2.6+Math.random()*1.8;

  const src=mkNoise(ctx,dur);
  const bp=mkFilter(ctx,'bandpass', 700+Math.random()*500, 1.8);
  const g=envGain(ctx,t0,vol*0.5,0.6,dur*0.3,dur*0.6);
  const pan=shimmerPan(ctx);
  bp.frequency.setValueAtTime(bp.frequency.value,t0);
  bp.frequency.linearRampToValueAtTime(bp.frequency.value*(0.5+Math.random()*0.6),t0+dur);
  src.connect(bp).connect(g);
  (pan? g.connect(pan).connect(dest) : g.connect(dest));
  src.start(t0); src.stop(t0+dur+0.1);

  if(Math.random()<0.6){
    const o=ctx.createOscillator(); o.type='sine';
    const base=1400+Math.random()*900;
    o.frequency.setValueAtTime(base,t0+dur*0.2);
    o.frequency.exponentialRampToValueAtTime(base*0.7,t0+dur*0.9);
    const og=envGain(ctx,t0+dur*0.15,vol*0.25,0.4,dur*0.2,dur*0.5);
    o.connect(og).connect(dest); o.start(t0+dur*0.15); o.stop(t0+dur+0.1);
  }
}

/* ===================== CATEGORY 2 — AGGRESSIVE / HOSTILE YOKAI ===================== */
function sfxHostile(opts){
  const ctx=ykCtx(); if(!ctx) return; const dest=ykDest(ctx); const t0=ctx.currentTime;
  const vol=ykVol()*0.5*((opts&&opts.intensity)||1);
  const big=(opts&&opts.big)||false;

  const src=mkNoise(ctx,big?3.2:1.6);
  const lp=mkFilter(ctx,'lowpass', big?220:340, 4.5);
  const g=envGain(ctx,t0,vol*0.8,0.05,big?1.6:0.7,big?1.4:0.6);
  src.connect(lp).connect(g).connect(dest);
  src.start(t0); src.stop(t0+(big?3.3:1.7));

  const freqs=big?[58,61.6,87,98]:[110,116.5,165];
  freqs.forEach((f,i)=>{
    const o=ctx.createOscillator(); o.type='sawtooth'; o.frequency.value=f; o.detune.value=(Math.random()*14-7);
    const og=envGain(ctx,t0+i*0.03,vol*(big?0.45:0.32)/(i*0.6+1),0.08,big?1.2:0.5,big?1.0:0.5);
    const lp2=mkFilter(ctx,'lowpass',big?500:700,1);
    o.connect(lp2).connect(og).connect(dest); o.start(t0+i*0.03); o.stop(t0+(big?2.5:1.3));
  });

  if(big){
    for(let k=0;k<5;k++){
      const dt0=t0+0.4+Math.random()*1.8;
      const o=ctx.createOscillator(); o.type='square'; o.frequency.value=900+Math.random()*700;
      const og=envGain(ctx,dt0,vol*0.18,0.002,0.01,0.06+Math.random()*0.05);
      const hp=mkFilter(ctx,'highpass',600,1);
      o.connect(hp).connect(og).connect(dest); o.start(dt0); o.stop(dt0+0.15);
    }
  }
}

/* ===================== CATEGORY 3 — MYSTERIOUS / ETHEREAL YOKAI ===================== */
function sfxEthereal(opts){
  const ctx=ykCtx(); if(!ctx) return; const dest=ykDest(ctx); const t0=ctx.currentTime;
  const vol=ykVol()*0.35*((opts&&opts.intensity)||1);
  const variant=(opts&&opts.variant)||(['chime','whisper','cry'][(Math.random()*3)|0]);

  if(variant==='chime'){
    const root=440*Math.pow(2,((Math.random()*7)|0)/12);
    const partials=[1,2.0,2.76,4.0];
    partials.forEach((p,i)=>{
      const o=ctx.createOscillator(); o.type='sine'; o.frequency.value=root*p;
      const dur=1.6+Math.random()*0.8;
      const og=envGain(ctx,t0+i*0.04,vol*0.5/(i*0.8+1),0.01,dur*0.15,dur*0.85);
      const pan=shimmerPan(ctx);
      (pan? og.connect(pan).connect(dest) : og.connect(dest));
      o.connect(og); o.start(t0+i*0.04); o.stop(t0+dur+0.1);
    });
  } else if(variant==='whisper'){
    const dur=1.8+Math.random()*1.0;
    const src=mkNoise(ctx,dur);
    const bp=mkFilter(ctx,'bandpass',1800+Math.random()*1200,2.4);
    const g=envGain(ctx,t0,vol*0.35,0.25,dur*0.3,dur*0.5);
    const pan=shimmerPan(ctx);
    src.connect(bp).connect(g);
    (pan? g.connect(pan).connect(dest): g.connect(dest));
    src.start(t0); src.stop(t0+dur+0.1);
  } else {
    const o=ctx.createOscillator(); o.type='sine';
    const f0=900+Math.random()*300;
    const dur=2.0+Math.random()*0.8;
    glide(o,t0,f0,f0*0.45,t0+dur);
    const og=envGain(ctx,t0,vol*0.4,0.3,dur*0.3,dur*0.5);
    const lp=mkFilter(ctx,'lowpass',2200,0.7);
    o.connect(lp).connect(og).connect(dest); o.start(t0); o.stop(t0+dur+0.1);
  }
}

/* ===================== CATEGORY 4 — YOKAI APPEARANCE / MANIFESTATION ===================== */
const MANIFEST_PROFILE={
  ryu:        {type:'cry',    intensity:0.9},
  tennyo:     {type:'chime',  intensity:0.7},
  oni:        {type:'hostile',intensity:0.8},
  tengu:      {type:'whisper',intensity:0.7},
  kitsune:    {type:'chime',  intensity:0.55},
  hitodama:   {type:'whisper',intensity:0.45},
  kappa:      {type:'whisper',intensity:0.5},
  tanuki:     {type:'ambient',intensity:0.5},
  yukionna:   {type:'cry',    intensity:0.6},
  kasaobake:  {type:'chime',  intensity:0.4},
  bakeneko:   {type:'whisper',intensity:0.55},
  nurarihyon: {type:'ambient',intensity:0.5}
};
function sfxManifestScaled(kind,mult){
  const p=MANIFEST_PROFILE[kind]||{type:'ambient',intensity:0.5};
  const intensity=p.intensity*(mult||1);
  if(p.type==='hostile') sfxHostile({intensity,big:!!p.big});
  else if(p.type==='ambient') sfxAmbientPresence({intensity});
  else sfxEthereal({variant:p.type==='cry'?'cry':(p.type==='chime'?'chime':'whisper'),intensity});
}

/* ===================== CATEGORY 5 — YOKAI INTERACTION ===================== */
function sfxInteraction(opts){
  const ctx=ykCtx(); if(!ctx) return; const dest=ykDest(ctx); const t0=ctx.currentTime;
  const vol=ykVol()*0.45*((opts&&opts.intensity)||1);
  const benevolent=(opts&&opts.benevolent!==false);

  if(benevolent){
    const root=660*Math.pow(2,((Math.random()*4)|0)/12);
    [1,1.5,2].forEach((p,i)=>{
      const o=ctx.createOscillator(); o.type='triangle'; o.frequency.value=root*p;
      const og=envGain(ctx,t0+i*0.02,vol*0.4/(i+1),0.005,0.05,0.25);
      o.connect(og).connect(dest); o.start(t0+i*0.02); o.stop(t0+0.4);
    });
  } else {
    const src=mkNoise(ctx,0.35);
    const bp=mkFilter(ctx,'bandpass',500,3);
    const g=envGain(ctx,t0,vol*0.5,0.01,0.05,0.25);
    src.connect(bp).connect(g).connect(dest); src.start(t0); src.stop(t0+0.4);
    const o=ctx.createOscillator(); o.type='sawtooth';
    glide(o,t0,260,90,t0+0.3);
    const og=envGain(ctx,t0,vol*0.3,0.01,0.04,0.22);
    o.connect(og).connect(dest); o.start(t0); o.stop(t0+0.35);
  }
}

/* ===================== REACTIVE LAYER ===================== */
const YK_STATE={ lastInteractionByKind:{} };
function ykNow(){ return (typeof performance!=='undefined') ? performance.now() : Date.now(); }

function ykEraScale(){
  try{
    const era=(typeof S!=='undefined'&&S.era!=null)?S.era:4;
    if(era===7) return {hostile:1.25, ethereal:0.85, ambient:0.9};
    if(era===8) return {hostile:0.9,  ethereal:1.2,  ambient:1.0};
    return {hostile:1.0, ethereal:1.0, ambient:1.0};
  }catch(e){ return {hostile:1,ethereal:1,ambient:1}; }
}

if(typeof window!=='undefined'){
  const _origAnnounce=(typeof announce==='function')?announce:null;
  window.announce=function(k){
    if(_origAnnounce) _origAnnounce(k);
    try{
      const scale=ykEraScale();
      const p=MANIFEST_PROFILE[k];
      const mult=p&&p.type==='hostile'?scale.hostile:(p&&p.type==='ambient'?scale.ambient:scale.ethereal);
      sfxManifestScaled(k, mult);
    }catch(e){}
  };
}

function ykOnInteraction(kind,benevolent){
  const now=ykNow(); const last=YK_STATE.lastInteractionByKind[kind]||0;
  if(now-last<900) return;
  YK_STATE.lastInteractionByKind[kind]=now;
  const scale=ykEraScale();
  const malKinds={oni:1};
  sfxInteraction({intensity:(malKinds[kind]?scale.hostile:scale.ethereal)*0.9, benevolent: benevolent!==false && !malKinds[kind]});
}

window.YokaiSFX={
  ambient: sfxAmbientPresence,
  hostile: sfxHostile,
  ethereal: sfxEthereal,
  manifest: sfxManifestScaled,
  interaction: ykOnInteraction,
  setVolume: function(v){ if(typeof optSet==='function') optSet('opt_yokaiVol', Math.max(0,Math.min(1,v))); }
};

})();


/* ==================================================================== */
/* === ykAmbientZoom === */
/* ==================================================================== */
/* ============================================================
   SORU SHITI — Zoomed-Out Ambient Soundscape
   Synthesized Web Audio API. No external assets.
   Audible only near full zoom-out; fades to silence as the
   player zooms in. Reads cam.zoom only — writes nothing back.
   ============================================================ */
(function(){
  "use strict";
  if (window.__ambientZoom) return; window.__ambientZoom = true;

  /* ---- zoom gate ----
     ZMIN=0.4 / ZMAX=2.6 in this project. Full presence at/near ZMIN,
     gone by AZ_HIGH. Smoothstep so it breathes rather than snaps. */
  var AZ_LOW  = 0.4;
  var AZ_HIGH = 0.85;
  function zoomAudibility(){
    var z = (typeof cam !== 'undefined' && cam.zoom) ? cam.zoom : 1;
    if (z <= AZ_LOW) return 1;
    if (z >= AZ_HIGH) return 0;
    var t = (z - AZ_LOW) / (AZ_HIGH - AZ_LOW);
    t = t*t*(3-2*t);
    return 1 - t;
  }

  var ctx = null, master = null, windBus = null, birdBus = null, textureBus = null;
  function ensureCtx(){
    if (ctx) { if (ctx.state==='suspended') ctx.resume(); return ctx; }
    try {
      ctx = (typeof sfxCtx === 'function') ? sfxCtx() : new (window.AudioContext||window.webkitAudioContext)();
    } catch(e){ ctx = null; }
    if (!ctx) return null;
    master = ctx.createGain(); master.gain.value = 0;
    windBus = ctx.createGain(); windBus.gain.value = 0.16;
    birdBus = ctx.createGain(); birdBus.gain.value = 0.22;
    textureBus = ctx.createGain(); textureBus.gain.value = 0.1;
    windBus.connect(master); birdBus.connect(master); textureBus.connect(master);
    master.connect((typeof sfxDest==='function') ? sfxDest(ctx) : ctx.destination);
    return ctx;
  }

  function mkNoiseBuffer(c, dur){
    var sr = c.sampleRate, n = Math.max(1, Math.floor(sr*dur));
    var buf = c.createBuffer(1, n, sr), d = buf.getChannelData(0);
    for (var i=0;i<n;i++) d[i] = Math.random()*2-1;
    return buf;
  }

  /* ---- WIND: looping filtered noise bed with slow LFO wander on both
     filter cutoff and gain, so it never sits perfectly static. ---- */
  var wind = null;
  function startWind(c){
    if (wind) return;
    var src = c.createBufferSource();
    src.buffer = mkNoiseBuffer(c, 6);
    src.loop = true;

    var bp = c.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = 320; bp.Q.value = 0.5;

    var g = c.createGain(); g.gain.value = 0.0001;

    var lfo = c.createOscillator(); lfo.frequency.value = 0.05;
    var lfoGain = c.createGain(); lfoGain.gain.value = 60;
    lfo.connect(lfoGain); lfoGain.connect(bp.frequency);

    var lfo2 = c.createOscillator(); lfo2.frequency.value = 0.035;
    var lfo2Gain = c.createGain(); lfo2Gain.gain.value = 0.3;
    var lfo2Off = c.createConstantSource(); lfo2Off.offset.value = 1;
    var gMul = c.createGain(); gMul.gain.value = 1;
    lfo2.connect(lfo2Gain); lfo2Gain.connect(gMul.gain);
    lfo2Off.connect(gMul.gain);

    src.connect(bp).connect(g).connect(windBus);
    var t0 = c.currentTime;
    lfo.start(t0); lfo2.start(t0); lfo2Off.start(t0);
    src.start(t0);
    g.gain.setTargetAtTime(0.55, t0, 2.5);

    wind = { src: src, gain: g, lfo: lfo, lfo2: lfo2, lfo2Off: lfo2Off };
  }
  function stopWind(){
    if (!wind) return;
    try {
      var t = ctx.currentTime;
      wind.gain.gain.setTargetAtTime(0.0001, t, 0.4);
      wind.src.stop(t+1.2); wind.lfo.stop(t+1.2); wind.lfo2.stop(t+1.2); wind.lfo2Off.stop(t+1.2);
    } catch(e){}
    wind = null;
  }

  /* ---- BIRDS: sparse, randomly scheduled chirps. Each chirp is a short
     pitch-glide tone burst, panned, with long randomized silence between. ---- */
  var birdTimer = 0, birdNextAt = 8 + Math.random()*14;
  function fireBird(c){
    var t0 = c.currentTime;
    var n = (Math.random()<0.75) ? 1 : 2;
    for (var i=0;i<n;i++){
      var dt0 = t0 + i*(0.1+Math.random()*0.08);
      var osc = c.createOscillator(); osc.type = 'sine';
      var f0 = 2200 + Math.random()*1600;
      var f1 = f0 * (0.6+Math.random()*0.45);
      osc.frequency.setValueAtTime(f0, dt0);
      osc.frequency.exponentialRampToValueAtTime(Math.max(f1,200), dt0+0.09+Math.random()*0.06);

      var g = c.createGain();
      g.gain.setValueAtTime(0.0001, dt0);
      g.gain.exponentialRampToValueAtTime(0.11, dt0+0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, dt0+0.14+Math.random()*0.08);

      var hp = c.createBiquadFilter(); hp.type='highpass'; hp.frequency.value=1200;

      try {
        var pan = c.createStereoPanner(); pan.pan.value = (Math.random()*2-1);
        osc.connect(hp).connect(g).connect(pan).connect(birdBus);
      } catch(e){
        osc.connect(hp).connect(g).connect(birdBus);
      }
      osc.start(dt0); osc.stop(dt0+0.3);
    }
  }
  function updateBirds(dt, audibility){
    if (audibility <= 0.01) { birdTimer = 0; return; }
    birdTimer += dt;
    if (birdTimer >= birdNextAt){
      birdTimer = 0;
      birdNextAt = 10 + Math.random()*20;
      if (Math.random() < 0.7) fireBird(ctx);
    }
  }

  /* ---- DISTANT NATURE TEXTURE: very low, slow-shifting filtered noise,
     separate band from wind so it reads as ground/foliage rustle rather
     than air movement. Mostly static with slow gentle swells. ---- */
  var texture = null;
  function startTexture(c){
    if (texture) return;
    var src = c.createBufferSource();
    src.buffer = mkNoiseBuffer(c, 8);
    src.loop = true;

    var bp = c.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = 1100; bp.Q.value = 0.9;

    var g = c.createGain(); g.gain.value = 0.0001;

    var lfo = c.createOscillator(); lfo.frequency.value = 0.025;
    var lfoGain = c.createGain(); lfoGain.gain.value = 0.5;
    var lfoOff = c.createConstantSource(); lfoOff.offset.value = 0.55;
    var gMul = c.createGain(); gMul.gain.value = 1;
    lfo.connect(lfoGain); lfoGain.connect(gMul.gain);
    lfoOff.connect(gMul.gain);

    src.connect(bp).connect(g).connect(textureBus);
    var t0 = c.currentTime;
    lfo.start(t0); lfoOff.start(t0);
    src.start(t0);
    g.gain.setTargetAtTime(0.5, t0, 3);

    texture = { src: src, gain: g, lfo: lfo, lfoOff: lfoOff };
  }
  function stopTexture(){
    if (!texture) return;
    try {
      var t = ctx.currentTime;
      texture.gain.gain.setTargetAtTime(0.0001, t, 0.4);
      texture.src.stop(t+1.2); texture.lfo.stop(t+1.2); texture.lfoOff.stop(t+1.2);
    } catch(e){}
    texture = null;
  }

  /* ---- master fade + lazy start/stop so nothing runs (no oscillators,
     no scheduling) while fully zoomed in. ---- */
  var active = false;
  var BASE_VOL = 0.22;
  function update(dt){
    var aud = zoomAudibility();
    if (aud > 0.001 && !active){
      var c = ensureCtx();
      if (c){ startWind(c); startTexture(c); active = true; }
    }
    if (active && ctx){
      var target = aud * BASE_VOL;
      master.gain.setTargetAtTime(Math.max(target,0.0001), ctx.currentTime, 0.6);
      updateBirds(dt, aud);
      if (aud <= 0.001){
        stopWind(); stopTexture(); active = false;
      }
    }
  }

  function tryResume(){ if (ctx && ctx.state==='suspended') ctx.resume(); }
  window.addEventListener('pointerdown', tryResume, {passive:true});

  window.SoruAmbientZoom = {
    update: update,
    setBaseVolume: function(v){ BASE_VOL = Math.max(0,Math.min(1,v)); },
    _debug: { zoomAudibility: zoomAudibility, ensureCtx: ensureCtx }
  };

})();

